/**
 * حماية النماذج والمدخلات من هجمات الحقن
 * يوفر مجموعة من المرشحات الأمنية لتنظيف المدخلات المستخدم
 */

const SecurityFilters = {
  /**
   * تنظيف المدخلات من الأكواد الضارة
   * @param {string} input - المدخل الذي يجب تنظيفه
   * @returns {string} المدخل المنظف
   */
  cleanInput(input) {
    if (typeof input !== 'string') return input;
    
    const originalInput = input;
    
    // إزالة وسوم السكريبت
    let cleaned = input
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
      // إزالة معالجات الأحداث
      .replace(/on\w+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/gi, '')
      // إزالة الرموز الخطيرة
      .replace(/javascript:/gi, '')
      // تنظيف حقن SQL محتمل
      .replace(/['";\\]/g, function(match) {
        return '&#' + match.charCodeAt(0) + ';';
      });
    
    // تحقق ما إذا كان قد تم تعديل المدخل، مما يشير إلى محاولة محتملة للهجوم
    if (cleaned !== originalInput) {
      // تتبع المحاولة إذا كان هناك تغيير
      if (typeof trackMaliciousAttempt === 'function') {
        trackMaliciousAttempt('XSS_ATTEMPT', {
          original: originalInput.substring(0, 100) + (originalInput.length > 100 ? '...' : ''),
          cleaned: cleaned.substring(0, 100) + (cleaned.length > 100 ? '...' : '')
        });
      }
    }
    
    return cleaned;
  },
  
  /**
   * التحقق من حجم البيانات المرسلة
   * @param {Object} data - البيانات المراد فحصها
   * @returns {boolean} صحيح إذا كان الحجم مقبولاً
   */
  checkPayloadSize(data) {
    const jsonData = JSON.stringify(data);
    
    // حد أقصى للحجم (10 كيلوبايت)
    const MAX_SIZE = 10000;
    
    if (jsonData.length > MAX_SIZE) {
      console.warn('حجم البيانات تجاوز الحد المسموح:', jsonData.length);
      
      if (typeof trackMaliciousAttempt === 'function') {
        trackMaliciousAttempt('OVERSIZED_PAYLOAD', {
          size: jsonData.length,
          max: MAX_SIZE
        });
      }
      
      // إبطاء الطلبات المشبوهة
      this.throttleRequest();
      return false;
    }
    
    return true;
  },
  
  /**
   * التحقق من معدل الطلبات لمنع هجمات القوة الغاشمة
   * @returns {boolean} صحيح إذا كان معدل الطلبات مقبولاً
   */
  checkRequestRate() {
    const now = Date.now();
    const THROTTLE_KEY = 'smm_request_timestamps';
    const MAX_REQUESTS = 10;  // الحد الأقصى للطلبات
    const TIME_WINDOW = 10000;  // فترة زمنية (10 ثوانٍ)
    
    // استرجاع سجل الطلبات السابقة
    let requestTimestamps = [];
    try {
      const storedTimestamps = localStorage.getItem(THROTTLE_KEY);
      if (storedTimestamps) {
        requestTimestamps = JSON.parse(storedTimestamps);
      }
    } catch (e) {
      console.error('خطأ في استرجاع سجل الطلبات:', e);
      requestTimestamps = [];
    }
    
    // إزالة الطلبات القديمة خارج النافذة الزمنية
    requestTimestamps = requestTimestamps.filter(timestamp => (now - timestamp) < TIME_WINDOW);
    
    // إضافة الطلب الحالي
    requestTimestamps.push(now);
    
    // حفظ سجل الطلبات المحدث
    try {
      localStorage.setItem(THROTTLE_KEY, JSON.stringify(requestTimestamps));
    } catch (e) {
      console.error('خطأ في حفظ سجل الطلبات:', e);
    }
    
    // التحقق من عدد الطلبات في النافذة الزمنية
    if (requestTimestamps.length > MAX_REQUESTS) {
      console.warn('تم تجاوز الحد الأقصى لمعدل الطلبات');
      
      if (typeof trackMaliciousAttempt === 'function') {
        trackMaliciousAttempt('RATE_LIMIT_EXCEEDED', {
          requests: requestTimestamps.length,
          window: TIME_WINDOW
        });
      }
      
      this.throttleRequest();
      return false;
    }
    
    return true;
  },
  
  /**
   * إبطاء الطلبات المشبوهة
   */
  throttleRequest() {
    console.warn('تم إبطاء الطلب بسبب نشاط مشبوه');
    
    // تأخير الاستجابة
    const startTime = Date.now();
    const delay = 3000 + Math.random() * 2000;  // 3-5 ثوانٍ
    
    while (Date.now() - startTime < delay) {
      // انتظار
    }
  },
  
  /**
   * التحقق من التوقيع الرقمي للنموذج
   * @param {HTMLFormElement} form - النموذج المراد التحقق منه
   * @returns {boolean} صحيح إذا كان التوقيع صحيحاً
   */
  validateFormSignature(form) {
    if (!form || !form.elements) return false;
    
    const securityToken = form.elements['security_token'];
    const formSignature = form.elements['form_signature'];
    
    if (!securityToken || !formSignature) {
      console.warn('النموذج لا يحتوي على توقيع أمان');
      return false;
    }
    
    // في الإنتاج، يتم التحقق من التوقيع على الخادم
    // هذا مجرد فحص أساسي على جانب العميل
    return true;
  },
  
  // نظام حماية حقول النماذج المحدث
  advancedCleanInput(input) {
    const cleaned = input
      .replace(/<script.*?>.*?<\/script>/gi, '')
      .replace(/on\w+="[^"]*"/gi, '')
      .replace(/['";\\]/g, '');
    
    if (cleaned !== input) {
      trackMaliciousAttempt('XSS_ATTEMPT', input);
    }
    
    return cleaned;
  },
  
  advancedCheckPayloadSize(data) {
    const jsonData = JSON.stringify(data);
    if (jsonData.length > 10000) {
      this.throttleRequest();
      return false;
    }
    return true;
  }
};

// تطبيق الحماية على جميع حقول الإدخال
document.addEventListener('DOMContentLoaded', () => {
  // تنظيف المدخلات تلقائياً
  document.querySelectorAll('input:not([type="password"]), textarea').forEach(field => {
    field.addEventListener('change', () => {
      field.value = SecurityFilters.cleanInput(field.value);
    });
  });
  
  // تطبيق حماية متقدمة على حقول النماذج
  document.querySelectorAll('input, textarea').forEach(field => {
    field.addEventListener('change', () => {
      field.value = SecurityFilters.advancedCleanInput(field.value);
    });
  });
  
  // التحقق من النماذج قبل الإرسال
  document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', (event) => {
      // التحقق من معدل الطلبات
      if (!SecurityFilters.checkRequestRate()) {
        event.preventDefault();
        alert('يرجى الانتظار قبل إرسال النموذج مرة أخرى.');
        return false;
      }
      
      // تنظيف جميع المدخلات
      form.querySelectorAll('input:not([type="password"]), textarea').forEach(field => {
        field.value = SecurityFilters.cleanInput(field.value);
      });
    });
  });
  
  // إضافة مستمعي الأحداث للطلبات AJAX
  if (typeof XMLHttpRequest !== 'undefined') {
    const originalOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function() {
      // التحقق من معدل الطلبات
      SecurityFilters.checkRequestRate();
      return originalOpen.apply(this, arguments);
    };
  }
  
  // حماية الطلبات باستخدام fetch API
  if (typeof fetch !== 'undefined') {
    const originalFetch = window.fetch;
    window.fetch = function(resource, init) {
      // التحقق من معدل الطلبات
      SecurityFilters.checkRequestRate();
      
      // إضافة رأس أمان للطلب
      if (init && init.headers) {
        init.headers = {
          ...init.headers,
          'X-Security-Token': 'smm-secure-' + Date.now()
        };
      }
      
      return originalFetch.call(this, resource, init);
    };
  }
});

// تسجيل محاولات الهجوم
function trackMaliciousAttempt(type, payload) {
  console.warn(`[SECURITY] Attempted ${type}:`, payload);
  
  fetch('/api/log-security-event', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
    },
    body: JSON.stringify({
      event_type: type,
      payload: payload,
      page_url: window.location.href
    })
  });
}
