/**
 * نظام مراقبة الأمان لـ SMM Panel
 * يوفر وظائف مراقبة لحظية للتهديدات وإنذارات الأمان
 */

// تكوين أنواع التهديدات والإنذارات
const ThreatAlerts = {
  SUSPICIOUS_LOGIN: {
    icon: '🔐',
    title: 'تسجيل دخول مشبوه',
    msg: 'تم رصد محاولة دخول من جهاز جديد',
    action: 'فحص',
  },
  DATA_BREACH_DETECTED: {
    icon: '⚠️',
    title: 'انتهاك لمحاولة كشف بيانتك',
    msg: 'فشل هجوم قرصنة تهديدات الجيثب',
    action: 'العرض',
  },
  UNUSUAL_ACTIVITY: {
    icon: '🕵️',
    title: 'نشاط غير معتاد',
    msg: 'تم اكتشاف نشاط غير معتاد في حسابك',
    action: 'مراجعة',
  },
  PASSWORD_RESET: {
    icon: '🔑',
    title: 'تغيير كلمة المرور',
    msg: 'تم تغيير كلمة المرور بنجاح',
    action: 'تأكيد',
  }
};

// عداد التهديدات
let blockedThreats = 0;

/**
 * إظهار إنذار أمني بناءً على نوع التهديد
 * @param {string} type - نوع التهديد
 */
function showArabicAlert(type) {
  const alert = ThreatAlerts[type];
  if (!alert) return;
  
  const alertDiv = document.createElement('div');
  
  alertDiv.className = 'alert-arabic animated-fadeIn';
  alertDiv.innerHTML = `
    <div class="alert-icon">${alert.icon}</div>
    <div class="alert-content">
      <h4>${alert.title}</h4>
      <p>${alert.msg}</p>
    </div>
    <button class="btn-alert" onclick="handleAlert('${type}')">
      ${alert.action}
    </button>
  `;
  
  const alertsContainer = document.getElementById('alertsContainer');
  if (alertsContainer) {
    alertsContainer.prepend(alertDiv);
  }
  
  // إزالة الإنذار بعد 10 ثواني
  setTimeout(() => {
    alertDiv.classList.add('animated-fadeOut');
    setTimeout(() => alertDiv.remove(), 1000);
  }, 10000);
}

/**
 * معالجة الإنذارات عند النقر عليها
 * @param {string} type - نوع التهديد
 */
function handleAlert(type) {
  console.log(`معالجة الإنذار: ${type}`);
  
  switch(type) {
    case 'SUSPICIOUS_LOGIN':
      window.location.href = '/security/active-sessions';
      break;
    case 'DATA_BREACH_DETECTED':
      window.location.href = '/security/threat-details';
      break;
    case 'UNUSUAL_ACTIVITY':
      window.location.href = '/security/activity-log';
      break;
    case 'PASSWORD_RESET':
      const alertElement = event.target.closest('.alert-arabic');
      if (alertElement) {
        alertElement.classList.add('animated-fadeOut');
        setTimeout(() => alertElement.remove(), 1000);
      }
      break;
    default:
      console.log('نوع إنذار غير معروف');
  }
}

/**
 * تتبع محاولة ضارة وتحديث عداد التهديدات
 * @param {string} threatType - نوع التهديد
 * @param {*} payload - البيانات المرتبطة بالتهديد
 */
function trackMaliciousAttempt(threatType, payload = null) {
  // زيادة العداد
  blockedThreats++;
  
  // تحديث شريط الحالة
  const counterElement = document.querySelector('.threat-counter .counter');
  if (counterElement) {
    counterElement.textContent = blockedThreats;
    
    // تأثير بصري للإشارة إلى تحديث العداد
    counterElement.style.color = '#ffcc00';
    setTimeout(() => {
      counterElement.style.color = '';
    }, 500);
  }
  
  // تسجيل محاولة الهجوم
  console.warn(`تم اكتشاف تهديد: ${threatType}`, payload);
  
  // إرسال التهديد إلى الخادم لتسجيله (اختياري)
  if (typeof fetch !== 'undefined') {
    fetch('/api/security/log-threat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        type: threatType,
        timestamp: new Date().toISOString(),
        payload
      }),
    }).catch(err => console.error('فشل تسجيل التهديد:', err));
  }
}

/**
 * تحديث حالة الأمان في شريط الحالة
 */
function updateSecurityStatus() {
  const encryptionStatus = document.getElementById('encryptionStatus');
  const firewallStatus = document.getElementById('firewallStatus');
  const sessionStatus = document.getElementById('sessionStatus');
  
  if (window.location.protocol === 'https:') {
    if (encryptionStatus) encryptionStatus.innerHTML = '🔒 اتصال مشفر بتقنية AES-256';
  } else {
    if (encryptionStatus) encryptionStatus.innerHTML = '⚠️ اتصال غير مشفر!';
  }
  
  // تحديث حالة جدار الحماية والجلسة مرة كل دقيقة
  setInterval(() => {
    // محاكاة فحص حالة جدار الحماية
    const firewallActive = Math.random() > 0.1;
    if (firewallStatus) {
      firewallStatus.innerHTML = firewallActive 
        ? '🛡️ جدار الحماية: نشط (مستوى عالي)' 
        : '⚠️ جدار الحماية: يتم الفحص...';
    }
    
    // التحقق من حالة الجلسة
    if (sessionStatus) {
      const sessionValid = document.cookie.includes('SMM_SESSION');
      sessionStatus.innerHTML = sessionValid 
        ? '👁️ الجلسة: مخزنة بتشفير نقطة-نقطة' 
        : '⚠️ الجلسة: منتهية الصلاحية';
    }
  }, 60000);
}

// محاكاة تهديدات عشوائية للعرض التوضيحي (يتم إزالتها في الإنتاج)
function simulateRandomThreats() {
  const threatTypes = Object.keys(ThreatAlerts);
  
  // إظهار تهديد عشوائي كل 30-90 ثانية
  setInterval(() => {
    const randomIndex = Math.floor(Math.random() * threatTypes.length);
    const randomType = threatTypes[randomIndex];
    
    // 30% فرصة لإظهار تهديد
    if (Math.random() < 0.3) {
      trackMaliciousAttempt(randomType);
      showArabicAlert(randomType);
    }
  }, 30000 + Math.random() * 60000);
}

// تهيئة نظام المراقبة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
  // إنشاء حاوية الإنذارات إذا لم تكن موجودة
  if (!document.getElementById('alertsContainer')) {
    const alertsDiv = document.createElement('div');
    alertsDiv.id = 'alertsContainer';
    alertsDiv.style.position = 'fixed';
    alertsDiv.style.top = '20px';
    alertsDiv.style.left = '20px';
    alertsDiv.style.zIndex = '9999';
    alertsDiv.style.maxWidth = '350px';
    document.body.appendChild(alertsDiv);
  }
  
  // تحديث حالة الأمان
  updateSecurityStatus();
  
  // في بيئة التطوير فقط: محاكاة تهديدات
  if (location.hostname === 'localhost' || location.hostname === '127.0.0.1') {
    simulateRandomThreats();
  }
});
