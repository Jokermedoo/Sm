/**
 * Town Media - SMM Panel
 * الملف الرئيسي لـ JavaScript
 * محسن لتجربة المستخدم وسهولة الاستخدام
 */

document.addEventListener('DOMContentLoaded', function() {
    // تفعيل الشروحات التوضيحية للخدمات
    initServiceTooltips();
    
    // تبسيط واجهة الطلبات للمستخدمين العاديين
    initSimplifiedOrderInterface();
    
    // إضافة المساعد التفاعلي
    initInteractiveHelper();
    // التنقل المتجاوب
    const navbarToggle = document.querySelector('.navbar-toggle');
    const navbarMenu = document.querySelector('.navbar-menu');
    
    if (navbarToggle) {
        navbarToggle.addEventListener('click', function() {
            navbarMenu.classList.toggle('active');
        });
    }
    
    // تحقق النموذج
    const forms = document.querySelectorAll('.needs-validation');
    
    if (forms.length > 0) {
        Array.from(forms).forEach(function(form) {
            form.addEventListener('submit', function(event) {
                if (!form.checkValidity()) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                form.classList.add('was-validated');
            }, false);
        });
    }
    
    // تنسيق الأرقام
    const formatNumbers = document.querySelectorAll('.format-number');
    
    if (formatNumbers.length > 0) {
        formatNumbers.forEach(function(element) {
            const value = parseFloat(element.textContent);
            if (!isNaN(value)) {
                element.textContent = value.toLocaleString('ar-SA');
            }
        });
    }
    
    // حقول الكمية مع أزرار الزيادة والنقصان
    const quantityInputs = document.querySelectorAll('.quantity-input');
    
    if (quantityInputs.length > 0) {
        quantityInputs.forEach(function(input) {
            const decreaseBtn = input.parentElement.querySelector('.quantity-decrease');
            const increaseBtn = input.parentElement.querySelector('.quantity-increase');
            
            if (decreaseBtn) {
                decreaseBtn.addEventListener('click', function() {
                    let value = parseInt(input.value);
                    const min = parseInt(input.getAttribute('min') || 0);
                    value = isNaN(value) ? min : value;
                    value = Math.max(min, value - 1);
                    input.value = value;
                    input.dispatchEvent(new Event('change'));
                });
            }
            
            if (increaseBtn) {
                increaseBtn.addEventListener('click', function() {
                    let value = parseInt(input.value);
                    const max = parseInt(input.getAttribute('max') || Infinity);
                    value = isNaN(value) ? 0 : value;
                    value = Math.min(max, value + 1);
                    input.value = value;
                    input.dispatchEvent(new Event('change'));
                });
            }
        });
    }
    
    // حساب السعر في نموذج الطلب الجديد
    const orderForm = document.getElementById('new-order-form');
    
    if (orderForm) {
        const serviceSelect = document.getElementById('service_id');
        const quantityInput = document.getElementById('quantity');
        const priceOutput = document.getElementById('price');
        const serviceDetails = document.getElementById('service-details');
        
        if (serviceSelect && quantityInput && priceOutput) {
            const updatePrice = function() {
                const serviceId = serviceSelect.value;
                const quantity = parseInt(quantityInput.value);
                
                if (!serviceId || isNaN(quantity)) {
                    priceOutput.textContent = '0.00';
                    return;
                }
                
                // إرسال طلب AJAX للحصول على السعر
                fetch(`/api/calculate-price?service_id=${serviceId}&quantity=${quantity}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            priceOutput.textContent = data.price.toFixed(2);
                        }
                    })
                    .catch(error => {
                        console.error('Error calculating price:', error);
                    });
            };
            
            serviceSelect.addEventListener('change', function() {
                const serviceId = this.value;
                
                if (!serviceId) {
                    serviceDetails.innerHTML = '';
                    return;
                }
                
                // إرسال طلب AJAX للحصول على تفاصيل الخدمة
                fetch(`/api/service-details?service_id=${serviceId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            serviceDetails.innerHTML = `
                                <div class="service-details-box">
                                    <p><strong>الحد الأدنى:</strong> ${data.service.min}</p>
                                    <p><strong>الحد الأقصى:</strong> ${data.service.max}</p>
                                    <p><strong>السعر لكل 1000:</strong> ${data.service.price.toFixed(2)}</p>
                                    <p class="service-description">${data.service.description}</p>
                                </div>
                            `;
                            
                            // تحديث حدود الكمية
                            quantityInput.setAttribute('min', data.service.min);
                            quantityInput.setAttribute('max', data.service.max);
                            
                            // تعديل القيمة الحالية إذا كانت خارج الحدود
                            const currentValue = parseInt(quantityInput.value);
                            if (isNaN(currentValue) || currentValue < data.service.min) {
                                quantityInput.value = data.service.min;
                            } else if (currentValue > data.service.max) {
                                quantityInput.value = data.service.max;
                            }
                            
                            updatePrice();
                        }
                    })
                    .catch(error => {
                        console.error('Error fetching service details:', error);
                    });
            });
            
            quantityInput.addEventListener('change', updatePrice);
            quantityInput.addEventListener('keyup', updatePrice);
        }
    }
    
    // تبديل الخدمات حسب الفئة
    const categoryButtons = document.querySelectorAll('.category-filter');
    
    if (categoryButtons.length > 0) {
        const serviceItems = document.querySelectorAll('.service-item');
        
        categoryButtons.forEach(button => {
            button.addEventListener('click', function() {
                const category = this.getAttribute('data-category');
                
                // إزالة الفئة النشطة من جميع الأزرار
                categoryButtons.forEach(btn => {
                    btn.classList.remove('active');
                });
                
                // إضافة الفئة النشطة للزر الحالي
                this.classList.add('active');
                
                // عرض أو إخفاء عناصر الخدمة بناءً على الفئة
                serviceItems.forEach(item => {
                    if (category === 'all' || item.getAttribute('data-category') === category) {
                        item.style.display = 'block';
                    } else {
                        item.style.display = 'none';
                    }
                });
            });
        });
    }
    
    // رسائل النجاح والخطأ المؤقتة
    const alerts = document.querySelectorAll('.alert-dismissible');
    
    if (alerts.length > 0) {
        alerts.forEach(function(alert) {
            const closeBtn = alert.querySelector('.close');
            
            if (closeBtn) {
                closeBtn.addEventListener('click', function() {
                    alert.style.display = 'none';
                });
            }
            
            // إخفاء تلقائي بعد 5 ثوان
            setTimeout(function() {
                alert.style.opacity = '0';
                setTimeout(function() {
                    alert.style.display = 'none';
                }, 500);
            }, 5000);
        });
    }
});

// تأكيد الحذف
function confirmDelete(message) {
    return confirm(message || 'هل أنت متأكد من أنك تريد الحذف؟');
}

/**
 * نسخ النص إلى الحافظة
 * @param {string} text - النص المراد نسخه
 * @param {string} elementId - معرف العنصر الذي سيتم تحديثه
 */
function copyToClipboard(text, elementId) {
    navigator.clipboard.writeText(text).then(function() {
        const element = document.getElementById(elementId);
        if (element) {
            const originalText = element.textContent;
            element.textContent = 'تم النسخ!';
            element.classList.add('copied');
            
            setTimeout(function() {
                element.textContent = originalText;
                element.classList.remove('copied');
            }, 2000);
        }
    }).catch(function(err) {
        console.error('فشل نسخ النص: ', err);
    });
}

/**
 * تفعيل الشروحات التوضيحية للخدمات
 * هذه الوظيفة تضيف شروحات مبسطة وسهلة الفهم للخدمات للمستخدمين العاديين
 */
function initServiceTooltips() {
    // البحث عن جميع عناصر الخدمات
    const serviceCards = document.querySelectorAll('.service-card, .service-item');
    
    if (serviceCards.length > 0) {
        serviceCards.forEach(card => {
            // إضافة زر المعلومات فقط إذا لم يكن موجودًا بالفعل
            if (!card.querySelector('.service-info-button')) {
                const infoButton = document.createElement('button');
                infoButton.className = 'service-info-button';
                infoButton.innerHTML = '<i class="fas fa-info-circle"></i>';
                card.appendChild(infoButton);
                
                // محاولة الحصول على معلومات الخدمة من السمات
                let serviceId = card.getAttribute('data-service-id') || card.getAttribute('id');
                let serviceName = card.getAttribute('data-service-name');
                let serviceDescription = card.getAttribute('data-service-description');
                
                // إذا لم تكن السمات موجودة، حاول البحث عن عناصر أخرى
                if (!serviceName) {
                    const nameElement = card.querySelector('.service-name, .service-title, h3, h4');
                    serviceName = nameElement ? nameElement.textContent.trim() : 'خدمة';
                }
                
                if (!serviceDescription) {
                    const descElement = card.querySelector('.service-description, .service-desc, p');
                    serviceDescription = descElement ? descElement.textContent.trim() : '';
                }
                
                // إضافة حدث النقر لعرض المعلومات
                infoButton.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    // إنشاء مربع المعلومات
                    showServiceExplanation(serviceName, serviceDescription, serviceId);
                });
            }
        });
    }
}

/**
 * عرض شرح مبسط للخدمة
 */
function showServiceExplanation(title, description, serviceId) {
    // إنشاء عنصر مربع الحوار
    const dialog = document.createElement('div');
    dialog.className = 'service-explanation-dialog';
    
    // إضافة محتوى مربع الحوار
    dialog.innerHTML = `
        <div class="service-explanation-content">
            <div class="service-explanation-header">
                <h3>${title}</h3>
                <button class="close-dialog"><i class="fas fa-times"></i></button>
            </div>
            <div class="service-explanation-body">
                <p>${description || 'لا يوجد وصف متاح لهذه الخدمة.'}</p>
                <div class="service-examples">
                    <h4>كيف تستخدم هذه الخدمة؟</h4>
                    <p>هذه الخدمة تساعدك في زيادة تواجدك على وسائل التواصل الاجتماعي عن طريق:</p>
                    <ul>
                        <li>زيادة عدد المتابعين بطريقة آمنة</li>
                        <li>زيادة التفاعل على منشوراتك</li>
                        <li>تحسين ظهور حسابك لدى المستخدمين الآخرين</li>
                    </ul>
                </div>
                <div class="service-usage">
                    <h4>خطوات الاستخدام:</h4>
                    <ol>
                        <li>اختر الخدمة المناسبة لك</li>
                        <li>أدخل رابط حسابك أو المنشور</li>
                        <li>حدد الكمية المطلوبة</li>
                        <li>اضغط على زر "تأكيد الطلب"</li>
                    </ol>
                </div>
            </div>
            <div class="service-explanation-footer">
                <button class="btn btn-primary btn-order-now" data-service-id="${serviceId}">اطلب الآن</button>
            </div>
        </div>
    `;
    
    // إضافة مربع الحوار إلى الصفحة
    document.body.appendChild(dialog);
    
    // إظهار مربع الحوار بتأثير
    setTimeout(() => dialog.classList.add('show'), 10);
    
    // إضافة حدث الإغلاق
    const closeButton = dialog.querySelector('.close-dialog');
    closeButton.addEventListener('click', () => {
        dialog.classList.remove('show');
        setTimeout(() => dialog.remove(), 300);
    });
    
    // إضافة حدث النقر على زر الطلب
    const orderButton = dialog.querySelector('.btn-order-now');
    orderButton.addEventListener('click', () => {
        dialog.classList.remove('show');
        setTimeout(() => dialog.remove(), 300);
        window.location.href = `/dashboard/new_order?service_id=${serviceId}`;
    });
    
    // إغلاق الحوار عند النقر خارجه
    dialog.addEventListener('click', function(e) {
        if (e.target === dialog) {
            dialog.classList.remove('show');
            setTimeout(() => dialog.remove(), 300);
        }
    });
}

/**
 * تبسيط واجهة الطلبات للمستخدمين العاديين
 */
function initSimplifiedOrderInterface() {
    const orderForm = document.getElementById('new-order-form');
    
    if (orderForm) {
        // إضافة مؤشرات تقدم بصرية
        const progressIndicator = document.createElement('div');
        progressIndicator.className = 'order-progress';
        progressIndicator.innerHTML = `
            <div class="progress-step active" data-step="1">
                <div class="step-number">1</div>
                <div class="step-label">اختيار الخدمة</div>
            </div>
            <div class="progress-line"></div>
            <div class="progress-step" data-step="2">
                <div class="step-number">2</div>
                <div class="step-label">تفاصيل الطلب</div>
            </div>
            <div class="progress-line"></div>
            <div class="progress-step" data-step="3">
                <div class="step-number">3</div>
                <div class="step-label">المراجعة والتأكيد</div>
            </div>
        `;
        
        // إضافة مؤشر التقدم قبل النموذج
        orderForm.parentNode.insertBefore(progressIndicator, orderForm);
        
        // تقسيم النموذج إلى خطوات
        const formSections = orderForm.querySelectorAll('.form-section');
        const nextButtons = orderForm.querySelectorAll('.btn-next-step');
        const prevButtons = orderForm.querySelectorAll('.btn-prev-step');
        
        // إضافة أحداث للأزرار
        if (nextButtons.length > 0) {
            nextButtons.forEach(button => {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    const currentStep = parseInt(this.getAttribute('data-current-step'));
                    const nextStep = currentStep + 1;
                    
                    // التحقق من صحة الحقول في الخطوة الحالية
                    const currentSection = orderForm.querySelector(`.form-section[data-step="${currentStep}"]`);
                    const inputs = currentSection.querySelectorAll('input, select, textarea');
                    let isValid = true;
                    
                    inputs.forEach(input => {
                        if (input.required && !input.value) {
                            isValid = false;
                            input.classList.add('is-invalid');
                        } else {
                            input.classList.remove('is-invalid');
                        }
                    });
                    
                    if (!isValid) {
                        showNotification('يرجى ملء جميع الحقول المطلوبة', 'warning');
                        return;
                    }
                    
                    // الانتقال إلى الخطوة التالية
                    goToStep(nextStep);
                });
            });
        }
        
        if (prevButtons.length > 0) {
            prevButtons.forEach(button => {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    const currentStep = parseInt(this.getAttribute('data-current-step'));
                    const prevStep = currentStep - 1;
                    
                    // الانتقال إلى الخطوة السابقة
                    goToStep(prevStep);
                });
            });
        }
        
        // وظيفة الانتقال إلى خطوة معينة
        function goToStep(step) {
            // إخفاء جميع الأقسام
            formSections.forEach(section => {
                section.style.display = 'none';
            });
            
            // إظهار القسم المطلوب
            const targetSection = orderForm.querySelector(`.form-section[data-step="${step}"]`);
            if (targetSection) {
                targetSection.style.display = 'block';
            }
            
            // تحديث مؤشر التقدم
            const progressSteps = progressIndicator.querySelectorAll('.progress-step');
            progressSteps.forEach(progressStep => {
                const stepNum = parseInt(progressStep.getAttribute('data-step'));
                if (stepNum <= step) {
                    progressStep.classList.add('active');
                } else {
                    progressStep.classList.remove('active');
                }
            });
            
            // التمرير إلى أعلى النموذج
            orderForm.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
        
        // عرض الخطوة الأولى افتراضيًا
        goToStep(1);
    }
}

/**
 * إضافة المساعد التفاعلي للمستخدمين الجدد
 */
function initInteractiveHelper() {
    // التحقق من كون المستخدم جديدًا
    const isNewUser = localStorage.getItem('is_new_user') !== 'false';
    
    if (isNewUser) {
        // إنشاء عنصر المساعد
        const helper = document.createElement('div');
        helper.className = 'interactive-helper';
        helper.innerHTML = `
            <div class="helper-avatar">
                <img src="/assets/images/helper-avatar.svg" alt="مساعد">
            </div>
            <div class="helper-content">
                <div class="helper-message">
                    <p>مرحبًا بك في منصة تاون ميديا! هل تحتاج إلى مساعدة في استخدام المنصة؟</p>
                </div>
                <div class="helper-actions">
                    <button class="btn btn-sm btn-primary helper-action" data-action="tour">جولة سريعة</button>
                    <button class="btn btn-sm btn-outline-primary helper-action" data-action="dismiss">لاحقًا</button>
                </div>
            </div>
            <button class="helper-toggle">
                <i class="fas fa-chevron-down"></i>
            </button>
        `;
        
        // إضافة المساعد إلى الصفحة
        document.body.appendChild(helper);
        
        // إضافة حدث التبديل
        const helperToggle = helper.querySelector('.helper-toggle');
        helperToggle.addEventListener('click', function() {
            helper.classList.toggle('collapsed');
            this.querySelector('i').classList.toggle('fa-chevron-down');
            this.querySelector('i').classList.toggle('fa-chevron-up');
        });
        
        // إضافة أحداث الأزرار
        const actionButtons = helper.querySelectorAll('.helper-action');
        actionButtons.forEach(button => {
            button.addEventListener('click', function() {
                const action = this.getAttribute('data-action');
                
                if (action === 'tour') {
                    startGuidedTour();
                } else if (action === 'dismiss') {
                    helper.classList.add('dismissed');
                    setTimeout(() => helper.remove(), 300);
                    localStorage.setItem('is_new_user', 'false');
                }
            });
        });
        
        // ظهور المساعد بعد ثانيتين
        setTimeout(() => helper.classList.add('show'), 2000);
    }
}

/**
 * بدء جولة إرشادية للمستخدم
 */
function startGuidedTour() {
    // قائمة بالعناصر التي سيتم شرحها وترتيبها
    const tourSteps = [
        {
            element: '.navbar',
            title: 'شريط التنقل',
            description: 'من هنا يمكنك التنقل بين أقسام المنصة المختلفة.',
            position: 'bottom'
        },
        {
            element: '.service-categories',
            title: 'فئات الخدمات',
            description: 'اختر الفئة التي تحتوي على الخدمات التي تبحث عنها.',
            position: 'bottom'
        },
        {
            element: '.service-list',
            title: 'قائمة الخدمات',
            description: 'تصفح الخدمات المتاحة واختر ما يناسب احتياجاتك.',
            position: 'top'
        },
        {
            element: '.user-balance',
            title: 'رصيدك',
            description: 'هنا يمكنك معرفة رصيدك الحالي وإضافة المزيد من الرصيد.',
            position: 'bottom'
        },
        {
            element: '.sidebar',
            title: 'القائمة الجانبية',
            description: 'تصفح الأقسام المختلفة مثل الطلبات والاشتراكات والتذاكر.',
            position: 'right'
        }
    ];
    
    // بدء الجولة
    let currentStep = 0;
    
    function showTourStep(step) {
        const tourData = tourSteps[step];
        const targetElement = document.querySelector(tourData.element);
        
        if (!targetElement) {
            // تخطي الخطوة إذا لم يتم العثور على العنصر
            if (step < tourSteps.length - 1) {
                showTourStep(step + 1);
            } else {
                endTour();
            }
            return;
        }
        
        // إنشاء عنصر الشرح
        const tooltip = document.createElement('div');
        tooltip.className = `tour-tooltip tour-position-${tourData.position}`;
        tooltip.innerHTML = `
            <div class="tour-tooltip-arrow"></div>
            <div class="tour-tooltip-content">
                <h4>${tourData.title}</h4>
                <p>${tourData.description}</p>
                <div class="tour-tooltip-footer">
                    <span class="tour-progress">${step + 1}/${tourSteps.length}</span>
                    <div class="tour-buttons">
                        ${step > 0 ? '<button class="btn btn-sm btn-outline-primary tour-prev">السابق</button>' : ''}
                        ${step < tourSteps.length - 1 ? '<button class="btn btn-sm btn-primary tour-next">التالي</button>' : '<button class="btn btn-sm btn-success tour-end">إنهاء</button>'}
                    </div>
                </div>
            </div>
        `;
        
        // إضافة التلميح إلى الصفحة
        document.body.appendChild(tooltip);
        
        // تحديد موضع التلميح بناءً على العنصر المستهدف
        positionTooltip(tooltip, targetElement, tourData.position);
        
        // إضافة التأثير المرئي للعنصر المستهدف
        targetElement.classList.add('tour-highlighted');
        
        // إضافة أحداث الأزرار
        const nextButton = tooltip.querySelector('.tour-next');
        const prevButton = tooltip.querySelector('.tour-prev');
        const endButton = tooltip.querySelector('.tour-end');
        
        if (nextButton) {
            nextButton.addEventListener('click', function() {
                targetElement.classList.remove('tour-highlighted');
                tooltip.remove();
                showTourStep(step + 1);
            });
        }
        
        if (prevButton) {
            prevButton.addEventListener('click', function() {
                targetElement.classList.remove('tour-highlighted');
                tooltip.remove();
                showTourStep(step - 1);
            });
        }
        
        if (endButton) {
            endButton.addEventListener('click', function() {
                endTour();
            });
        }
    }
    
    function positionTooltip(tooltip, targetElement, position) {
        const targetRect = targetElement.getBoundingClientRect();
        const tooltipRect = tooltip.getBoundingClientRect();
        
        let top, left;
        
        switch (position) {
            case 'top':
                top = targetRect.top - tooltipRect.height - 10;
                left = targetRect.left + (targetRect.width / 2) - (tooltipRect.width / 2);
                break;
            case 'bottom':
                top = targetRect.bottom + 10;
                left = targetRect.left + (targetRect.width / 2) - (tooltipRect.width / 2);
                break;
            case 'left':
                top = targetRect.top + (targetRect.height / 2) - (tooltipRect.height / 2);
                left = targetRect.left - tooltipRect.width - 10;
                break;
            case 'right':
                top = targetRect.top + (targetRect.height / 2) - (tooltipRect.height / 2);
                left = targetRect.right + 10;
                break;
        }
        
        // التأكد من أن التلميح لا يخرج عن حدود الشاشة
        if (top < 0) top = 10;
        if (left < 0) left = 10;
        if (left + tooltipRect.width > window.innerWidth) {
            left = window.innerWidth - tooltipRect.width - 10;
        }
        if (top + tooltipRect.height > window.innerHeight) {
            top = window.innerHeight - tooltipRect.height - 10;
        }
        
        tooltip.style.top = `${top}px`;
        tooltip.style.left = `${left}px`;
    }
    
    function endTour() {
        // إزالة جميع تلميحات الجولة
        document.querySelectorAll('.tour-tooltip').forEach(tooltip => tooltip.remove());
        
        // إزالة تأثير التمييز من جميع العناصر
        document.querySelectorAll('.tour-highlighted').forEach(element => {
            element.classList.remove('tour-highlighted');
        });
        
        // إظهار رسالة نجاح
        showNotification('تمت الجولة الإرشادية بنجاح!', 'success');
        
        // تعيين المستخدم كمستخدم قديم
        localStorage.setItem('is_new_user', 'false');
    }
    
    // بدء الجولة بالخطوة الأولى
    showTourStep(currentStep);
}

/**
 * عرض إشعار للمستخدم
 * @param {string} message - نص الإشعار
 * @param {string} type - نوع الإشعار (info, success, warning, error)
 * @returns {HTMLElement} - عنصر الإشعار المنشأ
 */
function showNotification(message, type = 'info') {
    // التحقق من وجود عنصر body
    if (!document.body) {
        console.error('لا يمكن إظهار الإشعار: عنصر body غير موجود');
        return null;
    }
    
    // التحقق من نوع الإشعار
    const validTypes = ['info', 'success', 'warning', 'error'];
    if (!validTypes.includes(type)) {
        type = 'info'; // استخدام النوع الافتراضي إذا كان النوع غير صالح
    }
    
    // تحديد الأيقونة المناسبة
    let iconClass = 'fa-info-circle';
    switch (type) {
        case 'success':
            iconClass = 'fa-check-circle';
            break;
        case 'warning':
            iconClass = 'fa-exclamation-triangle';
            break;
        case 'error':
            iconClass = 'fa-times-circle';
            break;
    }
    
    // إنشاء عنصر الإشعار
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.setAttribute('role', 'alert');
    notification.setAttribute('aria-live', 'assertive');
    
    // إنشاء محتوى الإشعار
    notification.innerHTML = `
        <div class="notification-icon">
            <i class="fas ${iconClass}"></i>
        </div>
        <div class="notification-content">
            <p>${message}</p>
        </div>
        <button class="notification-close" aria-label="إغلاق">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    // إضافة الإشعار إلى الصفحة
    document.body.appendChild(notification);
    
    // إظهار الإشعار بتأثير (مع تأخير قليل للسماح بالتحول)
    requestAnimationFrame(() => {
        setTimeout(() => notification.classList.add('show'), 10);
    });
    
    // إضافة حدث الإغلاق
    const closeButton = notification.querySelector('.notification-close');
    if (closeButton) {
        closeButton.addEventListener('click', function() {
            closeNotification(notification);
        });
    }
    
    // إخفاء الإشعار تلقائيًا بعد 5 ثوانٍ
    setTimeout(() => {
        closeNotification(notification);
    }, 5000);
    
    // وظيفة مساعدة لإغلاق الإشعار
    function closeNotification(notificationElement) {
        if (document.body.contains(notificationElement)) {
            notificationElement.classList.remove('show');
            notificationElement.classList.add('hiding');
            setTimeout(() => {
                if (document.body.contains(notificationElement)) {
                    document.body.removeChild(notificationElement);
                }
            }, 300);
        }
    }
    
    // إضافة دعم لوحة المفاتيح للإغلاق
    notification.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeNotification(notification);
        }
    });
    
    return notification;
}
