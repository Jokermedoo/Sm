/**
 * حماية وتأمين طلبات API
 * يوفر وظائف لتقييد معدل الطلبات وإضافة رؤوس أمان
 */

const ApiSecurity = {
  // رمز تأمين API الحالي
  _securityToken: null,
  
  // توقيت آخر تحديث للرمز
  _tokenLastUpdated: 0,
  
  // مدة صلاحية الرمز (بالمللي ثانية)
  _tokenLifetime: 15 * 60 * 1000, // 15 دقيقة
  
  // سجل الطلبات (مخزن في الذاكرة لتتبع معدل الطلبات)
  _requestLog: {},
  
  /**
   * تهيئة نظام الأمان
   */
  init() {
    // استعادة الرمز من التخزين المحلي إن وجد
    this._securityToken = localStorage.getItem('smm_api_token');
    const storedTime = localStorage.getItem('smm_api_token_time');
    this._tokenLastUpdated = storedTime ? parseInt(storedTime, 10) : 0;
    
    // التحقق من صلاحية الرمز واستعادته إذا لزم الأمر
    this._refreshTokenIfNeeded();
    
    // إعادة تعيين سجل الطلبات
    this._requestLog = {};
    
    // اعتراض طلبات fetch لإضافة رؤوس الأمان
    this._interceptFetchRequests();
    
    // تنظيف سجل الطلبات دورياً
    setInterval(() => this._cleanupRequestLog(), 60000); // كل دقيقة
    
    console.log('تم تهيئة نظام أمان API');
  },
  
  /**
   * تجديد رمز الأمان إذا لزم الأمر
   * @private
   */
  _refreshTokenIfNeeded() {
    const now = Date.now();
    
    // التحقق مما إذا كان الرمز قديماً أو غير موجود
    if (!this._securityToken || (now - this._tokenLastUpdated > this._tokenLifetime)) {
      this._generateNewToken();
    }
  },
  
  /**
   * إنشاء رمز أمان جديد
   * @private
   */
  _generateNewToken() {
    // استخدام توقيت عشوائي + توقيت حالي لإنشاء رمز
    const randomPart = Math.random().toString(36).substring(2, 15);
    const timePart = Date.now().toString(36);
    this._securityToken = `smm-${randomPart}-${timePart}`;
    this._tokenLastUpdated = Date.now();
    
    // حفظ الرمز في التخزين المحلي
    try {
      localStorage.setItem('smm_api_token', this._securityToken);
      localStorage.setItem('smm_api_token_time', this._tokenLastUpdated.toString());
    } catch (e) {
      console.error('خطأ في حفظ رمز الأمان:', e);
    }
    
    console.log('تم إنشاء رمز أمان API جديد');
  },
  
  /**
   * اعتراض طلبات fetch وإضافة رؤوس الأمان
   * @private
   */
  _interceptFetchRequests() {
    // حفظ إشارة إلى الدالة الأصلية
    const originalFetch = window.fetch;
    
    // استبدال الدالة الأصلية بدالة مخصصة
    window.fetch = (resource, options = {}) => {
      // التحقق من صلاحية الرمز
      this._refreshTokenIfNeeded();
      
      // فحص معدل الطلبات
      if (!this._checkRateLimit(resource)) {
        return Promise.reject(new Error('تم تجاوز معدل الطلبات المسموح. يرجى المحاولة لاحقاً.'));
      }
      
      // تحضير خيارات الطلب
      const secureOptions = { ...options };
      
      // إضافة الرؤوس إذا لم تكن موجودة
      secureOptions.headers = secureOptions.headers || {};
      
      // إضافة رؤوس الأمان
      secureOptions.headers = {
        ...secureOptions.headers,
        'X-API-Token': this._securityToken,
        'X-Request-Time': Date.now().toString(),
        'X-Requested-With': 'XMLHttpRequest' // لمنع CSRF
      };
      
      // تتبع الطلب في السجل
      this._logRequest(resource);
      
      // استدعاء الدالة الأصلية مع الخيارات المحسنة
      return originalFetch.call(window, resource, secureOptions);
    };
  },
  
  /**
   * التحقق من معدل الطلبات لمنع هجمات القوة الغاشمة
   * @param {string} resource - المورد المطلوب
   * @returns {boolean} ما إذا كان الطلب ضمن الحدود المسموح بها
   * @private
   */
  _checkRateLimit(resource) {
    const now = Date.now();
    const resourceKey = typeof resource === 'string' ? resource : resource.url;
    const urlPattern = this._getUrlPattern(resourceKey);
    
    // تهيئة سجل لهذا النمط إذا لم يكن موجوداً
    if (!this._requestLog[urlPattern]) {
      this._requestLog[urlPattern] = [];
    }
    
    // إزالة الطلبات القديمة (أكثر من دقيقة)
    this._requestLog[urlPattern] = this._requestLog[urlPattern].filter(
      time => (now - time) < 60000
    );
    
    // الحد الأقصى للطلبات في الدقيقة (يمكن ضبطه حسب نوع الطلب)
    let maxRequestsPerMinute = 60; // افتراضي
    
    // تطبيق حدود مختلفة بناءً على نوع الطلب
    if (urlPattern.includes('/api/auth')) {
      maxRequestsPerMinute = 10; // تقييد أكثر صرامة لطلبات المصادقة
    } else if (urlPattern.includes('/api/admin')) {
      maxRequestsPerMinute = 30; // تقييد وسطي لطلبات المشرف
    }
    
    // التحقق من عدد الطلبات
    if (this._requestLog[urlPattern].length >= maxRequestsPerMinute) {
      console.warn(`تم تجاوز معدل الطلبات لـ ${urlPattern}: ${this._requestLog[urlPattern].length} طلبات في الدقيقة`);
      
      // تتبع محاولة محتملة للهجوم
      if (typeof trackMaliciousAttempt === 'function') {
        trackMaliciousAttempt('API_RATE_LIMIT_EXCEEDED', {
          url: urlPattern,
          requests: this._requestLog[urlPattern].length,
          limit: maxRequestsPerMinute
        });
      }
      
      return false;
    }
    
    return true;
  },
  
  /**
   * تسجيل طلب في سجل الطلبات
   * @param {string|Request} resource - المورد المطلوب
   * @private
   */
  _logRequest(resource) {
    const now = Date.now();
    const resourceKey = typeof resource === 'string' ? resource : resource.url;
    const urlPattern = this._getUrlPattern(resourceKey);
    
    // تهيئة المصفوفة إذا لم تكن موجودة
    if (!this._requestLog[urlPattern]) {
      this._requestLog[urlPattern] = [];
    }
    
    // إضافة توقيت الطلب إلى السجل
    this._requestLog[urlPattern].push(now);
  },
  
  /**
   * تنظيف سجل الطلبات الدوري
   * @private
   */
  _cleanupRequestLog() {
    const now = Date.now();
    
    // إزالة الطلبات القديمة من جميع الأنماط
    Object.keys(this._requestLog).forEach(pattern => {
      this._requestLog[pattern] = this._requestLog[pattern].filter(
        time => (now - time) < 60000
      );
      
      // إزالة الأنماط الفارغة لتوفير الذاكرة
      if (this._requestLog[pattern].length === 0) {
        delete this._requestLog[pattern];
      }
    });
  },
  
  /**
   * استخراج نمط العنوان من مسار URL
   * @param {string} url - مسار URL الكامل
   * @returns {string} نمط العنوان المبسط
   * @private
   */
  _getUrlPattern(url) {
    try {
      // إزالة المعلمات والمعرفات الرقمية من العنوان
      const urlObj = new URL(url, window.location.origin);
      let path = urlObj.pathname;
      
      // استبدال المعرفات الرقمية بنمط عام
      path = path.replace(/\/\d+(\/?)/g, '/{id}$1');
      
      return path;
    } catch (e) {
      // في حالة الفشل، إرجاع العنوان الأصلي
      return url;
    }
  },
  
  /**
   * الحصول على رمز الأمان الحالي
   * @returns {string} رمز الأمان
   */
  getToken() {
    this._refreshTokenIfNeeded();
    return this._securityToken;
  },
  
  /**
   * الحصول على معلومات حالة النظام
   * @returns {object} معلومات الحالة
   */
  getStatus() {
    return {
      tokenAge: Date.now() - this._tokenLastUpdated,
      tokenLifetime: this._tokenLifetime,
      activePatterns: Object.keys(this._requestLog).length,
      totalRequests: Object.values(this._requestLog).reduce((sum, requests) => sum + requests.length, 0)
    };
  },
  
  /**
   * إضافة مصادقة JWT إلى الطلب
   * @param {Object} options - خيارات الطلب
   * @returns {Object} خيارات محدثة
   */
  addJwtAuth(options = {}) {
    const jwt = localStorage.getItem('smm_jwt_token');
    
    if (!jwt) {
      console.warn('لم يتم العثور على رمز JWT');
      return options;
    }
    
    options.headers = options.headers || {};
    options.headers.Authorization = `Bearer ${jwt}`;
    
    return options;
  }
};

// إضافة التحقق من الصلاحيات لطلبات API
function checkAPIPermission(permissionKey) {
  return new Promise((resolve, reject) => {
    $.ajax({
      url: '/api/check-permission',
      method: 'POST',
      data: {
        permission_key: permissionKey,
        _token: $('meta[name="csrf-token"]').attr('content')
      },
      success: function(response) {
        if (response.has_permission) {
          resolve();
        } else {
          showPermissionDeniedModal();
          reject('PERMISSION_DENIED');
        }
      },
      error: function(xhr) {
        logSecurityEvent('API_PERMISSION_CHECK_FAILED', xhr.responseText);
        reject('API_ERROR');
      }
    });
  });
}

// عرض نافذة رفض الصلاحية
function showPermissionDeniedModal() {
  Swal.fire({
    title: 'رفض الوصول',
    text: 'ليس لديك الصلاحية الكافية لتنفيذ هذا الإجراء',
    icon: 'error',
    confirmButtonText: 'حسناً'
  });
}

// تعديل الدوال الحالية لدمج التحقق من الصلاحيات
function sendSecureAPIRequest(endpoint, data, requiredPermission) {
  return checkAPIPermission(requiredPermission)
    .then(() => {
      return $.ajax({
        url: endpoint,
        method: 'POST',
        data: {
          ...data,
          _token: $('meta[name="csrf-token"]').attr('content')
        }
      });
    });
}

// تهيئة نظام أمان API عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
  ApiSecurity.init();
  
  // كشف محاولات التلاعب بالصفحة
  monitorDomChanges();
});

/**
 * مراقبة تغييرات DOM لكشف محاولات التلاعب
 */
function monitorDomChanges() {
  // قائمة بالعناصر الحساسة التي يجب مراقبتها
  const criticalElements = [
    'form',
    'input[type="password"]',
    'input[name="csrf_token"]',
    'button[type="submit"]'
  ];
  
  // إنشاء مراقب للتغييرات
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      // فحص التغييرات التي تؤثر على العناصر الحرجة
      if (mutation.type === 'childList' || mutation.type === 'attributes') {
        // فحص العناصر المضافة
        if (mutation.addedNodes.length > 0) {
          mutation.addedNodes.forEach((node) => {
            if (node.nodeType === Node.ELEMENT_NODE) {
              checkForSuspiciousElements(node);
            }
          });
        }
        
        // فحص تغييرات السمات
        if (mutation.type === 'attributes' && criticalElements.some(selector => mutation.target.matches(selector))) {
          checkAttributeChange(mutation.target, mutation.attributeName);
        }
      }
    });
  });
  
  // بدء المراقبة
  observer.observe(document.body, {
    childList: true,
    attributes: true,
    subtree: true,
    attributeFilter: ['action', 'onsubmit', 'onclick', 'src']
  });
  
  console.log('تم بدء مراقبة تغييرات DOM');
}

/**
 * فحص العناصر المشبوهة
 * @param {Element} element - عنصر DOM للفحص
 */
function checkForSuspiciousElements(element) {
  // فحص العناصر المضافة المشبوهة مثل سكريبت خارجي أو إطار iframe
  if (element.tagName === 'SCRIPT' && element.src && !isAllowedSource(element.src)) {
    console.warn('تم اكتشاف سكريبت خارجي مشبوه:', element.src);
    element.remove();
    
    // تتبع المحاولة
    if (typeof trackMaliciousAttempt === 'function') {
      trackMaliciousAttempt('SUSPICIOUS_SCRIPT', { src: element.src });
    }
  }
  
  if (element.tagName === 'IFRAME' && !isAllowedSource(element.src)) {
    console.warn('تم اكتشاف إطار iframe مشبوه:', element.src);
    element.remove();
    
    // تتبع المحاولة
    if (typeof trackMaliciousAttempt === 'function') {
      trackMaliciousAttempt('SUSPICIOUS_IFRAME', { src: element.src });
    }
  }
  
  // فحص الأحداث المشبوهة
  const suspiciousAttributes = ['onclick', 'onload', 'onerror', 'onsubmit'];
  suspiciousAttributes.forEach(attr => {
    if (element.hasAttribute(attr) && isSuspiciousCode(element.getAttribute(attr))) {
      console.warn(`تم اكتشاف سمة حدث مشبوهة: ${attr}`, element);
      element.removeAttribute(attr);
      
      // تتبع المحاولة
      if (typeof trackMaliciousAttempt === 'function') {
        trackMaliciousAttempt('SUSPICIOUS_EVENT', { 
          attribute: attr, 
          code: element.getAttribute(attr) 
        });
      }
    }
  });
  
  // فحص نماذج مع عناوين URL خارجية
  if (element.tagName === 'FORM' && element.action && !isAllowedSource(element.action)) {
    console.warn('تم اكتشاف نموذج مع عنوان URL خارجي:', element.action);
    
    // منع الإرسال إلى العنوان الخارجي
    const originalAction = element.action;
    element.action = window.location.href;
    
    // تتبع المحاولة
    if (typeof trackMaliciousAttempt === 'function') {
      trackMaliciousAttempt('EXTERNAL_FORM_ACTION', { action: originalAction });
    }
  }
}

/**
 * فحص تغييرات السمات المشبوهة
 * @param {Element} element - العنصر المتغير
 * @param {string} attributeName - اسم السمة التي تغيرت
 */
function checkAttributeChange(element, attributeName) {
  const value = element.getAttribute(attributeName);
  
  // فحص تغييرات السمات المشبوهة
  if (attributeName === 'action' && element.tagName === 'FORM' && !isAllowedSource(value)) {
    console.warn('تم اكتشاف تغيير مشبوه في عنوان النموذج:', value);
    element.setAttribute('action', window.location.href);
    
    // تتبع المحاولة
    if (typeof trackMaliciousAttempt === 'function') {
      trackMaliciousAttempt('FORM_ACTION_MODIFIED', { action: value });
    }
  }
  
  if (attributeName === 'src' && (element.tagName === 'SCRIPT' || element.tagName === 'IFRAME') && !isAllowedSource(value)) {
    console.warn(`تم اكتشاف تغيير مشبوه في مصدر ${element.tagName}:`, value);
    element.remove();
    
    // تتبع المحاولة
    if (typeof trackMaliciousAttempt === 'function') {
      trackMaliciousAttempt('SRC_MODIFIED', { 
        element: element.tagName, 
        src: value 
      });
    }
  }
  
  if (['onclick', 'onsubmit', 'onerror', 'onload'].includes(attributeName) && isSuspiciousCode(value)) {
    console.warn(`تم اكتشاف كود مشبوه في ${attributeName}:`, value);
    element.removeAttribute(attributeName);
    
    // تتبع المحاولة
    if (typeof trackMaliciousAttempt === 'function') {
      trackMaliciousAttempt('EVENT_HANDLER_MODIFIED', { 
        attribute: attributeName, 
        code: value 
      });
    }
  }
}

/**
 * التحقق مما إذا كان المصدر مسموحاً به
 * @param {string} src - مصدر العنصر
 * @returns {boolean} ما إذا كان المصدر مسموحاً به
 */
function isAllowedSource(src) {
  try {
    // قائمة المصادر المسموح بها
    const allowedDomains = [
      window.location.hostname,
      'cdn.jsdelivr.net',
      'cdnjs.cloudflare.com',
      'fonts.googleapis.com',
      'code.jquery.com',
      'stackpath.bootstrapcdn.com'
    ];
    
    // تحليل العنوان
    const url = new URL(src, window.location.href);
    
    // التحقق مما إذا كان المصدر في القائمة المسموح بها
    return allowedDomains.some(domain => url.hostname === domain || url.hostname.endsWith(`.${domain}`));
  } catch (e) {
    console.error('خطأ في تحليل المصدر:', e);
    return false;
  }
}

/**
 * التحقق مما إذا كان الكود مشبوهاً
 * @param {string} code - الكود للفحص
 * @returns {boolean} ما إذا كان الكود مشبوهاً
 */
function isSuspiciousCode(code) {
  if (!code) return false;
  
  // قائمة أنماط الكود المشبوه
  const suspiciousPatterns = [
    /eval\s*\(/i,
    /document\.cookie/i,
    /document\.location\s*=/i,
    /window\.location\s*=/i,
    /localStorage/i,
    /sessionStorage/i,
    /fetch\s*\(/i,
    /XMLHttpRequest/i,
    /ajax\s*\(/i
  ];
  
  // التحقق من وجود أي نمط مشبوه
  return suspiciousPatterns.some(pattern => pattern.test(code));
}
