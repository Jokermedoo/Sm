/**
 * Town Media - SMM Panel
 * ملف JavaScript الخاص بصفحات المصادقة
 */

document.addEventListener('DOMContentLoaded', function() {
    // وظيفة إظهار/إخفاء كلمة المرور
    const togglePasswordButtons = document.querySelectorAll('.toggle-password');
    
    if (togglePasswordButtons.length > 0) {
        togglePasswordButtons.forEach(function(button) {
            button.addEventListener('click', function() {
                const targetId = this.getAttribute('data-target');
                const passwordInput = document.querySelector(targetId);
                
                if (passwordInput) {
                    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                    passwordInput.setAttribute('type', type);
                    
                    // تغيير الأيقونة
                    const icon = this.querySelector('i');
                    if (icon) {
                        if (type === 'password') {
                            icon.classList.remove('fa-eye-slash');
                            icon.classList.add('fa-eye');
                        } else {
                            icon.classList.remove('fa-eye');
                            icon.classList.add('fa-eye-slash');
                        }
                    }
                }
            });
        });
    }
    
    // التحقق من تطابق كلمات المرور في نموذج التسجيل
    const registerForm = document.querySelector('form[action*="/auth/register"]');
    
    if (registerForm) {
        const password = document.getElementById('password');
        const passwordConfirm = document.getElementById('password_confirm');
        
        if (password && passwordConfirm) {
            // التحقق من تطابق كلمات المرور عند الكتابة
            passwordConfirm.addEventListener('input', function() {
                if (password.value !== this.value) {
                    this.setCustomValidity('كلمات المرور غير متطابقة');
                } else {
                    this.setCustomValidity('');
                }
            });
            
            // التحقق من قوة كلمة المرور
            password.addEventListener('input', function() {
                const value = this.value;
                const strongRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,})");
                
                if (!strongRegex.test(value)) {
                    this.setCustomValidity('كلمة المرور يجب أن تحتوي على 8 أحرف على الأقل، وتتضمن أحرفًا كبيرة وصغيرة وأرقامًا');
                } else {
                    this.setCustomValidity('');
                }
                
                // إعادة التحقق من تطابق كلمات المرور
                if (passwordConfirm.value && password.value !== passwordConfirm.value) {
                    passwordConfirm.setCustomValidity('كلمات المرور غير متطابقة');
                } else if (passwordConfirm.value) {
                    passwordConfirm.setCustomValidity('');
                }
            });
        }
        
        // التحقق من اسم المستخدم
        const username = document.getElementById('username');
        
        if (username) {
            username.addEventListener('input', function() {
                const value = this.value;
                const validUsernameRegex = /^[a-zA-Z0-9_]{4,20}$/;
                
                if (!validUsernameRegex.test(value)) {
                    this.setCustomValidity('اسم المستخدم يجب أن يكون بين 4 و 20 حرفًا، ويمكن أن يحتوي على أحرف وأرقام وشرطات سفلية فقط');
                } else {
                    this.setCustomValidity('');
                }
            });
        }
    }
    
    // معالجة نموذج تسجيل الدخول
    const loginForm = document.querySelector('form[action*="/auth/login"]');
    
    if (loginForm) {
        loginForm.addEventListener('submit', function(event) {
            const username = document.getElementById('username');
            const password = document.getElementById('password');
            
            if (username && !username.value.trim()) {
                username.setCustomValidity('يرجى إدخال اسم المستخدم أو البريد الإلكتروني');
                event.preventDefault();
                event.stopPropagation();
            } else if (username) {
                username.setCustomValidity('');
            }
            
            if (password && !password.value.trim()) {
                password.setCustomValidity('يرجى إدخال كلمة المرور');
                event.preventDefault();
                event.stopPropagation();
            } else if (password) {
                password.setCustomValidity('');
            }
        });
    }
    
    // معالجة نموذج استعادة كلمة المرور
    const forgotPasswordForm = document.querySelector('form[action*="/auth/forgot-password"]');
    
    if (forgotPasswordForm) {
        forgotPasswordForm.addEventListener('submit', function(event) {
            const email = document.getElementById('email');
            
            if (email) {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                
                if (!email.value.trim()) {
                    email.setCustomValidity('يرجى إدخال البريد الإلكتروني');
                    event.preventDefault();
                    event.stopPropagation();
                } else if (!emailRegex.test(email.value.trim())) {
                    email.setCustomValidity('يرجى إدخال بريد إلكتروني صالح');
                    event.preventDefault();
                    event.stopPropagation();
                } else {
                    email.setCustomValidity('');
                }
            }
        });
    }
    
    // معالجة نموذج إعادة تعيين كلمة المرور
    const resetPasswordForm = document.querySelector('form[action*="/auth/reset-password"]');
    
    if (resetPasswordForm) {
        const password = document.getElementById('password');
        const passwordConfirm = document.getElementById('password_confirm');
        
        if (password && passwordConfirm) {
            // التحقق من تطابق كلمات المرور عند الكتابة
            passwordConfirm.addEventListener('input', function() {
                if (password.value !== this.value) {
                    this.setCustomValidity('كلمات المرور غير متطابقة');
                } else {
                    this.setCustomValidity('');
                }
            });
            
            // التحقق من قوة كلمة المرور
            password.addEventListener('input', function() {
                const value = this.value;
                const strongRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,})");
                
                if (!strongRegex.test(value)) {
                    this.setCustomValidity('كلمة المرور يجب أن تحتوي على 8 أحرف على الأقل، وتتضمن أحرفًا كبيرة وصغيرة وأرقامًا');
                } else {
                    this.setCustomValidity('');
                }
                
                // إعادة التحقق من تطابق كلمات المرور
                if (passwordConfirm.value && password.value !== passwordConfirm.value) {
                    passwordConfirm.setCustomValidity('كلمات المرور غير متطابقة');
                } else if (passwordConfirm.value) {
                    passwordConfirm.setCustomValidity('');
                }
            });
        }
    }
});
