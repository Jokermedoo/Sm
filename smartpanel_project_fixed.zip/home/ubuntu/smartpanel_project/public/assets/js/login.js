/**
 * نظام تسجيل الدخول المحسن مع دعم التحقق الثنائي
 * يوفر واجهة مستخدم متطورة للتحقق بخطوتين
 */

// استخدام مكتبة SweetAlert2 للنوافذ المنبثقة
// تأكد من تضمين المكتبة في الصفحة: <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

/**
 * عرض نافذة التحقق الثنائي
 */
function show2FAModal() {
  Swal.fire({
    title: 'التحقق بخطوتين',
    html: `
      <div class="rtl">
        <p>تم إرسال رمز التحقق إلى هاتفك</p>
        <img src="assets/2fa-arabic.svg" width="120" onerror="this.src='assets/2fa-placeholder.png'; this.onerror=null;">
        
        <!-- مدخلات الرمز -->
        <div class="otp-container">
          ${Array(6).fill().map((_, i) => `
            <input type="tel" maxlength="1" class="otp-input" 
                   data-index="${i}" oninput="moveToNext(${i})">
          `).join('')}
        </div>
        
        <!-- خيارات بديلة -->
        <div class="mt-3">
          <button class="btn btn-sm btn-outline-secondary" onclick="sendSMS()" type="button">
            <i class="fas fa-sync"></i> إعادة الإرسال
          </button>
          <button class="btn btn-sm btn-outline-secondary" onclick="useBackupCode()" type="button">
            <i class="fas fa-key"></i> استخدام الرمز الاحتياطي
          </button>
        </div>
      </div>
    `,
    showCancelButton: true,
    confirmButtonText: 'تحقق',
    cancelButtonText: 'إلغاء',
    allowOutsideClick: false,
    didOpen: () => {
      // التركيز على أول حقل إدخال
      setTimeout(() => {
        document.querySelector('.otp-input[data-index="0"]').focus();
      }, 100);
    },
    preConfirm: () => {
      // جمع رمز التحقق من الحقول
      const otpInputs = document.querySelectorAll('.otp-input');
      const otpCode = Array.from(otpInputs).map(input => input.value).join('');
      
      if (otpCode.length !== 6 || !/^\d+$/.test(otpCode)) {
        Swal.showValidationMessage('يرجى إدخال رمز صحيح مكون من 6 أرقام');
        return false;
      }
      
      return otpCode;
    }
  }).then((result) => {
    if (result.isConfirmed) {
      // إرسال الرمز للتحقق
      verifyOTPCode(result.value);
    }
  });
}

/**
 * الانتقال إلى الحقل التالي عند إدخال رقم
 * @param {number} index - مؤشر الحقل الحالي
 */
function moveToNext(index) {
  const inputs = document.querySelectorAll('.otp-input');
  const input = inputs[index];
  
  // التأكد من أن المدخل هو رقم فقط
  input.value = input.value.replace(/[^0-9]/g, '');
  
  // الانتقال إلى الحقل التالي
  if (input.value && index < inputs.length - 1) {
    inputs[index + 1].focus();
  }
  
  // جمع الرمز عندما تكون جميع الحقول ممتلئة
  const allFilled = Array.from(inputs).every(input => input.value.length === 1);
  if (allFilled) {
    // تمكين زر التحقق
    const confirmButton = Swal.getConfirmButton();
    if (confirmButton) {
      confirmButton.disabled = false;
    }
  }
}

/**
 * إعادة إرسال رمز التحقق عبر الرسائل القصيرة
 */
function sendSMS() {
  // إظهار مؤشر التحميل
  Swal.showLoading();
  
  // محاكاة طلب AJAX
  setTimeout(() => {
    Swal.hideLoading();
    
    // عرض رسالة نجاح
    const currentHtml = Swal.getHtmlContainer().innerHTML;
    Swal.update({
      html: currentHtml + `
        <div class="alert alert-success mt-3 rtl" role="alert">
          <i class="fas fa-check-circle"></i>
          تم إرسال رمز جديد إلى هاتفك
        </div>
      `
    });
    
    // إعادة تعيين حقول الإدخال
    document.querySelectorAll('.otp-input').forEach(input => {
      input.value = '';
    });
    
    // التركيز على أول حقل
    document.querySelector('.otp-input[data-index="0"]').focus();
  }, 1500);
}

/**
 * استخدام رمز احتياطي بدلاً من رمز التحقق
 */
function useBackupCode() {
  Swal.fire({
    title: 'استخدام الرمز الاحتياطي',
    html: `
      <div class="rtl">
        <p>يرجى إدخال رمز الاحتياطي المكون من 8 أحرف</p>
        <input type="text" id="backupCodeInput" class="swal2-input" placeholder="XXXX-XXXX" maxlength="9">
        <p class="text-muted small mt-2">ملاحظة: يمكنك العثور على الرموز الاحتياطية في إعدادات الأمان</p>
      </div>
    `,
    showCancelButton: true,
    confirmButtonText: 'تحقق',
    cancelButtonText: 'إلغاء',
    didOpen: () => {
      // التركيز على حقل الإدخال
      document.getElementById('backupCodeInput').focus();
      
      // تنسيق الرمز تلقائياً (إضافة شرطة بين كل 4 أحرف)
      document.getElementById('backupCodeInput').addEventListener('input', function(e) {
        let value = e.target.value.replace(/[^A-Za-z0-9]/g, '');
        if (value.length > 4 && !value.includes('-')) {
          value = value.substring(0, 4) + '-' + value.substring(4);
        }
        e.target.value = value;
      });
    },
    preConfirm: () => {
      const backupCode = document.getElementById('backupCodeInput').value;
      
      // التحقق من صحة التنسيق (4 أحرف، شرطة، 4 أحرف)
      if (!/^[A-Za-z0-9]{4}-[A-Za-z0-9]{4}$/.test(backupCode)) {
        Swal.showValidationMessage('يرجى إدخال رمز احتياطي صحيح (مثال: ABCD-1234)');
        return false;
      }
      
      return backupCode;
    }
  }).then((result) => {
    if (result.isConfirmed) {
      // إرسال الرمز الاحتياطي للتحقق
      verifyBackupCode(result.value);
    }
  });
}

/**
 * التحقق من رمز OTP مع الخادم
 * @param {string} otpCode - رمز التحقق المدخل
 */
function verifyOTPCode(otpCode) {
  // إظهار مؤشر التحميل
  Swal.showLoading();
  
  // محاكاة طلب AJAX للتحقق من الرمز
  setTimeout(() => {
    const success = Math.random() > 0.2; // 80% فرصة للنجاح (للعرض التوضيحي فقط)
    
    if (success) {
      Swal.fire({
        icon: 'success',
        title: 'تم التحقق بنجاح',
        text: 'جاري تسجيل الدخول...',
        timer: 1500,
        showConfirmButton: false
      }).then(() => {
        // إعادة توجيه إلى لوحة التحكم
        window.location.href = '/dashboard';
      });
    } else {
      Swal.fire({
        icon: 'error',
        title: 'رمز غير صحيح',
        text: 'يرجى المحاولة مرة أخرى',
        confirmButtonText: 'حسناً'
      }).then(() => {
        // إعادة فتح نافذة التحقق
        show2FAModal();
      });
    }
  }, 1500);
}

/**
 * التحقق من الرمز الاحتياطي مع الخادم
 * @param {string} backupCode - الرمز الاحتياطي المدخل
 */
function verifyBackupCode(backupCode) {
  // إظهار مؤشر التحميل
  Swal.showLoading();
  
  // محاكاة طلب AJAX للتحقق من الرمز الاحتياطي
  setTimeout(() => {
    const success = Math.random() > 0.2; // 80% فرصة للنجاح (للعرض التوضيحي فقط)
    
    if (success) {
      Swal.fire({
        icon: 'success',
        title: 'تم التحقق بنجاح',
        text: 'جاري تسجيل الدخول...',
        timer: 1500,
        showConfirmButton: false
      }).then(() => {
        // إعادة توجيه إلى لوحة التحكم
        window.location.href = '/dashboard';
      });
    } else {
      Swal.fire({
        icon: 'error',
        title: 'رمز احتياطي غير صحيح',
        text: 'يرجى المحاولة مرة أخرى',
        confirmButtonText: 'حسناً'
      });
    }
  }, 1500);
}

/**
 * معالجة تسجيل الدخول
 * @param {Event} event - حدث إرسال النموذج
 */
function handleLogin(event) {
  // منع السلوك الافتراضي للنموذج
  event.preventDefault();
  
  // الحصول على بيانات النموذج
  const form = event.target;
  const username = form.querySelector('[name="username"]').value;
  const password = form.querySelector('[name="password"]').value;
  const rememberMe = form.querySelector('[name="remember"]')?.checked || false;
  
  // التحقق من صحة المدخلات
  if (!username || !password) {
    Swal.fire({
      icon: 'error',
      title: 'خطأ في المدخلات',
      text: 'يرجى إدخال اسم المستخدم وكلمة المرور',
      confirmButtonText: 'حسناً'
    });
    return;
  }
  
  // إظهار مؤشر التحميل
  Swal.fire({
    title: 'جاري التحقق...',
    text: 'يرجى الانتظار',
    allowOutsideClick: false,
    showConfirmButton: false,
    didOpen: () => {
      Swal.showLoading();
    }
  });
  
  // محاكاة طلب AJAX لتسجيل الدخول
  setTimeout(() => {
    const loginSuccess = Math.random() > 0.3; // 70% فرصة للنجاح (للعرض التوضيحي فقط)
    
    if (loginSuccess) {
      // تحقق مما إذا كان المستخدم لديه 2FA مفعل
      const has2FA = Math.random() > 0.5; // 50% فرصة (للعرض التوضيحي فقط)
      
      if (has2FA) {
        // إغلاق نافذة التحميل وفتح نافذة التحقق الثنائي
        Swal.close();
        show2FAModal();
      } else {
        // تسجيل دخول ناجح بدون 2FA
        Swal.fire({
          icon: 'success',
          title: 'تم تسجيل الدخول بنجاح',
          text: 'جاري التوجيه إلى لوحة التحكم...',
          timer: 1500,
          showConfirmButton: false
        }).then(() => {
          // إعادة توجيه إلى لوحة التحكم
          window.location.href = '/dashboard';
        });
      }
    } else {
      // فشل تسجيل الدخول
      Swal.fire({
        icon: 'error',
        title: 'فشل تسجيل الدخول',
        text: 'اسم المستخدم أو كلمة المرور غير صحيحة',
        confirmButtonText: 'حسناً'
      });
    }
  }, 1500);
}

// إضافة مستمع الحدث عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
  // البحث عن نموذج تسجيل الدخول وإضافة مستمع الحدث
  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', handleLogin);
  }
});
