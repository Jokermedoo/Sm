<?php
/**
 * SMM Panel - نظام إدارة خدمات وسائل التواصل الاجتماعي
 * نقطة الدخول العامة للتطبيق
 */

// تعريف مسار التطبيق الأساسي
define('BASE_PATH', dirname(__DIR__));

// التحقق من إصدار PHP
if (version_compare(PHP_VERSION, '7.4.0', '<')) {
    die('يتطلب النظام PHP 7.4 أو أحدث. الإصدار الحالي: ' . PHP_VERSION);
}

// التحقق من تثبيت الإضافات المطلوبة
$required_extensions = ['pdo', 'pdo_mysql', 'mbstring', 'json', 'curl', 'gd'];
foreach ($required_extensions as $ext) {
    if (!extension_loaded($ext)) {
        die('الإضافة المطلوبة غير مثبتة: ' . $ext);
    }
}

// تضمين الإعدادات المشددة
require __DIR__.'/../config/hardened_settings.php';

// إعدادات الجلسات الآمنة
require __DIR__.'/../config/session_settings.php';

// تم التعليق: نظام التسجيل الأمني القديم - يستخدم الآن App\\Core\\Logger
// require __DIR__.'/../includes/security_logger.php';

// تحديد بداية الجلسة مع إعدادات أمان محسنة
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', isset($_SERVER['HTTPS']));
session_name('SMM_SESSION'); // استخدام اسم جلسة آمن
session_start();

// منع XSS والتهديدات الأمنية الأخرى
header('X-XSS-Protection: 1; mode=block');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');

// تضمين ملفات التكوين
require_once BASE_PATH . '/config/config.php';
require_once BASE_PATH . '/config/functions.php';
require_once BASE_PATH . '/app/autoload.php';

// تحميل النظام الأساسي مع التحديثات
require __DIR__.'/../app/core/AdvancedUserSystem.php';
require __DIR__.'/../app/core/UnifiedPaymentSystem.php';

// إنشاء المجلدات المطلوبة إذا لم تكن موجودة
$required_directories = [
    BASE_PATH . '/uploads',
    BASE_PATH . '/logs',
    BASE_PATH . '/cache'
];

foreach ($required_directories as $dir) {
    if (!is_dir($dir)) {
        if (!mkdir($dir, 0755, true)) {
            die('فشل إنشاء المجلد المطلوب: ' . $dir);
        }
    }
}

// بدء معالجة الطلب
try {
    $router = new \App\Controllers\Router();
    $router->handleRequest();
} catch (Exception $e) {
    // تسجيل الخطأ
    error_log($e->getMessage());
    
    // عرض صفحة الخطأ
    include BASE_PATH . '/app/views/error.php';
}
