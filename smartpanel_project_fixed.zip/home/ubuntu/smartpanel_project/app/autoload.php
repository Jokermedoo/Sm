<?php
/**
 * التحميل التلقائي للفئات
 * 
 * تم تحسينه بتاريخ: 30-05-2025
 * - استخدام المسارات المعرفة مركزياً
 * - دعم المسارات لمجلد متجر SMM
 * - تحسين أداء التحميل التلقائي
 */

// تأكد من تحميل ملف المسارات المركزي
// يتم تحميله أولاً في index.php لكن نتحقق هنا للتأكيد
if (!defined('ROOT_PATH') && file_exists(__DIR__ . '/../config/paths.php')) {
    require_once __DIR__ . '/../config/paths.php';
}

spl_autoload_register(function ($class) {
    // تحويل اسم الفئة إلى مسار ملف
    $class = str_replace('\\', '/', $class);
    
    // استخدام المسارات المعرفة مركزياً
    $paths = [
        'app/controllers/',
        'app/models/',
        'app/core/',
        'app/modules/',
        'smm-store/app/core/', // إضافة مسار متجر SMM
        'includes/'
    ];
    
    // البحث عن الملف في المسارات المحددة
    foreach ($paths as $path) {
        // استخدام ROOT_PATH المعرف في paths.php
        $file = ROOT_PATH . '/' . $path . $class . '.php';
        if (file_exists($file)) {
            require_once $file;
            return true;
        }
    }
    
    // محاولة ثانية للبحث عن الفئة بدون مسار المجلد
    $file = ROOT_PATH . '/' . $class . '.php';
    if (file_exists($file)) {
        require_once $file;
        return true;
    }
    
    return false;
});
