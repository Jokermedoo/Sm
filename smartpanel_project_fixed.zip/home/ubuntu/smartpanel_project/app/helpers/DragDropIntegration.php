<?php
/**
 * SMM Panel - Drag and Drop Integration Helper
 * 
 * This file helps integrate drag and drop features into the SMM Panel application
 */

namespace App\Helpers;

class DragDropIntegration {
    /**
     * Adds necessary JS and CSS files to the page
     * 
     * @param bool $adminOnly Whether to include admin-only features
     * @return string HTML to include in the page
     */
    public static function loadAssets($adminOnly = false) {
        $baseUrl = defined('BASE_URL') ? BASE_URL : '';
        $output = '';
        
        // Include CSS
        $output .= '<link rel="stylesheet" href="' . $baseUrl . '/assets/css/drag-drop.css">' . PHP_EOL;
        
        // Include JS (at the end of the page)
        $output .= '<script src="' . $baseUrl . '/assets/libs/sortable.min.js"></script>' . PHP_EOL;
        $output .= '<script src="' . $baseUrl . '/assets/js/drag-drop.js"></script>' . PHP_EOL;
        
        // Include admin-only features
        if ($adminOnly) {
            $output .= '<script src="' . $baseUrl . '/assets/js/admin-drag-drop.js"></script>' . PHP_EOL;
        }
        
        return $output;
    }
    
    /**
     * Renders a sortable list element
     * 
     * @param array $items Items to render in the list
     * @param string $saveUrl URL to save the sorted order
     * @param array $options Additional options
     * @return string HTML for the sortable list
     */
    public static function renderSortableList($items, $saveUrl, $options = []) {
        $listType = $options['listType'] ?? 'ul';
        $listClass = $options['listClass'] ?? 'sortable-list';
        $itemClass = $options['itemClass'] ?? 'sortable-item';
        $handle = $options['handle'] ?? true;
        $handleClass = $options['handleClass'] ?? 'sort-handle';
        $idField = $options['idField'] ?? 'id';
        $labelField = $options['labelField'] ?? 'name';
        
        $optionsJson = json_encode($options);
        
        $output = "<{$listType} class=\"{$listClass}\" data-sortable-list data-save-url=\"{$saveUrl}\" data-options='{$optionsJson}'>";
        
        foreach ($items as $item) {
            $id = $item[$idField] ?? '';
            $label = $item[$labelField] ?? '';
            
            $output .= "<li class=\"{$itemClass}\" data-id=\"{$id}\">";
            
            if ($handle) {
                $output .= "<span class=\"{$handleClass}\"></span>";
            }
            
            $output .= htmlspecialchars($label);
            $output .= "</li>";
        }
        
        $output .= "</{$listType}>";
        
        return $output;
    }
    
    /**
     * Renders a file upload dropzone
     * 
     * @param string $uploadUrl URL to upload files
     * @param array $options Additional options
     * @return string HTML for the file dropzone
     */
    public static function renderFileDropzone($uploadUrl, $options = []) {
        $maxFiles = $options['maxFiles'] ?? 1;
        $allowedTypes = $options['allowedTypes'] ?? 'image/jpeg,image/png,application/pdf';
        $maxSize = $options['maxSize'] ?? 5; // MB
        $dropzoneClass = $options['dropzoneClass'] ?? 'file-dropzone';
        $message = $options['message'] ?? 'اسحب وأفلت الملفات هنا أو انقر للاختيار';
        $icon = $options['icon'] ?? '📁';
        $multiple = $maxFiles > 1 ? 'multiple' : '';
        
        $output = "<div class=\"{$dropzoneClass}\" data-file-dropzone data-upload-url=\"{$uploadUrl}\" " .
                  "data-max-files=\"{$maxFiles}\" data-allowed-types=\"{$allowedTypes}\" data-max-size=\"{$maxSize}\">";
        
        $output .= "<div class=\"dropzone-message\">";
        $output .= "<div class=\"dropzone-icon\">{$icon}</div>";
        $output .= "<p>{$message}</p>";
        $output .= "</div>";
        
        $output .= "<input type=\"file\" {$multiple} hidden>";
        $output .= "<div data-preview-container></div>";
        
        $output .= "<div class=\"progress\">";
        $output .= "<div class=\"progress-bar\" data-upload-progress></div>";
        $output .= "</div>";
        
        $output .= "</div>";
        
        return $output;
    }
    
    /**
     * Registers necessary routes for drag and drop functionality
     * 
     * @param object $router Router object
     */
    public static function registerRoutes($router) {
        // User preferences routes
        $router->post('/api/user-preferences/update-widget-order', 'Api\\DragDropController@updateWidgetOrder');
        
        // Admin routes
        $router->post('/admin/api/categories/update-order', 'Api\\DragDropController@updateCategoryOrder');
        $router->post('/admin/api/services/update-order', 'Api\\DragDropController@updateServiceOrder');
        $router->post('/admin/api/orders/update-status', 'Api\\DragDropController@updateOrderStatus');
        $router->post('/admin/api/list/update-order', 'Api\\DragDropController@updateListOrder');
    }
    
    /**
     * Renders kanban board for order management
     * 
     * @param array $orders Orders grouped by status
     * @return string HTML for the kanban board
     */
    public static function renderOrderKanban($orders) {
        $statuses = [
            'pending' => 'قيد الانتظار',
            'processing' => 'قيد المعالجة',
            'completed' => 'مكتمل',
            'failed' => 'فشل',
            'cancelled' => 'ملغي',
            'refunded' => 'مسترد'
        ];
        
        $statusColors = [
            'pending' => 'warning',
            'processing' => 'info',
            'completed' => 'success',
            'failed' => 'danger',
            'cancelled' => 'secondary',
            'refunded' => 'primary'
        ];
        
        $output = "<div class=\"kanban-container\">";
        
        foreach ($statuses as $statusKey => $statusName) {
            $output .= "<div data-status-container data-status=\"{$statusKey}\">";
            $output .= "<div class=\"status-column-header\">{$statusName}</div>";
            
            if (isset($orders[$statusKey]) && is_array($orders[$statusKey])) {
                foreach ($orders[$statusKey] as $order) {
                    $output .= "<div class=\"order-item\" data-order-id=\"{$order['id']}\" data-status=\"{$statusKey}\">";
                    $output .= "<div class=\"order-item-header\">";
                    $output .= "<span class=\"order-item-id\">#{$order['id']}</span>";
                    $output .= "<span class=\"status-badge badge bg-{$statusColors[$statusKey]}\">{$statusName}</span>";
                    $output .= "</div>";
                    
                    $output .= "<div class=\"order-item-details\">";
                    $output .= "<div>{$order['service_name']}</div>";
                    $output .= "<div>{$order['quantity']} - {$order['price']} $</div>";
                    $output .= "</div>";
                    
                    $output .= "<div class=\"order-item-customer\">";
                    $output .= "<small>{$order['user_name']}</small>";
                    $output .= "</div>";
                    
                    $output .= "</div>"; // order-item
                }
            }
            
            $output .= "</div>"; // status-container
        }
        
        $output .= "</div>"; // kanban-container
        
        return $output;
    }
}
