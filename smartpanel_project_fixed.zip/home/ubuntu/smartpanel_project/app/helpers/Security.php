<?php
namespace App\Helpers;

/**
 * Security Helper - فئة مساعدة لإدارة وظائف الأمان المختلفة في التطبيق
 * 
 * تقدم هذه الفئة وظائف للتعامل مع مختلف جوانب الأمان مثل تصفية المدخلات، 
 * منع هجمات XSS، التحقق من CSRF، وتشفير البيانات
 */
class Security {
    /**
     * رمز التحقق من CSRF
     * @var string
     */
    private static $csrfToken = null;
    
    /**
     * تنظيف بيانات الإدخال (HTML Purify)
     * 
     * @param string $input النص المدخل
     * @return string النص المنظف
     */
    public static function sanitize($input) {
        if (is_array($input)) {
            return array_map([self::class, 'sanitize'], $input);
        }
        
        // تحويل الرموز الخاصة بـ HTML إلى كيانات
        $sanitized = htmlspecialchars($input, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        
        // إزالة المسافات الزائدة
        $sanitized = trim($sanitized);
        
        return $sanitized;
    }
    
    /**
     * تصفية المدخلات بشكل آمن للاستخدام في استعلامات SQL
     * ملاحظة: هذا ليس بديلاً عن استخدام Prepared Statements
     * 
     * @param string $input النص المدخل
     * @return string النص المصفى
     */
    public static function sanitizeForDb($input) {
        if (is_array($input)) {
            return array_map([self::class, 'sanitizeForDb'], $input);
        }
        
        // استخدام دالة mysql_real_escape_string إذا كانت متاحة
        if (function_exists('mysqli_real_escape_string') && isset($GLOBALS['db'])) {
            return mysqli_real_escape_string($GLOBALS['db'], $input);
        }
        
        // استخدام دالة addslashes كحل بديل
        return addslashes($input);
    }
    
    /**
     * تصفية متغيرات URL (قيم GET)
     * 
     * @param string $input النص المدخل
     * @return string النص المصفى
     */
    public static function sanitizeUrl($input) {
        if (is_array($input)) {
            return array_map([self::class, 'sanitizeUrl'], $input);
        }
        
        // تصفية قيم URL
        $sanitized = filter_var($input, FILTER_SANITIZE_URL);
        
        return $sanitized;
    }
    
    /**
     * التحقق من صحة البريد الإلكتروني
     * 
     * @param string $email البريد الإلكتروني
     * @return bool
     */
    public static function isValidEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
    
    /**
     * التحقق من صحة رابط URL
     * 
     * @param string $url رابط URL
     * @return bool
     */
    public static function isValidUrl($url) {
        return filter_var($url, FILTER_VALIDATE_URL) !== false;
    }
    
    /**
     * إنشاء كلمة مرور مشفرة (Hash)
     * 
     * @param string $password كلمة المرور الأصلية
     * @return string كلمة المرور المشفرة
     */
    public static function hashPassword($password) {
        // استخدام خوارزمية PASSWORD_ARGON2ID إذا كانت متاحة (PHP 7.3+)
        if (defined('PASSWORD_ARGON2ID')) {
            return password_hash($password, PASSWORD_ARGON2ID);
        }
        
        // استخدام خوارزمية PASSWORD_ARGON2I إذا كانت متاحة (PHP 7.2+)
        if (defined('PASSWORD_ARGON2I')) {
            return password_hash($password, PASSWORD_ARGON2I);
        }
        
        // استخدام خوارزمية PASSWORD_BCRYPT كخيار احتياطي
        return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    }
    
    /**
     * التحقق من صحة كلمة المرور
     * 
     * @param string $password كلمة المرور الأصلية
     * @param string $hash كلمة المرور المشفرة المخزنة
     * @return bool
     */
    public static function verifyPassword($password, $hash) {
        return password_verify($password, $hash);
    }
    
    /**
     * التحقق مما إذا كانت كلمة المرور تحتاج إلى إعادة تشفير
     * 
     * @param string $hash كلمة المرور المشفرة
     * @return bool
     */
    public static function passwordNeedsRehash($hash) {
        $currentAlgo = defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : 
                     (defined('PASSWORD_ARGON2I') ? PASSWORD_ARGON2I : PASSWORD_BCRYPT);
                     
        return password_needs_rehash($hash, $currentAlgo);
    }
    
    /**
     * إنشاء رمز CSRF (Cross-Site Request Forgery) وتخزينه في الجلسة
     * 
     * @return string رمز CSRF
     */
    public static function generateCsrfToken() {
        // إنشاء رمز جديد فقط إذا لم يكن موجودًا بالفعل
        if (self::$csrfToken === null) {
            if (function_exists('random_bytes')) {
                $token = bin2hex(random_bytes(32));
            } elseif (function_exists('openssl_random_pseudo_bytes')) {
                $token = bin2hex(openssl_random_pseudo_bytes(32));
            } else {
                // خيار احتياطي أقل أمانًا
                $token = md5(uniqid(mt_rand(), true));
            }
            
            $_SESSION['csrf_token'] = $token;
            $_SESSION['csrf_token_time'] = time();
            self::$csrfToken = $token;
        }
        
        return self::$csrfToken;
    }
    
    /**
     * التحقق من صحة رمز CSRF
     * 
     * @param string $token رمز CSRF المقدم
     * @param int $maxLifetime العمر الأقصى للرمز بالثواني (افتراضيًا ساعة واحدة)
     * @return bool
     */
    public static function validateCsrfToken($token, $maxLifetime = 3600) {
        if (!isset($_SESSION['csrf_token']) || !isset($_SESSION['csrf_token_time'])) {
            return false;
        }
        
        // التحقق من صلاحية الرمز
        $valid = ($_SESSION['csrf_token'] === $token);
        
        // التحقق من عمر الرمز
        $tokenAge = time() - $_SESSION['csrf_token_time'];
        if ($tokenAge > $maxLifetime) {
            // إذا انتهت صلاحية الرمز، قم بإنشاء رمز جديد
            self::generateCsrfToken();
            return false;
        }
        
        return $valid;
    }
    
    /**
     * إنشاء رمز CSRF كحقل نموذج HTML
     * 
     * @return string حقل CSRF HTML
     */
    public static function csrfField() {
        $token = self::generateCsrfToken();
        return '<input type="hidden" name="csrf_token" value="' . $token . '">';
    }
    
    /**
     * إنشاء رمز عشوائي للتحقق من البريد الإلكتروني أو إعادة تعيين كلمة المرور
     * 
     * @param int $length طول الرمز
     * @return string الرمز العشوائي
     */
    public static function generateToken($length = 32) {
        if (function_exists('random_bytes')) {
            return bin2hex(random_bytes($length / 2));
        } elseif (function_exists('openssl_random_pseudo_bytes')) {
            return bin2hex(openssl_random_pseudo_bytes($length / 2));
        } else {
            // خيار احتياطي أقل أمانًا
            return substr(str_shuffle(MD5(microtime())), 0, $length);
        }
    }
    
    /**
     * تشفير بيانات حساسة
     * 
     * @param string $data البيانات المراد تشفيرها
     * @param string $key مفتاح التشفير (اختياري)
     * @return string البيانات المشفرة
     */
    public static function encrypt($data, $key = null) {
        // إذا لم يتم توفير مفتاح، استخدم المفتاح المعرف في الإعدادات
        if ($key === null) {
            $key = defined('ENCRYPTION_KEY') ? ENCRYPTION_KEY : 'default_encryption_key';
        }
        
        // استخدام خوارزمية AES-256-CBC للتشفير
        $method = 'AES-256-CBC';
        
        // إنشاء متجه التهيئة (IV)
        $ivLength = openssl_cipher_iv_length($method);
        $iv = openssl_random_pseudo_bytes($ivLength);
        
        // تشفير البيانات
        $encrypted = openssl_encrypt($data, $method, $key, 0, $iv);
        
        // دمج IV مع البيانات المشفرة
        return base64_encode($iv . $encrypted);
    }
    
    /**
     * فك تشفير البيانات المشفرة
     * 
     * @param string $data البيانات المشفرة
     * @param string $key مفتاح التشفير (اختياري)
     * @return string البيانات الأصلية بعد فك التشفير
     */
    public static function decrypt($data, $key = null) {
        // إذا لم يتم توفير مفتاح، استخدم المفتاح المعرف في الإعدادات
        if ($key === null) {
            $key = defined('ENCRYPTION_KEY') ? ENCRYPTION_KEY : 'default_encryption_key';
        }
        
        // استخدام خوارزمية AES-256-CBC للتشفير
        $method = 'AES-256-CBC';
        
        // فك تشفير البيانات من التشفير Base64
        $data = base64_decode($data);
        
        // استخراج متجه التهيئة (IV)
        $ivLength = openssl_cipher_iv_length($method);
        $iv = substr($data, 0, $ivLength);
        
        // استخراج البيانات المشفرة
        $encrypted = substr($data, $ivLength);
        
        // فك تشفير البيانات
        return openssl_decrypt($encrypted, $method, $key, 0, $iv);
    }
    
    /**
     * التحقق من قوة كلمة المرور
     * 
     * @param string $password كلمة المرور
     * @return array نتيجة التحقق [قوية => bool, رسائل => array]
     */
    public static function checkPasswordStrength($password) {
        $result = [
            'strong' => true,
            'messages' => []
        ];
        
        // التحقق من طول كلمة المرور
        if (strlen($password) < 8) {
            $result['strong'] = false;
            $result['messages'][] = 'يجب أن تكون كلمة المرور على الأقل 8 أحرف';
        }
        
        // التحقق من وجود أحرف كبيرة
        if (!preg_match('/[A-Z]/', $password)) {
            $result['strong'] = false;
            $result['messages'][] = 'يجب أن تحتوي كلمة المرور على حرف كبير واحد على الأقل';
        }
        
        // التحقق من وجود أحرف صغيرة
        if (!preg_match('/[a-z]/', $password)) {
            $result['strong'] = false;
            $result['messages'][] = 'يجب أن تحتوي كلمة المرور على حرف صغير واحد على الأقل';
        }
        
        // التحقق من وجود أرقام
        if (!preg_match('/[0-9]/', $password)) {
            $result['strong'] = false;
            $result['messages'][] = 'يجب أن تحتوي كلمة المرور على رقم واحد على الأقل';
        }
        
        // التحقق من وجود رموز خاصة
        if (!preg_match('/[^A-Za-z0-9]/', $password)) {
            $result['strong'] = false;
            $result['messages'][] = 'يجب أن تحتوي كلمة المرور على رمز خاص واحد على الأقل';
        }
        
        return $result;
    }
    
    /**
     * التحقق من هجمات حقن SQL البسيطة
     * 
     * @param string $input النص المدخل
     * @return bool
     */
    public static function hasSqlInjection($input) {
        // قائمة بالكلمات المفتاحية لـ SQL التي يمكن استخدامها في هجمات الحقن
        $sqlKeywords = [
            'SELECT', 'INSERT', 'UPDATE', 'DELETE', 'DROP', 'UNION', 
            'ALTER', 'EXEC', 'EXECUTE', 'TRUNCATE', 'INFORMATION_SCHEMA',
            '--', '/*', 'SLEEP(', 'BENCHMARK(', 'WAITFOR DELAY'
        ];
        
        // تحويل النص إلى حروف كبيرة للمقارنة
        $upperInput = strtoupper($input);
        
        // التحقق من وجود كلمات مفتاحية مشبوهة
        foreach ($sqlKeywords as $keyword) {
            if (strpos($upperInput, $keyword) !== false) {
                return true;
            }
        }
        
        // التحقق من وجود أنماط مشبوهة
        $suspiciousPatterns = [
            '/\'\s*OR\s*\'1\'\s*=\s*\'1/i',  // 'OR '1'='1
            '/\'\s*OR\s*1\s*=\s*1/i',        // 'OR 1=1
            '/\'\s*OR\s*\'\'\s*=\s*\'/i',    // 'OR ''='
            '/\'\s*OR\s*1\s*--/i',           // 'OR 1--
            '/\'\s*OR\s*\'.*\'\s*LIKE\s*\'.*%/i', // 'OR 'x' LIKE 'y%
            '/\'\s*AND\s*\(SELECT\s*\d+\s*FROM/i'  // 'AND (SELECT x FROM
        ];
        
        foreach ($suspiciousPatterns as $pattern) {
            if (preg_match($pattern, $input)) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * التحقق من هجمات XSS البسيطة
     * 
     * @param string $input النص المدخل
     * @return bool
     */
    public static function hasXss($input) {
        // قائمة بالعلامات والسمات المشبوهة
        $xssPatterns = [
            '/<script[^>]*>.*?<\/script>/is',   // <script> tags
            '/<\s*script.*?>/is',               // <script ...>
            '/<\s*iframe.*?>/is',               // <iframe ...>
            '/<\s*img.*?onerror.*?>/is',        // <img onerror=...>
            '/<\s*body.*?onload.*?>/is',        // <body onload=...>
            '/on(abort|blur|change|click|dblclick|error|focus|keydown|keypress|keyup|load|mousedown|mousemove|mouseout|mouseover|mouseup|reset|select|submit|unload)\s*=\s*([\'"])?.*?\2/is',  // event handlers
            '/javascript\s*:/is',               // javascript:
            '/vbscript\s*:/is',                 // vbscript:
            '/data\s*:/is',                     // data:
            '/expression\s*\(/is',              // expression(
            '/behaviour\s*:/is',                // behaviour:
            '/document\.cookie/is',             // document.cookie
            '/document\.location/is',           // document.location
            '/document\.write/is',              // document.write
            '/xhr\./is',                        // xhr.
            '/fetch\s*\(/is',                   // fetch(
            '/eval\s*\(/is',                    // eval(
            '/setTimeout\s*\(/is',              // setTimeout(
            '/setInterval\s*\(/is',             // setInterval(
            '/alert\s*\(/is',                   // alert(
            '/new\s+Function\s*\(/is'           // new Function(
        ];
        
        foreach ($xssPatterns as $pattern) {
            if (preg_match($pattern, $input)) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * توليد نص آمن لجلسات المستخدم
     * 
     * @return void
     */
    public static function secureSession() {
        // تعيين اسم الجلسة
        $sessionName = 'SECURE_SESSION';
        session_name($sessionName);
        
        // إعدادات آمنة للجلسات
        $cookieParams = session_get_cookie_params();
        $cookieSecure = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on');
        
        session_set_cookie_params(
            $cookieParams['lifetime'],
            $cookieParams['path'], 
            $cookieParams['domain'],
            $cookieSecure,
            true    // httponly flag
        );
        
        // بدء الجلسة
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        // تغيير معرف الجلسة في كل مرة
        if (!isset($_SESSION['initialized'])) {
            session_regenerate_id(true);
            $_SESSION['initialized'] = true;
        }
        
        // تعيين رؤوس أمان إضافية
        header('X-Frame-Options: SAMEORIGIN');
        header('X-XSS-Protection: 1; mode=block');
        header('X-Content-Type-Options: nosniff');
    }
}
