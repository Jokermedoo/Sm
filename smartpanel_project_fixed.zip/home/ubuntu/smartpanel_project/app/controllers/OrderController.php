<?php
namespace App\Controllers;

use App\Models\OrderModel;
use App\Models\ServiceModel;
use App\Models\UserModel;
use App\Models\PaymentModel;
use App\Helpers\Validator;
use App\Helpers\Security;
use App\Helpers\Logger;

/**
 * OrderController - Controlador para gestionar todas las operaciones relacionadas con pedidos
 * 
 * Este controlador maneja la creación, visualización, cancelación y gestión de pedidos
 * Implementa validación de entradas, verificación de permisos y manejo de errores
 */
class OrderController {
    private $orderModel;
    private $serviceModel;
    private $userModel;
    private $paymentModel;
    private $validator;
    private $logger;
    
    /**
     * Constructor - inicializa los modelos y helpers necesarios
     */
    public function __construct() {
        $this->orderModel = new OrderModel();
        $this->serviceModel = new ServiceModel();
        $this->userModel = new UserModel();
        $this->paymentModel = new PaymentModel();
        $this->validator = new Validator();
        $this->logger = new Logger();
    }
    
    /**
     * Método por defecto - muestra la lista de pedidos del usuario actual
     * 
     * @param array $request Datos de la petición
     * @return void
     */
    public function index($request) {
        // Verificar si el usuario está autenticado
        if (!isset($_SESSION['user_id'])) {
            $this->redirect('/auth/login?redirect=' . urlencode($_SERVER['REQUEST_URI']));
            return;
        }
        
        $userId = $_SESSION['user_id'];
        $page = isset($request['get']['page']) ? (int)$request['get']['page'] : 1;
        $limit = 20;
        $offset = ($page - 1) * $limit;
        
        // Filtros para la búsqueda
        $filters = [];
        $filters['user_id'] = $userId;
        
        if (isset($request['get']['status']) && !empty($request['get']['status'])) {
            $filters['status'] = Security::sanitize($request['get']['status']);
        }
        
        if (isset($request['get']['service']) && !empty($request['get']['service'])) {
            $filters['service_id'] = (int)$request['get']['service'];
        }
        
        // Obtener los pedidos según los filtros
        $orders = $this->orderModel->getOrdersByFilters($filters, $limit, $offset);
        $totalOrders = $this->orderModel->countOrdersByFilters($filters);
        $totalPages = ceil($totalOrders / $limit);
        
        // Obtener servicios para el filtro
        $services = $this->serviceModel->getAllServices();
        
        // Renderizar la vista
        $data = [
            'orders' => $orders,
            'services' => $services,
            'currentPage' => $page,
            'totalPages' => $totalPages,
            'filters' => $filters
        ];
        
        $this->render('orders/index', $data);
    }
    
    /**
     * Muestra el formulario para crear un nuevo pedido
     * 
     * @param array $request Datos de la petición
     * @return void
     */
    public function newOrder($request) {
        // Verificar si el usuario está autenticado
        if (!isset($_SESSION['user_id'])) {
            $this->redirect('/auth/login?redirect=' . urlencode($_SERVER['REQUEST_URI']));
            return;
        }
        
        $userId = $_SESSION['user_id'];
        $user = $this->userModel->getUserById($userId);
        
        // Obtener categorías y servicios
        $categories = $this->serviceModel->getAllCategories(true);
        $services = [];
        
        if (isset($request['get']['category']) && !empty($request['get']['category'])) {
            $categoryId = (int)$request['get']['category'];
            $services = $this->serviceModel->getServicesByCategory($categoryId, true);
        }
        
        // Renderizar la vista
        $data = [
            'categories' => $categories,
            'services' => $services,
            'user' => $user
        ];
        
        $this->render('orders/new', $data);
    }
    
    /**
     * Procesa la creación de un nuevo pedido
     * 
     * @param array $request Datos de la petición
     * @return void
     */
    public function createOrder($request) {
        // Verificar si el usuario está autenticado
        if (!isset($_SESSION['user_id'])) {
            $this->jsonResponse(['success' => false, 'message' => 'Usuario no autenticado'], 401);
            return;
        }
        
        // Verificar token CSRF
        if (!$this->validateCsrfToken($request)) {
            $this->jsonResponse(['success' => false, 'message' => 'Token de seguridad inválido'], 403);
            return;
        }
        
        $userId = $_SESSION['user_id'];
        $serviceId = isset($request['post']['service_id']) ? (int)$request['post']['service_id'] : 0;
        $quantity = isset($request['post']['quantity']) ? (int)$request['post']['quantity'] : 0;
        $link = isset($request['post']['link']) ? Security::sanitize($request['post']['link']) : '';
        
        // Validar los datos de entrada
        $errors = [];
        
        if (empty($serviceId)) {
            $errors[] = 'Debe seleccionar un servicio';
        }
        
        if (empty($quantity)) {
            $errors[] = 'Debe especificar una cantidad';
        }
        
        if (empty($link)) {
            $errors[] = 'Debe proporcionar un enlace';
        } elseif (!$this->validator->isValidUrl($link)) {
            $errors[] = 'El enlace proporcionado no es válido';
        }
        
        // Si hay errores, devolver respuesta de error
        if (!empty($errors)) {
            $this->jsonResponse(['success' => false, 'errors' => $errors], 400);
            return;
        }
        
        // Obtener el servicio
        $service = $this->serviceModel->getServiceById($serviceId);
        
        if (!$service) {
            $this->jsonResponse(['success' => false, 'message' => 'El servicio seleccionado no existe'], 404);
            return;
        }
        
        // Validar que la cantidad esté dentro de los límites
        if ($quantity < $service['min'] || $quantity > $service['max']) {
            $this->jsonResponse([
                'success' => false, 
                'message' => "La cantidad debe estar entre {$service['min']} y {$service['max']}"
            ], 400);
            return;
        }
        
        // Calcular el precio
        $price = $this->serviceModel->calculatePrice($serviceId, $quantity);
        
        // Comprobar si el usuario tiene saldo suficiente
        $user = $this->userModel->getUserById($userId);
        
        if ($user['balance'] < $price) {
            $this->jsonResponse([
                'success' => false, 
                'message' => 'Saldo insuficiente. Por favor recargue su cuenta.'
            ], 400);
            return;
        }
        
        // Preparar los datos del pedido
        $orderData = [
            'user_id' => $userId,
            'service_id' => $serviceId,
            'link' => $link,
            'quantity' => $quantity,
            'price' => $price,
            'status' => 'pending'
        ];
        
        // Crear el pedido
        try {
            $orderId = $this->orderModel->createOrder($orderData);
            
            if ($orderId) {
                // Registrar la actividad
                $this->logger->log("Usuario ID $userId creó un nuevo pedido ID $orderId", 'order', $userId);
                
                $this->jsonResponse([
                    'success' => true, 
                    'message' => 'Pedido creado correctamente',
                    'order_id' => $orderId
                ]);
            } else {
                $this->jsonResponse(['success' => false, 'message' => 'Error al crear el pedido'], 500);
            }
        } catch (\Exception $e) {
            $this->logger->log("Error al crear pedido: " . $e->getMessage(), 'error', $userId);
            $this->jsonResponse(['success' => false, 'message' => 'Error interno al procesar el pedido'], 500);
        }
    }
    
    /**
     * Muestra los detalles de un pedido específico
     * 
     * @param array $request Datos de la petición
     * @param int $orderId ID del pedido
     * @return void
     */
    public function viewOrder($request, $orderId = null) {
        // Verificar si el usuario está autenticado
        if (!isset($_SESSION['user_id'])) {
            $this->redirect('/auth/login?redirect=' . urlencode($_SERVER['REQUEST_URI']));
            return;
        }
        
        $userId = $_SESSION['user_id'];
        
        // Si no se proporciona ID, redirigir a la lista de pedidos
        if (!$orderId) {
            $this->redirect('/orders');
            return;
        }
        
        // Obtener el pedido
        $order = $this->orderModel->getOrderById($orderId);
        
        if (!$order) {
            $this->setFlashMessage('error', 'El pedido solicitado no existe');
            $this->redirect('/orders');
            return;
        }
        
        // Verificar que el pedido pertenezca al usuario actual o sea administrador
        if ($order['user_id'] != $userId && $_SESSION['user_role'] !== 'admin') {
            $this->setFlashMessage('error', 'No tiene permiso para ver este pedido');
            $this->redirect('/orders');
            return;
        }
        
        // Obtener el servicio asociado
        $service = $this->serviceModel->getServiceById($order['service_id']);
        
        // Obtener historial del pedido
        $history = $this->orderModel->getOrderHistory($orderId);
        
        // Renderizar la vista
        $data = [
            'order' => $order,
            'service' => $service,
            'history' => $history
        ];
        
        $this->render('orders/view', $data);
    }
    
    /**
     * Cancela un pedido si está en estado pendiente
     * 
     * @param array $request Datos de la petición
     * @return void
     */
    public function cancelOrder($request) {
        // Verificar si el usuario está autenticado
        if (!isset($_SESSION['user_id'])) {
            $this->jsonResponse(['success' => false, 'message' => 'Usuario no autenticado'], 401);
            return;
        }
        
        // Verificar token CSRF
        if (!$this->validateCsrfToken($request)) {
            $this->jsonResponse(['success' => false, 'message' => 'Token de seguridad inválido'], 403);
            return;
        }
        
        $userId = $_SESSION['user_id'];
        $orderId = isset($request['post']['order_id']) ? (int)$request['post']['order_id'] : 0;
        
        if (empty($orderId)) {
            $this->jsonResponse(['success' => false, 'message' => 'ID de pedido no proporcionado'], 400);
            return;
        }
        
        // Obtener el pedido
        $order = $this->orderModel->getOrderById($orderId);
        
        if (!$order) {
            $this->jsonResponse(['success' => false, 'message' => 'El pedido solicitado no existe'], 404);
            return;
        }
        
        // Verificar que el pedido pertenezca al usuario actual o sea administrador
        if ($order['user_id'] != $userId && $_SESSION['user_role'] !== 'admin') {
            $this->jsonResponse(['success' => false, 'message' => 'No tiene permiso para cancelar este pedido'], 403);
            return;
        }
        
        // Verificar que el pedido esté en estado cancelable
        $cancelableStatuses = ['pending', 'processing'];
        if (!in_array($order['status'], $cancelableStatuses)) {
            $this->jsonResponse(['success' => false, 'message' => 'Este pedido no se puede cancelar en su estado actual'], 400);
            return;
        }
        
        // Cancelar el pedido
        try {
            $result = $this->orderModel->updateOrderStatus($orderId, 'cancelled');
            
            if ($result) {
                // Devolver el saldo al usuario
                $this->userModel->updateUserBalance($userId, $order['price']);
                
                // Registrar la actividad
                $this->logger->log("Usuario ID $userId canceló el pedido ID $orderId", 'order', $userId);
                
                $this->jsonResponse(['success' => true, 'message' => 'Pedido cancelado correctamente']);
            } else {
                $this->jsonResponse(['success' => false, 'message' => 'Error al cancelar el pedido'], 500);
            }
        } catch (\Exception $e) {
            $this->logger->log("Error al cancelar pedido: " . $e->getMessage(), 'error', $userId);
            $this->jsonResponse(['success' => false, 'message' => 'Error interno al procesar la cancelación'], 500);
        }
    }
    
    /**
     * Método auxiliar para renderizar vistas
     * 
     * @param string $view Nombre de la vista
     * @param array $data Datos para la vista
     * @return void
     */
    private function render($view, $data = []) {
        // Extraer los datos para que estén disponibles en la vista
        extract($data);
        
        // Incluir el encabezado
        require_once VIEWS_PATH . '/includes/header.php';
        
        // Incluir la vista
        require_once VIEWS_PATH . "/" . $view . '.php';
        
        // Incluir el pie de página
        require_once VIEWS_PATH . '/includes/footer.php';
    }
    
    /**
     * Método auxiliar para redirigir
     * 
     * @param string $url URL de destino
     * @return void
     */
    private function redirect($url) {
        header('Location: ' . $url);
        exit;
    }
    
    /**
     * Método auxiliar para respuestas JSON
     * 
     * @param array $data Datos de respuesta
     * @param int $statusCode Código de estado HTTP
     * @return void
     */
    private function jsonResponse($data, $statusCode = 200) {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }
    
    /**
     * Método auxiliar para establecer mensajes flash
     * 
     * @param string $type Tipo de mensaje (success, error, warning, info)
     * @param string $message Contenido del mensaje
     * @return void
     */
    private function setFlashMessage($type, $message) {
        if (!isset($_SESSION['flash_messages'])) {
            $_SESSION['flash_messages'] = [];
        }
        
        $_SESSION['flash_messages'][] = [
            'type' => $type,
            'message' => $message
        ];
    }
    
    /**
     * Método auxiliar para validar token CSRF
     * 
     * @param array $request Datos de la petición
     * @return bool
     */
    private function validateCsrfToken($request) {
        if (!isset($_SESSION['csrf_token'])) {
            return false;
        }
        
        $token = isset($request['post']['csrf_token']) ? $request['post']['csrf_token'] : null;
        
        if (!$token) {
            $headers = getallheaders();
            $token = isset($headers['X-CSRF-Token']) ? $headers['X-CSRF-Token'] : null;
        }
        
        return $token && $token === $_SESSION['csrf_token'];
    }
}
هذه التنفيذات ستضيف خاصية السحب والإفلات لتطبيق SMM Panel بطريقة احترافية وسهلة الاستخدام. يمكن تطبيق هذه الميزات على أي جزء من التطبيق لتحسين تجربة المستخدم وجعل التفاعل أكثر سلاسة وكفاءة.