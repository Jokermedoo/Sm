<?php
/**
 * HomeController - متحكم الصفحة الرئيسية
 * يتعامل مع عرض الصفحة الرئيسية وصفحات المعلومات العامة
 */
namespace App\Controllers;

use App\Models\ServiceModel;
use App\Models\SettingsModel;

class HomeController {
    private $serviceModel;
    private $settingsModel;

    public function __construct() {
        $this->serviceModel = new ServiceModel();
        $this->settingsModel = new SettingsModel();
    }

    /**
     * عرض الصفحة الرئيسية
     */
    public function index() {
        // جلب إعدادات الموقع
        $siteSettings = $this->settingsModel->getAll();
        
        // جلب الخدمات المميزة
        $featuredServices = $this->getFeaturedServices();
        
        // استدعاء قالب الصفحة الرئيسية
        require_once VIEWS_PATH . '/templates/header.php';
        require_once VIEWS_PATH . '/home/index.php';
        require_once VIEWS_PATH . '/templates/footer.php';
    }
    
    /**
     * عرض صفحة الخدمات
     */
    public function services() {
        // جلب جميع الخدمات مصنفة حسب الفئة
        $categories = $this->getServiceCategories();
        $services = $this->getAllServices();
        
        // استدعاء قالب صفحة الخدمات
        require_once VIEWS_PATH . '/templates/header.php';
        require_once VIEWS_PATH . '/home/services.php';
        require_once VIEWS_PATH . '/templates/footer.php';
    }
    
    /**
     * عرض صفحة التسعير
     */
    public function pricing() {
        // جلب خطط التسعير
        $pricingPlans = $this->getPricingPlans();
        
        // استدعاء قالب صفحة التسعير
        require_once VIEWS_PATH . '/templates/header.php';
        require_once VIEWS_PATH . '/home/pricing.php';
        require_once VIEWS_PATH . '/templates/footer.php';
    }
    
    /**
     * عرض صفحة الأسئلة الشائعة
     */
    public function faq() {
        // جلب الأسئلة الشائعة
        $faqItems = $this->getFaqItems();
        
        // استدعاء قالب صفحة الأسئلة الشائعة
        require_once VIEWS_PATH . '/templates/header.php';
        require_once VIEWS_PATH . '/home/faq.php';
        require_once VIEWS_PATH . '/templates/footer.php';
    }
    
    /**
     * عرض صفحة الاتصال
     */
    public function contact() {
        // التحقق من إرسال نموذج الاتصال
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['contact_submit'])) {
            $this->processContactForm();
        }
        
        // استدعاء قالب صفحة الاتصال
        require_once VIEWS_PATH . '/templates/header.php';
        require_once VIEWS_PATH . '/home/contact.php';
        require_once VIEWS_PATH . '/templates/footer.php';
    }
    
    /**
     * عرض صفحة المدونة
     */
    public function blog() {
        // جلب منشورات المدونة
        $blogPosts = $this->getBlogPosts();
        
        // استدعاء قالب صفحة المدونة
        require_once VIEWS_PATH . '/templates/header.php';
        require_once VIEWS_PATH . '/home/blog.php';
        require_once VIEWS_PATH . '/templates/footer.php';
    }
    
    /**
     * عرض منشور مدونة محدد
     * @param int $id معرف المنشور
     */
    public function blogPost($id) {
        // جلب تفاصيل المنشور
        $post = $this->getBlogPostById($id);
        
        // التحقق من وجود المنشور
        if (!$post) {
            header('Location: ' . BASE_URL . '/home/blog');
            exit;
        }
        
        // استدعاء قالب صفحة تفاصيل المنشور
        require_once VIEWS_PATH . '/templates/header.php';
        require_once VIEWS_PATH . '/home/blog_post.php';
        require_once VIEWS_PATH . '/templates/footer.php';
    }
    
    /**
     * عرض صفحة الشروط والأحكام
     */
    public function terms() {
        // جلب الشروط والأحكام
        $terms = $this->getTermsAndConditions();
        
        // استدعاء قالب صفحة الشروط والأحكام
        require_once VIEWS_PATH . '/templates/header.php';
        require_once VIEWS_PATH . '/home/terms.php';
        require_once VIEWS_PATH . '/templates/footer.php';
    }
    
    /**
     * جلب إعدادات الموقع
     * @return array
     */
    private function getSiteSettings() {
        $db = connectDB();
        $stmt = $db->prepare("SELECT * FROM site_settings LIMIT 1");
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * جلب الخدمات المميزة
     * @return array
     */
    private function getFeaturedServices() {
        $db = connectDB();
        $stmt = $db->prepare("SELECT * FROM services WHERE is_featured = 1 AND status = 'active' LIMIT 6");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * جلب جميع الخدمات
     * @return array
     */
    private function getAllServices() {
        $db = connectDB();
        $stmt = $db->prepare("SELECT * FROM services WHERE status = 'active' ORDER BY category_id, name");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * جلب فئات الخدمات
     * @return array
     */
    private function getServiceCategories() {
        $db = connectDB();
        $stmt = $db->prepare("SELECT * FROM categories ORDER BY name");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * جلب خطط التسعير
     * @return array
     */
    private function getPricingPlans() {
        $db = connectDB();
        $stmt = $db->prepare("SELECT * FROM pricing_plans WHERE status = 'active' ORDER BY price");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * جلب الأسئلة الشائعة
     * @return array
     */
    private function getFaqItems() {
        $db = connectDB();
        $stmt = $db->prepare("SELECT * FROM faq ORDER BY display_order");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * معالجة نموذج الاتصال
     */
    private function processContactForm() {
        // التحقق من صحة البيانات
        $name = sanitize($_POST['name']);
        $email = sanitize($_POST['email']);
        $subject = sanitize($_POST['subject']);
        $message = sanitize($_POST['message']);
        
        if (empty($name) || empty($email) || empty($message)) {
            showError('جميع الحقول مطلوبة');
            return;
        }
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            showError('يرجى إدخال بريد إلكتروني صحيح');
            return;
        }
        
        // حفظ رسالة الاتصال في قاعدة البيانات
        $db = connectDB();
        $stmt = $db->prepare("INSERT INTO contact_messages (name, email, subject, message, created_at) VALUES (?, ?, ?, ?, NOW())");
        $success = $stmt->execute([$name, $email, $subject, $message]);
        
        if ($success) {
            // إرسال بريد إلكتروني بالرسالة (يمكن تنفيذه لاحقًا)
            showSuccess('تم إرسال رسالتك بنجاح. سنتواصل معك قريبًا.');
        } else {
            showError('حدث خطأ أثناء إرسال الرسالة. يرجى المحاولة مرة أخرى.');
        }
    }
    
    /**
     * جلب منشورات المدونة
     * @return array
     */
    private function getBlogPosts() {
        $db = connectDB();
        $stmt = $db->prepare("SELECT * FROM blog_posts WHERE status = 'published' ORDER BY created_at DESC");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * جلب منشور مدونة محدد
     * @param int $id معرف المنشور
     * @return array|bool
     */
    private function getBlogPostById($id) {
        $db = connectDB();
        $stmt = $db->prepare("SELECT * FROM blog_posts WHERE id = ? AND status = 'published'");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * جلب الشروط والأحكام
     * @return string
     */
    private function getTermsAndConditions() {
        $db = connectDB();
        $stmt = $db->prepare("SELECT content FROM pages WHERE slug = 'terms'");
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ? $result['content'] : '';
    }
}
