<?php
/**
 * APIController
 * المتحكم الخاص بواجهة برمجة التطبيقات (API)
 */
class APIController extends BaseAPIController {
    private $userModel;
    private $serviceModel;
    private $orderModel;
    private $transactionModel;
    
    /**
     * إنشاء نموذج المتحكم
     */
    public function __construct() {
        parent::__construct(); // Call parent constructor
        $this->userModel = new UserModel();
        $this->serviceModel = new ServiceModel();
        $this->orderModel = new OrderModel();
        $this->transactionModel = new TransactionModel();
    }
    
    /**
     * الحصول على معلومات الحساب
     */
    public function getAccountInfo() {
        $user_id = $this->validateApiKey();
        
        if (!$user_id) {
            return;
        }
        
        // جلب معلومات المستخدم
        $user = $this->userModel->getUserById($user_id);
        
        if (!$user) {
            $this->sendError('User not found', 404);
            return;
        }
        
        // إعداد البيانات للاستجابة
        $data = [
            'username' => $user['username'],
            'email' => $user['email'],
            'balance' => $user['balance'],
            'currency' => CURRENCY_CODE,
            'created_at' => $user['created_at']
        ];
        
        $this->sendResponse($data);
    }
    
    /**
     * الحصول على قائمة الخدمات
     */
    public function getServices() {
        $user_id = $this->validateApiKey();
        
        if (!$user_id) {
            return;
        }
        
        // جلب جميع الخدمات النشطة
        $services = $this->serviceModel->getAllServices(true);
        
        if (!$services) {
            $this->sendError('No services found', 404);
            return;
        }
        
        // تنسيق البيانات
        $formatted_services = [];
        foreach ($services as $service) {
            $formatted_services[] = [
                'id' => $service['id'],
                'name' => $service['name'],
                'category' => $service['category_name'],
                'price' => $service['price'],
                'min' => $service['min'],
                'max' => $service['max'],
                'description' => $service['description']
            ];
        }
        
        $this->sendResponse($formatted_services);
    }
    
    /**
     * إنشاء طلب جديد
     */
    public function createOrder() {
        $user_id = $this->validateApiKey();
        
        if (!$user_id) {
            return;
        }
        
        // التحقق من البيانات المطلوبة
        $service_id = isset($_REQUEST['service']) ? (int)$_REQUEST['service'] : 0;
        $link = isset($_REQUEST['link']) ? $_REQUEST['link'] : '';
        $quantity = isset($_REQUEST['quantity']) ? (int)$_REQUEST['quantity'] : 0;
        
        if (empty($service_id) || empty($link) || empty($quantity)) {
            $this->sendError('service, link, and quantity are required');
            return;
        }
        
        // جلب معلومات الخدمة
        $service = $this->serviceModel->getServiceById($service_id);
        
        if (!$service) {
            $this->sendError('Service not found', 404);
            return;
        }
        
        // التحقق من الكمية
        if ($quantity < $service['min'] || $quantity > $service['max']) {
            $this->sendError('Quantity should be between ' . $service['min'] . ' and ' . $service['max']);
            return;
        }
        
        // حساب السعر
        $price = $this->serviceModel->calculatePrice($service_id, $quantity);
        
        // التحقق من الرصيد
        $user = $this->userModel->getUserById($user_id);
        
        if ($user['balance'] < $price) {
            $this->sendError('Insufficient balance');
            return;
        }
        
        // إنشاء الطلب
        $order_data = [
            'user_id' => $user_id,
            'service_id' => $service_id,
            'link' => $link,
            'quantity' => $quantity,
            'price' => $price,
            'status' => 'pending'
        ];
        
        $order_id = $this->orderModel->createOrder($order_data);
        
        if (!$order_id) {
            $this->sendError('Failed to create order');
            return;
        }
        
        // خصم من رصيد المستخدم
        $this->userModel->updateBalance($user_id, -$price);
        
        // إنشاء معاملة
        $transaction_data = [
            'user_id' => $user_id,
            'amount' => $price,
            'type' => 'order',
            'status' => 'completed',
            'description' => 'API Order #' . $order_id,
            'order_id' => $order_id
        ];
        
        $this->transactionModel->createTransaction($transaction_data);
        
        // إعداد البيانات للاستجابة
        $data = [
            'order_id' => $order_id,
            'price' => $price,
            'currency' => CURRENCY_CODE,
            'status' => 'pending'
        ];
        
        $this->sendResponse($data);
    }
    
    /**
     * الحصول على حالة الطلب
     */
    public function getOrderStatus() {
        $user_id = $this->validateApiKey();
        
        if (!$user_id) {
            return;
        }
        
        // التحقق من معرف الطلب
        $order_id = isset($_REQUEST['order_id']) ? (int)$_REQUEST['order_id'] : 0;
        
        if (empty($order_id)) {
            $this->sendError('order_id is required');
            return;
        }
        
        // جلب معلومات الطلب
        $order = $this->orderModel->getOrderById($order_id);
        
        if (!$order) {
            $this->sendError('Order not found', 404);
            return;
        }
        
        // التحقق من ملكية الطلب
        if ($order['user_id'] != $user_id) {
            $this->sendError('You do not have permission to view this order', 403);
            return;
        }
        
        // إعداد البيانات للاستجابة
        $data = [
            'order_id' => $order['id'],
            'status' => $order['status'],
            'service' => $order['service_name'],
            'link' => $order['link'],
            'quantity' => $order['quantity'],
            'remains' => $order['remains'],
            'start_count' => $order['start_count'],
            'price' => $order['price'],
            'currency' => CURRENCY_CODE,
            'created_at' => $order['created_at']
        ];
        
        $this->sendResponse($data);
    }
    
    /**
     * الحصول على معلومات متعددة للطلبات
     */
    public function getMultipleOrdersStatus() {
        $user_id = $this->validateApiKey();
        
        if (!$user_id) {
            return;
        }
        
        // التحقق من معرفات الطلبات
        $order_ids = isset($_REQUEST['order_ids']) ? $_REQUEST['order_ids'] : '';
        
        if (empty($order_ids)) {
            $this->sendError('order_ids is required');
            return;
        }
        
        // تحويل النص إلى مصفوفة
        if (is_string($order_ids)) {
            $order_ids = explode(',', $order_ids);
        }
        
        // التحقق من صحة المصفوفة
        if (!is_array($order_ids) || count($order_ids) == 0) {
            $this->sendError('Invalid order_ids format');
            return;
        }
        
        // الحد الأقصى لعدد الطلبات
        if (count($order_ids) > 100) {
            $this->sendError('You can check up to 100 orders at once');
            return;
        }
        
        // جلب معلومات الطلبات
        $orders_data = [];
        
        foreach ($order_ids as $order_id) {
            $order = $this->orderModel->getOrderById((int)$order_id);
            
            if ($order && $order['user_id'] == $user_id) {
                $orders_data[$order_id] = [
                    'status' => $order['status'],
                    'remains' => $order['remains'],
                    'start_count' => $order['start_count']
                ];
            }
        }
        
        $this->sendResponse($orders_data);
    }
    
    /**
     * إلغاء طلب
     */
    public function cancelOrder() {
        $user_id = $this->validateApiKey();
        
        if (!$user_id) {
            return;
        }
        
        // التحقق من معرف الطلب
        $order_id = isset($_REQUEST['order_id']) ? (int)$_REQUEST['order_id'] : 0;
        
        if (empty($order_id)) {
            $this->sendError('order_id is required');
            return;
        }
        
        // جلب معلومات الطلب
        $order = $this->orderModel->getOrderById($order_id);
        
        if (!$order) {
            $this->sendError('Order not found', 404);
            return;
        }
        
        // التحقق من ملكية الطلب
        if ($order['user_id'] != $user_id) {
            $this->sendError('You do not have permission to cancel this order', 403);
            return;
        }
        
        // التحقق من حالة الطلب
        if ($order['status'] != 'pending') {
            $this->sendError('Only pending orders can be canceled');
            return;
        }
        
        // إلغاء الطلب
        $result = $this->orderModel->updateOrderStatus($order_id, 'canceled');
        
        if (!$result) {
            $this->sendError('Failed to cancel the order');
            return;
        }
        
        // إعادة المبلغ إلى رصيد المستخدم
        $this->userModel->updateBalance($user_id, $order['price']);
        
        // إنشاء معاملة استرداد
        $transaction_data = [
            'user_id' => $user_id,
            'amount' => $order['price'],
            'type' => 'refund',
            'status' => 'completed',
            'description' => 'Refund for Order #' . $order_id,
            'order_id' => $order_id
        ];
        
        $this->transactionModel->createTransaction($transaction_data);
        
        $this->sendResponse(['message' => 'Order has been canceled successfully']);
    }
    
    /**
     * الحصول على رصيد الحساب
     */
    public function getBalance() {
        $user_id = $this->validateApiKey();
        
        if (!$user_id) {
            return;
        }
        
        // جلب معلومات المستخدم
        $user = $this->userModel->getUserById($user_id);
        
        if (!$user) {
            $this->sendError('User not found', 404);
            return;
        }
        
        // إعداد البيانات للاستجابة
        $data = [
            'balance' => $user['balance'],
            'currency' => CURRENCY_CODE
        ];
        
        $this->sendResponse($data);
    }
}