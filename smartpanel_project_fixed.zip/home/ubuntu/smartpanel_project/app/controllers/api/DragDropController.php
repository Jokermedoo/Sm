<?php
/**
 * Drag and Drop Controller
 * 
 * Handles API endpoints for drag and drop functionality
 * including reordering items, updating statuses, and category changes
 */

namespace App\Controllers\Api;

use App\Models\OrderModel;
use App\Models\ServiceModel;
use App\Models\CategoryModel;
use App\Models\UserPreferencesModel;
use App\Helpers\Security;
use App\Helpers\Response;

class DragDropController {
    private $orderModel;
    private $serviceModel;
    private $categoryModel;
    private $userPreferencesModel;
    
    public function __construct() {
        $this->orderModel = new OrderModel();
        $this->serviceModel = new ServiceModel();
        $this->categoryModel = new CategoryModel();
        $this->userPreferencesModel = new UserPreferencesModel();
    }
    
    /**
     * Update the order of widgets in the dashboard
     * 
     * @param array $request Request data
     * @return array Response
     */
    public function updateWidgetOrder($request) {
        // Validate request
        if (!isset($request['post']['widgets']) || !is_array($request['post']['widgets'])) {
            return Response::json(false, 'بيانات غير صالحة');
        }
        
        // Validate CSRF token
        if (!$this->validateCsrfToken($request)) {
            return Response::json(false, 'توكن CSRF غير صالح');
        }
        
        // Get user ID from session
        $userId = $_SESSION['user_id'] ?? 0;
        if (!$userId) {
            return Response::json(false, 'يجب تسجيل الدخول');
        }
        
        $widgets = $request['post']['widgets'];
        
        try {
            $result = $this->userPreferencesModel->updateWidgetOrder($userId, $widgets);
            
            if ($result) {
                return Response::json(true, 'تم تحديث ترتيب لوحة المعلومات بنجاح');
            } else {
                return Response::json(false, 'فشل تحديث ترتيب لوحة المعلومات');
            }
        } catch (\Exception $e) {
            error_log('Error updating widget order: ' . $e->getMessage());
            return Response::json(false, 'حدث خطأ أثناء تحديث ترتيب لوحة المعلومات');
        }
    }
    
    /**
     * Update the order of categories
     * 
     * @param array $request Request data
     * @return array Response
     */
    public function updateCategoryOrder($request) {
        // Validate request
        if (!isset($request['post']['categories']) || !is_array($request['post']['categories'])) {
            return Response::json(false, 'بيانات غير صالحة');
        }
        
        // Validate CSRF token
        if (!$this->validateCsrfToken($request)) {
            return Response::json(false, 'توكن CSRF غير صالح');
        }
        
        // Validate admin permissions
        if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
            return Response::json(false, 'ليس لديك صلاحية للقيام بهذا الإجراء');
        }
        
        $categories = $request['post']['categories'];
        
        try {
            $result = $this->categoryModel->updateCategoriesOrder($categories);
            
            if ($result) {
                return Response::json(true, 'تم تحديث ترتيب الفئات بنجاح');
            } else {
                return Response::json(false, 'فشل تحديث ترتيب الفئات');
            }
        } catch (\Exception $e) {
            error_log('Error updating category order: ' . $e->getMessage());
            return Response::json(false, 'حدث خطأ أثناء تحديث ترتيب الفئات');
        }
    }
    
    /**
     * Update the order of services within categories
     * 
     * @param array $request Request data
     * @return array Response
     */
    public function updateServiceOrder($request) {
        // Validate request
        if (!isset($request['post']['services']) || !is_array($request['post']['services'])) {
            return Response::json(false, 'بيانات غير صالحة');
        }
        
        // Validate CSRF token
        if (!$this->validateCsrfToken($request)) {
            return Response::json(false, 'توكن CSRF غير صالح');
        }
        
        // Validate admin permissions
        if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
            return Response::json(false, 'ليس لديك صلاحية للقيام بهذا الإجراء');
        }
        
        $services = $request['post']['services'];
        $categoryChanged = $request['post']['category_changed'] ?? false;
        $oldCategoryId = $request['post']['old_category_id'] ?? null;
        $newCategoryId = $request['post']['new_category_id'] ?? null;
        
        try {
            $result = $this->serviceModel->updateServicesOrder($services, $categoryChanged, $oldCategoryId, $newCategoryId);
            
            if ($result) {
                if ($categoryChanged) {
                    return Response::json(true, 'تم نقل الخدمة وتحديث الترتيب بنجاح');
                } else {
                    return Response::json(true, 'تم تحديث ترتيب الخدمات بنجاح');
                }
            } else {
                return Response::json(false, 'فشل تحديث ترتيب الخدمات');
            }
        } catch (\Exception $e) {
            error_log('Error updating service order: ' . $e->getMessage());
            return Response::json(false, 'حدث خطأ أثناء تحديث ترتيب الخدمات');
        }
    }
    
    /**
     * Update order status via drag and drop
     * 
     * @param array $request Request data
     * @return array Response
     */
    public function updateOrderStatus($request) {
        // Validate request
        if (!isset($request['post']['order_id']) || !isset($request['post']['status'])) {
            return Response::json(false, 'بيانات غير صالحة');
        }
        
        // Validate CSRF token
        if (!$this->validateCsrfToken($request)) {
            return Response::json(false, 'توكن CSRF غير صالح');
        }
        
        // Validate admin permissions
        if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
            return Response::json(false, 'ليس لديك صلاحية للقيام بهذا الإجراء');
        }
        
        $orderId = (int) $request['post']['order_id'];
        $status = Security::sanitize($request['post']['status']);
        
        // Validate status
        $validStatuses = ['pending', 'processing', 'completed', 'failed', 'cancelled', 'refunded'];
        if (!in_array($status, $validStatuses)) {
            return Response::json(false, 'حالة غير صالحة');
        }
        
        try {
            $result = $this->orderModel->updateOrderStatus($orderId, $status);
            
            if ($result) {
                // Get status text for display
                $statusText = $this->getStatusText($status);
                return Response::json(true, "تم تحديث حالة الطلب إلى \"$statusText\"");
            } else {
                return Response::json(false, 'فشل تحديث حالة الطلب');
            }
        } catch (\Exception $e) {
            error_log('Error updating order status: ' . $e->getMessage());
            return Response::json(false, 'حدث خطأ أثناء تحديث حالة الطلب');
        }
    }
    
    /**
     * Update the order of general sortable lists
     * 
     * @param array $request Request data
     * @return array Response
     */
    public function updateListOrder($request) {
        // Validate request
        if (!isset($request['post']['items']) || !is_array($request['post']['items']) || !isset($request['post']['list_type'])) {
            return Response::json(false, 'بيانات غير صالحة');
        }
        
        // Validate CSRF token
        if (!$this->validateCsrfToken($request)) {
            return Response::json(false, 'توكن CSRF غير صالح');
        }
        
        $items = $request['post']['items'];
        $listType = Security::sanitize($request['post']['list_type']);
        
        try {
            $result = false;
            
            // Route to the appropriate model method based on list type
            switch ($listType) {
                case 'faq':
                    $result = $this->updateFaqOrder($items);
                    break;
                case 'payment_methods':
                    $result = $this->updatePaymentMethodsOrder($items);
                    break;
                case 'custom_pages':
                    $result = $this->updateCustomPagesOrder($items);
                    break;
                default:
                    return Response::json(false, 'نوع قائمة غير معروف');
            }
            
            if ($result) {
                return Response::json(true, 'تم تحديث الترتيب بنجاح');
            } else {
                return Response::json(false, 'فشل تحديث الترتيب');
            }
        } catch (\Exception $e) {
            error_log('Error updating list order: ' . $e->getMessage());
            return Response::json(false, 'حدث خطأ أثناء تحديث الترتيب');
        }
    }
    
    /**
     * Helper method to update FAQ order
     * 
     * @param array $items Items with id and order
     * @return bool Success status
     */
    private function updateFaqOrder($items) {
        // Implementation would go here
        // For now, just return true for demonstration
        return true;
    }
    
    /**
     * Helper method to update payment methods order
     * 
     * @param array $items Items with id and order
     * @return bool Success status
     */
    private function updatePaymentMethodsOrder($items) {
        // Implementation would go here
        // For now, just return true for demonstration
        return true;
    }
    
    /**
     * Helper method to update custom pages order
     * 
     * @param array $items Items with id and order
     * @return bool Success status
     */
    private function updateCustomPagesOrder($items) {
        // Implementation would go here
        // For now, just return true for demonstration
        return true;
    }
    
    /**
     * Get status text based on status code
     * 
     * @param string $status Status code
     * @return string Status text
     */
    private function getStatusText($status) {
        $statusMap = [
            'pending' => 'قيد الانتظار',
            'processing' => 'قيد المعالجة',
            'completed' => 'مكتمل',
            'failed' => 'فشل',
            'cancelled' => 'ملغي',
            'refunded' => 'مسترد'
        ];
        
        return $statusMap[$status] ?? $status;
    }
    
    /**
     * Helper method to validate CSRF token
     * 
     * @param array $request Request data
     * @return bool
     */
    private function validateCsrfToken($request) {
        if (!isset($_SESSION['csrf_token'])) {
            return false;
        }
        
        $token = isset($request['post']['csrf_token']) ? $request['post']['csrf_token'] : null;
        
        if (!$token) {
            $headers = getallheaders();
            $token = isset($headers['X-CSRF-Token']) ? $headers['X-CSRF-Token'] : null;
        }
        
        return $token && $token === $_SESSION['csrf_token'];
    }
}
