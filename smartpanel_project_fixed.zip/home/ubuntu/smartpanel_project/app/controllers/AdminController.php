<?php
/**
 * AdminController - متحكم لوحة الإدارة
 * يدير جميع وظائف لوحة التحكم للمسؤولين
 */
class AdminController {
    private $userModel;
    private $orderModel;
    private $serviceModel;
    private $transactionModel;
    private $ticketModel;
    private $settingsModel;
    
    /**
     * إنشاء كائن AdminController
     */
    public function __construct() {
        // التحقق من صلاحيات المسؤول
        if (!isAdmin()) {
            redirect(BASE_URL . '/dashboard');
        }
        
        // تهيئة النماذج
        $this->userModel = new UserModel();
        $this->orderModel = new OrderModel();
        $this->serviceModel = new ServiceModel();
        $this->transactionModel = new TransactionModel();
        $this->ticketModel = new TicketModel();
        $this->settingsModel = new SettingsModel();
    }
    
    /**
     * عرض لوحة التحكم الرئيسية
     */
    public function index() {
        try {
            // إحصائيات عامة
            $stats = [
                'total_users' => $this->userModel->getTotalUsers(),
                'total_orders' => $this->orderModel->getTotalOrders(),
                'total_revenue' => $this->transactionModel->getTotalRevenue(),
                'pending_tickets' => $this->ticketModel->getPendingTicketsCount(),
                'active_services' => $this->serviceModel->getActiveServicesCount()
            ];
            
            // آخر الطلبات
            $recent_orders = $this->orderModel->getRecentOrders(5);
            
            // آخر المعاملات
            $recent_transactions = $this->transactionModel->getRecentTransactions(5);
            
            // آخر التذاكر
            $recent_tickets = $this->ticketModel->getRecentTickets(5);
            
            // عرض الصفحة
            require_once VIEWS_PATH . '/admin/dashboard.php';
            
        } catch (Exception $e) {
            logActivity("خطأ في لوحة الإدارة: " . $e->getMessage(), 'error');
            showError('حدث خطأ أثناء تحميل لوحة التحكم');
            redirect(BASE_URL . '/dashboard');
        }
    }
    
    /**
     * إدارة المستخدمين
     */
    public function users() {
        try {
            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            $search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
            
            $users = $this->userModel->getAllUsers($page, ITEMS_PER_PAGE, $search);
            $total_users = $this->userModel->getTotalUsers($search);
            $total_pages = ceil($total_users / ITEMS_PER_PAGE);
            
            require_once VIEWS_PATH . '/admin/users.php';
            
        } catch (Exception $e) {
            logActivity("خطأ في إدارة المستخدمين: " . $e->getMessage(), 'error');
            showError('حدث خطأ أثناء تحميل صفحة المستخدمين');
            redirect(BASE_URL . '/admin');
        }
    }
    
    /**
     * إدارة الخدمات
     */
    public function services() {
        try {
            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            $search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
            
            $services = $this->serviceModel->getAllServices($page, ITEMS_PER_PAGE, $search);
            $total_services = $this->serviceModel->getTotalServices($search);
            $total_pages = ceil($total_services / ITEMS_PER_PAGE);
            
            require_once VIEWS_PATH . '/admin/services.php';
            
        } catch (Exception $e) {
            logActivity("خطأ في إدارة الخدمات: " . $e->getMessage(), 'error');
            showError('حدث خطأ أثناء تحميل صفحة الخدمات');
            redirect(BASE_URL . '/admin');
        }
    }
    
    /**
     * إدارة الطلبات
     */
    public function orders() {
        try {
            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            $status = isset($_GET['status']) ? sanitize($_GET['status']) : '';
            $search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
            
            $orders = $this->orderModel->getAllOrders($page, ITEMS_PER_PAGE, $status, $search);
            $total_orders = $this->orderModel->getTotalOrders($status, $search);
            $total_pages = ceil($total_orders / ITEMS_PER_PAGE);
            
            require_once VIEWS_PATH . '/admin/orders.php';
            
        } catch (Exception $e) {
            logActivity("خطأ في إدارة الطلبات: " . $e->getMessage(), 'error');
            showError('حدث خطأ أثناء تحميل صفحة الطلبات');
            redirect(BASE_URL . '/admin');
        }
    }
    
    /**
     * إدارة التذاكر
     */
    public function tickets() {
        try {
            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            $status = isset($_GET['status']) ? sanitize($_GET['status']) : '';
            $search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
            
            $tickets = $this->ticketModel->getAllTickets($page, ITEMS_PER_PAGE, $status, $search);
            $total_tickets = $this->ticketModel->getTotalTickets($status, $search);
            $total_pages = ceil($total_tickets / ITEMS_PER_PAGE);
            
            require_once VIEWS_PATH . '/admin/tickets.php';
            
        } catch (Exception $e) {
            logActivity("خطأ في إدارة التذاكر: " . $e->getMessage(), 'error');
            showError('حدث خطأ أثناء تحميل صفحة التذاكر');
            redirect(BASE_URL . '/admin');
        }
    }
    
    /**
     * إدارة المعاملات
     */
    public function transactions() {
        try {
            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            $type = isset($_GET['type']) ? sanitize($_GET['type']) : '';
            $search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
            
            $transactions = $this->transactionModel->getAllTransactions($page, ITEMS_PER_PAGE, $type, $search);
            $total_transactions = $this->transactionModel->getTotalTransactions($type, $search);
            $total_pages = ceil($total_transactions / ITEMS_PER_PAGE);
            
            require_once VIEWS_PATH . '/admin/transactions.php';
            
        } catch (Exception $e) {
            logActivity("خطأ في إدارة المعاملات: " . $e->getMessage(), 'error');
            showError('حدث خطأ أثناء تحميل صفحة المعاملات');
            redirect(BASE_URL . '/admin');
        }
    }
    
    /**
     * إعدادات النظام
     */
    public function settings() {
        try {
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                // التحقق من رمز CSRF
                if (!validateCsrfToken($_POST['csrf_token'])) {
                    throw new Exception('رمز CSRF غير صالح');
                }
                
                // تحديث الإعدادات
                $settings = [
                    'site_name' => sanitize($_POST['site_name']),
                    'site_description' => sanitize($_POST['site_description']),
                    'maintenance_mode' => isset($_POST['maintenance_mode']),
                    'registration_enabled' => isset($_POST['registration_enabled']),
                    'min_deposit' => (float)$_POST['min_deposit'],
                    'max_deposit' => (float)$_POST['max_deposit'],
                    'currency' => sanitize($_POST['currency']),
                    'timezone' => sanitize($_POST['timezone'])
                ];
                
                $this->settingsModel->updateSettings($settings);
                showSuccess('تم تحديث الإعدادات بنجاح');
                redirect(BASE_URL . '/admin/settings');
            }
            
            $settings = $this->settingsModel->getAllSettings();
            require_once VIEWS_PATH . '/admin/settings.php';
            
        } catch (Exception $e) {
            logActivity("خطأ في إعدادات النظام: " . $e->getMessage(), 'error');
            showError('حدث خطأ أثناء تحديث الإعدادات');
            redirect(BASE_URL . '/admin/settings');
        }
    }
    
    /**
     * سجلات النظام
     */
    public function logs() {
        try {
            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            $level = isset($_GET['level']) ? sanitize($_GET['level']) : '';
            $search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
            
            $logs = $this->getSystemLogs($page, ITEMS_PER_PAGE, $level, $search);
            $total_logs = $this->getTotalLogs($level, $search);
            $total_pages = ceil($total_logs / ITEMS_PER_PAGE);
            
            require_once VIEWS_PATH . '/admin/logs.php';
            
        } catch (Exception $e) {
            logActivity("خطأ في عرض السجلات: " . $e->getMessage(), 'error');
            showError('حدث خطأ أثناء تحميل صفحة السجلات');
            redirect(BASE_URL . '/admin');
        }
    }
    
    /**
     * الحصول على سجلات النظام
     */
    private function getSystemLogs($page, $per_page, $level = '', $search = '') {
        $offset = ($page - 1) * $per_page;
        $log_file = LOGS_PATH . '/' . date('Y-m-d') . '.log';
        
        if (!file_exists($log_file)) {
            return [];
        }
        
        $logs = [];
        $lines = file($log_file);
        $lines = array_reverse($lines);
        
        foreach ($lines as $line) {
            if ($level && strpos($line, "[$level]") === false) {
                continue;
            }
            
            if ($search && stripos($line, $search) === false) {
                continue;
            }
            
            $logs[] = $line;
            
            if (count($logs) >= $per_page) {
                break;
            }
        }
        
        return $logs;
    }
    
    /**
     * الحصول على إجمالي عدد السجلات
     */
    private function getTotalLogs($level = '', $search = '') {
        $log_file = LOGS_PATH . '/' . date('Y-m-d') . '.log';
        
        if (!file_exists($log_file)) {
            return 0;
        }
        
        $count = 0;
        $lines = file($log_file);
        
        foreach ($lines as $line) {
            if ($level && strpos($line, "[$level]") === false) {
                continue;
            }
            
            if ($search && stripos($line, $search) === false) {
                continue;
            }
            
            $count++;
        }
        
        return $count;
    }
}
