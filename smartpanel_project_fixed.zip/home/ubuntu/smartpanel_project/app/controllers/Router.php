<?php
namespace App\Controllers;

/**
 * Router Class - موجه الطلبات الرئيسي للتطبيق
 */
class Router {
    private $controller = 'HomeController';
    private $method = 'index';
    private $params = [];
    private $namespace = 'App\\Controllers\\';
    
    /**
     * معالجة الطلب الحالي
     */
    public function handleRequest() {
        try {
            $url = $this->parseUrl();
            
            // التحقق من وجود المتحكم
            if (isset($url[0])) {
                $controllerName = ucfirst($url[0]) . 'Controller';
                $controllerFile = CONTROLLERS_PATH . '/' . $controllerName . '.php';
                
                if (file_exists($controllerFile)) {
                    $this->controller = $controllerName;
                    unset($url[0]);
                }
            }
            
            // تحميل المتحكم
            $controller = $this->namespace . $this->controller;
            
            // التحقق من وجود الفئة
            if (!class_exists($this->controller)) {
                throw new Exception('المتحكم غير موجود: ' . $this->controller);
            }
        
        // إنشاء كائن المتحكم
        $this->controller = new $this->controller();
        
        // التحقق من وجود الإجراء المطلوب
        if (isset($url[1]) && method_exists($this->controller, $url[1])) {
            $this->method = $url[1];
            unset($url[1]);
        }
        
        // الحصول على المعلمات إن وجدت
        $this->params = $url ? array_values($url) : [];
            
        } catch (Exception $e) {
            logActivity("خطأ في التوجيه: " . $e->getMessage(), 'error');
            $this->handleError($e);
        }
    }
    
    /**
     * تحليل URL وتقسيمه إلى أجزاء
     * @return array
     */
    private function parseUrl() {
        if (isset($_GET['url'])) {
            $url = filter_var(rtrim($_GET['url'], '/'), FILTER_SANITIZE_URL);
            if ($url === false) {
                throw new Exception('URL غير صالح');
            }
            return explode('/', $url);
        }
        return [];
    }
    
    /**
     * استدعاء المتحكم والإجراء المناسبين مع المعلمات
     */
    public function route() {
        try {
        // التحقق من وضع الصيانة
        if (MAINTENANCE_MODE && !$this->isMaintenanceExempt()) {
            require_once VIEWS_PATH . '/maintenance.php';
            exit;
        }
        
            // التحقق من وجود الإجراء
            if (!method_exists($this->controller, $this->method)) {
                throw new Exception('الإجراء غير موجود: ' . $this->method);
            }
            
            // التحقق من صلاحيات الوصول
            if (!$this->checkAccess()) {
                throw new Exception('غير مصرح لك بالوصول إلى هذه الصفحة');
            }
            
            // استدعاء الإجراء
        call_user_func_array([$this->controller, $this->method], $this->params);
            
        } catch (Exception $e) {
            logActivity("خطأ في التوجيه: " . $e->getMessage(), 'error');
            $this->handleError($e);
        }
    }
    
    /**
     * التحقق من استثناءات وضع الصيانة (مثل المسؤول)
     * @return bool
     */
    private function isMaintenanceExempt() {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
    }
    
    /**
     * التحقق من صلاحيات الوصول
     * @return bool
     */
    private function checkAccess() {
        // التحقق من تسجيل الدخول للصفحات المحمية
        $protectedControllers = ['DashboardController', 'AdminController', 'ProfileController'];
        $publicMethods = ['login', 'register', 'forgotPassword', 'resetPassword'];
        
        if (in_array($this->controller, $protectedControllers) && !in_array($this->method, $publicMethods)) {
            if (!isLoggedIn()) {
                redirect(BASE_URL . '/auth/login');
                return false;
            }
        }
        
        // التحقق من صلاحيات المسؤول
        $adminControllers = ['AdminController'];
        if (in_array($this->controller, $adminControllers) && !isAdmin()) {
            redirect(BASE_URL . '/dashboard');
            return false;
        }
        
        return true;
    }
    
    /**
     * معالجة الأخطاء
     * @param Exception $e
     */
    private function handleError($e) {
        if (DEBUG_MODE) {
            die("خطأ: " . $e->getMessage());
        } else {
            // تسجيل الخطأ
            logActivity($e->getMessage(), 'error');
            
            // عرض صفحة الخطأ
            require_once VIEWS_PATH . '/error.php';
            exit;
        }
    }
}
