<?php
/**
 * AuthController - متحكم المصادقة
 * يتعامل مع تسجيل الدخول، تسجيل مستخدم جديد، وتسجيل الخروج
 */
class AuthController {
    /**
     * عرض صفحة تسجيل الدخول
     */
    public function login() {
        // التحقق مما إذا كان المستخدم مسجل الدخول بالفعل
        if (isLoggedIn()) {
            redirect(BASE_URL . '/dashboard');
        }
        
        // التحقق من إرسال نموذج تسجيل الدخول
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login_submit'])) {
            $this->processLoginForm();
        }
        
        // استدعاء قالب صفحة تسجيل الدخول
        require_once VIEWS_PATH . '/templates/header.php';
        require_once VIEWS_PATH . '/auth/login.php';
        require_once VIEWS_PATH . '/templates/footer.php';
    }
    
    /**
     * عرض صفحة تسجيل مستخدم جديد
     */
    public function register() {
        // التحقق مما إذا كان المستخدم مسجل الدخول بالفعل
        if (isLoggedIn()) {
            redirect(BASE_URL . '/dashboard');
        }
        
        // التحقق من إرسال نموذج التسجيل
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register_submit'])) {
            $this->processRegisterForm();
        }
        
        // استدعاء قالب صفحة التسجيل
        require_once VIEWS_PATH . '/templates/header.php';
        require_once VIEWS_PATH . '/auth/register.php';
        require_once VIEWS_PATH . '/templates/footer.php';
    }
    
    /**
     * تسجيل الخروج
     */
    public function logout() {
        // حذف بيانات الجلسة
        session_unset();
        session_destroy();
        
        // إعادة توجيه المستخدم إلى الصفحة الرئيسية
        redirect(BASE_URL);
    }
    
    /**
     * استعادة كلمة المرور
     */
    public function forgotPassword() {
        // التحقق من إرسال نموذج استعادة كلمة المرور
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['forgot_submit'])) {
            $this->processForgotPasswordForm();
        }
        
        // استدعاء قالب صفحة استعادة كلمة المرور
        require_once VIEWS_PATH . '/templates/header.php';
        require_once VIEWS_PATH . '/auth/forgot_password.php';
        require_once VIEWS_PATH . '/templates/footer.php';
    }
    
    /**
     * إعادة تعيين كلمة المرور
     * @param string $token رمز إعادة التعيين
     */
    public function resetPassword($token = null) {
        if (!$token) {
            redirect(BASE_URL . '/auth/forgotPassword');
        }
        
        // التحقق من صحة الرمز
        $tokenValid = $this->validateResetToken($token);
        
        if (!$tokenValid) {
            showError('رمز إعادة التعيين غير صالح أو منتهي الصلاحية.');
            redirect(BASE_URL . '/auth/forgotPassword');
        }
        
        // التحقق من إرسال نموذج إعادة تعيين كلمة المرور
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset_submit'])) {
            $this->processResetPasswordForm($token);
        }
        
        // استدعاء قالب صفحة إعادة تعيين كلمة المرور
        require_once VIEWS_PATH . '/templates/header.php';
        require_once VIEWS_PATH . '/auth/reset_password.php';
        require_once VIEWS_PATH . '/templates/footer.php';
    }
    
    /**
     * معالجة نموذج تسجيل الدخول
     */
    private function processLoginForm() {
        // التحقق من صحة البيانات
        $username = sanitize($_POST['username']);
        $password = $_POST['password'];
        $remember = isset($_POST['remember']) ? true : false;
        
        if (empty($username) || empty($password)) {
            showError('يرجى إدخال اسم المستخدم وكلمة المرور.');
            return;
        }
        
        // التحقق من تطابق بيانات المستخدم
        $db = connectDB();
        $stmt = $db->prepare("SELECT * FROM users WHERE (username = ? OR email = ?) AND is_active = 1");
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$user || !password_verify($password, $user['password'])) {
            showError('اسم المستخدم أو كلمة المرور غير صحيحة.');
            return;
        }
        
        // تحديث آخر تسجيل دخول
        $updateStmt = $db->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
        $updateStmt->execute([$user['id']]);
        
        // تخزين بيانات المستخدم في الجلسة
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['user_email'] = $user['email'];
        
        // إذا تم اختيار "تذكرني"، إنشاء ملف تعريف ارتباط (cookie) لتسجيل الدخول التلقائي
        if ($remember) {
            $this->createRememberMeCookie($user['id']);
        }
        
        // إعادة توجيه المستخدم حسب الدور
        if ($user['role'] === 'admin') {
            redirect(BASE_URL . '/admin');
        } else {
            redirect(BASE_URL . '/dashboard');
        }
    }
    
    /**
     * معالجة نموذج التسجيل
     */
    private function processRegisterForm() {
        // التحقق من صحة البيانات
        $username = sanitize($_POST['username']);
        $email = sanitize($_POST['email']);
        $password = $_POST['password'];
        $confirmPassword = $_POST['confirm_password'];
        
        // التحقق من اكتمال البيانات
        if (empty($username) || empty($email) || empty($password) || empty($confirmPassword)) {
            showError('جميع الحقول مطلوبة.');
            return;
        }
        
        // التحقق من صحة البريد الإلكتروني
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            showError('يرجى إدخال بريد إلكتروني صحيح.');
            return;
        }
        
        // التحقق من تطابق كلمات المرور
        if ($password !== $confirmPassword) {
            showError('كلمات المرور غير متطابقة.');
            return;
        }
        
        // التحقق من طول كلمة المرور
        if (strlen($password) < 6) {
            showError('يجب أن تتكون كلمة المرور من 6 أحرف على الأقل.');
            return;
        }
        
        // التحقق من عدم وجود اسم مستخدم أو بريد إلكتروني مكرر
        $db = connectDB();
        $stmt = $db->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        $existingUser = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($existingUser) {
            if ($existingUser['username'] === $username) {
                showError('اسم المستخدم موجود بالفعل. يرجى اختيار اسم آخر.');
            } else {
                showError('البريد الإلكتروني مسجل بالفعل. يرجى استخدام بريد آخر أو تسجيل الدخول.');
            }
            return;
        }
        
        // تشفير كلمة المرور
        $passwordHash = password_hash($password, PASSWORD_DEFAULT, ['cost' => HASH_COST]);
        
        // إنشاء المستخدم الجديد
        $insertStmt = $db->prepare("
            INSERT INTO users (username, email, password, role, balance, is_active, created_at) 
            VALUES (?, ?, ?, 'user', 0.00, 1, NOW())
        ");
        $success = $insertStmt->execute([$username, $email, $passwordHash]);
        
        if ($success) {
            $userId = $db->lastInsertId();
            
            // إنشاء سجل المستخدم الإضافي
            $profileStmt = $db->prepare("
                INSERT INTO user_profiles (user_id, created_at) 
                VALUES (?, NOW())
            ");
            $profileStmt->execute([$userId]);
            
            showSuccess('تم إنشاء حسابك بنجاح! يمكنك الآن تسجيل الدخول.');
            redirect(BASE_URL . '/auth/login');
        } else {
            showError('حدث خطأ أثناء إنشاء الحساب. يرجى المحاولة مرة أخرى.');
        }
    }
    
    /**
     * معالجة نموذج استعادة كلمة المرور
     */
    private function processForgotPasswordForm() {
        $email = sanitize($_POST['email']);
        
        if (empty($email)) {
            showError('يرجى إدخال البريد الإلكتروني.');
            return;
        }
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            showError('يرجى إدخال بريد إلكتروني صحيح.');
            return;
        }
        
        // التحقق من وجود المستخدم
        $db = connectDB();
        $stmt = $db->prepare("SELECT * FROM users WHERE email = ? AND is_active = 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$user) {
            // عدم الكشف عما إذا كان البريد الإلكتروني موجودًا لأسباب أمنية
            showSuccess('إذا كان البريد الإلكتروني مسجلاً، فستتلقى رسالة مع تعليمات إعادة تعيين كلمة المرور.');
            return;
        }
        
        // إنشاء رمز إعادة تعيين كلمة المرور
        $token = bin2hex(random_bytes(32));
        $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        // حفظ الرمز في قاعدة البيانات
        $tokenStmt = $db->prepare("
            INSERT INTO password_resets (user_id, token, expires_at, created_at) 
            VALUES (?, ?, ?, NOW())
        ");
        $tokenStmt->execute([$user['id'], $token, $expiry]);
        
        // إرسال بريد إلكتروني مع رابط إعادة التعيين (وهمي في هذا المثال)
        $resetUrl = BASE_URL . '/auth/resetPassword/' . $token;
        
        // هنا يتم إرسال البريد الإلكتروني (يمكن تنفيذه لاحقًا)
        // mail($email, 'إعادة تعيين كلمة المرور', 'لإعادة تعيين كلمة المرور، يرجى النقر على الرابط التالي: ' . $resetUrl);
        
        showSuccess('تم إرسال تعليمات إعادة تعيين كلمة المرور إلى بريدك الإلكتروني.');
    }
    
    /**
     * التحقق من صحة رمز إعادة التعيين
     * @param string $token الرمز
     * @return bool
     */
    private function validateResetToken($token) {
        $db = connectDB();
        $stmt = $db->prepare("
            SELECT * FROM password_resets 
            WHERE token = ? AND expires_at > NOW() 
            ORDER BY created_at DESC LIMIT 1
        ");
        $stmt->execute([$token]);
        $resetRequest = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $resetRequest ? true : false;
    }
    
    /**
     * معالجة نموذج إعادة تعيين كلمة المرور
     * @param string $token رمز إعادة التعيين
     */
    private function processResetPasswordForm($token) {
        $password = $_POST['password'];
        $confirmPassword = $_POST['confirm_password'];
        
        if (empty($password) || empty($confirmPassword)) {
            showError('جميع الحقول مطلوبة.');
            return;
        }
        
        if ($password !== $confirmPassword) {
            showError('كلمات المرور غير متطابقة.');
            return;
        }
        
        if (strlen($password) < 6) {
            showError('يجب أن تتكون كلمة المرور من 6 أحرف على الأقل.');
            return;
        }
        
        $db = connectDB();
        
        // الحصول على معلومات طلب إعادة التعيين
        $stmt = $db->prepare("
            SELECT * FROM password_resets 
            WHERE token = ? AND expires_at > NOW() 
            ORDER BY created_at DESC LIMIT 1
        ");
        $stmt->execute([$token]);
        $resetRequest = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$resetRequest) {
            showError('رمز إعادة التعيين غير صالح أو منتهي الصلاحية.');
            redirect(BASE_URL . '/auth/forgotPassword');
            return;
        }
        
        // تشفير كلمة المرور الجديدة
        $passwordHash = password_hash($password, PASSWORD_DEFAULT, ['cost' => HASH_COST]);
        
        // تحديث كلمة مرور المستخدم
        $updateStmt = $db->prepare("UPDATE users SET password = ? WHERE id = ?");
        $success = $updateStmt->execute([$passwordHash, $resetRequest['user_id']]);
        
        if ($success) {
            // حذف جميع طلبات إعادة التعيين لهذا المستخدم
            $deleteStmt = $db->prepare("DELETE FROM password_resets WHERE user_id = ?");
            $deleteStmt->execute([$resetRequest['user_id']]);
            
            showSuccess('تم إعادة تعيين كلمة المرور بنجاح. يمكنك الآن تسجيل الدخول باستخدام كلمة المرور الجديدة.');
            redirect(BASE_URL . '/auth/login');
        } else {
            showError('حدث خطأ أثناء إعادة تعيين كلمة المرور. يرجى المحاولة مرة أخرى.');
        }
    }
    
    /**
     * إنشاء ملف تعريف ارتباط "تذكرني"
     * @param int $userId معرف المستخدم
     */
    private function createRememberMeCookie($userId) {
        $token = bin2hex(random_bytes(32));
        $expiry = time() + (30 * 24 * 60 * 60); // 30 يوم
        
        $db = connectDB();
        $stmt = $db->prepare("
            INSERT INTO remember_tokens (user_id, token, expires_at, created_at) 
            VALUES (?, ?, FROM_UNIXTIME(?), NOW())
        ");
        $stmt->execute([$userId, $token, $expiry]);
        
        // إنشاء ملف تعريف ارتباط آمن
        setcookie('remember_token', $token, $expiry, '/', '', true, true);
    }
}
