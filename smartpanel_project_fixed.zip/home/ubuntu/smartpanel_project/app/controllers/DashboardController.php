<?php
/**
 * DashboardController
 * المتحكم الرئيسي للوحة تحكم المستخدم
 */
class DashboardController {
    private $userModel;
    private $serviceModel;
    private $orderModel;
    private $transactionModel;
    private $ticketModel;
    private $settingsModel;
    private $subscriptionModel;
    private $notification;
    
    /**
     * إنشاء نموذج المتحكم
     */
    public function __construct() {
        // التحقق من تسجيل الدخول
        if (!isset($_SESSION['user_id'])) {
            redirect('/auth/login');
        }
        
        // تهيئة النماذج
        $this->userModel = new UserModel();
        $this->serviceModel = new ServiceModel();
        $this->orderModel = new OrderModel();
        $this->transactionModel = new TransactionModel();
        $this->ticketModel = new TicketModel();
        $this->settingsModel = new SettingsModel();
        $this->subscriptionModel = new SubscriptionModel();
        $this->notification = new NotificationSystem();
    }
    
    /**
     * عرض لوحة التحكم الرئيسية
     */
    public function index() {
        // جلب بيانات المستخدم
        $user_id = $_SESSION['user_id'];
        $user = $this->userModel->getUserById($user_id);
        
        // إحصائيات المستخدم
        $total_orders = $this->orderModel->countOrdersByUser($user_id);
        $pending_orders = $this->orderModel->countOrdersByUserAndStatus($user_id, 'pending');
        $completed_orders = $this->orderModel->countOrdersByUserAndStatus($user_id, 'completed');
        $total_subscriptions = $this->subscriptionModel->countSubscriptionsByUser($user_id);
        $active_subscriptions = $this->subscriptionModel->countSubscriptionsByUser($user_id, 'active');
        $open_tickets = $this->ticketModel->countTicketsByUserAndStatus($user_id, 'open');
        
        // آخر الطلبات
        $recent_orders = $this->orderModel->getRecentOrdersByUser($user_id, 5);
        
        // آخر المعاملات
        $recent_transactions = $this->transactionModel->getRecentTransactionsByUser($user_id, 5);
        
        // الإشعارات غير المقروءة
        $unread_notifications = $this->notification->getUnreadNotifications($user_id, 5);
        
        // تحميل القالب
        $data = [
            'page_title' => 'لوحة التحكم',
            'active_tab' => 'dashboard',
            'user' => $user,
            'total_orders' => $total_orders,
            'pending_orders' => $pending_orders,
            'completed_orders' => $completed_orders,
            'total_subscriptions' => $total_subscriptions,
            'active_subscriptions' => $active_subscriptions,
            'open_tickets' => $open_tickets,
            'recent_orders' => $recent_orders,
            'recent_transactions' => $recent_transactions,
            'unread_notifications' => $unread_notifications
        ];
        
        view('dashboard/index', $data, 'dashboard');
    }
    
    /**
     * عرض صفحة الطلب الجديد
     */
    public function newOrder() {
        // جلب الفئات
        $categories = $this->serviceModel->getAllCategories();
        
        // تحميل القالب
        $data = [
            'page_title' => 'طلب جديد',
            'active_tab' => 'new_order',
            'categories' => $categories
        ];
        
        view('dashboard/new_order', $data, 'dashboard');
    }
    
    /**
     * الحصول على الخدمات بناءً على الفئة (AJAX)
     */
    public function getServices() {
        if (!isset($_POST['category_id'])) {
            echo json_encode([]);
            return;
        }
        
        $category_id = (int) $_POST['category_id'];
        
        // جلب الخدمات
        $services = $this->serviceModel->getServicesByCategory($category_id);
        
        // إرسال الاستجابة كـ JSON
        header('Content-Type: application/json');
        echo json_encode($services);
    }
    
    /**
     * الحصول على تفاصيل الخدمة (AJAX)
     */
    public function getServiceDetails() {
        if (!isset($_POST['service_id'])) {
            echo json_encode(['error' => 'معرف الخدمة غير موجود']);
            return;
        }
        
        $service_id = (int) $_POST['service_id'];
        
        // جلب الخدمة
        $service = $this->serviceModel->getServiceById($service_id);
        
        if (!$service) {
            echo json_encode(['error' => 'الخدمة غير موجودة']);
            return;
        }
        
        // إرسال الاستجابة كـ JSON
        header('Content-Type: application/json');
        echo json_encode($service);
    }
    
    /**
     * معالجة إرسال الطلب الجديد
     */
    public function submitOrder() {
        // التحقق من الطلب POST
        if ($_SERVER['REQUEST_METHOD'] != 'POST') {
            redirect('/dashboard/new_order');
        }
        
        // تنظيف وتحقق من البيانات
        $service_id = filter_input(INPUT_POST, 'service', FILTER_SANITIZE_NUMBER_INT);
        $link = filter_input(INPUT_POST, 'link', FILTER_SANITIZE_URL);
        $quantity = filter_input(INPUT_POST, 'quantity', FILTER_SANITIZE_NUMBER_INT);
        
        // جلب معلومات الخدمة
        $service = $this->serviceModel->getServiceById($service_id);
        
        if (!$service) {
            setFlashMessage('error', 'الخدمة غير موجودة');
            redirect('/dashboard/new_order');
        }
        
        // التحقق من صحة البيانات
        if (empty($service_id) || empty($link) || empty($quantity)) {
            setFlashMessage('error', 'يرجى ملء جميع الحقول المطلوبة');
            redirect('/dashboard/new_order');
        }
        
        // التحقق من الكمية
        if ($quantity < $service['min'] || $quantity > $service['max']) {
            setFlashMessage('error', 'الكمية يجب أن تكون بين ' . $service['min'] . ' و ' . $service['max']);
            redirect('/dashboard/new_order');
        }
        
        // حساب السعر
        $price = $this->serviceModel->calculatePrice($service_id, $quantity);
        
        // التحقق من الرصيد
        $user = $this->userModel->getUserById($_SESSION['user_id']);
        if ($user['balance'] < $price) {
            setFlashMessage('error', 'رصيدك غير كافٍ لإتمام هذا الطلب. يرجى إضافة رصيد.');
            redirect('/dashboard/add_funds');
        }
        
        // إنشاء الطلب
        $order_data = [
            'user_id' => $_SESSION['user_id'],
            'service_id' => $service_id,
            'link' => $link,
            'quantity' => $quantity,
            'price' => $price,
            'status' => 'pending',
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        $order_id = $this->orderModel->createOrder($order_data);
        
        if ($order_id) {
            // خصم من رصيد المستخدم
            $this->userModel->updateBalance($_SESSION['user_id'], -$price);
            
            // إنشاء معاملة
            $transaction_data = [
                'user_id' => $_SESSION['user_id'],
                'amount' => $price,
                'type' => 'order',
                'status' => 'completed',
                'description' => 'طلب #' . $order_id,
                'order_id' => $order_id,
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            $this->transactionModel->createTransaction($transaction_data);
            
            // إنشاء إشعار
            $this->notification->createNotification(
                $_SESSION['user_id'],
                'تم إنشاء طلب جديد',
                'تم إنشاء الطلب #' . $order_id . ' بنجاح وهو قيد المعالجة الآن.',
                'success'
            );
            
            setFlashMessage('success', 'تم إنشاء الطلب بنجاح. رقم الطلب: #' . $order_id);
            redirect('/dashboard/orders');
        } else {
            setFlashMessage('error', 'حدث خطأ أثناء إنشاء الطلب. يرجى المحاولة مرة أخرى.');
            redirect('/dashboard/new_order');
        }
    }
    }
    
    /**
     * عرض صفحة الطلبات
     */
    public function orders() {
        $user_id = $_SESSION['user_id'];
        
        // معلمات البحث والترتيب
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $status = isset($_GET['status']) ? $_GET['status'] : '';
        $search = isset($_GET['search']) ? $_GET['search'] : '';
        
        // جلب عدد الطلبات
        $total_orders = $this->orderModel->countUserOrders($user_id, $status, $search);
        
        // إعدادات الترقيم
        $items_per_page = 15;
        $total_pages = ceil($total_orders / $items_per_page);
        $page = min($page, max(1, $total_pages));
        $offset = ($page - 1) * $items_per_page;
        
        // جلب الطلبات
        $orders = $this->orderModel->getUserOrders($user_id, $offset, $items_per_page, $status, $search);
        
        // تحميل القالب
        $data = [
            'page_title' => 'طلباتي',
            'active_tab' => 'orders',
            'orders' => $orders,
            'total_orders' => $total_orders,
            'current_page' => $page,
            'total_pages' => $total_pages,
            'status' => $status,
            'search' => $search
        ];
        
        view('dashboard/orders', $data, 'dashboard');
    }
    
    /**
     * عرض تفاصيل طلب معين
     * 
     * @param int $order_id معرف الطلب
     */
    public function viewOrder($order_id) {
        $user_id = $_SESSION['user_id'];
        
        // جلب تفاصيل الطلب
        $order = $this->orderModel->getUserOrder($order_id, $user_id);
        
        if (!$order) {
            setFlashMessage('error', 'لم يتم العثور على الطلب المطلوب');
            redirect('/dashboard/orders');
        }
        
        // جلب الخدمة المرتبطة بالطلب
        $service = $this->serviceModel->getServiceById($order['service_id']);
        
        // تحميل القالب
        $data = [
            'page_title' => 'تفاصيل الطلب #' . $order_id,
            'active_tab' => 'orders',
            'order' => $order,
            'service' => $service
        ];
        
        view('dashboard/view_order', $data, 'dashboard');
    }
    
    /**
     * إلغاء طلب
     * 
     * @param int $order_id معرف الطلب
     */
    public function cancelOrder($order_id) {
        $user_id = $_SESSION['user_id'];
        
        // جلب تفاصيل الطلب
        $order = $this->orderModel->getUserOrder($order_id, $user_id);
        
        if (!$order) {
            setFlashMessage('error', 'لم يتم العثور على الطلب المطلوب');
            redirect('/dashboard/orders');
        }
        
        // التحقق من أن الطلب قابل للإلغاء
        if ($order['status'] != 'pending' && $order['status'] != 'processing') {
            setFlashMessage('error', 'لا يمكن إلغاء هذا الطلب في وضعه الحالي');
            redirect('/dashboard/orders');
        }
        
        // تحديث حالة الطلب
        $result = $this->orderModel->updateOrderStatus($order_id, 'canceled');
        
        if ($result) {
            // إرجاع المبلغ إلى رصيد المستخدم
            $this->userModel->updateBalance($user_id, $order['price']);
            
            // إنشاء معاملة استرداد
            $transaction_data = [
                'user_id' => $user_id,
                'amount' => $order['price'],
                'type' => 'refund',
                'status' => 'completed',
                'description' => 'استرداد للطلب #' . $order_id,
                'order_id' => $order_id,
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            $this->transactionModel->createTransaction($transaction_data);
            
            // إنشاء إشعار
            $this->notification->createNotification(
                $user_id,
                'تم إلغاء الطلب',
                'تم إلغاء الطلب #' . $order_id . ' وتم إرجاع المبلغ إلى رصيدك.',
                'info'
            );
            
            setFlashMessage('success', 'تم إلغاء الطلب وإرجاع المبلغ إلى رصيدك.');
        } else {
            setFlashMessage('error', 'حدث خطأ أثناء إلغاء الطلب. يرجى المحاولة مرة أخرى.');
        }
        
        redirect('/dashboard/orders');
    }
    
    /**
     * عرض صفحة الطلب المتعدد
     */
    public function massOrder() {
        // جلب الفئات
        $categories = $this->serviceModel->getAllCategories();
        
        // تحميل القالب
        $data = [
            'page_title' => 'طلب متعدد',
            'active_tab' => 'mass_order',
            'categories' => $categories
        ];
        
        view('dashboard/mass_order', $data, 'dashboard');
    }
    
    /**
     * معالجة الطلب المتعدد
     */
    public function submitMassOrder() {
        if ($_SERVER['REQUEST_METHOD'] != 'POST') {
            redirect('/dashboard/mass_order');
        }
        
        $orders_data = filter_input(INPUT_POST, 'orders', FILTER_SANITIZE_STRING);
        
        if (empty($orders_data)) {
            setFlashMessage('error', 'يرجى إدخال بيانات الطلبات');
            redirect('/dashboard/mass_order');
        }
        
        // تقسيم البيانات إلى أسطر
        $orders_lines = explode("\n", $orders_data);
        
        $success_count = 0;
        $failed_count = 0;
        $total_price = 0;
        $errors = [];
        $orders = [];
        
        // تحليل كل سطر
        foreach ($orders_lines as $line) {
            $line = trim($line);
            if (empty($line)) continue;
            
            // تقسيم السطر بواسطة الفواصل
            $parts = explode('|', $line);
            
            if (count($parts) < 3) {
                $failed_count++;
                $errors[] = "خطأ في تنسيق السطر: $line";
                continue;
            }
            
            $service_id = trim($parts[0]);
            $link = trim($parts[1]);
            $quantity = (int)trim($parts[2]);
            
            // جلب معلومات الخدمة
            $service = $this->serviceModel->getServiceById($service_id);
            
            if (!$service) {
                $failed_count++;
                $errors[] = "الخدمة غير موجودة: $service_id";
                continue;
            }
            
            // التحقق من الكمية
            if ($quantity < $service['min'] || $quantity > $service['max']) {
                $failed_count++;
                $errors[] = "الكمية يجب أن تكون بين {$service['min']} و {$service['max']} للخدمة: $service_id";
                continue;
            }
            
            // حساب السعر
            $price = $this->serviceModel->calculatePrice($service_id, $quantity);
            $total_price += $price;
            
            // إضافة الطلب إلى قائمة الطلبات
            $orders[] = [
                'service_id' => $service_id,
                'service_name' => $service['name'],
                'link' => $link,
                'quantity' => $quantity,
                'price' => $price
            ];
            
            $success_count++;
        }
        
        // التحقق من وجود طلبات ناجحة
        if ($success_count == 0) {
            setFlashMessage('error', 'لم يتم العثور على طلبات صالحة');
            redirect('/dashboard/mass_order');
        }
        
        // التحقق من الرصيد
        $user = $this->userModel->getUserById($_SESSION['user_id']);
        if ($user['balance'] < $total_price) {
            setFlashMessage('error', "رصيدك غير كافٍ لإتمام هذه الطلبات. المبلغ المطلوب: " . formatCurrency($total_price));
            redirect('/dashboard/add_funds');
        }
        
        // إنشاء الطلبات
        $created_orders = [];
        foreach ($orders as $order) {
            $order_data = [
                'user_id' => $_SESSION['user_id'],
                'service_id' => $order['service_id'],
                'link' => $order['link'],
                'quantity' => $order['quantity'],
                'price' => $order['price'],
                'status' => 'pending',
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            $order_id = $this->orderModel->createOrder($order_data);
            if ($order_id) {
                $created_orders[] = $order_id;
                
                // إنشاء معاملة
                $transaction_data = [
                    'user_id' => $_SESSION['user_id'],
                    'amount' => $order['price'],
                    'type' => 'order',
                    'status' => 'completed',
                    'description' => 'طلب #' . $order_id,
                    'order_id' => $order_id,
                    'created_at' => date('Y-m-d H:i:s')
                ];
                
                $this->transactionModel->createTransaction($transaction_data);
            }
        }
        
        // خصم المبلغ من رصيد المستخدم
        $this->userModel->updateBalance($_SESSION['user_id'], -$total_price);
        
        // إنشاء إشعار
        $this->notification->createNotification(
            $_SESSION['user_id'],
            'تم إنشاء طلبات متعددة',
            "تم إنشاء $success_count طلب بنجاح. المبلغ الإجمالي: " . formatCurrency($total_price),
            'success'
        );
        
        setFlashMessage('success', "تم إنشاء $success_count طلب بنجاح. المبلغ الإجمالي: " . formatCurrency($total_price));
        redirect('/dashboard/orders');
    }
    
    /**
     * عرض صفحة إضافة رصيد
     */
    public function addFunds() {
        // جلب طرق الدفع المتاحة
        $payment_processor = new PaymentProcessor();
        $payment_methods = $payment_processor->getPaymentMethods();
        
        // تحميل القالب
        $data = [
            'page_title' => 'إضافة رصيد',
            'active_tab' => 'add_funds',
            'payment_methods' => $payment_methods
        ];
        
        view('dashboard/add_funds', $data, 'dashboard');
    }
    
    /**
     * معالجة طلب إضافة رصيد
     */
    public function processAddFunds() {
        if ($_SERVER['REQUEST_METHOD'] != 'POST') {
            redirect('/dashboard/add_funds');
        }
        
        $amount = filter_input(INPUT_POST, 'amount', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
        $payment_method = filter_input(INPUT_POST, 'payment_method', FILTER_SANITIZE_STRING);
        
        if (empty($amount) || $amount <= 0) {
            setFlashMessage('error', 'يرجى إدخال مبلغ صحيح');
            redirect('/dashboard/add_funds');
        }
        
        if (empty($payment_method)) {
            setFlashMessage('error', 'يرجى اختيار طريقة دفع');
            redirect('/dashboard/add_funds');
        }
        
        // بدء عملية الدفع
        $payment_processor = new PaymentProcessor();
        $payment_data = $payment_processor->initializePayment(
            $_SESSION['user_id'],
            $amount,
            $payment_method,
            'إيداع رصيد'
        );
        
        if (!$payment_data) {
            setFlashMessage('error', 'حدث خطأ أثناء بدء عملية الدفع. يرجى المحاولة مرة أخرى.');
            redirect('/dashboard/add_funds');
        }
        
        // إنشاء إشعار
        $this->notification->createNotification(
            $_SESSION['user_id'],
            'طلب إضافة رصيد',
            "تم بدء طلب إضافة رصيد بمبلغ " . formatCurrency($amount) . " باستخدام $payment_method.",
            'info'
        );
        
        // إعادة توجيه المستخدم إلى صفحة الدفع
        redirect($payment_data['redirect_url']);
    }
    
    /**
     * عرض صفحة المعاملات
     */
    public function transactions() {
        $user_id = $_SESSION['user_id'];
        
        // معلمات البحث والترتيب
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $type = isset($_GET['type']) ? $_GET['type'] : '';
        $status = isset($_GET['status']) ? $_GET['status'] : '';
        
        // جلب عدد المعاملات
        $total_transactions = $this->transactionModel->countUserTransactions($user_id, $type, $status);
        
        // إعدادات الترقيم
        $items_per_page = 15;
        $total_pages = ceil($total_transactions / $items_per_page);
        $page = min($page, max(1, $total_pages));
        $offset = ($page - 1) * $items_per_page;
        
        // جلب المعاملات
        $transactions = $this->transactionModel->getUserTransactions($user_id, $offset, $items_per_page, $type, $status);
        
        // تحميل القالب
        $data = [
            'page_title' => 'المعاملات',
            'active_tab' => 'transactions',
            'transactions' => $transactions,
            'total_transactions' => $total_transactions,
            'current_page' => $page,
            'total_pages' => $total_pages,
            'type' => $type,
            'status' => $status
        ];
        
        view('dashboard/transactions', $data, 'dashboard');
    }
}