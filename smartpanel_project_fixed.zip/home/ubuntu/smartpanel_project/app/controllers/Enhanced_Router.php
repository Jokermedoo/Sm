<?php
namespace App\Controllers;

/**
 * Enhanced Router Class - موجه الطلبات المحسّن للتطبيق
 * تاريخ التحديث: 30-05-2025
 * 
 * مميزات الإصدار المحسّن:
 * - دعم أنماط URL متعددة
 * - معالجة أفضل للأخطاء
 * - التوجيه حسب HTTP Method
 * - دعم التوجيه المحدد مسبقاً
 * - أمان محسّن ضد هجمات CSRF وXSS
 */
class Enhanced_Router {
    private $controller = 'HomeController';
    private $method = 'index';
    private $params = [];
    private $namespace = 'App\\Controllers\\';
    private $routes = [];
    private $request = null;
    private $response = null;
    private $httpMethod = 'GET';
    
    /**
     * Constructor - يقوم بتهيئة الموجه
     */
    public function __construct() {
        $this->request = $this->createRequestObject();
        $this->response = $this->createResponseObject();
        $this->httpMethod = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        
        // تحميل المسارات المحسنة
        require_once CONFIG_PATH . '/enhanced_paths.php';
        
        // تحميل ملف المسارات المحددة مسبقاً إذا كان موجوداً
        $routesFile = CONFIG_PATH . '/routes.php';
        if (file_exists($routesFile)) {
            $this->routes = require_once $routesFile;
        }
    }
    
    /**
     * معالجة الطلب الحالي
     */
    public function handleRequest() {
        try {
            // التحقق من وضع الصيانة
            if (defined('MAINTENANCE_MODE') && MAINTENANCE_MODE && !$this->isMaintenanceExempt()) {
                return $this->showMaintenancePage();
            }
            
            // التحقق من CSRF token للطلبات غير GET
            if ($this->httpMethod !== 'GET' && !$this->validateCsrfToken()) {
                throw new \Exception('انتهت صلاحية الجلسة أو رمز CSRF غير صالح');
            }
            
            $url = $this->parseUrl();
            
            // التحقق من وجود مسار محدد مسبقاً
            $routePath = implode('/', $url);
            if (isset($this->routes[$routePath])) {
                return $this->handlePredefinedRoute($this->routes[$routePath]);
            }
            
            // معالجة المسار الديناميكي
            $this->processController($url);
            
            // التحقق من صلاحيات الوصول
            if (!$this->checkAccess()) {
                if (!$this->isLoggedIn()) {
                    // إعادة توجيه للمستخدم غير المسجل
                    $this->redirect(BASE_URL . '/auth/login?redirect=' . urlencode($_SERVER['REQUEST_URI']));
                } else {
                    // عدم التصريح بالوصول
                    throw new \Exception('غير مصرح لك بالوصول إلى هذه الصفحة');
                }
            }
            
            return $this->route();
            
        } catch (\Exception $e) {
            $this->logActivity("خطأ في التوجيه: " . $e->getMessage(), 'error');
            return $this->handleError($e);
        }
    }
    
    /**
     * إنشاء كائن الطلب
     */
    private function createRequestObject() {
        return [
            'get' => $_GET,
            'post' => $_POST,
            'files' => $_FILES,
            'cookie' => $_COOKIE,
            'session' => $_SESSION ?? [],
            'server' => $_SERVER,
            'headers' => $this->getAllHeaders(),
            'body' => file_get_contents('php://input')
        ];
    }
    
    /**
     * إنشاء كائن الاستجابة
     */
    private function createResponseObject() {
        return [
            'headers' => [],
            'statusCode' => 200,
            'content' => null
        ];
    }
    
    /**
     * الحصول على جميع ترويسات HTTP
     */
    private function getAllHeaders() {
        if (function_exists('getallheaders')) {
            return getallheaders();
        }
        
        $headers = [];
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) === 'HTTP_') {
                $name = str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))));
                $headers[$name] = $value;
            }
        }
        
        return $headers;
    }
    
    /**
     * التحقق من رمز CSRF
     */
    private function validateCsrfToken() {
        if (!isset($_SESSION['csrf_token'])) {
            return false;
        }
        
        $token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? null;
        return $token && $token === $_SESSION['csrf_token'];
    }
    
    /**
     * تحليل URL وتقسيمه إلى أجزاء
     * @return array
     */
    private function parseUrl() {
        $url = [];
        
        // استخدام مسار URI مباشرة
        if (isset($_SERVER['REQUEST_URI'])) {
            $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
            // إزالة المسار الأساسي إذا كان التطبيق في مجلد فرعي
            $basePath = dirname($_SERVER['SCRIPT_NAME']);
            if ($basePath !== '/' && $basePath !== '\\') {
                $uri = substr($uri, strlen($basePath));
            }
            $uri = trim($uri, '/');
            if (!empty($uri)) {
                $url = explode('/', filter_var($uri, FILTER_SANITIZE_URL));
            }
        } 
        // التوافق مع .htaccess القديم
        elseif (isset($_GET['url'])) {
            $urlString = filter_var(rtrim($_GET['url'], '/'), FILTER_SANITIZE_URL);
            if ($urlString !== false && !empty($urlString)) {
                $url = explode('/', $urlString);
            }
        }
        
        return $url;
    }
    
    /**
     * معالجة المتحكم من URL
     */
    private function processController(&$url) {
        // التحقق من وجود المتحكم
        if (isset($url[0]) && !empty($url[0])) {
            $controllerName = ucfirst($url[0]) . 'Controller';
            $controllerFile = CONTROLLERS_PATH . '/' . $controllerName . '.php';
            
            if (file_exists($controllerFile)) {
                $this->controller = $controllerName;
                unset($url[0]);
            }
        }
        
        // التحقق من وجود الإجراء
        if (isset($url[1]) && !empty($url[1])) {
            $methodName = $url[1];
            $controller = $this->namespace . $this->controller;
            
            if (class_exists($controller)) {
                $controllerInstance = new $controller();
                if (method_exists($controllerInstance, $methodName)) {
                    $this->method = $methodName;
                    unset($url[1]);
                }
            }
        }
        
        // الحصول على المعلمات إن وجدت
        $this->params = $url ? array_values($url) : [];
    }
    
    /**
     * معالجة المسار المحدد مسبقاً
     */
    private function handlePredefinedRoute($routeConfig) {
        if (is_callable($routeConfig)) {
            // تنفيذ الدالة المباشرة
            return call_user_func($routeConfig, $this->request, $this->response);
        } elseif (is_array($routeConfig) && isset($routeConfig['controller'], $routeConfig['action'])) {
            // استخدام المتحكم والإجراء المحددين
            $this->controller = $routeConfig['controller'];
            $this->method = $routeConfig['action'];
            $this->params = $routeConfig['params'] ?? [];
            
            return $this->route();
        }
        
        throw new \Exception('تكوين المسار غير صالح');
    }
    
    /**
     * استدعاء المتحكم والإجراء المناسبين مع المعلمات
     */
    public function route() {
        try {
            $controller = $this->namespace . $this->controller;
            
            if (!class_exists($controller)) {
                throw new \Exception('المتحكم غير موجود: ' . $this->controller);
            }
            
            $controllerInstance = new $controller();
            
            if (!method_exists($controllerInstance, $this->method)) {
                throw new \Exception('الإجراء غير موجود: ' . $this->method);
            }
            
            // استدعاء الإجراء مع نقل كائن الطلب كأول معلمة
            $params = array_merge([$this->request], $this->params);
            return call_user_func_array([$controllerInstance, $this->method], $params);
            
        } catch (\Exception $e) {
            $this->logActivity("خطأ في التوجيه: " . $e->getMessage(), 'error');
            return $this->handleError($e);
        }
    }
    
    /**
     * التحقق من استثناءات وضع الصيانة
     * @return bool
     */
    private function isMaintenanceExempt() {
        // التحقق من IP المسموح به
        $allowedIPs = defined('MAINTENANCE_ALLOWED_IPS') ? MAINTENANCE_ALLOWED_IPS : [];
        $clientIP = $_SERVER['REMOTE_ADDR'] ?? '';
        
        if (in_array($clientIP, $allowedIPs)) {
            return true;
        }
        
        // التحقق من المستخدم المسؤول
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
    }
    
    /**
     * عرض صفحة الصيانة
     */
    private function showMaintenancePage() {
        http_response_code(503); // Service Unavailable
        header('Retry-After: 3600'); // إعادة المحاولة بعد ساعة
        require_once VIEWS_PATH . '/maintenance.php';
        exit;
    }
    
    /**
     * التحقق من صلاحيات الوصول
     * @return bool
     */
    private function checkAccess() {
        // التحقق من تسجيل الدخول للصفحات المحمية
        $protectedControllers = ['DashboardController', 'AdminController', 'ProfileController', 'SubscriptionController', 'TicketController', 'OrderController'];
        $publicMethods = ['login', 'register', 'forgotPassword', 'resetPassword', 'activate', 'verifyToken'];
        
        if (in_array($this->controller, $protectedControllers) && !in_array($this->method, $publicMethods)) {
            if (!$this->isLoggedIn()) {
                return false;
            }
        }
        
        // التحقق من صلاحيات المسؤول
        $adminControllers = ['AdminController'];
        $adminMethods = ['manageUsers', 'manageServices', 'manageOrders', 'managePayments', 'settings', 'systemLogs'];
        
        if (in_array($this->controller, $adminControllers) || 
            (isset($_SESSION['user_role']) && $_SESSION['user_role'] !== 'admin' && in_array($this->method, $adminMethods))) {
            if (!$this->isAdmin()) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * التحقق من تسجيل دخول المستخدم
     * @return bool
     */
    private function isLoggedIn() {
        return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
    }
    
    /**
     * التحقق من صلاحيات المسؤول
     * @return bool
     */
    private function isAdmin() {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
    }
    
    /**
     * إعادة توجيه المستخدم
     * @param string $url
     */
    private function redirect($url) {
        header('Location: ' . $url);
        exit;
    }
    
    /**
     * معالجة الأخطاء
     * @param Exception $e
     */
    private function handleError($e) {
        $statusCode = 500; // Internal Server Error
        
        // تحديد رمز الحالة بناءً على نوع الخطأ
        if ($e instanceof \App\Exceptions\NotFoundException) {
            $statusCode = 404; // Not Found
        } elseif ($e instanceof \App\Exceptions\UnauthorizedException) {
            $statusCode = 403; // Forbidden
        } elseif ($e instanceof \App\Exceptions\ValidationException) {
            $statusCode = 400; // Bad Request
        }
        
        http_response_code($statusCode);
        
        if (defined('DEBUG_MODE') && DEBUG_MODE) {
            $errorData = [
                'message' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'trace' => $e->getTrace()
            ];
            
            if ($this->isAjaxRequest()) {
                header('Content-Type: application/json');
                echo json_encode(['error' => $errorData]);
                exit;
            } else {
                // عرض صفحة خطأ مفصلة
                extract(['error' => $errorData]);
                require_once VIEWS_PATH . '/error_debug.php';
                exit;
            }
        } else {
            // تسجيل الخطأ
            $this->logActivity($e->getMessage(), 'error');
            
            if ($this->isAjaxRequest()) {
                header('Content-Type: application/json');
                echo json_encode(['error' => 'حدث خطأ في النظام. الرجاء المحاولة مرة أخرى لاحقاً.']);
                exit;
            } else {
                // عرض صفحة الخطأ العامة
                extract(['statusCode' => $statusCode]);
                require_once VIEWS_PATH . '/error.php';
                exit;
            }
        }
    }
    
    /**
     * التحقق من طلب AJAX
     * @return bool
     */
    private function isAjaxRequest() {
        return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }
    
    /**
     * تسجيل نشاط النظام
     * @param string $message
     * @param string $level
     */
    private function logActivity($message, $level = 'info') {
        if (function_exists('logActivity')) {
            logActivity($message, $level);
        } else {
            $logFile = LOGS_PATH . '/' . $level . '_' . date('Y-m-d') . '.log';
            $logMessage = '[' . date('Y-m-d H:i:s') . '] ' . $message . PHP_EOL;
            file_put_contents($logFile, $logMessage, FILE_APPEND);
        }
    }
}
