<div class="row mb-4">
    <div class="col-md-12">
        <h1 class="mb-3">تذاكر الدعم</h1>
        <p class="text-muted">إدارة طلبات الدعم الفني والتواصل مع فريق تاون ميديا.</p>
    </div>
</div>

<div class="row mb-4">
    <div class="col-md-12">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <h5 class="mb-0">قائمة التذاكر</h5>
                <a href="<?php echo BASE_URL; ?>/dashboard/tickets/new" class="btn btn-primary">
                    <i class="fas fa-plus-circle me-1"></i> تذكرة جديدة
                </a>
            </div>
            <div class="card-body p-0">
                <!-- فلاتر البحث -->
                <div class="p-3 border-bottom bg-light">
                    <form method="get" action="<?php echo BASE_URL; ?>/dashboard/tickets" class="row g-3">
                        <div class="col-md-4">
                            <select class="form-select form-select-sm" name="status" id="statusFilter">
                                <option value="">جميع الحالات</option>
                                <option value="open" <?php echo (isset($_GET['status']) && $_GET['status'] == 'open') ? 'selected' : ''; ?>>مفتوحة</option>
                                <option value="answered" <?php echo (isset($_GET['status']) && $_GET['status'] == 'answered') ? 'selected' : ''; ?>>تم الرد</option>
                                <option value="customer_reply" <?php echo (isset($_GET['status']) && $_GET['status'] == 'customer_reply') ? 'selected' : ''; ?>>رد العميل</option>
                                <option value="closed" <?php echo (isset($_GET['status']) && $_GET['status'] == 'closed') ? 'selected' : ''; ?>>مغلقة</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <input type="text" class="form-control form-control-sm" name="search" placeholder="البحث عن موضوع التذكرة" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary btn-sm w-100">بحث</button>
                        </div>
                    </form>
                </div>
                
                <!-- جدول التذاكر -->
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>رقم التذكرة</th>
                                <th>الموضوع</th>
                                <th>القسم</th>
                                <th>آخر تحديث</th>
                                <th>الحالة</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($tickets)): ?>
                                <?php foreach ($tickets as $ticket): ?>
                                <tr>
                                    <td>#<?php echo $ticket['id']; ?></td>
                                    <td>
                                        <a href="<?php echo BASE_URL; ?>/dashboard/tickets/view/<?php echo $ticket['id']; ?>" class="text-decoration-none">
                                            <?php echo $ticket['subject']; ?>
                                        </a>
                                    </td>
                                    <td><?php echo $ticket['department']; ?></td>
                                    <td><?php echo formatDate($ticket['updated_at']); ?></td>
                                    <td>
                                        <?php
                                        switch ($ticket['status']) {
                                            case 'open':
                                                echo '<span class="badge bg-success">مفتوحة</span>';
                                                break;
                                            case 'answered':
                                                echo '<span class="badge bg-info">تم الرد</span>';
                                                break;
                                            case 'customer_reply':
                                                echo '<span class="badge bg-primary">رد العميل</span>';
                                                break;
                                            case 'closed':
                                                echo '<span class="badge bg-secondary">مغلقة</span>';
                                                break;
                                            default:
                                                echo '<span class="badge bg-secondary">غير معروفة</span>';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-sm btn-light border dropdown-toggle" type="button" id="actionDropdown<?php echo $ticket['id']; ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                                <i class="fas fa-ellipsis-h"></i>
                                            </button>
                                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="actionDropdown<?php echo $ticket['id']; ?>">
                                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/dashboard/tickets/view/<?php echo $ticket['id']; ?>"><i class="fas fa-eye me-2"></i> عرض التذكرة</a></li>
                                                <?php if ($ticket['status'] != 'closed'): ?>
                                                <li><a class="dropdown-item text-danger" href="<?php echo BASE_URL; ?>/dashboard/tickets/close/<?php echo $ticket['id']; ?>" onclick="return confirm('هل أنت متأكد من رغبتك في إغلاق هذه التذكرة؟');"><i class="fas fa-times-circle me-2"></i> إغلاق التذكرة</a></li>
                                                <?php else: ?>
                                                <li><a class="dropdown-item text-success" href="<?php echo BASE_URL; ?>/dashboard/tickets/reopen/<?php echo $ticket['id']; ?>"><i class="fas fa-redo-alt me-2"></i> إعادة فتح التذكرة</a></li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center py-4">
                                        <div class="py-5">
                                            <i class="fas fa-ticket-alt fa-3x text-muted mb-3"></i>
                                            <h5>لا توجد تذاكر دعم</h5>
                                            <p class="text-muted">لم تقم بإنشاء أي تذاكر دعم حتى الآن.</p>
                                            <a href="<?php echo BASE_URL; ?>/dashboard/tickets/new" class="btn btn-primary mt-2">إنشاء تذكرة جديدة</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- الترقيم (Pagination) -->
                <?php if (!empty($tickets) && $total_pages > 1): ?>
                <div class="p-3 border-top">
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-center mb-0">
                            <?php if ($current_page > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo BASE_URL; ?>/dashboard/tickets?page=<?php echo $current_page - 1; ?><?php echo !empty($query_string) ? '&' . $query_string : ''; ?>" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>
                            <?php endif; ?>
                            
                            <?php
                            $start_page = max(1, $current_page - 2);
                            $end_page = min($start_page + 4, $total_pages);
                            
                            if ($end_page - $start_page < 4 && $start_page > 1) {
                                $start_page = max(1, $end_page - 4);
                            }
                            
                            for ($i = $start_page; $i <= $end_page; $i++):
                            ?>
                            <li class="page-item <?php echo ($i == $current_page) ? 'active' : ''; ?>">
                                <a class="page-link" href="<?php echo BASE_URL; ?>/dashboard/tickets?page=<?php echo $i; ?><?php echo !empty($query_string) ? '&' . $query_string : ''; ?>"><?php echo $i; ?></a>
                            </li>
                            <?php endfor; ?>
                            
                            <?php if ($current_page < $total_pages): ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo BASE_URL; ?>/dashboard/tickets?page=<?php echo $current_page + 1; ?><?php echo !empty($query_string) ? '&' . $query_string : ''; ?>" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- تفسير حالات التذاكر -->
<div class="row">
    <div class="col-md-12">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">تفسير حالات التذاكر</h5>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="d-flex align-items-center">
                            <span class="badge bg-success me-2">مفتوحة</span>
                            <span>تم إنشاء التذكرة وتنتظر الرد من فريق الدعم.</span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="d-flex align-items-center">
                            <span class="badge bg-info me-2">تم الرد</span>
                            <span>قام فريق الدعم بالرد على التذكرة وتنتظر ردك.</span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="d-flex align-items-center">
                            <span class="badge bg-primary me-2">رد العميل</span>
                            <span>قمت بالرد على التذكرة وتنتظر رد فريق الدعم.</span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="d-flex align-items-center">
                            <span class="badge bg-secondary me-2">مغلقة</span>
                            <span>تم إغلاق التذكرة بعد حل المشكلة.</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// تنفيذ البحث عند تغيير حالة التذكرة
document.addEventListener('DOMContentLoaded', function() {
    const statusFilter = document.getElementById('statusFilter');
    
    statusFilter.addEventListener('change', function() {
        this.form.submit();
    });
});
</script>
