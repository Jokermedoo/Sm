<div class="row mb-4">
    <div class="col-md-12">
        <h1 class="mb-3">الاشتراكات</h1>
        <p class="text-muted">إدارة اشتراكاتك الدورية في خدمات التسويق عبر وسائل التواصل الاجتماعي.</p>
    </div>
</div>

<div class="row mb-4">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <h5 class="mb-0">قائمة الاشتراكات</h5>
                <a href="<?php echo BASE_URL; ?>/dashboard/new_subscription" class="btn btn-sm btn-primary">
                    <i class="fas fa-plus-circle me-1"></i> اشتراك جديد
                </a>
            </div>
            <div class="card-body p-0">
                <!-- فلاتر البحث -->
                <div class="p-3 border-bottom bg-light">
                    <form method="get" action="<?php echo BASE_URL; ?>/dashboard/subscriptions" class="row g-3">
                        <div class="col-md-3">
                            <select class="form-select form-select-sm" name="status" id="statusFilter">
                                <option value="">جميع الحالات</option>
                                <option value="active" <?php echo (isset($_GET['status']) && $_GET['status'] == 'active') ? 'selected' : ''; ?>>نشط</option>
                                <option value="paused" <?php echo (isset($_GET['status']) && $_GET['status'] == 'paused') ? 'selected' : ''; ?>>متوقف مؤقتًا</option>
                                <option value="completed" <?php echo (isset($_GET['status']) && $_GET['status'] == 'completed') ? 'selected' : ''; ?>>مكتمل</option>
                                <option value="expired" <?php echo (isset($_GET['status']) && $_GET['status'] == 'expired') ? 'selected' : ''; ?>>منتهي</option>
                                <option value="canceled" <?php echo (isset($_GET['status']) && $_GET['status'] == 'canceled') ? 'selected' : ''; ?>>ملغي</option>
                            </select>
                        </div>
                        <div class="col-md-7">
                            <input type="text" class="form-control form-control-sm" name="search" placeholder="بحث بالرابط أو اسم الخدمة" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary btn-sm w-100">بحث</button>
                        </div>
                    </form>
                </div>
                
                <!-- جدول الاشتراكات -->
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>رقم الاشتراك</th>
                                <th>الخدمة</th>
                                <th>الرابط</th>
                                <th>الكمية</th>
                                <th>التكرار</th>
                                <th>الحالة</th>
                                <th>آخر تنفيذ</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($subscriptions)): ?>
                                <?php foreach ($subscriptions as $subscription): ?>
                                <tr>
                                    <td>#<?php echo $subscription['id']; ?></td>
                                    <td>
                                        <span class="d-inline-block text-truncate" style="max-width: 150px;" title="<?php echo $subscription['service_name']; ?>">
                                            <?php echo $subscription['service_name']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="<?php echo $subscription['link']; ?>" target="_blank" class="d-inline-block text-truncate" style="max-width: 150px;" title="<?php echo $subscription['link']; ?>">
                                            <?php echo $subscription['link']; ?>
                                        </a>
                                    </td>
                                    <td><?php echo number_format($subscription['quantity']); ?></td>
                                    <td>
                                        <?php 
                                            switch($subscription['interval']) {
                                                case 'daily':
                                                    echo 'يومي';
                                                    break;
                                                case 'weekly':
                                                    echo 'أسبوعي';
                                                    break;
                                                case 'monthly':
                                                    echo 'شهري';
                                                    break;
                                                default:
                                                    echo $subscription['interval'];
                                            }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        switch ($subscription['status']) {
                                            case 'active':
                                                echo '<span class="badge bg-success">نشط</span>';
                                                break;
                                            case 'paused':
                                                echo '<span class="badge bg-warning">متوقف مؤقتًا</span>';
                                                break;
                                            case 'completed':
                                                echo '<span class="badge bg-info">مكتمل</span>';
                                                break;
                                            case 'expired':
                                                echo '<span class="badge bg-secondary">منتهي</span>';
                                                break;
                                            case 'canceled':
                                                echo '<span class="badge bg-danger">ملغي</span>';
                                                break;
                                            default:
                                                echo '<span class="badge bg-secondary">' . $subscription['status'] . '</span>';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php echo !empty($subscription['last_run']) ? formatDate($subscription['last_run']) : '-'; ?>
                                    </td>
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-sm btn-light border dropdown-toggle" type="button" id="actionDropdown<?php echo $subscription['id']; ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                                <i class="fas fa-ellipsis-h"></i>
                                            </button>
                                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="actionDropdown<?php echo $subscription['id']; ?>">
                                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/dashboard/subscription/<?php echo $subscription['id']; ?>"><i class="fas fa-eye me-2"></i> تفاصيل</a></li>
                                                
                                                <?php if ($subscription['status'] == 'active'): ?>
                                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/dashboard/pause_subscription/<?php echo $subscription['id']; ?>" onclick="return confirm('هل أنت متأكد من رغبتك في إيقاف هذا الاشتراك مؤقتًا؟');"><i class="fas fa-pause-circle me-2"></i> إيقاف مؤقت</a></li>
                                                <?php elseif ($subscription['status'] == 'paused'): ?>
                                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/dashboard/resume_subscription/<?php echo $subscription['id']; ?>"><i class="fas fa-play-circle me-2"></i> استئناف</a></li>
                                                <?php endif; ?>
                                                
                                                <?php if (in_array($subscription['status'], ['active', 'paused'])): ?>
                                                <li><a class="dropdown-item text-danger" href="<?php echo BASE_URL; ?>/dashboard/cancel_subscription/<?php echo $subscription['id']; ?>" onclick="return confirm('هل أنت متأكد من رغبتك في إلغاء هذا الاشتراك؟');"><i class="fas fa-times-circle me-2"></i> إلغاء</a></li>
                                                <?php endif; ?>
                                                
                                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/dashboard/new_subscription?renew=<?php echo $subscription['id']; ?>"><i class="fas fa-redo-alt me-2"></i> تجديد</a></li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center py-4">
                                        <div class="py-5">
                                            <i class="fas fa-sync fa-3x text-muted mb-3"></i>
                                            <h5>لا توجد اشتراكات بعد</h5>
                                            <p class="text-muted">ابدأ بإنشاء اشتراك دوري لخدمات التسويق عبر وسائل التواصل الاجتماعي.</p>
                                            <a href="<?php echo BASE_URL; ?>/dashboard/new_subscription" class="btn btn-primary mt-2">إنشاء اشتراك جديد</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- الترقيم (Pagination) -->
                <?php if (!empty($subscriptions) && $total_pages > 1): ?>
                <div class="p-3 border-top">
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-center mb-0">
                            <?php if ($current_page > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo BASE_URL; ?>/dashboard/subscriptions?page=<?php echo $current_page - 1; ?><?php echo !empty($query_string) ? '&' . $query_string : ''; ?>" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>
                            <?php endif; ?>
                            
                            <?php
                            $start_page = max(1, $current_page - 2);
                            $end_page = min($start_page + 4, $total_pages);
                            
                            if ($end_page - $start_page < 4 && $start_page > 1) {
                                $start_page = max(1, $end_page - 4);
                            }
                            
                            for ($i = $start_page; $i <= $end_page; $i++):
                            ?>
                            <li class="page-item <?php echo ($i == $current_page) ? 'active' : ''; ?>">
                                <a class="page-link" href="<?php echo BASE_URL; ?>/dashboard/subscriptions?page=<?php echo $i; ?><?php echo !empty($query_string) ? '&' . $query_string : ''; ?>"><?php echo $i; ?></a>
                            </li>
                            <?php endfor; ?>
                            
                            <?php if ($current_page < $total_pages): ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo BASE_URL; ?>/dashboard/subscriptions?page=<?php echo $current_page + 1; ?><?php echo !empty($query_string) ? '&' . $query_string : ''; ?>" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4">
        <!-- معلومات الاشتراكات -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">معلومات الاشتراكات</h5>
            </div>
            <div class="card-body">
                <div class="mb-4">
                    <h6 class="mb-3">إحصائيات الاشتراكات</h6>
                    <div class="d-flex mb-2">
                        <div style="width: 110px;"><strong>نشط:</strong></div>
                        <div><?php echo isset($subscription_stats['active']) ? $subscription_stats['active'] : 0; ?></div>
                    </div>
                    <div class="d-flex mb-2">
                        <div style="width: 110px;"><strong>متوقف مؤقتًا:</strong></div>
                        <div><?php echo isset($subscription_stats['paused']) ? $subscription_stats['paused'] : 0; ?></div>
                    </div>
                    <div class="d-flex mb-2">
                        <div style="width: 110px;"><strong>مكتمل:</strong></div>
                        <div><?php echo isset($subscription_stats['completed']) ? $subscription_stats['completed'] : 0; ?></div>
                    </div>
                    <div class="d-flex mb-2">
                        <div style="width: 110px;"><strong>منتهي:</strong></div>
                        <div><?php echo isset($subscription_stats['expired']) ? $subscription_stats['expired'] : 0; ?></div>
                    </div>
                    <div class="d-flex">
                        <div style="width: 110px;"><strong>ملغي:</strong></div>
                        <div><?php echo isset($subscription_stats['canceled']) ? $subscription_stats['canceled'] : 0; ?></div>
                    </div>
                </div>
                
                <div class="alert alert-info">
                    <h6 class="mb-2"><i class="fas fa-info-circle me-2"></i> كيف تعمل الاشتراكات؟</h6>
                    <p class="mb-0 small">الاشتراكات هي طلبات دورية يتم تنفيذها تلقائيًا حسب الفترة الزمنية التي تحددها. سيتم خصم المبلغ من رصيدك في كل مرة يتم فيها تنفيذ الاشتراك.</p>
                </div>
                
                <div class="alert alert-light border">
                    <h6 class="mb-2">فترات الاشتراك</h6>
                    <div class="mb-2 small">
                        <strong>يومي:</strong> يتم تنفيذ الطلب مرة واحدة كل 24 ساعة
                    </div>
                    <div class="mb-2 small">
                        <strong>أسبوعي:</strong> يتم تنفيذ الطلب مرة واحدة كل 7 أيام
                    </div>
                    <div class="small">
                        <strong>شهري:</strong> يتم تنفيذ الطلب مرة واحدة كل 30 يومًا
                    </div>
                </div>
                
                <div class="alert alert-warning">
                    <h6 class="mb-2"><i class="fas fa-exclamation-triangle me-2"></i> ملاحظة مهمة</h6>
                    <p class="mb-0 small">تأكد من وجود رصيد كافٍ في حسابك لتجنب توقف الاشتراكات بسبب نقص الرصيد.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// تنفيذ البحث عند تغيير الحالة
document.addEventListener('DOMContentLoaded', function() {
    const statusFilter = document.getElementById('statusFilter');
    
    if (statusFilter) {
        statusFilter.addEventListener('change', function() {
            this.closest('form').submit();
        });
    }
});
</script>
