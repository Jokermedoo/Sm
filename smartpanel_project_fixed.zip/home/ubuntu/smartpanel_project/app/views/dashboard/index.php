<div class="row mb-4">
    <div class="col-md-12">
        <h1 class="mb-3">مرحباً، <?php echo $_SESSION['username']; ?></h1>
        <p class="text-muted">لوحة التحكم الخاصة بك في تاون ميديا. يمكنك إدارة طلباتك ومراقبة حسابك من هنا.</p>
    </div>
</div>

<!-- الإحصائيات السريعة -->
<div class="row g-4 mb-4">
    <div class="col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0">رصيدك</h5>
                    <div class="stat-icon bg-primary-light">
                        <i class="fas fa-wallet text-primary"></i>
                    </div>
                </div>
                <h3 class="mb-0 text-primary"><?php echo formatCurrency($_SESSION['balance']); ?></h3>
                <a href="<?php echo BASE_URL; ?>/dashboard/add_funds" class="btn btn-sm btn-outline-primary mt-3">إضافة رصيد</a>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0">الطلبات</h5>
                    <div class="stat-icon bg-success-light">
                        <i class="fas fa-shopping-cart text-success"></i>
                    </div>
                </div>
                <h3 class="mb-0 text-success"><?php echo $total_orders; ?></h3>
                <a href="<?php echo BASE_URL; ?>/dashboard/orders" class="btn btn-sm btn-outline-success mt-3">عرض الطلبات</a>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0">الاشتراكات</h5>
                    <div class="stat-icon bg-info-light">
                        <i class="fas fa-sync text-info"></i>
                    </div>
                </div>
                <h3 class="mb-0 text-info"><?php echo $total_subscriptions; ?></h3>
                <a href="<?php echo BASE_URL; ?>/dashboard/subscriptions" class="btn btn-sm btn-outline-info mt-3">عرض الاشتراكات</a>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0">التذاكر</h5>
                    <div class="stat-icon bg-warning-light">
                        <i class="fas fa-ticket-alt text-warning"></i>
                    </div>
                </div>
                <h3 class="mb-0 text-warning"><?php echo $open_tickets; ?></h3>
                <a href="<?php echo BASE_URL; ?>/dashboard/tickets" class="btn btn-sm btn-outline-warning mt-3">عرض التذاكر</a>
            </div>
        </div>
    </div>
</div>

<!-- آخر الطلبات -->
<div class="row mb-4">
    <div class="col-md-12">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
                <h5 class="mb-0">آخر الطلبات</h5>
                <a href="<?php echo BASE_URL; ?>/dashboard/orders" class="btn btn-sm btn-primary">عرض الكل</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>رقم الطلب</th>
                                <th>الخدمة</th>
                                <th>الرابط</th>
                                <th>الكمية</th>
                                <th>السعر</th>
                                <th>الحالة</th>
                                <th>التاريخ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($recent_orders)): ?>
                                <?php foreach ($recent_orders as $order): ?>
                                <tr>
                                    <td>#<?php echo $order['id']; ?></td>
                                    <td><?php echo $order['service_name']; ?></td>
                                    <td>
                                        <a href="<?php echo $order['link']; ?>" target="_blank" title="<?php echo $order['link']; ?>">
                                            <?php echo truncateText($order['link'], 30); ?>
                                        </a>
                                    </td>
                                    <td><?php echo number_format($order['quantity']); ?></td>
                                    <td><?php echo formatCurrency($order['price']); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo getStatusColor($order['status']); ?>">
                                            <?php echo getStatusText($order['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo formatDate($order['created_at']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center py-3">لا توجد طلبات بعد. <a href="<?php echo BASE_URL; ?>/dashboard/new_order">إنشاء طلب جديد</a></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- آخر المعاملات -->
<div class="row mb-4">
    <div class="col-md-12">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
                <h5 class="mb-0">آخر المعاملات</h5>
                <a href="<?php echo BASE_URL; ?>/dashboard/transactions" class="btn btn-sm btn-primary">عرض الكل</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>رقم المعاملة</th>
                                <th>النوع</th>
                                <th>المبلغ</th>
                                <th>الحالة</th>
                                <th>التاريخ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($recent_transactions)): ?>
                                <?php foreach ($recent_transactions as $transaction): ?>
                                <tr>
                                    <td>#<?php echo $transaction['id']; ?></td>
                                    <td>
                                        <?php if ($transaction['type'] == 'deposit'): ?>
                                            <span class="text-success"><i class="fas fa-plus-circle me-1"></i> إيداع</span>
                                        <?php elseif ($transaction['type'] == 'order'): ?>
                                            <span class="text-danger"><i class="fas fa-minus-circle me-1"></i> طلب</span>
                                        <?php else: ?>
                                            <?php echo $transaction['type']; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($transaction['type'] == 'deposit'): ?>
                                            <span class="text-success">+<?php echo formatCurrency($transaction['amount']); ?></span>
                                        <?php elseif ($transaction['type'] == 'order'): ?>
                                            <span class="text-danger">-<?php echo formatCurrency($transaction['amount']); ?></span>
                                        <?php else: ?>
                                            <?php echo formatCurrency($transaction['amount']); ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo getTransactionStatusColor($transaction['status']); ?>">
                                            <?php echo getTransactionStatusText($transaction['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo formatDate($transaction['created_at']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="text-center py-3">لا توجد معاملات بعد.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- روابط سريعة -->
<div class="row">
    <div class="col-md-12">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">روابط سريعة</h5>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-3 col-6">
                        <a href="<?php echo BASE_URL; ?>/dashboard/new_order" class="btn btn-light border d-flex flex-column align-items-center p-3 h-100 w-100">
                            <i class="fas fa-plus-circle fa-2x mb-2 text-primary"></i>
                            <span>طلب جديد</span>
                        </a>
                    </div>
                    <div class="col-md-3 col-6">
                        <a href="<?php echo BASE_URL; ?>/dashboard/add_funds" class="btn btn-light border d-flex flex-column align-items-center p-3 h-100 w-100">
                            <i class="fas fa-wallet fa-2x mb-2 text-success"></i>
                            <span>إضافة رصيد</span>
                        </a>
                    </div>
                    <div class="col-md-3 col-6">
                        <a href="<?php echo BASE_URL; ?>/dashboard/tickets/new" class="btn btn-light border d-flex flex-column align-items-center p-3 h-100 w-100">
                            <i class="fas fa-ticket-alt fa-2x mb-2 text-warning"></i>
                            <span>تذكرة جديدة</span>
                        </a>
                    </div>
                    <div class="col-md-3 col-6">
                        <a href="<?php echo BASE_URL; ?>/dashboard/api" class="btn btn-light border d-flex flex-column align-items-center p-3 h-100 w-100">
                            <i class="fas fa-code fa-2x mb-2 text-info"></i>
                            <span>API</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
