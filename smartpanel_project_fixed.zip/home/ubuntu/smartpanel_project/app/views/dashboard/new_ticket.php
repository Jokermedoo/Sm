<div class="row mb-4">
    <div class="col-md-12">
        <h1 class="mb-3">إنشاء تذكرة دعم جديدة</h1>
        <p class="text-muted">قم بإنشاء تذكرة جديدة للتواصل مع فريق الدعم الفني.</p>
    </div>
</div>

<div class="row">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">تفاصيل التذكرة</h5>
            </div>
            <div class="card-body">
                <form action="<?php echo BASE_URL; ?>/dashboard/tickets/submit" method="post" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="department" class="form-label">القسم</label>
                        <select class="form-select" id="department" name="department" required>
                            <option value="">اختر القسم</option>
                            <option value="technical">الدعم الفني</option>
                            <option value="billing">قسم الفواتير والمدفوعات</option>
                            <option value="orders">استفسارات الطلبات</option>
                            <option value="api">دعم API</option>
                            <option value="other">أخرى</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="subject" class="form-label">الموضوع</label>
                        <input type="text" class="form-control" id="subject" name="subject" required placeholder="أدخل موضوع التذكرة">
                    </div>
                    
                    <div class="mb-3">
                        <label for="message" class="form-label">الرسالة</label>
                        <textarea class="form-control" id="message" name="message" rows="6" required placeholder="اشرح مشكلتك أو استفسارك بالتفصيل"></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label for="priority" class="form-label">الأولوية</label>
                        <select class="form-select" id="priority" name="priority" required>
                            <option value="low">منخفضة</option>
                            <option value="medium" selected>متوسطة</option>
                            <option value="high">عالية</option>
                            <option value="urgent">عاجلة</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="order_id" class="form-label">رقم الطلب (اختياري)</label>
                        <input type="text" class="form-control" id="order_id" name="order_id" placeholder="إذا كانت التذكرة متعلقة بطلب معين">
                    </div>
                    
                    <div class="mb-3">
                        <label for="attachments" class="form-label">المرفقات (اختياري)</label>
                        <input class="form-control" type="file" id="attachments" name="attachments[]" multiple>
                        <div class="form-text">يمكنك إرفاق ما يصل إلى 3 ملفات. الحد الأقصى لحجم الملف: 2 ميجابايت. الصيغ المدعومة: JPG، PNG، PDF، ZIP.</div>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">إرسال التذكرة</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4">
        <!-- نصائح لإنشاء تذكرة فعالة -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">نصائح لإنشاء تذكرة فعالة</h5>
            </div>
            <div class="card-body">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item px-0">
                        <i class="fas fa-check-circle text-success me-2"></i> اختر القسم المناسب لتوجيه التذكرة للفريق المختص.
                    </li>
                    <li class="list-group-item px-0">
                        <i class="fas fa-check-circle text-success me-2"></i> اكتب عنوانًا واضحًا يلخص المشكلة.
                    </li>
                    <li class="list-group-item px-0">
                        <i class="fas fa-check-circle text-success me-2"></i> اشرح المشكلة بالتفصيل وأضف أي معلومات ذات صلة.
                    </li>
                    <li class="list-group-item px-0">
                        <i class="fas fa-check-circle text-success me-2"></i> أرفق لقطات شاشة إذا كانت متاحة لتوضيح المشكلة.
                    </li>
                    <li class="list-group-item px-0">
                        <i class="fas fa-check-circle text-success me-2"></i> حدد الأولوية المناسبة لضمان معالجة التذكرة بشكل صحيح.
                    </li>
                </ul>
            </div>
        </div>
        
        <!-- وقت الاستجابة المتوقع -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">وقت الاستجابة المتوقع</h5>
            </div>
            <div class="card-body">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-bolt text-danger me-2"></i> أولوية عاجلة</span>
                        <span class="badge bg-light text-dark">1-2 ساعة</span>
                    </li>
                    <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-arrow-up text-warning me-2"></i> أولوية عالية</span>
                        <span class="badge bg-light text-dark">4-6 ساعات</span>
                    </li>
                    <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-minus text-info me-2"></i> أولوية متوسطة</span>
                        <span class="badge bg-light text-dark">12-24 ساعة</span>
                    </li>
                    <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-arrow-down text-success me-2"></i> أولوية منخفضة</span>
                        <span class="badge bg-light text-dark">24-48 ساعة</span>
                    </li>
                </ul>
            </div>
        </div>
        
        <!-- التذاكر الحالية -->
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">تذاكرك الحالية</h5>
            </div>
            <div class="card-body p-0">
                <?php if (!empty($active_tickets)): ?>
                <div class="list-group list-group-flush">
                    <?php foreach ($active_tickets as $ticket): ?>
                    <a href="<?php echo BASE_URL; ?>/dashboard/tickets/view/<?php echo $ticket['id']; ?>" class="list-group-item list-group-item-action">
                        <div class="d-flex w-100 justify-content-between align-items-center">
                            <h6 class="mb-1 text-truncate"><?php echo $ticket['subject']; ?></h6>
                            <?php
                            switch ($ticket['status']) {
                                case 'open':
                                    echo '<span class="badge bg-success">مفتوحة</span>';
                                    break;
                                case 'answered':
                                    echo '<span class="badge bg-info">تم الرد</span>';
                                    break;
                                case 'customer_reply':
                                    echo '<span class="badge bg-primary">رد العميل</span>';
                                    break;
                                default:
                                    echo '<span class="badge bg-secondary">غير معروفة</span>';
                            }
                            ?>
                        </div>
                        <small class="text-muted"><?php echo formatDate($ticket['updated_at']); ?></small>
                    </a>
                    <?php endforeach; ?>
                </div>
                <?php else: ?>
                <div class="text-center py-4">
                    <p class="mb-0">لا توجد تذاكر نشطة حالياً</p>
                </div>
                <?php endif; ?>
                
                <div class="p-3 border-top">
                    <a href="<?php echo BASE_URL; ?>/dashboard/tickets" class="btn btn-sm btn-outline-primary d-block">عرض جميع التذاكر</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // التحقق من عدد الملفات المرفقة
    const attachmentsInput = document.getElementById('attachments');
    const maxFiles = 3;
    
    attachmentsInput.addEventListener('change', function() {
        if (this.files.length > maxFiles) {
            alert(`يمكنك إرفاق ${maxFiles} ملفات كحد أقصى. الرجاء تقليل عدد الملفات المحددة.`);
            this.value = ''; // إعادة تعيين الاختيار
        }
        
        // التحقق من حجم الملفات
        const maxSize = 2 * 1024 * 1024; // 2 ميجابايت
        
        for (let i = 0; i < this.files.length; i++) {
            if (this.files[i].size > maxSize) {
                alert(`الملف "${this.files[i].name}" أكبر من الحد المسموح به (2 ميجابايت). الرجاء اختيار ملف أصغر.`);
                this.value = ''; // إعادة تعيين الاختيار
                break;
            }
        }
    });
});
</script>
