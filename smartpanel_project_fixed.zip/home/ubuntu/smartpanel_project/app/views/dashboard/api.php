<div class="row mb-4">
    <div class="col-md-12">
        <h1 class="mb-3">واجهة برمجة التطبيقات (API)</h1>
        <p class="text-muted">استخدم واجهة برمجة التطبيقات لإرسال الطلبات برمجيًا من تطبيقك أو موقعك الإلكتروني.</p>
    </div>
</div>

<div class="row">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">معلومات الـ API</h5>
            </div>
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-md-12">
                        <div class="alert alert-primary d-flex align-items-center">
                            <i class="fas fa-info-circle fa-2x me-3"></i>
                            <div>
                                <h6 class="mb-1">ملاحظة مهمة</h6>
                                <p class="mb-0">لا تشارك مفتاح API الخاص بك مع أي شخص. يمنح هذا المفتاح وصولاً كاملاً إلى حسابك.</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <label class="form-label">عنوان API</label>
                        <div class="input-group">
                            <input type="text" class="form-control" value="<?php echo BASE_URL; ?>/api/v1" readonly id="apiUrl">
                            <button class="btn btn-outline-secondary" type="button" onclick="copyToClipboard('apiUrl')">
                                <i class="fas fa-copy"></i>
                            </button>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">مفتاح API</label>
                        <div class="input-group">
                            <input type="text" class="form-control" value="<?php echo $api_key; ?>" readonly id="apiKey">
                            <button class="btn btn-outline-secondary" type="button" onclick="copyToClipboard('apiKey')">
                                <i class="fas fa-copy"></i>
                            </button>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <a href="<?php echo BASE_URL; ?>/dashboard/regenerate_api_key" class="btn btn-warning" onclick="return confirm('هل أنت متأكد من رغبتك في إعادة إنشاء مفتاح API؟ سيتم إبطال مفتاحك الحالي.');">
                            <i class="fas fa-sync me-1"></i> إعادة إنشاء مفتاح API
                        </a>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-12">
                        <h5 class="mb-3">نقاط النهاية المتاحة</h5>
                        
                        <div class="accordion" id="apiEndpoints">
                            <!-- نقطة النهاية: معلومات الحساب -->
                            <div class="accordion-item border mb-3 rounded">
                                <h2 class="accordion-header" id="accountInfo">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#accountInfoCollapse" aria-expanded="false" aria-controls="accountInfoCollapse">
                                        <div class="d-flex align-items-center w-100">
                                            <span class="badge bg-primary me-2">GET</span>
                                            <span>/api/v1/account</span>
                                        </div>
                                    </button>
                                </h2>
                                <div id="accountInfoCollapse" class="accordion-collapse collapse" aria-labelledby="accountInfo" data-bs-parent="#apiEndpoints">
                                    <div class="accordion-body">
                                        <p>الحصول على معلومات حسابك بما في ذلك الرصيد والبيانات الشخصية.</p>
                                        
                                        <h6 class="mt-3">المعلمات</h6>
                                        <div class="table-responsive">
                                            <table class="table table-bordered">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>المعلمة</th>
                                                        <th>الوصف</th>
                                                        <th>مطلوب</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>api_key</td>
                                                        <td>مفتاح API الخاص بك</td>
                                                        <td>نعم</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        
                                        <h6 class="mt-3">مثال على الاستجابة</h6>
<pre class="bg-light p-3 rounded"><code>{
    "status": "success",
    "data": {
        "username": "user123",
        "email": "user@example.com",
        "balance": "500.00",
        "currency": "USD",
        "created_at": "2023-01-15"
    }
}</code></pre>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- نقطة النهاية: الخدمات -->
                            <div class="accordion-item border mb-3 rounded">
                                <h2 class="accordion-header" id="services">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#servicesCollapse" aria-expanded="false" aria-controls="servicesCollapse">
                                        <div class="d-flex align-items-center w-100">
                                            <span class="badge bg-primary me-2">GET</span>
                                            <span>/api/v1/services</span>
                                        </div>
                                    </button>
                                </h2>
                                <div id="servicesCollapse" class="accordion-collapse collapse" aria-labelledby="services" data-bs-parent="#apiEndpoints">
                                    <div class="accordion-body">
                                        <p>الحصول على قائمة بجميع الخدمات المتاحة.</p>
                                        
                                        <h6 class="mt-3">المعلمات</h6>
                                        <div class="table-responsive">
                                            <table class="table table-bordered">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>المعلمة</th>
                                                        <th>الوصف</th>
                                                        <th>مطلوب</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>api_key</td>
                                                        <td>مفتاح API الخاص بك</td>
                                                        <td>نعم</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        
                                        <h6 class="mt-3">مثال على الاستجابة</h6>
<pre class="bg-light p-3 rounded"><code>{
    "status": "success",
    "data": [
        {
            "id": 1,
            "name": "Instagram Followers",
            "category": "Instagram",
            "price": "5.00",
            "min": 100,
            "max": 10000,
            "description": "High quality Instagram followers"
        },
        {
            "id": 2,
            "name": "Facebook Page Likes",
            "category": "Facebook",
            "price": "4.50",
            "min": 50,
            "max": 5000,
            "description": "Real Facebook page likes"
        }
    ]
}</code></pre>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- نقطة النهاية: إنشاء طلب -->
                            <div class="accordion-item border mb-3 rounded">
                                <h2 class="accordion-header" id="createOrder">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#createOrderCollapse" aria-expanded="false" aria-controls="createOrderCollapse">
                                        <div class="d-flex align-items-center w-100">
                                            <span class="badge bg-success me-2">POST</span>
                                            <span>/api/v1/order</span>
                                        </div>
                                    </button>
                                </h2>
                                <div id="createOrderCollapse" class="accordion-collapse collapse" aria-labelledby="createOrder" data-bs-parent="#apiEndpoints">
                                    <div class="accordion-body">
                                        <p>إنشاء طلب جديد.</p>
                                        
                                        <h6 class="mt-3">المعلمات</h6>
                                        <div class="table-responsive">
                                            <table class="table table-bordered">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>المعلمة</th>
                                                        <th>الوصف</th>
                                                        <th>مطلوب</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>api_key</td>
                                                        <td>مفتاح API الخاص بك</td>
                                                        <td>نعم</td>
                                                    </tr>
                                                    <tr>
                                                        <td>service</td>
                                                        <td>معرف الخدمة</td>
                                                        <td>نعم</td>
                                                    </tr>
                                                    <tr>
                                                        <td>link</td>
                                                        <td>رابط المنشور أو الحساب</td>
                                                        <td>نعم</td>
                                                    </tr>
                                                    <tr>
                                                        <td>quantity</td>
                                                        <td>الكمية المطلوبة</td>
                                                        <td>نعم</td>
                                                    </tr>
                                                    <tr>
                                                        <td>comments</td>
                                                        <td>التعليقات (للخدمات التي تتطلب تعليقات)</td>
                                                        <td>لا</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        
                                        <h6 class="mt-3">مثال على الاستجابة</h6>
<pre class="bg-light p-3 rounded"><code>{
    "status": "success",
    "data": {
        "order_id": 12345,
        "service": "Instagram Followers",
        "link": "https://instagram.com/username",
        "quantity": 1000,
        "price": "5.00",
        "status": "pending"
    }
}</code></pre>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- نقطة النهاية: حالة الطلب -->
                            <div class="accordion-item border mb-3 rounded">
                                <h2 class="accordion-header" id="orderStatus">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#orderStatusCollapse" aria-expanded="false" aria-controls="orderStatusCollapse">
                                        <div class="d-flex align-items-center w-100">
                                            <span class="badge bg-primary me-2">GET</span>
                                            <span>/api/v1/order/status</span>
                                        </div>
                                    </button>
                                </h2>
                                <div id="orderStatusCollapse" class="accordion-collapse collapse" aria-labelledby="orderStatus" data-bs-parent="#apiEndpoints">
                                    <div class="accordion-body">
                                        <p>الحصول على حالة طلب محدد.</p>
                                        
                                        <h6 class="mt-3">المعلمات</h6>
                                        <div class="table-responsive">
                                            <table class="table table-bordered">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>المعلمة</th>
                                                        <th>الوصف</th>
                                                        <th>مطلوب</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>api_key</td>
                                                        <td>مفتاح API الخاص بك</td>
                                                        <td>نعم</td>
                                                    </tr>
                                                    <tr>
                                                        <td>order_id</td>
                                                        <td>معرف الطلب</td>
                                                        <td>نعم</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        
                                        <h6 class="mt-3">مثال على الاستجابة</h6>
<pre class="bg-light p-3 rounded"><code>{
    "status": "success",
    "data": {
        "order_id": 12345,
        "service": "Instagram Followers",
        "link": "https://instagram.com/username",
        "quantity": 1000,
        "remains": 200,
        "status": "processing",
        "created_at": "2023-05-20 15:30:45"
    }
}</code></pre>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- نقطة النهاية: قائمة الطلبات -->
                            <div class="accordion-item border mb-3 rounded">
                                <h2 class="accordion-header" id="ordersList">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#ordersListCollapse" aria-expanded="false" aria-controls="ordersListCollapse">
                                        <div class="d-flex align-items-center w-100">
                                            <span class="badge bg-primary me-2">GET</span>
                                            <span>/api/v1/orders</span>
                                        </div>
                                    </button>
                                </h2>
                                <div id="ordersListCollapse" class="accordion-collapse collapse" aria-labelledby="ordersList" data-bs-parent="#apiEndpoints">
                                    <div class="accordion-body">
                                        <p>الحصول على قائمة بجميع طلباتك.</p>
                                        
                                        <h6 class="mt-3">المعلمات</h6>
                                        <div class="table-responsive">
                                            <table class="table table-bordered">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>المعلمة</th>
                                                        <th>الوصف</th>
                                                        <th>مطلوب</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>api_key</td>
                                                        <td>مفتاح API الخاص بك</td>
                                                        <td>نعم</td>
                                                    </tr>
                                                    <tr>
                                                        <td>status</td>
                                                        <td>تصفية حسب الحالة (pending, processing, completed, canceled, all)</td>
                                                        <td>لا</td>
                                                    </tr>
                                                    <tr>
                                                        <td>page</td>
                                                        <td>رقم الصفحة للنتائج</td>
                                                        <td>لا</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        
                                        <h6 class="mt-3">مثال على الاستجابة</h6>
<pre class="bg-light p-3 rounded"><code>{
    "status": "success",
    "data": {
        "orders": [
            {
                "order_id": 12345,
                "service": "Instagram Followers",
                "link": "https://instagram.com/username",
                "quantity": 1000,
                "price": "5.00",
                "status": "completed",
                "created_at": "2023-05-20 15:30:45"
            },
            {
                "order_id": 12346,
                "service": "Facebook Page Likes",
                "link": "https://facebook.com/page",
                "quantity": 500,
                "price": "2.25",
                "status": "processing",
                "created_at": "2023-05-21 10:15:30"
            }
        ],
        "pagination": {
            "current_page": 1,
            "total_pages": 5,
            "total_orders": 48
        }
    }
}</code></pre>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">أمثلة على الكود</h5>
            </div>
            <div class="card-body">
                <ul class="nav nav-tabs mb-3" id="codeExampleTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="php-tab" data-bs-toggle="tab" data-bs-target="#php" type="button" role="tab" aria-controls="php" aria-selected="true">PHP</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="javascript-tab" data-bs-toggle="tab" data-bs-target="#javascript" type="button" role="tab" aria-controls="javascript" aria-selected="false">JavaScript</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="python-tab" data-bs-toggle="tab" data-bs-target="#python" type="button" role="tab" aria-controls="python" aria-selected="false">Python</button>
                    </li>
                </ul>
                <div class="tab-content" id="codeExampleTabContent">
                    <div class="tab-pane fade show active" id="php" role="tabpanel" aria-labelledby="php-tab">
<pre class="bg-light p-3 rounded"><code>// مثال على إنشاء طلب جديد باستخدام PHP

$api_url = '<?php echo BASE_URL; ?>/api/v1/order';
$api_key = 'YOUR_API_KEY'; // استبدل بمفتاح API الخاص بك

$data = [
    'api_key' => $api_key,
    'service' => 1, // معرف الخدمة
    'link' => 'https://instagram.com/username',
    'quantity' => 1000
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $api_url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);
print_r($result);
</code></pre>
                    </div>
                    <div class="tab-pane fade" id="javascript" role="tabpanel" aria-labelledby="javascript-tab">
<pre class="bg-light p-3 rounded"><code>// مثال على إنشاء طلب جديد باستخدام JavaScript

const apiUrl = '<?php echo BASE_URL; ?>/api/v1/order';
const apiKey = 'YOUR_API_KEY'; // استبدل بمفتاح API الخاص بك

const data = {
    api_key: apiKey,
    service: 1, // معرف الخدمة
    link: 'https://instagram.com/username',
    quantity: 1000
};

fetch(apiUrl, {
    method: 'POST',
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams(data),
})
.then(response => response.json())
.then(result => {
    console.log(result);
})
.catch(error => {
    console.error('Error:', error);
});
</code></pre>
                    </div>
                    <div class="tab-pane fade" id="python" role="tabpanel" aria-labelledby="python-tab">
<pre class="bg-light p-3 rounded"><code>import requests

# مثال على إنشاء طلب جديد باستخدام Python

api_url = '<?php echo BASE_URL; ?>/api/v1/order'
api_key = 'YOUR_API_KEY'  # استبدل بمفتاح API الخاص بك

data = {
    'api_key': api_key,
    'service': 1,  # معرف الخدمة
    'link': 'https://instagram.com/username',
    'quantity': 1000
}

response = requests.post(api_url, data=data)
result = response.json()
print(result)
</code></pre>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4">
        <!-- معلومات عن API -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">استخدام الـ API</h5>
            </div>
            <div class="card-body">
                <p>واجهة برمجة التطبيقات (API) تسمح لك بالتفاعل مع تاون ميديا برمجيًا وإرسال الطلبات مباشرة من تطبيقك أو موقعك الإلكتروني.</p>
                
                <h6 class="mt-3">الفوائد</h6>
                <ul class="list-group list-group-flush mb-3">
                    <li class="list-group-item px-0">
                        <i class="fas fa-check-circle text-success me-2"></i> أتمتة طلبات التسويق الاجتماعي
                    </li>
                    <li class="list-group-item px-0">
                        <i class="fas fa-check-circle text-success me-2"></i> التكامل مع تطبيقات وأنظمة أخرى
                    </li>
                    <li class="list-group-item px-0">
                        <i class="fas fa-check-circle text-success me-2"></i> إرسال طلبات متعددة بسهولة
                    </li>
                    <li class="list-group-item px-0">
                        <i class="fas fa-check-circle text-success me-2"></i> تتبع حالة الطلبات برمجيًا
                    </li>
                </ul>
                
                <h6 class="mt-3">المصادقة</h6>
                <p>تتم المصادقة عبر إرسال مفتاح API مع كل طلب. يمكنك إعادة إنشاء مفتاح API في أي وقت للحفاظ على أمان حسابك.</p>
                
                <h6 class="mt-3">معدل الطلبات</h6>
                <p>الحد الأقصى لعدد الطلبات هو 100 طلب في الدقيقة لكل مستخدم. إذا تجاوزت هذا الحد، سيتم تقييد وصولك مؤقتًا.</p>
            </div>
        </div>
        
        <!-- سجل استخدام API -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">سجل استخدام API</h5>
            </div>
            <div class="card-body p-0">
                <?php if (!empty($api_logs)): ?>
                <div class="list-group list-group-flush">
                    <?php foreach ($api_logs as $log): ?>
                    <div class="list-group-item">
                        <div class="d-flex justify-content-between align-items-center">
                            <span>
                                <span class="badge bg-<?php echo ($log['status'] == 'success') ? 'success' : 'danger'; ?> me-2">
                                    <?php echo strtoupper($log['method']); ?>
                                </span>
                                <?php echo $log['endpoint']; ?>
                            </span>
                            <small class="text-muted"><?php echo formatDate($log['created_at']); ?></small>
                        </div>
                        <small class="text-muted d-block mt-1"><?php echo $log['ip_address']; ?></small>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php else: ?>
                <div class="text-center py-4">
                    <p class="mb-0">لا توجد سجلات استخدام بعد</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- الدعم الفني -->
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="me-3">
                        <i class="fas fa-headset fa-2x text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-1">بحاجة إلى مساعدة في API؟</h5>
                        <p class="mb-2">فريق الدعم الفني متاح لمساعدتك في تكامل API مع تطبيقك.</p>
                        <a href="<?php echo BASE_URL; ?>/dashboard/tickets/new?department=api" class="btn btn-sm btn-outline-primary">فتح تذكرة دعم</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// نسخ النص إلى الحافظة
function copyToClipboard(elementId) {
    const element = document.getElementById(elementId);
    element.select();
    document.execCommand('copy');
    
    // إظهار رسالة نجاح
    alert('تم نسخ النص!');
}
</script>
