<div class="row mb-4">
    <div class="col-md-12">
        <h1 class="mb-3">طلب جديد</h1>
        <p class="text-muted">أنشئ طلبًا جديدًا لخدمات التسويق عبر وسائل التواصل الاجتماعي.</p>
    </div>
</div>

<div class="row">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">تفاصيل الطلب</h5>
            </div>
            <div class="card-body">
                <form id="newOrderForm" action="<?php echo BASE_URL; ?>/dashboard/submit_order" method="post">
                    <div class="mb-3">
                        <label for="category" class="form-label">الفئة</label>
                        <select class="form-select" id="category" name="category" required>
                            <option value="">اختر الفئة</option>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?php echo $category['id']; ?>"><?php echo $category['name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="service" class="form-label">الخدمة</label>
                        <select class="form-select" id="service" name="service" required disabled>
                            <option value="">اختر الخدمة أولاً</option>
                        </select>
                        <div class="form-text mt-2 service-description" id="serviceDescription"></div>
                    </div>
                    
                    <div id="dynamicFields">
                        <!-- هنا سيتم إضافة الحقول الديناميكية بناءً على نوع الخدمة -->
                    </div>
                    
                    <div class="mb-3" id="linkField" style="display:none;">
                        <label for="link" class="form-label">الرابط</label>
                        <input type="text" class="form-control" id="link" name="link" placeholder="https://">
                        <div class="form-text">أدخل رابط المنشور أو الحساب الذي تريد تعزيزه.</div>
                    </div>
                    
                    <div class="mb-3" id="quantityField" style="display:none;">
                        <label for="quantity" class="form-label">الكمية</label>
                        <input type="number" class="form-control" id="quantity" name="quantity" min="1">
                        <div class="form-text">الحد الأدنى: <span id="minQuantity">1</span>, الحد الأقصى: <span id="maxQuantity">1000</span></div>
                    </div>
                    
                    <div class="mb-3" id="usernameField" style="display:none;">
                        <label for="username" class="form-label">اسم المستخدم</label>
                        <input type="text" class="form-control" id="username" name="username" placeholder="@username">
                        <div class="form-text">أدخل اسم المستخدم بدون علامة @.</div>
                    </div>
                    
                    <div class="mb-3" id="commentsField" style="display:none;">
                        <label for="comments" class="form-label">التعليقات</label>
                        <textarea class="form-control" id="comments" name="comments" rows="4" placeholder="تعليق لكل سطر"></textarea>
                        <div class="form-text">أدخل تعليق واحد لكل سطر.</div>
                    </div>
                    
                    <div class="mb-3" id="answerNumberField" style="display:none;">
                        <label for="answerNumber" class="form-label">عدد الإجابات</label>
                        <input type="number" class="form-control" id="answerNumber" name="answerNumber" min="1">
                    </div>
                    
                    <div class="mb-3" id="delayField" style="display:none;">
                        <label for="delay" class="form-label">التأخير (بالدقائق)</label>
                        <input type="number" class="form-control" id="delay" name="delay" min="0">
                        <div class="form-text">تأخير قبل بدء تنفيذ الطلب (0 للتنفيذ الفوري).</div>
                    </div>
                    
                    <div class="alert alert-info" id="orderSummary" style="display:none;">
                        <h6>ملخص الطلب:</h6>
                        <p><strong>السعر:</strong> <span id="orderPrice">0</span> <?php echo CURRENCY_CODE; ?></p>
                        <p class="mb-0"><strong>الخدمة:</strong> <span id="orderService">-</span></p>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">إرسال الطلب</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4">
        <!-- معلومات الرصيد -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">رصيدك</h5>
            </div>
            <div class="card-body">
                <h3 class="text-primary mb-3"><?php echo formatCurrency($_SESSION['balance']); ?></h3>
                <a href="<?php echo BASE_URL; ?>/dashboard/add_funds" class="btn btn-primary d-block">إضافة رصيد</a>
            </div>
        </div>
        
        <!-- معلومات الطلب -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">معلومات مهمة</h5>
            </div>
            <div class="card-body">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item px-0">
                        <i class="fas fa-clock text-primary me-2"></i> وقت المعالجة: يختلف حسب الخدمة
                    </li>
                    <li class="list-group-item px-0">
                        <i class="fas fa-shield-alt text-primary me-2"></i> خدماتنا آمنة 100% على حسابك
                    </li>
                    <li class="list-group-item px-0">
                        <i class="fas fa-info-circle text-primary me-2"></i> قد تتغير الأسعار بناءً على الكمية المطلوبة
                    </li>
                    <li class="list-group-item px-0">
                        <i class="fas fa-headset text-primary me-2"></i> دعم فني 24/7 لأي استفسارات
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<script>
// JavaScript لإدارة النموذج الديناميكي للطلب الجديد
document.addEventListener('DOMContentLoaded', function() {
    const categorySelect = document.getElementById('category');
    const serviceSelect = document.getElementById('service');
    const serviceDescription = document.getElementById('serviceDescription');
    const quantityField = document.getElementById('quantityField');
    const linkField = document.getElementById('linkField');
    const usernameField = document.getElementById('usernameField');
    const commentsField = document.getElementById('commentsField');
    const answerNumberField = document.getElementById('answerNumberField');
    const delayField = document.getElementById('delayField');
    const minQuantity = document.getElementById('minQuantity');
    const maxQuantity = document.getElementById('maxQuantity');
    const orderSummary = document.getElementById('orderSummary');
    const orderPrice = document.getElementById('orderPrice');
    const orderService = document.getElementById('orderService');
    const quantity = document.getElementById('quantity');
    
    // تحميل الخدمات عند تغيير الفئة
    categorySelect.addEventListener('change', function() {
        const categoryId = this.value;
        
        // إعادة تعيين الحقول
        serviceSelect.innerHTML = '<option value="">اختر الخدمة</option>';
        serviceSelect.disabled = true;
        
        if (categoryId) {
            // AJAX لجلب الخدمات بناءً على الفئة المحددة
            fetch(`${baseUrl}/dashboard/get_services/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.length > 0) {
                        data.forEach(service => {
                            const option = document.createElement('option');
                            option.value = service.id;
                            option.textContent = `${service.name} (${formatCurrency(service.price)}/1000)`;
                            option.dataset.price = service.price;
                            option.dataset.min = service.min;
                            option.dataset.max = service.max;
                            option.dataset.type = service.type;
                            option.dataset.description = service.description;
                            serviceSelect.appendChild(option);
                        });
                        serviceSelect.disabled = false;
                    }
                })
                .catch(error => console.error('Error loading services:', error));
        }
    });
    
    // تحديث الحقول بناءً على الخدمة المحددة
    serviceSelect.addEventListener('change', function() {
        hideAllFields();
        
        if (this.value) {
            const selectedOption = this.options[this.selectedIndex];
            const serviceType = selectedOption.dataset.type;
            const serviceMinQuantity = parseInt(selectedOption.dataset.min);
            const serviceMaxQuantity = parseInt(selectedOption.dataset.max);
            const servicePrice = parseFloat(selectedOption.dataset.price);
            const serviceName = selectedOption.textContent;
            const description = selectedOption.dataset.description;
            
            // عرض وصف الخدمة
            serviceDescription.textContent = description;
            
            // تحديث الحقول بناءً على نوع الخدمة
            if (serviceType.includes('link')) {
                linkField.style.display = 'block';
            }
            
            if (serviceType.includes('quantity')) {
                quantityField.style.display = 'block';
                minQuantity.textContent = serviceMinQuantity;
                maxQuantity.textContent = serviceMaxQuantity;
                
                // تعيين الحد الأدنى والأقصى للكمية
                quantity.min = serviceMinQuantity;
                quantity.max = serviceMaxQuantity;
                quantity.value = serviceMinQuantity;
            }
            
            if (serviceType.includes('username')) {
                usernameField.style.display = 'block';
            }
            
            if (serviceType.includes('comments')) {
                commentsField.style.display = 'block';
            }
            
            if (serviceType.includes('answer')) {
                answerNumberField.style.display = 'block';
            }
            
            if (serviceType.includes('delay')) {
                delayField.style.display = 'block';
            }
            
            // تحديث ملخص الطلب
            orderService.textContent = serviceName;
            calculatePrice(servicePrice, serviceMinQuantity);
            orderSummary.style.display = 'block';
        } else {
            orderSummary.style.display = 'none';
            serviceDescription.textContent = '';
        }
    });
    
    // حساب السعر عند تغيير الكمية
    quantity.addEventListener('input', function() {
        if (serviceSelect.value) {
            const selectedOption = serviceSelect.options[serviceSelect.selectedIndex];
            const servicePrice = parseFloat(selectedOption.dataset.price);
            calculatePrice(servicePrice, this.value);
        }
    });
    
    // حساب السعر
    function calculatePrice(pricePerThousand, quantity) {
        const price = (pricePerThousand / 1000) * quantity;
        orderPrice.textContent = formatCurrency(price);
    }
    
    // إخفاء جميع الحقول الديناميكية
    function hideAllFields() {
        linkField.style.display = 'none';
        quantityField.style.display = 'none';
        usernameField.style.display = 'none';
        commentsField.style.display = 'none';
        answerNumberField.style.display = 'none';
        delayField.style.display = 'none';
    }
    
    // تنسيق السعر
    function formatCurrency(amount) {
        return parseFloat(amount).toFixed(2) + ' <?php echo CURRENCY_CODE; ?>';
    }
});
</script>
