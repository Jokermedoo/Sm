<div class="row mb-4">
    <div class="col-md-12">
        <h1 class="mb-3">الملف الشخصي</h1>
        <p class="text-muted">إدارة معلوماتك الشخصية وإعدادات الحساب.</p>
    </div>
</div>

<div class="row">
    <div class="col-lg-4 mb-4">
        <!-- بطاقة الملف الشخصي -->
        <div class="card border-0 shadow-sm text-center">
            <div class="card-body">
                <div class="mb-3">
                    <img src="<?php echo getProfileImage($user['id']); ?>" alt="الصورة الشخصية" class="rounded-circle img-thumbnail" width="120" height="120">
                </div>
                <h5 class="card-title mb-1"><?php echo $user['full_name']; ?></h5>
                <p class="text-muted mb-3">@<?php echo $user['username']; ?></p>
                
                <div class="d-flex justify-content-center mb-3">
                    <div class="mx-2 text-center">
                        <div class="fw-bold text-primary"><?php echo $total_orders; ?></div>
                        <small class="text-muted">الطلبات</small>
                    </div>
                    <div class="mx-2 text-center">
                        <div class="fw-bold text-primary"><?php echo formatCurrency($user['total_spent']); ?></div>
                        <small class="text-muted">الإنفاق</small>
                    </div>
                    <div class="mx-2 text-center">
                        <div class="fw-bold text-primary"><?php echo formatDate($user['created_at'], 'd/m/Y'); ?></div>
                        <small class="text-muted">تاريخ التسجيل</small>
                    </div>
                </div>
                
                <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#changeAvatarModal">
                    <i class="fas fa-camera me-1"></i> تغيير الصورة
                </button>
            </div>
        </div>
    </div>
    
    <div class="col-lg-8">
        <!-- تحديث المعلومات الشخصية -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">المعلومات الشخصية</h5>
            </div>
            <div class="card-body">
                <form action="<?php echo BASE_URL; ?>/dashboard/update_profile" method="post">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="fullName" class="form-label">الاسم الكامل</label>
                            <input type="text" class="form-control" id="fullName" name="full_name" value="<?php echo $user['full_name']; ?>">
                        </div>
                        <div class="col-md-6">
                            <label for="email" class="form-label">البريد الإلكتروني</label>
                            <input type="email" class="form-control" id="email" value="<?php echo $user['email']; ?>" readonly>
                            <div class="form-text">لا يمكن تغيير البريد الإلكتروني.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="username" class="form-label">اسم المستخدم</label>
                            <input type="text" class="form-control" id="username" value="<?php echo $user['username']; ?>" readonly>
                            <div class="form-text">لا يمكن تغيير اسم المستخدم.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="phone" class="form-label">رقم الهاتف</label>
                            <input type="text" class="form-control" id="phone" name="phone" value="<?php echo $user['phone']; ?>">
                        </div>
                        <div class="col-12">
                            <label for="address" class="form-label">العنوان</label>
                            <textarea class="form-control" id="address" name="address" rows="3"><?php echo $user['address']; ?></textarea>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary">حفظ التغييرات</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- تغيير كلمة المرور -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">تغيير كلمة المرور</h5>
            </div>
            <div class="card-body">
                <form action="<?php echo BASE_URL; ?>/dashboard/update_password" method="post">
                    <div class="row g-3">
                        <div class="col-md-12">
                            <label for="currentPassword" class="form-label">كلمة المرور الحالية</label>
                            <input type="password" class="form-control" id="currentPassword" name="current_password" required>
                        </div>
                        <div class="col-md-6">
                            <label for="newPassword" class="form-label">كلمة المرور الجديدة</label>
                            <input type="password" class="form-control" id="newPassword" name="new_password" required>
                            <div class="form-text">يجب أن تحتوي كلمة المرور على 8 أحرف على الأقل.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="confirmPassword" class="form-label">تأكيد كلمة المرور الجديدة</label>
                            <input type="password" class="form-control" id="confirmPassword" name="confirm_password" required>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary">تحديث كلمة المرور</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- إعدادات الإشعارات -->
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">إعدادات الإشعارات</h5>
            </div>
            <div class="card-body">
                <form action="<?php echo BASE_URL; ?>/dashboard/update_notifications" method="post">
                    <div class="row g-3">
                        <div class="col-12">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="emailNotifications" name="email_notifications" <?php echo $user['email_notifications'] ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="emailNotifications">إشعارات البريد الإلكتروني</label>
                                <div class="form-text">تلقي إشعارات عبر البريد الإلكتروني عند تحديث حالة الطلبات.</div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="smsNotifications" name="sms_notifications" <?php echo $user['sms_notifications'] ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="smsNotifications">إشعارات الرسائل القصيرة</label>
                                <div class="form-text">تلقي إشعارات عبر الرسائل القصيرة لتحديثات مهمة.</div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="marketingEmails" name="marketing_emails" <?php echo $user['marketing_emails'] ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="marketingEmails">رسائل تسويقية</label>
                                <div class="form-text">تلقي عروض وتحديثات تسويقية من تاون ميديا.</div>
                            </div>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary">حفظ الإعدادات</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- مودال تغيير الصورة الشخصية -->
<div class="modal fade" id="changeAvatarModal" tabindex="-1" aria-labelledby="changeAvatarModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="changeAvatarModalLabel">تغيير الصورة الشخصية</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="<?php echo BASE_URL; ?>/dashboard/update_avatar" method="post" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="avatarFile" class="form-label">اختر صورة جديدة</label>
                        <input class="form-control" type="file" id="avatarFile" name="avatar" accept="image/*" required>
                        <div class="form-text">الحد الأقصى لحجم الملف: 2 ميجابايت. الصيغ المدعومة: JPG، PNG، GIF.</div>
                    </div>
                    <div class="text-center mb-3">
                        <img id="avatarPreview" src="#" alt="معاينة الصورة" class="img-thumbnail d-none" style="max-width: 200px; max-height: 200px;">
                    </div>
                    <div class="d-flex justify-content-end">
                        <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary">تحديث الصورة</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // معاينة الصورة قبل الرفع
    const avatarFile = document.getElementById('avatarFile');
    const avatarPreview = document.getElementById('avatarPreview');
    
    avatarFile.addEventListener('change', function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            
            reader.onload = function(e) {
                avatarPreview.src = e.target.result;
                avatarPreview.classList.remove('d-none');
            }
            
            reader.readAsDataURL(file);
        } else {
            avatarPreview.src = '#';
            avatarPreview.classList.add('d-none');
        }
    });
    
    // التحقق من تطابق كلمات المرور
    const newPassword = document.getElementById('newPassword');
    const confirmPassword = document.getElementById('confirmPassword');
    
    function validatePassword() {
        if (newPassword.value !== confirmPassword.value) {
            confirmPassword.setCustomValidity('كلمات المرور غير متطابقة');
        } else {
            confirmPassword.setCustomValidity('');
        }
    }
    
    newPassword.addEventListener('change', validatePassword);
    confirmPassword.addEventListener('keyup', validatePassword);
});
</script>
