<div class="row mb-4">
    <div class="col-md-12">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="mb-1">تفاصيل الطلب #<?php echo $order['id']; ?></h1>
                <p class="text-muted mb-0">تابع حالة وتفاصيل طلبك</p>
            </div>
            <div>
                <?php if ($order['status'] == 'pending'): ?>
                    <a href="<?php echo BASE_URL; ?>/dashboard/cancel_order/<?php echo $order['id']; ?>" class="btn btn-outline-danger" onclick="return confirm('هل أنت متأكد من رغبتك في إلغاء هذا الطلب؟');">
                        <i class="fas fa-times-circle me-1"></i> إلغاء الطلب
                    </a>
                <?php endif; ?>
                <a href="<?php echo BASE_URL; ?>/dashboard/new_order?reorder=<?php echo $order['id']; ?>" class="btn btn-outline-primary ms-2">
                    <i class="fas fa-redo-alt me-1"></i> إعادة الطلب
                </a>
                <a href="<?php echo BASE_URL; ?>/dashboard/orders" class="btn btn-outline-secondary ms-2">
                    <i class="fas fa-arrow-right me-1"></i> العودة
                </a>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-8">
        <!-- بطاقة تفاصيل الطلب -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">معلومات الطلب</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <span class="d-block text-muted">الخدمة</span>
                        <h6><?php echo $order['service_name']; ?></h6>
                    </div>
                    <div class="col-md-6 mb-3">
                        <span class="d-block text-muted">الحالة</span>
                        <div>
                            <span class="badge bg-<?php echo getStatusColor($order['status']); ?> p-2">
                                <?php echo getStatusText($order['status']); ?>
                            </span>
                        </div>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <span class="d-block text-muted">الرابط</span>
                        <div class="d-flex align-items-center">
                            <a href="<?php echo $order['link']; ?>" target="_blank" class="text-truncate">
                                <?php echo $order['link']; ?>
                            </a>
                            <button class="btn btn-sm btn-light border ms-2" onclick="copyToClipboard('<?php echo $order['link']; ?>')">
                                <i class="fas fa-copy"></i>
                            </button>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <span class="d-block text-muted">تاريخ الطلب</span>
                        <h6><?php echo formatDate($order['created_at'], 'd/m/Y H:i'); ?></h6>
                    </div>
                    
                    <div class="col-md-4 mb-3">
                        <span class="d-block text-muted">الكمية المطلوبة</span>
                        <h6><?php echo number_format($order['quantity']); ?></h6>
                    </div>
                    <div class="col-md-4 mb-3">
                        <span class="d-block text-muted">الكمية المنفذة</span>
                        <h6><?php echo number_format($order['remains'] ? $order['quantity'] - $order['remains'] : $order['quantity']); ?></h6>
                    </div>
                    <div class="col-md-4 mb-3">
                        <span class="d-block text-muted">الكمية المتبقية</span>
                        <h6><?php echo number_format($order['remains'] ? $order['remains'] : 0); ?></h6>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <span class="d-block text-muted">السعر</span>
                        <h6><?php echo formatCurrency($order['price']); ?></h6>
                    </div>
                    <div class="col-md-6 mb-3">
                        <span class="d-block text-muted">طريقة الدفع</span>
                        <h6>رصيد الحساب</h6>
                    </div>
                    
                    <?php if ($order['start_counter']): ?>
                    <div class="col-md-6 mb-3">
                        <span class="d-block text-muted">العداد الأولي</span>
                        <h6><?php echo number_format($order['start_counter']); ?></h6>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($order['current_counter']): ?>
                    <div class="col-md-6 mb-3">
                        <span class="d-block text-muted">العداد الحالي</span>
                        <h6><?php echo number_format($order['current_counter']); ?></h6>
                    </div>
                    <?php endif; ?>
                </div>
                
                <?php if (!empty($order['comments'])): ?>
                <div class="mt-2">
                    <span class="d-block text-muted mb-2">التعليقات</span>
                    <div class="p-3 bg-light rounded">
                        <?php echo nl2br(htmlspecialchars($order['comments'])); ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if (!empty($order['error_details'])): ?>
                <div class="mt-3 alert alert-danger">
                    <h6>تفاصيل الخطأ:</h6>
                    <p class="mb-0"><?php echo $order['error_details']; ?></p>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- تتبع حالة الطلب -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">تتبع الحالة</h5>
            </div>
            <div class="card-body">
                <ul class="timeline">
                    <li class="timeline-item">
                        <div class="timeline-marker bg-success"></div>
                        <div class="timeline-content">
                            <h6 class="mb-0">تم إنشاء الطلب</h6>
                            <small class="text-muted"><?php echo formatDate($order['created_at'], 'd/m/Y H:i'); ?></small>
                        </div>
                    </li>
                    
                    <?php if (in_array($order['status'], ['processing', 'completed', 'partial', 'refunded'])): ?>
                    <li class="timeline-item">
                        <div class="timeline-marker <?php echo in_array($order['status'], ['processing', 'completed', 'partial', 'refunded']) ? 'bg-success' : 'bg-light'; ?>"></div>
                        <div class="timeline-content">
                            <h6 class="mb-0">قيد التنفيذ</h6>
                            <small class="text-muted"><?php echo isset($order['processing_at']) ? formatDate($order['processing_at'], 'd/m/Y H:i') : ''; ?></small>
                        </div>
                    </li>
                    <?php endif; ?>
                    
                    <?php if (in_array($order['status'], ['completed', 'partial', 'refunded'])): ?>
                    <li class="timeline-item">
                        <div class="timeline-marker <?php echo in_array($order['status'], ['completed', 'partial', 'refunded']) ? 'bg-success' : 'bg-light'; ?>"></div>
                        <div class="timeline-content">
                            <h6 class="mb-0"><?php echo $order['status'] == 'partial' ? 'مكتمل جزئيًا' : 'مكتمل'; ?></h6>
                            <small class="text-muted"><?php echo isset($order['completed_at']) ? formatDate($order['completed_at'], 'd/m/Y H:i') : ''; ?></small>
                            <?php if ($order['status'] == 'partial'): ?>
                            <p class="mt-1 text-muted small">تم تنفيذ <?php echo number_format($order['quantity'] - $order['remains']); ?> من أصل <?php echo number_format($order['quantity']); ?></p>
                            <?php endif; ?>
                        </div>
                    </li>
                    <?php endif; ?>
                    
                    <?php if ($order['status'] == 'refunded'): ?>
                    <li class="timeline-item">
                        <div class="timeline-marker bg-success"></div>
                        <div class="timeline-content">
                            <h6 class="mb-0">تم استرداد المبلغ</h6>
                            <small class="text-muted"><?php echo isset($order['refunded_at']) ? formatDate($order['refunded_at'], 'd/m/Y H:i') : ''; ?></small>
                            <p class="mt-1 text-muted small">تم استرداد مبلغ <?php echo formatCurrency($order['refund_amount']); ?> إلى رصيدك</p>
                        </div>
                    </li>
                    <?php endif; ?>
                    
                    <?php if ($order['status'] == 'canceled'): ?>
                    <li class="timeline-item">
                        <div class="timeline-marker bg-danger"></div>
                        <div class="timeline-content">
                            <h6 class="mb-0">تم إلغاء الطلب</h6>
                            <small class="text-muted"><?php echo isset($order['canceled_at']) ? formatDate($order['canceled_at'], 'd/m/Y H:i') : ''; ?></small>
                        </div>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        
        <!-- مساعدة ودعم -->
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="me-3">
                        <i class="fas fa-headset fa-2x text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-1">هل تواجه مشكلة مع هذا الطلب؟</h5>
                        <p class="mb-2">يمكنك التواصل مع فريق الدعم الفني على مدار الساعة.</p>
                        <a href="<?php echo BASE_URL; ?>/dashboard/tickets/new?order_id=<?php echo $order['id']; ?>" class="btn btn-sm btn-primary">فتح تذكرة دعم</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4">
        <!-- بطاقة ملخص الطلب -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">ملخص الطلب</h5>
            </div>
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span>رقم الطلب:</span>
                    <span class="fw-bold">#<?php echo $order['id']; ?></span>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span>الخدمة:</span>
                    <span class="text-truncate" style="max-width: 200px;"><?php echo $order['service_name']; ?></span>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span>الكمية:</span>
                    <span><?php echo number_format($order['quantity']); ?></span>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span>التاريخ:</span>
                    <span><?php echo formatDate($order['created_at'], 'd/m/Y'); ?></span>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span>السعر:</span>
                    <span class="fw-bold"><?php echo formatCurrency($order['price']); ?></span>
                </div>
                <div class="d-flex justify-content-between align-items-center">
                    <span>الحالة:</span>
                    <span class="badge bg-<?php echo getStatusColor($order['status']); ?>">
                        <?php echo getStatusText($order['status']); ?>
                    </span>
                </div>
                
                <hr class="my-3">
                
                <div class="progress mb-2" style="height: 20px;">
                    <?php 
                    $progress = 0;
                    
                    if ($order['status'] == 'completed') {
                        $progress = 100;
                    } elseif ($order['status'] == 'partial') {
                        $progress = round(($order['quantity'] - $order['remains']) / $order['quantity'] * 100);
                    } elseif ($order['status'] == 'processing') {
                        $progress = 50;
                    } elseif ($order['status'] == 'pending') {
                        $progress = 10;
                    }
                    
                    $progressColor = 'bg-primary';
                    if ($order['status'] == 'completed') {
                        $progressColor = 'bg-success';
                    } elseif ($order['status'] == 'partial') {
                        $progressColor = 'bg-info';
                    } elseif ($order['status'] == 'canceled' || $order['status'] == 'refunded') {
                        $progressColor = 'bg-danger';
                        $progress = 100;
                    }
                    ?>
                    <div class="progress-bar <?php echo $progressColor; ?>" role="progressbar" style="width: <?php echo $progress; ?>%" aria-valuenow="<?php echo $progress; ?>" aria-valuemin="0" aria-valuemax="100"><?php echo $progress; ?>%</div>
                </div>
                
                <div class="text-center mt-4">
                    <a href="<?php echo BASE_URL; ?>/dashboard/tickets/new?order_id=<?php echo $order['id']; ?>" class="btn btn-outline-primary btn-sm w-100">
                        <i class="fas fa-question-circle me-1"></i> استفسار عن الطلب
                    </a>
                </div>
            </div>
        </div>
        
        <!-- طلبات مشابهة -->
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">طلبات مشابهة</h5>
            </div>
            <div class="card-body p-0">
                <?php if (!empty($similar_orders)): ?>
                <div class="list-group list-group-flush">
                    <?php foreach ($similar_orders as $similar): ?>
                    <a href="<?php echo BASE_URL; ?>/dashboard/order/<?php echo $similar['id']; ?>" class="list-group-item list-group-item-action">
                        <div class="d-flex justify-content-between align-items-center">
                            <span>#<?php echo $similar['id']; ?></span>
                            <span class="badge bg-<?php echo getStatusColor($similar['status']); ?>">
                                <?php echo getStatusText($similar['status']); ?>
                            </span>
                        </div>
                        <div class="d-flex justify-content-between mt-2">
                            <small class="text-muted"><?php echo number_format($similar['quantity']); ?> - <?php echo formatCurrency($similar['price']); ?></small>
                            <small class="text-muted"><?php echo formatDate($similar['created_at'], 'd/m/Y'); ?></small>
                        </div>
                    </a>
                    <?php endforeach; ?>
                </div>
                <?php else: ?>
                <div class="text-center py-4">
                    <p class="mb-0">لا توجد طلبات مشابهة</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<style>
/* تنسيقات تتبع الحالة */
.timeline {
    position: relative;
    padding-left: 10px;
    list-style: none;
}

.timeline:before {
    content: "";
    position: absolute;
    top: 0;
    bottom: 0;
    left: 7px;
    width: 2px;
    background-color: #e9ecef;
}

.timeline-item {
    position: relative;
    padding-bottom: 1.5rem;
}

.timeline-item:last-child {
    padding-bottom: 0;
}

.timeline-marker {
    position: absolute;
    top: 4px;
    left: -5px;
    width: 14px;
    height: 14px;
    border-radius: 50%;
    border: 2px solid #fff;
    box-shadow: 0 0 0 2px #e9ecef;
}

.timeline-content {
    padding-left: 25px;
}
</style>

<script>
// نسخ النص إلى الحافظة
function copyToClipboard(text) {
    const el = document.createElement('textarea');
    el.value = text;
    document.body.appendChild(el);
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);
    
    // إظهار رسالة نجاح
    alert('تم نسخ الرابط!');
}
</script>
