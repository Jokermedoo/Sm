<div class="row mb-4">
    <div class="col-md-12">
        <h1 class="mb-3">المعاملات المالية</h1>
        <p class="text-muted">سجل المعاملات المالية وحركة الرصيد في حسابك.</p>
    </div>
</div>

<div class="row mb-4">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <h5 class="mb-0">سجل المعاملات</h5>
                <a href="<?php echo BASE_URL; ?>/dashboard/add_funds" class="btn btn-sm btn-primary">
                    <i class="fas fa-plus-circle me-1"></i> إضافة رصيد
                </a>
            </div>
            <div class="card-body p-0">
                <!-- فلاتر البحث -->
                <div class="p-3 border-bottom bg-light">
                    <form method="get" action="<?php echo BASE_URL; ?>/dashboard/transactions" class="row g-3">
                        <div class="col-md-3">
                            <select class="form-select form-select-sm" name="type" id="typeFilter">
                                <option value="">جميع المعاملات</option>
                                <option value="deposit" <?php echo (isset($_GET['type']) && $_GET['type'] == 'deposit') ? 'selected' : ''; ?>>إيداع</option>
                                <option value="order" <?php echo (isset($_GET['type']) && $_GET['type'] == 'order') ? 'selected' : ''; ?>>طلب</option>
                                <option value="refund" <?php echo (isset($_GET['type']) && $_GET['type'] == 'refund') ? 'selected' : ''; ?>>استرداد</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <select class="form-select form-select-sm" name="status" id="statusFilter">
                                <option value="">جميع الحالات</option>
                                <option value="pending" <?php echo (isset($_GET['status']) && $_GET['status'] == 'pending') ? 'selected' : ''; ?>>قيد الانتظار</option>
                                <option value="completed" <?php echo (isset($_GET['status']) && $_GET['status'] == 'completed') ? 'selected' : ''; ?>>مكتمل</option>
                                <option value="canceled" <?php echo (isset($_GET['status']) && $_GET['status'] == 'canceled') ? 'selected' : ''; ?>>ملغي</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <input type="text" class="form-control form-control-sm" name="search" placeholder="بحث بالوصف أو المرجع" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary btn-sm w-100">بحث</button>
                        </div>
                    </form>
                </div>
                
                <!-- جدول المعاملات -->
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>رقم المعاملة</th>
                                <th>النوع</th>
                                <th>المبلغ</th>
                                <th>الحالة</th>
                                <th>التفاصيل</th>
                                <th>التاريخ</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($transactions)): ?>
                                <?php foreach ($transactions as $transaction): ?>
                                <tr>
                                    <td>#<?php echo $transaction['id']; ?></td>
                                    <td>
                                        <?php if ($transaction['type'] == 'deposit'): ?>
                                            <span class="badge bg-success">إيداع</span>
                                        <?php elseif ($transaction['type'] == 'order'): ?>
                                            <span class="badge bg-primary">طلب</span>
                                        <?php elseif ($transaction['type'] == 'refund'): ?>
                                            <span class="badge bg-info">استرداد</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary"><?php echo $transaction['type']; ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($transaction['type'] == 'deposit' || $transaction['type'] == 'refund'): ?>
                                            <span class="text-success">+<?php echo formatCurrency($transaction['amount']); ?></span>
                                        <?php elseif ($transaction['type'] == 'order'): ?>
                                            <span class="text-danger">-<?php echo formatCurrency($transaction['amount']); ?></span>
                                        <?php else: ?>
                                            <?php echo formatCurrency($transaction['amount']); ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php
                                        switch ($transaction['status']) {
                                            case 'pending':
                                                echo '<span class="badge bg-warning">قيد الانتظار</span>';
                                                break;
                                            case 'completed':
                                                echo '<span class="badge bg-success">مكتمل</span>';
                                                break;
                                            case 'canceled':
                                                echo '<span class="badge bg-danger">ملغي</span>';
                                                break;
                                            default:
                                                echo '<span class="badge bg-secondary">' . $transaction['status'] . '</span>';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php if ($transaction['type'] == 'order' && !empty($transaction['order_id'])): ?>
                                            <a href="<?php echo BASE_URL; ?>/dashboard/order/<?php echo $transaction['order_id']; ?>" class="text-decoration-none">
                                                طلب #<?php echo $transaction['order_id']; ?>
                                            </a>
                                        <?php elseif ($transaction['type'] == 'deposit'): ?>
                                            <span><?php echo $transaction['payment_method']; ?></span>
                                        <?php elseif ($transaction['type'] == 'refund'): ?>
                                            <span>استرداد للطلب #<?php echo $transaction['order_id']; ?></span>
                                        <?php else: ?>
                                            <span><?php echo $transaction['description'] ?: '-'; ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo formatDate($transaction['created_at']); ?></td>
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-sm btn-light border dropdown-toggle" type="button" id="actionDropdown<?php echo $transaction['id']; ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                                <i class="fas fa-ellipsis-h"></i>
                                            </button>
                                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="actionDropdown<?php echo $transaction['id']; ?>">
                                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/dashboard/transaction/<?php echo $transaction['id']; ?>"><i class="fas fa-eye me-2"></i> عرض التفاصيل</a></li>
                                                <?php if ($transaction['type'] == 'deposit' && $transaction['status'] == 'pending'): ?>
                                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/dashboard/complete_payment/<?php echo $transaction['id']; ?>"><i class="fas fa-check-circle me-2"></i> إكمال الدفع</a></li>
                                                <li><a class="dropdown-item text-danger" href="<?php echo BASE_URL; ?>/dashboard/cancel_payment/<?php echo $transaction['id']; ?>" onclick="return confirm('هل أنت متأكد من رغبتك في إلغاء هذه المعاملة؟');"><i class="fas fa-times-circle me-2"></i> إلغاء</a></li>
                                                <?php endif; ?>
                                                <?php if ($transaction['type'] == 'order'): ?>
                                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/dashboard/order/<?php echo $transaction['order_id']; ?>"><i class="fas fa-shopping-cart me-2"></i> عرض الطلب</a></li>
                                                <?php endif; ?>
                                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/dashboard/download_receipt/<?php echo $transaction['id']; ?>"><i class="fas fa-file-download me-2"></i> تحميل الإيصال</a></li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center py-4">
                                        <div class="py-5">
                                            <i class="fas fa-exchange-alt fa-3x text-muted mb-3"></i>
                                            <h5>لا توجد معاملات بعد</h5>
                                            <p class="text-muted">لم تقم بأي معاملات مالية حتى الآن.</p>
                                            <a href="<?php echo BASE_URL; ?>/dashboard/add_funds" class="btn btn-primary mt-2">إضافة رصيد</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- الترقيم (Pagination) -->
                <?php if (!empty($transactions) && $total_pages > 1): ?>
                <div class="p-3 border-top">
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-center mb-0">
                            <?php if ($current_page > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo BASE_URL; ?>/dashboard/transactions?page=<?php echo $current_page - 1; ?><?php echo !empty($query_string) ? '&' . $query_string : ''; ?>" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>
                            <?php endif; ?>
                            
                            <?php
                            $start_page = max(1, $current_page - 2);
                            $end_page = min($start_page + 4, $total_pages);
                            
                            if ($end_page - $start_page < 4 && $start_page > 1) {
                                $start_page = max(1, $end_page - 4);
                            }
                            
                            for ($i = $start_page; $i <= $end_page; $i++):
                            ?>
                            <li class="page-item <?php echo ($i == $current_page) ? 'active' : ''; ?>">
                                <a class="page-link" href="<?php echo BASE_URL; ?>/dashboard/transactions?page=<?php echo $i; ?><?php echo !empty($query_string) ? '&' . $query_string : ''; ?>"><?php echo $i; ?></a>
                            </li>
                            <?php endfor; ?>
                            
                            <?php if ($current_page < $total_pages): ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo BASE_URL; ?>/dashboard/transactions?page=<?php echo $current_page + 1; ?><?php echo !empty($query_string) ? '&' . $query_string : ''; ?>" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4">
        <!-- ملخص المعاملات -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">ملخص المعاملات</h5>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="stat-card p-3 border rounded text-center h-100">
                            <div class="stat-icon bg-success-light mx-auto mb-2">
                                <i class="fas fa-arrow-up text-success"></i>
                            </div>
                            <h5 class="text-success mb-1"><?php echo formatCurrency($total_deposits); ?></h5>
                            <p class="text-muted mb-0 small">إجمالي الإيداعات</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="stat-card p-3 border rounded text-center h-100">
                            <div class="stat-icon bg-danger-light mx-auto mb-2">
                                <i class="fas fa-arrow-down text-danger"></i>
                            </div>
                            <h5 class="text-danger mb-1"><?php echo formatCurrency($total_spent); ?></h5>
                            <p class="text-muted mb-0 small">إجمالي المصروفات</p>
                        </div>
                    </div>
                </div>
                
                <hr class="my-4">
                
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span>الرصيد الحالي:</span>
                    <h5 class="mb-0 text-primary"><?php echo formatCurrency($_SESSION['balance']); ?></h5>
                </div>
                
                <a href="<?php echo BASE_URL; ?>/dashboard/add_funds" class="btn btn-primary w-100 mt-2">إضافة رصيد</a>
            </div>
        </div>
        
        <!-- آخر المعاملات -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">آخر الإيداعات</h5>
            </div>
            <div class="card-body p-0">
                <?php if (!empty($recent_deposits)): ?>
                <div class="list-group list-group-flush">
                    <?php foreach ($recent_deposits as $deposit): ?>
                    <a href="<?php echo BASE_URL; ?>/dashboard/transaction/<?php echo $deposit['id']; ?>" class="list-group-item list-group-item-action">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h6 class="mb-1 text-success">+<?php echo formatCurrency($deposit['amount']); ?></h6>
                                <small class="text-muted"><?php echo $deposit['payment_method']; ?></small>
                            </div>
                            <div class="text-end">
                                <span class="badge bg-<?php echo ($deposit['status'] == 'completed') ? 'success' : (($deposit['status'] == 'pending') ? 'warning' : 'danger'); ?>">
                                    <?php echo ($deposit['status'] == 'completed') ? 'مكتمل' : (($deposit['status'] == 'pending') ? 'قيد الانتظار' : 'ملغي'); ?>
                                </span>
                                <small class="d-block text-muted"><?php echo formatDate($deposit['created_at'], 'd/m/Y'); ?></small>
                            </div>
                        </div>
                    </a>
                    <?php endforeach; ?>
                </div>
                <?php else: ?>
                <div class="text-center py-4">
                    <p class="mb-0">لا توجد إيداعات بعد</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- طرق الدفع المتاحة -->
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">طرق الدفع المتاحة</h5>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <?php foreach ($payment_methods as $method): ?>
                    <div class="col-6">
                        <div class="d-flex align-items-center p-2 border rounded">
                            <img src="<?php echo BASE_URL; ?>/assets/images/payment/<?php echo $method['image']; ?>" alt="<?php echo $method['name']; ?>" width="32" class="me-2">
                            <span><?php echo $method['name']; ?></span>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// تنفيذ البحث عند تغيير نوع المعاملة أو الحالة
document.addEventListener('DOMContentLoaded', function() {
    const typeFilter = document.getElementById('typeFilter');
    const statusFilter = document.getElementById('statusFilter');
    
    typeFilter.addEventListener('change', function() {
        this.form.submit();
    });
    
    statusFilter.addEventListener('change', function() {
        this.form.submit();
    });
});
</script>
