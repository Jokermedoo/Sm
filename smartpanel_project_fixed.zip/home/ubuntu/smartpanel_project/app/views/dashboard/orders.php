<div class="row mb-4">
    <div class="col-md-12">
        <h1 class="mb-3">طلباتي</h1>
        <p class="text-muted">عرض وإدارة جميع طلباتك السابقة وتتبع حالتها.</p>
    </div>
</div>

<div class="row mb-4">
    <div class="col-md-12">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <h5 class="mb-0">قائمة الطلبات</h5>
                <div>
                    <a href="<?php echo BASE_URL; ?>/dashboard/new_order" class="btn btn-sm btn-primary">
                        <i class="fas fa-plus-circle me-1"></i> طلب جديد
                    </a>
                </div>
            </div>
            <div class="card-body p-0">
                <!-- فلاتر البحث -->
                <div class="p-3 border-bottom bg-light">
                    <form id="orderFilterForm" method="get" action="<?php echo BASE_URL; ?>/dashboard/orders" class="row g-3">
                        <div class="col-md-3">
                            <select class="form-select form-select-sm" name="status" id="statusFilter">
                                <option value="">جميع الحالات</option>
                                <option value="pending" <?php echo (isset($_GET['status']) && $_GET['status'] == 'pending') ? 'selected' : ''; ?>>قيد الانتظار</option>
                                <option value="processing" <?php echo (isset($_GET['status']) && $_GET['status'] == 'processing') ? 'selected' : ''; ?>>قيد التنفيذ</option>
                                <option value="completed" <?php echo (isset($_GET['status']) && $_GET['status'] == 'completed') ? 'selected' : ''; ?>>مكتمل</option>
                                <option value="canceled" <?php echo (isset($_GET['status']) && $_GET['status'] == 'canceled') ? 'selected' : ''; ?>>ملغي</option>
                                <option value="partial" <?php echo (isset($_GET['status']) && $_GET['status'] == 'partial') ? 'selected' : ''; ?>>مكتمل جزئيًا</option>
                                <option value="refunded" <?php echo (isset($_GET['status']) && $_GET['status'] == 'refunded') ? 'selected' : ''; ?>>مسترد</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <input type="text" class="form-control form-control-sm" name="order_id" placeholder="رقم الطلب" value="<?php echo isset($_GET['order_id']) ? htmlspecialchars($_GET['order_id']) : ''; ?>">
                        </div>
                        <div class="col-md-4">
                            <input type="text" class="form-control form-control-sm" name="link" placeholder="بحث بالرابط" value="<?php echo isset($_GET['link']) ? htmlspecialchars($_GET['link']) : ''; ?>">
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary btn-sm w-100">بحث</button>
                        </div>
                    </form>
                </div>
                
                <!-- جدول الطلبات -->
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>رقم الطلب</th>
                                <th>الخدمة</th>
                                <th>الرابط</th>
                                <th>الكمية</th>
                                <th>المنفذ</th>
                                <th>السعر</th>
                                <th>الحالة</th>
                                <th>التاريخ</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($orders)): ?>
                                <?php foreach ($orders as $order): ?>
                                <tr>
                                    <td>#<?php echo $order['id']; ?></td>
                                    <td>
                                        <span class="d-inline-block text-truncate" style="max-width: 150px;" title="<?php echo $order['service_name']; ?>">
                                            <?php echo $order['service_name']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="<?php echo $order['link']; ?>" target="_blank" class="d-inline-block text-truncate" style="max-width: 150px;" title="<?php echo $order['link']; ?>">
                                            <?php echo $order['link']; ?>
                                        </a>
                                    </td>
                                    <td><?php echo number_format($order['quantity']); ?></td>
                                    <td><?php echo number_format($order['remains'] ? $order['quantity'] - $order['remains'] : $order['quantity']); ?></td>
                                    <td><?php echo formatCurrency($order['price']); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo getStatusColor($order['status']); ?>">
                                            <?php echo getStatusText($order['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo formatDate($order['created_at']); ?></td>
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-sm btn-light border dropdown-toggle" type="button" id="actionDropdown<?php echo $order['id']; ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                                <i class="fas fa-ellipsis-h"></i>
                                            </button>
                                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="actionDropdown<?php echo $order['id']; ?>">
                                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/dashboard/order/<?php echo $order['id']; ?>"><i class="fas fa-eye me-2"></i> تفاصيل</a></li>
                                                <?php if ($order['status'] == 'pending'): ?>
                                                <li><a class="dropdown-item text-danger" href="<?php echo BASE_URL; ?>/dashboard/cancel_order/<?php echo $order['id']; ?>" onclick="return confirm('هل أنت متأكد من رغبتك في إلغاء هذا الطلب؟');"><i class="fas fa-times-circle me-2"></i> إلغاء</a></li>
                                                <?php endif; ?>
                                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/dashboard/new_order?reorder=<?php echo $order['id']; ?>"><i class="fas fa-redo-alt me-2"></i> إعادة الطلب</a></li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="9" class="text-center py-4">
                                        <div class="py-5">
                                            <i class="fas fa-shopping-cart fa-3x text-muted mb-3"></i>
                                            <h5>لا توجد طلبات بعد</h5>
                                            <p class="text-muted">ابدأ بإنشاء طلبك الأول لخدمات التسويق عبر وسائل التواصل الاجتماعي.</p>
                                            <a href="<?php echo BASE_URL; ?>/dashboard/new_order" class="btn btn-primary mt-2">إنشاء طلب جديد</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- الترقيم (Pagination) -->
                <?php if (!empty($orders) && $total_pages > 1): ?>
                <div class="p-3 border-top">
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-center mb-0">
                            <?php if ($current_page > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo BASE_URL; ?>/dashboard/orders?page=<?php echo $current_page - 1; ?><?php echo !empty($query_string) ? '&' . $query_string : ''; ?>" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>
                            <?php endif; ?>
                            
                            <?php
                            $start_page = max(1, $current_page - 2);
                            $end_page = min($start_page + 4, $total_pages);
                            
                            if ($end_page - $start_page < 4 && $start_page > 1) {
                                $start_page = max(1, $end_page - 4);
                            }
                            
                            for ($i = $start_page; $i <= $end_page; $i++):
                            ?>
                            <li class="page-item <?php echo ($i == $current_page) ? 'active' : ''; ?>">
                                <a class="page-link" href="<?php echo BASE_URL; ?>/dashboard/orders?page=<?php echo $i; ?><?php echo !empty($query_string) ? '&' . $query_string : ''; ?>"><?php echo $i; ?></a>
                            </li>
                            <?php endfor; ?>
                            
                            <?php if ($current_page < $total_pages): ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo BASE_URL; ?>/dashboard/orders?page=<?php echo $current_page + 1; ?><?php echo !empty($query_string) ? '&' . $query_string : ''; ?>" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- تفسير حالات الطلبات -->
<div class="row">
    <div class="col-md-12">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">تفسير حالات الطلبات</h5>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-4">
                        <div class="d-flex align-items-center">
                            <span class="badge bg-warning me-2">قيد الانتظار</span>
                            <span>الطلب في قائمة الانتظار ولم يبدأ التنفيذ بعد.</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="d-flex align-items-center">
                            <span class="badge bg-info me-2">قيد التنفيذ</span>
                            <span>جارٍ تنفيذ الطلب حاليًا.</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="d-flex align-items-center">
                            <span class="badge bg-success me-2">مكتمل</span>
                            <span>تم تنفيذ الطلب بنجاح.</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="d-flex align-items-center">
                            <span class="badge bg-danger me-2">ملغي</span>
                            <span>تم إلغاء الطلب.</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="d-flex align-items-center">
                            <span class="badge bg-secondary me-2">مكتمل جزئيًا</span>
                            <span>تم تنفيذ جزء من الطلب فقط.</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="d-flex align-items-center">
                            <span class="badge bg-primary me-2">مسترد</span>
                            <span>تم استرداد المبلغ المدفوع للطلب.</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// تنفيذ البحث عند تغيير حالة الطلب
document.addEventListener('DOMContentLoaded', function() {
    const statusFilter = document.getElementById('statusFilter');
    
    statusFilter.addEventListener('change', function() {
        document.getElementById('orderFilterForm').submit();
    });
});
</script>
