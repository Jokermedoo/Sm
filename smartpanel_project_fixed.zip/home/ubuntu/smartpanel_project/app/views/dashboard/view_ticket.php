<div class="row mb-4">
    <div class="col-md-12">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="mb-1">تذكرة #<?php echo $ticket['id']; ?></h1>
                <h5 class="text-muted mb-0"><?php echo $ticket['subject']; ?></h5>
            </div>
            <div>
                <?php if ($ticket['status'] == 'closed'): ?>
                    <a href="<?php echo BASE_URL; ?>/dashboard/tickets/reopen/<?php echo $ticket['id']; ?>" class="btn btn-outline-success">
                        <i class="fas fa-redo-alt me-1"></i> إعادة فتح
                    </a>
                <?php else: ?>
                    <a href="<?php echo BASE_URL; ?>/dashboard/tickets/close/<?php echo $ticket['id']; ?>" class="btn btn-outline-danger" onclick="return confirm('هل أنت متأكد من رغبتك في إغلاق هذه التذكرة؟');">
                        <i class="fas fa-times-circle me-1"></i> إغلاق التذكرة
                    </a>
                <?php endif; ?>
                <a href="<?php echo BASE_URL; ?>/dashboard/tickets" class="btn btn-outline-primary ms-2">
                    <i class="fas fa-arrow-right me-1"></i> العودة
                </a>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-8">
        <!-- رسائل التذكرة -->
        <div class="ticket-messages mb-4">
            <!-- الرسالة الأصلية -->
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center">
                        <img src="<?php echo getProfileImage($ticket['user_id']); ?>" alt="الصورة الشخصية" class="rounded-circle me-2" width="32" height="32">
                        <div>
                            <h6 class="mb-0"><?php echo $ticket['username']; ?></h6>
                            <small class="text-muted"><?php echo formatDate($ticket['created_at'], 'd/m/Y H:i'); ?></small>
                        </div>
                    </div>
                    <span class="badge bg-primary">الرسالة الأصلية</span>
                </div>
                <div class="card-body">
                    <div class="message-content mb-3">
                        <?php echo nl2br(htmlspecialchars($ticket['message'])); ?>
                    </div>
                    
                    <?php if (!empty($ticket['attachments'])): ?>
                    <div class="attachments">
                        <h6>المرفقات:</h6>
                        <div class="d-flex flex-wrap gap-2">
                            <?php foreach ($ticket['attachments'] as $attachment): ?>
                            <div class="attachment-item">
                                <a href="<?php echo BASE_URL; ?>/uploads/tickets/<?php echo $attachment['filename']; ?>" target="_blank" class="btn btn-sm btn-light border d-flex align-items-center">
                                    <?php
                                    $ext = pathinfo($attachment['filename'], PATHINFO_EXTENSION);
                                    $icon = 'fa-file';
                                    
                                    switch (strtolower($ext)) {
                                        case 'jpg':
                                        case 'jpeg':
                                        case 'png':
                                        case 'gif':
                                            $icon = 'fa-file-image';
                                            break;
                                        case 'pdf':
                                            $icon = 'fa-file-pdf';
                                            break;
                                        case 'zip':
                                        case 'rar':
                                            $icon = 'fa-file-archive';
                                            break;
                                        case 'doc':
                                        case 'docx':
                                            $icon = 'fa-file-word';
                                            break;
                                    }
                                    ?>
                                    <i class="fas <?php echo $icon; ?> me-1"></i>
                                    <span><?php echo $attachment['original_name']; ?></span>
                                </a>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- الردود -->
            <?php if (!empty($replies)): ?>
                <?php foreach ($replies as $reply): ?>
                <div class="card border-0 shadow-sm mb-3 <?php echo ($reply['is_admin']) ? 'admin-reply' : ''; ?>">
                    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center">
                            <?php if ($reply['is_admin']): ?>
                                <img src="<?php echo BASE_URL; ?>/assets/images/admin-avatar.png" alt="صورة المشرف" class="rounded-circle me-2" width="32" height="32">
                                <div>
                                    <h6 class="mb-0 text-primary">فريق الدعم الفني</h6>
                                    <small class="text-muted"><?php echo formatDate($reply['created_at'], 'd/m/Y H:i'); ?></small>
                                </div>
                            <?php else: ?>
                                <img src="<?php echo getProfileImage($reply['user_id']); ?>" alt="الصورة الشخصية" class="rounded-circle me-2" width="32" height="32">
                                <div>
                                    <h6 class="mb-0"><?php echo $reply['username']; ?></h6>
                                    <small class="text-muted"><?php echo formatDate($reply['created_at'], 'd/m/Y H:i'); ?></small>
                                </div>
                            <?php endif; ?>
                        </div>
                        <?php if ($reply['is_admin']): ?>
                            <span class="badge bg-info">رد الدعم الفني</span>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <div class="message-content mb-3">
                            <?php echo nl2br(htmlspecialchars($reply['message'])); ?>
                        </div>
                        
                        <?php if (!empty($reply['attachments'])): ?>
                        <div class="attachments">
                            <h6>المرفقات:</h6>
                            <div class="d-flex flex-wrap gap-2">
                                <?php foreach ($reply['attachments'] as $attachment): ?>
                                <div class="attachment-item">
                                    <a href="<?php echo BASE_URL; ?>/uploads/tickets/<?php echo $attachment['filename']; ?>" target="_blank" class="btn btn-sm btn-light border d-flex align-items-center">
                                        <?php
                                        $ext = pathinfo($attachment['filename'], PATHINFO_EXTENSION);
                                        $icon = 'fa-file';
                                        
                                        switch (strtolower($ext)) {
                                            case 'jpg':
                                            case 'jpeg':
                                            case 'png':
                                            case 'gif':
                                                $icon = 'fa-file-image';
                                                break;
                                            case 'pdf':
                                                $icon = 'fa-file-pdf';
                                                break;
                                            case 'zip':
                                            case 'rar':
                                                $icon = 'fa-file-archive';
                                                break;
                                            case 'doc':
                                            case 'docx':
                                                $icon = 'fa-file-word';
                                                break;
                                        }
                                        ?>
                                        <i class="fas <?php echo $icon; ?> me-1"></i>
                                        <span><?php echo $attachment['original_name']; ?></span>
                                    </a>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <!-- نموذج الرد -->
        <?php if ($ticket['status'] != 'closed'): ?>
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">إضافة رد</h5>
            </div>
            <div class="card-body">
                <form action="<?php echo BASE_URL; ?>/dashboard/tickets/reply/<?php echo $ticket['id']; ?>" method="post" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="reply_message" class="form-label">الرسالة</label>
                        <textarea class="form-control" id="reply_message" name="message" rows="5" required placeholder="اكتب ردك هنا..."></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label for="attachments" class="form-label">المرفقات (اختياري)</label>
                        <input class="form-control" type="file" id="attachments" name="attachments[]" multiple>
                        <div class="form-text">يمكنك إرفاق ما يصل إلى 3 ملفات. الحد الأقصى لحجم الملف: 2 ميجابايت. الصيغ المدعومة: JPG، PNG، PDF، ZIP.</div>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">إرسال الرد</button>
                    </div>
                </form>
            </div>
        </div>
        <?php else: ?>
        <div class="alert alert-secondary">
            <div class="d-flex align-items-center">
                <i class="fas fa-lock fa-2x me-3"></i>
                <div>
                    <h6 class="mb-1">هذه التذكرة مغلقة</h6>
                    <p class="mb-2">لا يمكن إضافة ردود جديدة على التذاكر المغلقة.</p>
                    <a href="<?php echo BASE_URL; ?>/dashboard/tickets/reopen/<?php echo $ticket['id']; ?>" class="btn btn-sm btn-outline-primary">إعادة فتح التذكرة</a>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <div class="col-lg-4">
        <!-- معلومات التذكرة -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">معلومات التذكرة</h5>
            </div>
            <div class="card-body">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item px-0 d-flex justify-content-between">
                        <span class="fw-medium">الحالة:</span>
                        <?php
                        switch ($ticket['status']) {
                            case 'open':
                                echo '<span class="badge bg-success">مفتوحة</span>';
                                break;
                            case 'answered':
                                echo '<span class="badge bg-info">تم الرد</span>';
                                break;
                            case 'customer_reply':
                                echo '<span class="badge bg-primary">رد العميل</span>';
                                break;
                            case 'closed':
                                echo '<span class="badge bg-secondary">مغلقة</span>';
                                break;
                            default:
                                echo '<span class="badge bg-secondary">غير معروفة</span>';
                        }
                        ?>
                    </li>
                    <li class="list-group-item px-0 d-flex justify-content-between">
                        <span class="fw-medium">القسم:</span>
                        <span><?php echo getDepartmentName($ticket['department']); ?></span>
                    </li>
                    <li class="list-group-item px-0 d-flex justify-content-between">
                        <span class="fw-medium">الأولوية:</span>
                        <?php
                        switch ($ticket['priority']) {
                            case 'low':
                                echo '<span class="badge bg-success">منخفضة</span>';
                                break;
                            case 'medium':
                                echo '<span class="badge bg-info">متوسطة</span>';
                                break;
                            case 'high':
                                echo '<span class="badge bg-warning">عالية</span>';
                                break;
                            case 'urgent':
                                echo '<span class="badge bg-danger">عاجلة</span>';
                                break;
                            default:
                                echo '<span class="badge bg-secondary">غير معروفة</span>';
                        }
                        ?>
                    </li>
                    <li class="list-group-item px-0 d-flex justify-content-between">
                        <span class="fw-medium">تاريخ الإنشاء:</span>
                        <span><?php echo formatDate($ticket['created_at'], 'd/m/Y H:i'); ?></span>
                    </li>
                    <li class="list-group-item px-0 d-flex justify-content-between">
                        <span class="fw-medium">آخر تحديث:</span>
                        <span><?php echo formatDate($ticket['updated_at'], 'd/m/Y H:i'); ?></span>
                    </li>
                    <?php if ($ticket['order_id']): ?>
                    <li class="list-group-item px-0 d-flex justify-content-between">
                        <span class="fw-medium">رقم الطلب المرتبط:</span>
                        <a href="<?php echo BASE_URL; ?>/dashboard/order/<?php echo $ticket['order_id']; ?>">#<?php echo $ticket['order_id']; ?></a>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        
        <!-- تذاكر أخرى -->
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">تذاكرك الأخرى</h5>
            </div>
            <div class="card-body p-0">
                <?php if (!empty($other_tickets)): ?>
                <div class="list-group list-group-flush">
                    <?php foreach ($other_tickets as $other_ticket): ?>
                    <a href="<?php echo BASE_URL; ?>/dashboard/tickets/view/<?php echo $other_ticket['id']; ?>" class="list-group-item list-group-item-action <?php echo ($other_ticket['id'] == $ticket['id']) ? 'active' : ''; ?>">
                        <div class="d-flex w-100 justify-content-between align-items-center">
                            <h6 class="mb-1 text-truncate"><?php echo $other_ticket['subject']; ?></h6>
                            <?php
                            if ($other_ticket['id'] != $ticket['id']) {
                                switch ($other_ticket['status']) {
                                    case 'open':
                                        echo '<span class="badge bg-success">مفتوحة</span>';
                                        break;
                                    case 'answered':
                                        echo '<span class="badge bg-info">تم الرد</span>';
                                        break;
                                    case 'customer_reply':
                                        echo '<span class="badge bg-primary">رد العميل</span>';
                                        break;
                                    case 'closed':
                                        echo '<span class="badge bg-secondary">مغلقة</span>';
                                        break;
                                    default:
                                        echo '<span class="badge bg-secondary">غير معروفة</span>';
                                }
                            }
                            ?>
                        </div>
                        <small class="text-muted"><?php echo formatDate($other_ticket['updated_at']); ?></small>
                    </a>
                    <?php endforeach; ?>
                </div>
                <?php else: ?>
                <div class="text-center py-4">
                    <p class="mb-0">لا توجد تذاكر أخرى</p>
                </div>
                <?php endif; ?>
                
                <div class="p-3 border-top">
                    <a href="<?php echo BASE_URL; ?>/dashboard/tickets/new" class="btn btn-sm btn-outline-primary d-block">إنشاء تذكرة جديدة</a>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* تنسيقات إضافية لتحسين مظهر صفحة عرض التذكرة */
.admin-reply .card-header {
    background-color: rgba(79, 70, 229, 0.05);
}

.message-content {
    white-space: pre-line;
}

.attachment-item {
    max-width: 200px;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // التحقق من عدد الملفات المرفقة
    const attachmentsInput = document.getElementById('attachments');
    if (attachmentsInput) {
        const maxFiles = 3;
        
        attachmentsInput.addEventListener('change', function() {
            if (this.files.length > maxFiles) {
                alert(`يمكنك إرفاق ${maxFiles} ملفات كحد أقصى. الرجاء تقليل عدد الملفات المحددة.`);
                this.value = ''; // إعادة تعيين الاختيار
            }
            
            // التحقق من حجم الملفات
            const maxSize = 2 * 1024 * 1024; // 2 ميجابايت
            
            for (let i = 0; i < this.files.length; i++) {
                if (this.files[i].size > maxSize) {
                    alert(`الملف "${this.files[i].name}" أكبر من الحد المسموح به (2 ميجابايت). الرجاء اختيار ملف أصغر.`);
                    this.value = ''; // إعادة تعيين الاختيار
                    break;
                }
            }
        });
    }
});
</script>
