<div class="row mb-4">
    <div class="col-md-12">
        <h1 class="mb-3">طلب جماعي</h1>
        <p class="text-muted">أنشئ عدة طلبات دفعة واحدة لتوفير الوقت والجهد.</p>
    </div>
</div>

<div class="row">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">تفاصيل الطلبات</h5>
            </div>
            <div class="card-body">
                <div class="alert alert-info mb-4">
                    <h6 class="mb-2"><i class="fas fa-info-circle me-2"></i> كيفية الاستخدام:</h6>
                    <ol class="mb-0 ps-3">
                        <li>أدخل تفاصيل كل طلب في سطر منفصل بالتنسيق التالي:</li>
                        <li class="mt-1"><code>معرف_الخدمة|الرابط|الكمية</code></li>
                        <li class="mt-1">مثال: <code>12|https://www.instagram.com/username/post|1000</code></li>
                        <li class="mt-1">يمكنك معرفة معرف الخدمة من صفحة قائمة الخدمات.</li>
                    </ol>
                </div>
                
                <form id="massOrderForm" action="<?php echo BASE_URL; ?>/dashboard/submit_mass_order" method="post">
                    <div class="mb-3">
                        <label for="orders" class="form-label">الطلبات</label>
                        <textarea class="form-control" id="orders" name="orders" rows="10" placeholder="معرف_الخدمة|الرابط|الكمية" required></textarea>
                        <div class="form-text">
                            أدخل طلب واحد في كل سطر بالتنسيق: معرف_الخدمة|الرابط|الكمية
                        </div>
                    </div>
                    
                    <div class="alert alert-info" id="orderSummary" style="display:none;">
                        <h6>ملخص الطلبات:</h6>
                        <p><strong>عدد الطلبات:</strong> <span id="orderCount">0</span></p>
                        <p><strong>إجمالي السعر:</strong> <span id="totalPrice">0</span> <?php echo CURRENCY_CODE; ?></p>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <button type="button" id="validateBtn" class="btn btn-secondary mb-2">التحقق من الطلبات</button>
                        <button type="submit" id="submitBtn" class="btn btn-primary" disabled>إرسال الطلبات</button>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">قائمة الخدمات المتاحة</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>معرف</th>
                                <th>الخدمة</th>
                                <th>الحد الأدنى</th>
                                <th>الحد الأقصى</th>
                                <th>السعر لكل 1000</th>
                                <th>الفئة</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($services)): ?>
                                <?php foreach ($services as $service): ?>
                                <tr>
                                    <td><?php echo $service['id']; ?></td>
                                    <td><?php echo $service['name']; ?></td>
                                    <td><?php echo number_format($service['min']); ?></td>
                                    <td><?php echo number_format($service['max']); ?></td>
                                    <td><?php echo formatCurrency($service['price']); ?></td>
                                    <td><?php echo $service['category_name']; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center py-3">لا توجد خدمات متاحة.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4">
        <!-- معلومات الرصيد -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">رصيدك</h5>
            </div>
            <div class="card-body">
                <h3 class="text-primary mb-3"><?php echo formatCurrency($_SESSION['balance']); ?></h3>
                <a href="<?php echo BASE_URL; ?>/dashboard/add_funds" class="btn btn-primary d-block">إضافة رصيد</a>
            </div>
        </div>
        
        <!-- معلومات الطلب -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">معلومات مهمة</h5>
            </div>
            <div class="card-body">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item px-0">
                        <i class="fas fa-info-circle text-primary me-2"></i> يجب التأكد من صحة معرف الخدمة
                    </li>
                    <li class="list-group-item px-0">
                        <i class="fas fa-exclamation-triangle text-primary me-2"></i> الطلبات الخاطئة ستتم تجاهلها
                    </li>
                    <li class="list-group-item px-0">
                        <i class="fas fa-credit-card text-primary me-2"></i> سيتم خصم المبلغ الإجمالي من رصيدك
                    </li>
                    <li class="list-group-item px-0">
                        <i class="fas fa-download text-primary me-2"></i> يمكنك تحميل قالب اكسل للطلبات الجماعية
                        <a href="<?php echo BASE_URL; ?>/assets/files/mass_order_template.xlsx" class="d-block mt-2">
                            <i class="fas fa-file-excel me-1"></i> تحميل القالب
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const validateBtn = document.getElementById('validateBtn');
    const submitBtn = document.getElementById('submitBtn');
    const ordersTextarea = document.getElementById('orders');
    const orderSummary = document.getElementById('orderSummary');
    const orderCount = document.getElementById('orderCount');
    const totalPrice = document.getElementById('totalPrice');
    
    // التحقق من صحة الطلبات
    validateBtn.addEventListener('click', function() {
        const orders = ordersTextarea.value.trim();
        
        if (!orders) {
            showAlert('يرجى إدخال الطلبات أولاً', 'danger');
            return;
        }
        
        const orderLines = orders.split('\n').filter(line => line.trim() !== '');
        let validOrders = 0;
        let invalidOrders = [];
        
        // التحقق من تنسيق كل سطر
        orderLines.forEach((line, index) => {
            const parts = line.split('|');
            
            if (parts.length !== 3) {
                invalidOrders.push({line: index + 1, reason: 'التنسيق غير صحيح'});
            } else {
                const serviceId = parts[0].trim();
                const link = parts[1].trim();
                const quantity = parts[2].trim();
                
                if (!serviceId || isNaN(serviceId)) {
                    invalidOrders.push({line: index + 1, reason: 'معرف الخدمة غير صالح'});
                } else if (!link || !isValidURL(link)) {
                    invalidOrders.push({line: index + 1, reason: 'الرابط غير صالح'});
                } else if (!quantity || isNaN(quantity) || quantity <= 0) {
                    invalidOrders.push({line: index + 1, reason: 'الكمية غير صالحة'});
                } else {
                    validOrders++;
                }
            }
        });
        
        if (invalidOrders.length > 0) {
            let errorMessage = 'هناك أخطاء في الطلبات التالية:<br><ul>';
            invalidOrders.forEach(order => {
                errorMessage += `<li>السطر ${order.line}: ${order.reason}</li>`;
            });
            errorMessage += '</ul>';
            
            showAlert(errorMessage, 'danger');
            
            if (validOrders > 0) {
                showAlert(`تم التحقق من ${validOrders} طلب(ات) بنجاح. يرجى تصحيح الأخطاء في الطلبات الأخرى.`, 'warning', true);
            }
        } else {
            // إذا كانت جميع الطلبات صحيحة، قم بجلب سعر كل طلب
            fetch(`${baseUrl}/dashboard/validate_mass_order`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ orders: orderLines }),
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    orderCount.textContent = data.order_count;
                    totalPrice.textContent = data.total_price;
                    orderSummary.style.display = 'block';
                    submitBtn.disabled = false;
                    
                    showAlert(`تم التحقق من ${data.order_count} طلب(ات) بنجاح. المبلغ الإجمالي: ${data.total_price} ${data.currency}`, 'success');
                } else {
                    showAlert('حدث خطأ أثناء التحقق من الطلبات: ' + data.message, 'danger');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAlert('حدث خطأ أثناء التحقق من الطلبات', 'danger');
            });
        }
    });
    
    // وظيفة للتحقق من صحة الرابط
    function isValidURL(url) {
        try {
            new URL(url);
            return true;
        } catch (e) {
            return false;
        }
    }
    
    // عرض رسالة تنبيه
    function showAlert(message, type, append = false) {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;
        
        const cardBody = document.querySelector('#massOrderForm').closest('.card-body');
        
        if (!append) {
            // إزالة أي تنبيهات سابقة
            const existingAlerts = cardBody.querySelectorAll('.alert:not(#orderSummary)');
            existingAlerts.forEach(alert => alert.remove());
        }
        
        // إضافة التنبيه الجديد في بداية النموذج
        cardBody.insertBefore(alertDiv, cardBody.firstChild);
    }
});
</script>
