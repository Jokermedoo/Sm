<div class="row mb-4">
    <div class="col-md-12">
        <h1 class="mb-3">إضافة رصيد</h1>
        <p class="text-muted">قم بشحن حسابك لشراء خدمات التسويق عبر وسائل التواصل الاجتماعي.</p>
    </div>
</div>

<div class="row">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">اختر طريقة الدفع</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12 mb-3">
                        <div class="alert alert-info">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-info-circle fa-2x me-3"></i>
                                <div>
                                    <h6 class="mb-1">الحد الأدنى للإيداع: <?php echo formatCurrency(MIN_DEPOSIT_AMOUNT); ?></h6>
                                    <p class="mb-0">بعد إتمام عملية الدفع، سيتم إضافة الرصيد إلى حسابك تلقائيًا.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <form id="addFundsForm" action="<?php echo BASE_URL; ?>/dashboard/process_payment" method="post">
                    <div class="mb-4">
                        <label for="amount" class="form-label">المبلغ (<?php echo CURRENCY_CODE; ?>)</label>
                        <div class="input-group">
                            <span class="input-group-text"><?php echo CURRENCY_SYMBOL; ?></span>
                            <input type="number" class="form-control" id="amount" name="amount" min="<?php echo MIN_DEPOSIT_AMOUNT; ?>" step="0.01" required value="<?php echo MIN_DEPOSIT_AMOUNT; ?>">
                        </div>
                        <div class="form-text">الحد الأدنى للإيداع: <?php echo formatCurrency(MIN_DEPOSIT_AMOUNT); ?></div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">اختر طريقة الدفع</label>
                        <div class="row g-3">
                            <?php foreach ($payment_methods as $method): ?>
                            <div class="col-md-4">
                                <div class="form-check payment-method-card border rounded p-3">
                                    <input class="form-check-input" type="radio" name="payment_method" id="payment_<?php echo $method['id']; ?>" value="<?php echo $method['id']; ?>" <?php echo ($method['id'] == 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label w-100" for="payment_<?php echo $method['id']; ?>">
                                        <div class="d-flex align-items-center">
                                            <img src="<?php echo BASE_URL; ?>/assets/images/payment/<?php echo $method['image']; ?>" alt="<?php echo $method['name']; ?>" class="payment-icon me-2" width="40">
                                            <span><?php echo $method['name']; ?></span>
                                        </div>
                                        <?php if ($method['fee'] > 0): ?>
                                        <small class="text-muted d-block mt-1">رسوم: <?php echo $method['fee']; ?>%</small>
                                        <?php endif; ?>
                                    </label>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="mb-4">
                        <div class="alert alert-light border">
                            <h6>ملخص</h6>
                            <div class="d-flex justify-content-between mb-2">
                                <span>المبلغ:</span>
                                <span id="summaryAmount"><?php echo formatCurrency(MIN_DEPOSIT_AMOUNT); ?></span>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span>الرسوم:</span>
                                <span id="summaryFee"><?php echo formatCurrency(0); ?></span>
                            </div>
                            <div class="d-flex justify-content-between fw-bold">
                                <span>الإجمالي:</span>
                                <span id="summaryTotal"><?php echo formatCurrency(MIN_DEPOSIT_AMOUNT); ?></span>
                            </div>
                        </div>
                    </div>

                    <div class="form-check mb-4">
                        <input class="form-check-input" type="checkbox" id="agreeTerms" required>
                        <label class="form-check-label" for="agreeTerms">
                            أوافق على <a href="<?php echo BASE_URL; ?>/terms" target="_blank">الشروط والأحكام</a>
                        </label>
                    </div>

                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary btn-lg">المتابعة للدفع</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <!-- معلومات الرصيد -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">رصيدك الحالي</h5>
            </div>
            <div class="card-body">
                <h3 class="text-primary mb-0"><?php echo formatCurrency($_SESSION['balance']); ?></h3>
            </div>
        </div>

        <!-- أسئلة متكررة -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">أسئلة متكررة</h5>
            </div>
            <div class="card-body">
                <div class="accordion" id="paymentFAQ">
                    <div class="accordion-item border-0 mb-3">
                        <h2 class="accordion-header" id="headingOne">
                            <button class="accordion-button collapsed bg-light rounded" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                كم من الوقت يستغرق إضافة الرصيد؟
                            </button>
                        </h2>
                        <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#paymentFAQ">
                            <div class="accordion-body">
                                يتم إضافة الرصيد بشكل فوري بمجرد إتمام عملية الدفع بنجاح.
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item border-0 mb-3">
                        <h2 class="accordion-header" id="headingTwo">
                            <button class="accordion-button collapsed bg-light rounded" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                هل هناك رسوم إضافية؟
                            </button>
                        </h2>
                        <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#paymentFAQ">
                            <div class="accordion-body">
                                قد تفرض بعض طرق الدفع رسومًا إضافية. يتم عرض هذه الرسوم بوضوح عند اختيار طريقة الدفع.
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item border-0">
                        <h2 class="accordion-header" id="headingThree">
                            <button class="accordion-button collapsed bg-light rounded" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                هل يمكنني استرداد رصيدي؟
                            </button>
                        </h2>
                        <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#paymentFAQ">
                            <div class="accordion-body">
                                لا يمكن استرداد الرصيد بعد إضافته إلى حسابك. يرجى التأكد من المبلغ قبل إتمام عملية الدفع.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- الدعم -->
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="me-3">
                        <i class="fas fa-headset fa-2x text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-1">بحاجة إلى مساعدة؟</h5>
                        <p class="mb-2">فريق الدعم متاح على مدار الساعة.</p>
                        <a href="<?php echo BASE_URL; ?>/dashboard/tickets/new" class="btn btn-sm btn-outline-primary">فتح تذكرة دعم</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const amountInput = document.getElementById('amount');
    const paymentMethods = document.querySelectorAll('input[name="payment_method"]');
    const summaryAmount = document.getElementById('summaryAmount');
    const summaryFee = document.getElementById('summaryFee');
    const summaryTotal = document.getElementById('summaryTotal');
    
    // قائمة الرسوم لكل طريقة دفع
    const paymentFees = {
        <?php foreach ($payment_methods as $method): ?>
        <?php echo $method['id']; ?>: <?php echo $method['fee'] / 100; ?>,
        <?php endforeach; ?>
    };
    
    // تحديث الملخص عند تغيير المبلغ أو طريقة الدفع
    function updateSummary() {
        const amount = parseFloat(amountInput.value) || <?php echo MIN_DEPOSIT_AMOUNT; ?>;
        let selectedMethodId = 1; // افتراضي
        
        // البحث عن طريقة الدفع المحددة
        paymentMethods.forEach(method => {
            if (method.checked) {
                selectedMethodId = parseInt(method.value);
            }
        });
        
        const feePercentage = paymentFees[selectedMethodId] || 0;
        const feeAmount = amount * feePercentage;
        const totalAmount = amount + feeAmount;
        
        // تحديث الملخص
        summaryAmount.textContent = formatCurrency(amount);
        summaryFee.textContent = formatCurrency(feeAmount);
        summaryTotal.textContent = formatCurrency(totalAmount);
    }
    
    // تنسيق المبلغ كعملة
    function formatCurrency(amount) {
        return parseFloat(amount).toFixed(2) + ' <?php echo CURRENCY_CODE; ?>';
    }
    
    // إضافة مستمعي الأحداث
    amountInput.addEventListener('input', updateSummary);
    paymentMethods.forEach(method => {
        method.addEventListener('change', updateSummary);
    });
    
    // تحديث الملخص عند تحميل الصفحة
    updateSummary();
});
</script>
