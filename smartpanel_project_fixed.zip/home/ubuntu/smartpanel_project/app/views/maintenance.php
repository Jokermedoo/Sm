<?php
/**
 * صفحة الصيانة المخصصة
 */
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>صيانة - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .maintenance-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .maintenance-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            padding: 40px;
            text-align: center;
            max-width: 600px;
            width: 90%;
        }
        .maintenance-icon {
            font-size: 80px;
            color: #ffc107;
            margin-bottom: 20px;
            animation: wrench 2.5s ease infinite;
        }
        .maintenance-title {
            color: #343a40;
            font-size: 28px;
            margin-bottom: 15px;
        }
        .maintenance-message {
            color: #6c757d;
            margin-bottom: 30px;
            line-height: 1.6;
        }
        .maintenance-time {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 30px;
        }
        @keyframes wrench {
            0% { transform: rotate(-12deg); }
            8% { transform: rotate(12deg); }
            10% { transform: rotate(24deg); }
            18% { transform: rotate(-24deg); }
            20% { transform: rotate(-24deg); }
            28% { transform: rotate(24deg); }
            30% { transform: rotate(24deg); }
            38% { transform: rotate(-24deg); }
            40% { transform: rotate(-24deg); }
            48% { transform: rotate(24deg); }
            50% { transform: rotate(0deg); }
            100% { transform: rotate(0deg); }
        }
    </style>
</head>
<body>
    <div class="maintenance-container">
        <div class="maintenance-card">
            <i class="fas fa-wrench maintenance-icon"></i>
            <h1 class="maintenance-title">نحن نقوم بالصيانة</h1>
            <p class="maintenance-message">
                نعتذر عن الإزعاج، نحن نقوم حالياً بإجراء بعض التحسينات على الموقع.
                سنعود قريباً مع تجربة أفضل لكم.
            </p>
            <div class="maintenance-time">
                <i class="fas fa-clock"></i>
                الوقت المتوقع للانتهاء: قريباً
            </div>
            <p class="text-muted">
                للتواصل مع الدعم الفني: <a href="mailto:support@example.com">support@example.com</a>
            </p>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 