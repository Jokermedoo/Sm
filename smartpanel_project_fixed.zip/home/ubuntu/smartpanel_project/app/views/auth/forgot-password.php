<div class="auth-container py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-primary text-white text-center py-3">
                        <h4 class="mb-0">استعادة كلمة المرور</h4>
                    </div>
                    <div class="card-body p-4">
                        <p class="mb-4">أدخل بريدك الإلكتروني وسنرسل لك رابطًا لإعادة تعيين كلمة المرور الخاصة بك.</p>
                        
                        <?php if(isset($error)): ?>
                            <div class="alert alert-danger">
                                <?php echo $error; ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if(isset($success)): ?>
                            <div class="alert alert-success">
                                <?php echo $success; ?>
                            </div>
                        <?php endif; ?>
                        
                        <form action="<?php echo BASE_URL; ?>/auth/forgot-password" method="post" class="needs-validation" novalidate>
                            <div class="form-group mb-3">
                                <label for="email" class="form-label">البريد الإلكتروني</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                    <input type="email" class="form-control" id="email" name="email" value="<?php echo isset($email) ? $email : ''; ?>" required>
                                </div>
                                <div class="invalid-feedback">
                                    يرجى إدخال بريد إلكتروني صالح
                                </div>
                            </div>
                            
                            <?php if(isset($recaptcha) && $recaptcha): ?>
                                <div class="form-group mb-3">
                                    <div class="g-recaptcha" data-sitekey="<?php echo RECAPTCHA_SITE_KEY; ?>"></div>
                                </div>
                            <?php endif; ?>
                            
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-lg w-100">
                                    إرسال رابط الاستعادة <i class="fas fa-paper-plane ms-2"></i>
                                </button>
                            </div>
                        </form>
                        
                        <div class="text-center mt-4">
                            <p class="mb-0"><a href="<?php echo BASE_URL; ?>/auth/login" class="text-decoration-none">العودة إلى تسجيل الدخول</a></p>
                        </div>
                    </div>
                </div>
                
                <div class="text-center mt-4">
                    <a href="<?php echo BASE_URL; ?>" class="text-decoration-none"><i class="fas fa-arrow-left me-1"></i> العودة إلى الصفحة الرئيسية</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
// إضافة reCAPTCHA إذا كان مفعلاً
if(isset($recaptcha) && $recaptcha): 
    $footer_code = '<script src="https://www.google.com/recaptcha/api.js" async defer></script>';
endif;
?>
