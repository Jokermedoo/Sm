<div class="auth-container py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-primary text-white text-center py-3">
                        <h4 class="mb-0">تسجيل الدخول</h4>
                    </div>
                    <div class="card-body p-4">
                        <?php if(isset($error)): ?>
                            <div class="alert alert-danger">
                                <?php echo $error; ?>
                            </div>
                        <?php endif; ?>
                        
                        <form action="<?php echo BASE_URL; ?>/auth/login" method="post" class="needs-validation" novalidate>
                            <div class="form-group mb-3">
                                <label for="username" class="form-label">اسم المستخدم أو البريد الإلكتروني</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                                    <input type="text" class="form-control" id="username" name="username" value="<?php echo isset($username) ? $username : ''; ?>" required>
                                </div>
                                <div class="invalid-feedback">
                                    يرجى إدخال اسم المستخدم أو البريد الإلكتروني
                                </div>
                            </div>
                            
                            <div class="form-group mb-3">
                                <label for="password" class="form-label">كلمة المرور</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                    <input type="password" class="form-control" id="password" name="password" required>
                                    <button type="button" class="btn btn-outline-secondary toggle-password" data-target="#password">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                                <div class="invalid-feedback">
                                    يرجى إدخال كلمة المرور
                                </div>
                            </div>
                            
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="remember_me" name="remember_me" value="1">
                                    <label class="form-check-label" for="remember_me">تذكرني</label>
                                </div>
                                <a href="<?php echo BASE_URL; ?>/auth/forgot-password" class="text-decoration-none">نسيت كلمة المرور؟</a>
                            </div>
                            
                            <?php if(isset($recaptcha) && $recaptcha): ?>
                                <div class="form-group mb-3">
                                    <div class="g-recaptcha" data-sitekey="<?php echo RECAPTCHA_SITE_KEY; ?>"></div>
                                </div>
                            <?php endif; ?>
                            
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-lg w-100">
                                    تسجيل الدخول <i class="fas fa-sign-in-alt ms-2"></i>
                                </button>
                            </div>
                        </form>
                        
                        <div class="text-center mt-4">
                            <p class="mb-0">ليس لديك حساب؟ <a href="<?php echo BASE_URL; ?>/auth/register" class="text-decoration-none">سجل الآن</a></p>
                        </div>
                    </div>
                </div>
                
                <div class="text-center mt-4">
                    <a href="<?php echo BASE_URL; ?>" class="text-decoration-none"><i class="fas fa-arrow-left me-1"></i> العودة إلى الصفحة الرئيسية</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
// إضافة reCAPTCHA إذا كان مفعلاً
if(isset($recaptcha) && $recaptcha): 
    $footer_code = '<script src="https://www.google.com/recaptcha/api.js" async defer></script>';
endif;

// إضافة سكريبت لإظهار/إخفاء كلمة المرور
$additional_js = isset($additional_js) ? $additional_js : [];
$additional_js[] = 'auth.js';
?>
