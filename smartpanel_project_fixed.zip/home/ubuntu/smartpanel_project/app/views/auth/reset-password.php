<div class="auth-container py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-primary text-white text-center py-3">
                        <h4 class="mb-0">إعادة تعيين كلمة المرور</h4>
                    </div>
                    <div class="card-body p-4">
                        <p class="mb-4">الرجاء إدخال كلمة المرور الجديدة.</p>
                        
                        <?php if(isset($error)): ?>
                            <div class="alert alert-danger">
                                <?php echo $error; ?>
                            </div>
                        <?php endif; ?>
                        
                        <form action="<?php echo BASE_URL; ?>/auth/reset-password/<?php echo $token; ?>" method="post" class="needs-validation" novalidate>
                            <input type="hidden" name="token" value="<?php echo $token; ?>">
                            
                            <div class="form-group mb-3">
                                <label for="password" class="form-label">كلمة المرور الجديدة</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                    <input type="password" class="form-control" id="password" name="password" required>
                                    <button type="button" class="btn btn-outline-secondary toggle-password" data-target="#password">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                                <div class="form-text small">
                                    يجب أن تحتوي على 8 أحرف على الأقل، وتتضمن أحرفًا كبيرة وصغيرة وأرقامًا.
                                </div>
                                <div class="invalid-feedback">
                                    يرجى إدخال كلمة مرور قوية
                                </div>
                            </div>
                            
                            <div class="form-group mb-3">
                                <label for="password_confirm" class="form-label">تأكيد كلمة المرور</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                    <input type="password" class="form-control" id="password_confirm" name="password_confirm" required>
                                    <button type="button" class="btn btn-outline-secondary toggle-password" data-target="#password_confirm">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                                <div class="invalid-feedback">
                                    كلمات المرور غير متطابقة
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-lg w-100">
                                    تغيير كلمة المرور <i class="fas fa-save ms-2"></i>
                                </button>
                            </div>
                        </form>
                        
                        <div class="text-center mt-4">
                            <p class="mb-0"><a href="<?php echo BASE_URL; ?>/auth/login" class="text-decoration-none">العودة إلى تسجيل الدخول</a></p>
                        </div>
                    </div>
                </div>
                
                <div class="text-center mt-4">
                    <a href="<?php echo BASE_URL; ?>" class="text-decoration-none"><i class="fas fa-arrow-left me-1"></i> العودة إلى الصفحة الرئيسية</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// إضافة سكريبت لإظهار/إخفاء كلمة المرور
$additional_js = isset($additional_js) ? $additional_js : [];
$additional_js[] = 'auth.js';
?>
