<div class="auth-container py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-primary text-white text-center py-3">
                        <h4 class="mb-0">إنشاء حساب جديد</h4>
                    </div>
                    <div class="card-body p-4">
                        <?php if(isset($error)): ?>
                            <div class="alert alert-danger">
                                <?php echo $error; ?>
                            </div>
                        <?php endif; ?>
                        
                        <form action="<?php echo BASE_URL; ?>/auth/register" method="post" class="needs-validation" novalidate>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="username" class="form-label">اسم المستخدم</label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                                            <input type="text" class="form-control" id="username" name="username" value="<?php echo isset($username) ? $username : ''; ?>" required>
                                        </div>
                                        <div class="form-text small">
                                            يجب أن يكون بين 4 و 20 حرفًا، ويمكن أن يحتوي على أحرف وأرقام وشرطات سفلية فقط.
                                        </div>
                                        <div class="invalid-feedback">
                                            يرجى إدخال اسم مستخدم صالح
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="email" class="form-label">البريد الإلكتروني</label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                            <input type="email" class="form-control" id="email" name="email" value="<?php echo isset($email) ? $email : ''; ?>" required>
                                        </div>
                                        <div class="invalid-feedback">
                                            يرجى إدخال بريد إلكتروني صالح
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group mb-3">
                                <label for="full_name" class="form-label">الاسم الكامل</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-user-circle"></i></span>
                                    <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo isset($full_name) ? $full_name : ''; ?>" required>
                                </div>
                                <div class="invalid-feedback">
                                    يرجى إدخال الاسم الكامل
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="password" class="form-label">كلمة المرور</label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                            <input type="password" class="form-control" id="password" name="password" required>
                                            <button type="button" class="btn btn-outline-secondary toggle-password" data-target="#password">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                        </div>
                                        <div class="form-text small">
                                            يجب أن تحتوي على 8 أحرف على الأقل، وتتضمن أحرفًا كبيرة وصغيرة وأرقامًا.
                                        </div>
                                        <div class="invalid-feedback">
                                            يرجى إدخال كلمة مرور قوية
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="password_confirm" class="form-label">تأكيد كلمة المرور</label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                            <input type="password" class="form-control" id="password_confirm" name="password_confirm" required>
                                            <button type="button" class="btn btn-outline-secondary toggle-password" data-target="#password_confirm">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                        </div>
                                        <div class="invalid-feedback">
                                            كلمات المرور غير متطابقة
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <?php if(isset($recaptcha) && $recaptcha): ?>
                                <div class="form-group mb-3">
                                    <div class="g-recaptcha" data-sitekey="<?php echo RECAPTCHA_SITE_KEY; ?>"></div>
                                </div>
                            <?php endif; ?>
                            
                            <div class="form-group mb-3">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="terms" name="terms" required>
                                    <label class="form-check-label" for="terms">
                                        أوافق على <a href="<?php echo BASE_URL; ?>/terms" target="_blank">الشروط والأحكام</a> و <a href="<?php echo BASE_URL; ?>/privacy" target="_blank">سياسة الخصوصية</a>
                                    </label>
                                    <div class="invalid-feedback">
                                        يجب الموافقة على الشروط والأحكام للمتابعة
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-lg w-100">
                                    إنشاء حساب <i class="fas fa-user-plus ms-2"></i>
                                </button>
                            </div>
                        </form>
                        
                        <div class="text-center mt-4">
                            <p class="mb-0">لديك حساب بالفعل؟ <a href="<?php echo BASE_URL; ?>/auth/login" class="text-decoration-none">تسجيل الدخول</a></p>
                        </div>
                    </div>
                </div>
                
                <div class="text-center mt-4">
                    <a href="<?php echo BASE_URL; ?>" class="text-decoration-none"><i class="fas fa-arrow-left me-1"></i> العودة إلى الصفحة الرئيسية</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
// إضافة reCAPTCHA إذا كان مفعلاً
if(isset($recaptcha) && $recaptcha): 
    $footer_code = '<script src="https://www.google.com/recaptcha/api.js" async defer></script>';
endif;

// إضافة سكريبت لإظهار/إخفاء كلمة المرور
$additional_js = isset($additional_js) ? $additional_js : [];
$additional_js[] = 'auth.js';
?>
