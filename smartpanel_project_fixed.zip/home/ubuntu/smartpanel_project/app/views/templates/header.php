<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' | ' . SITE_NAME : SITE_NAME; ?></title>
    <meta name="description" content="<?php echo isset($page_description) ? $page_description : 'خدمات SMM لتعزيز حضورك على وسائل التواصل الاجتماعي. زيادة المتابعين، الإعجابات، المشاهدات والمزيد.'; ?>">
    <meta name="keywords" content="SMM, social media marketing, خدمات تسويق, زيادة متابعين, Town Media, تاون ميديا">
    <meta property="og:title" content="<?php echo SITE_NAME; ?> - خدمات SMM">
    <meta property="og:description" content="خدمات SMM لتعزيز حضورك على وسائل التواصل الاجتماعي. زيادة المتابعين، الإعجابات، المشاهدات والمزيد.">
    <meta property="og:type" content="website">
    
    <!-- الأيقونة المفضلة -->
    <link rel="icon" type="image/x-icon" href="<?php echo BASE_URL; ?>/assets/images/favicon.ico">
    
    <!-- الخطوط -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap">
    
    <!-- CSS الأساسي -->
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/main.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- JavaScript الأساسي -->
    <script src="<?php echo BASE_URL; ?>/assets/js/jquery-3.6.0.min.js"></script>
    <script src="<?php echo BASE_URL; ?>/assets/js/bootstrap.bundle.min.js"></script>
    
    <!-- إعدادات الألوان المخصصة -->
    <style>
        :root {
            --primary-color: #4F46E5;
            --secondary-color: #10B981;
            --body-font: 'Tajawal', sans-serif;
        }
        
        body {
            font-family: var(--body-font);
            direction: rtl;
        }
    </style>
</head>
<body>
    <!-- شريط التنقل -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand" href="<?php echo BASE_URL; ?>">
                <img src="<?php echo BASE_URL; ?>/assets/images/logo.png" alt="<?php echo SITE_NAME; ?>" height="40">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link <?php echo (isset($active_page) && $active_page == 'home') ? 'active' : ''; ?>" href="<?php echo BASE_URL; ?>">الرئيسية</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo (isset($active_page) && $active_page == 'services') ? 'active' : ''; ?>" href="<?php echo BASE_URL; ?>/services">الخدمات</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo (isset($active_page) && $active_page == 'pricing') ? 'active' : ''; ?>" href="<?php echo BASE_URL; ?>/pricing">التسعير</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo (isset($active_page) && $active_page == 'api') ? 'active' : ''; ?>" href="<?php echo BASE_URL; ?>/api">API</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo (isset($active_page) && $active_page == 'blog') ? 'active' : ''; ?>" href="<?php echo BASE_URL; ?>/blog">المدونة</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo (isset($active_page) && $active_page == 'faq') ? 'active' : ''; ?>" href="<?php echo BASE_URL; ?>/faq">الأسئلة الشائعة</a>
                    </li>
                </ul>
                <div class="d-flex">
                    <?php if (isLoggedIn()): ?>
                        <a href="<?php echo BASE_URL; ?>/dashboard" class="btn btn-outline-primary me-2">لوحة التحكم</a>
                        <a href="<?php echo BASE_URL; ?>/auth/logout" class="btn btn-danger">تسجيل الخروج</a>
                    <?php else: ?>
                        <a href="<?php echo BASE_URL; ?>/auth/login" class="btn btn-outline-primary me-2">تسجيل الدخول</a>
                        <a href="<?php echo BASE_URL; ?>/auth/register" class="btn btn-primary">التسجيل</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>
    
    <!-- عرض رسائل النظام -->
    <?php if (isset($_SESSION['error_message']) || isset($_SESSION['success_message'])): ?>
        <div class="container mt-3">
            <?php if (isset($_SESSION['error_message'])): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo $_SESSION['error_message']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php unset($_SESSION['error_message']); ?>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo $_SESSION['success_message']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php unset($_SESSION['success_message']); ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>
    
    <!-- بداية المحتوى الرئيسي -->
    <main>
