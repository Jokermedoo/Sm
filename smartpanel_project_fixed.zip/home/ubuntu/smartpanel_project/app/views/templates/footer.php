    </main>
    <!-- نهاية المحتوى الرئيسي -->
    
    <!-- بداية التذييل -->
    <footer class="bg-dark text-white mt-5 py-5">
        <div class="container">
            <div class="row g-4">
                <div class="col-md-4">
                    <h5 class="mb-3">حول تاون ميديا</h5>
                    <p>نقدم أفضل خدمات التسويق عبر وسائل التواصل الاجتماعي لمساعدتك على تعزيز حضورك الرقمي وتنمية متابعيك بطريقة آمنة وفعالة.</p>
                    <div class="mt-3">
                        <a href="<?php echo BASE_URL; ?>/terms" class="text-white text-decoration-none me-3">الشروط والأحكام</a>
                        <a href="<?php echo BASE_URL; ?>/privacy-policy" class="text-white text-decoration-none">سياسة الخصوصية</a>
                    </div>
                </div>
                <div class="col-md-4">
                    <h5 class="mb-3">روابط سريعة</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="<?php echo BASE_URL; ?>" class="text-white text-decoration-none">الرئيسية</a></li>
                        <li class="mb-2"><a href="<?php echo BASE_URL; ?>/services" class="text-white text-decoration-none">الخدمات</a></li>
                        <li class="mb-2"><a href="<?php echo BASE_URL; ?>/pricing" class="text-white text-decoration-none">التسعير</a></li>
                        <li class="mb-2"><a href="<?php echo BASE_URL; ?>/api" class="text-white text-decoration-none">API</a></li>
                        <li class="mb-2"><a href="<?php echo BASE_URL; ?>/blog" class="text-white text-decoration-none">المدونة</a></li>
                        <li class="mb-2"><a href="<?php echo BASE_URL; ?>/faq" class="text-white text-decoration-none">الأسئلة الشائعة</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5 class="mb-3">تواصل معنا</h5>
                    <p><i class="fas fa-envelope me-2"></i> info@townmedia.com</p>
                    <p><i class="fas fa-phone me-2"></i> +20 123 456 7890</p>
                    <div class="social-icons mt-3">
                        <a href="#" class="text-white me-3"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
            </div>
            <div class="border-top border-secondary pt-4 mt-4 text-center">
                <p class="mb-0">&copy; <?php echo date('Y'); ?> تاون ميديا. جميع الحقوق محفوظة.</p>
            </div>
        </div>
    </footer>
    
    <!-- زر واتساب -->
    <div class="whatsapp-btn">
        <a href="https://wa.me/201234567890" target="_blank" class="btn btn-success rounded-circle shadow-lg">
            <i class="fab fa-whatsapp fa-2x"></i>
        </a>
    </div>
    
    <!-- JavaScript إضافي -->
    <script src="<?php echo BASE_URL; ?>/assets/js/main.js"></script>
</body>
</html>
