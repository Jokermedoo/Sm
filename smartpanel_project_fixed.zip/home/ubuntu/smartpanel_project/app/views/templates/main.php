<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' - ' . SITE_NAME : SITE_NAME; ?></title>
    <meta name="description" content="<?php echo isset($page_description) ? $page_description : SITE_DESCRIPTION; ?>">
    
    <!-- الخطوط -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- أيقونات Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- ملف CSS الرئيسي -->
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/main.css">
    
    <!-- ملفات CSS الإضافية -->
    <?php if(isset($additional_css)): ?>
        <?php foreach($additional_css as $css): ?>
            <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/<?php echo $css; ?>">
        <?php endforeach; ?>
    <?php endif; ?>
    
    <!-- أيقونة الموقع -->
    <link rel="shortcut icon" href="<?php echo BASE_URL; ?>/assets/img/favicon.ico" type="image/x-icon">
    
    <!-- رمز إضافي في رأس الصفحة -->
    <?php if(isset($header_code)) echo $header_code; ?>
</head>
<body class="<?php echo isset($body_class) ? $body_class : ''; ?>">
    <!-- الشريط العلوي -->
    <nav class="navbar">
        <div class="container">
            <a href="<?php echo BASE_URL; ?>" class="navbar-brand">
                <img src="<?php echo BASE_URL; ?>/assets/img/logo.png" alt="<?php echo SITE_NAME; ?>" height="40">
            </a>
            
            <button class="navbar-toggle d-md-none">
                <i class="fas fa-bars"></i>
            </button>
            
            <div class="navbar-menu">
                <ul class="navbar-nav">
                    <li class="nav-item <?php echo (isset($active_page) && $active_page == 'home') ? 'active' : ''; ?>">
                        <a href="<?php echo BASE_URL; ?>" class="nav-link">الرئيسية</a>
                    </li>
                    <li class="nav-item <?php echo (isset($active_page) && $active_page == 'services') ? 'active' : ''; ?>">
                        <a href="<?php echo BASE_URL; ?>/services" class="nav-link">الخدمات</a>
                    </li>
                    <li class="nav-item <?php echo (isset($active_page) && $active_page == 'api') ? 'active' : ''; ?>">
                        <a href="<?php echo BASE_URL; ?>/api" class="nav-link">API</a>
                    </li>
                    <li class="nav-item <?php echo (isset($active_page) && $active_page == 'faq') ? 'active' : ''; ?>">
                        <a href="<?php echo BASE_URL; ?>/faq" class="nav-link">الأسئلة الشائعة</a>
                    </li>
                    <li class="nav-item <?php echo (isset($active_page) && $active_page == 'contact') ? 'active' : ''; ?>">
                        <a href="<?php echo BASE_URL; ?>/contact" class="nav-link">اتصل بنا</a>
                    </li>
                </ul>
                
                <ul class="navbar-nav mr-auto">
                    <?php if(isLoggedIn()): ?>
                        <li class="nav-item">
                            <a href="<?php echo BASE_URL; ?>/dashboard" class="nav-link">
                                <i class="fas fa-tachometer-alt"></i> لوحة التحكم
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo BASE_URL; ?>/auth/logout" class="btn btn-outline-primary">
                                <i class="fas fa-sign-out-alt"></i> تسجيل الخروج
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a href="<?php echo BASE_URL; ?>/auth/login" class="nav-link">تسجيل الدخول</a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo BASE_URL; ?>/auth/register" class="btn btn-primary">إنشاء حساب</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    
    <!-- رسائل التنبيه -->
    <?php if(isset($_SESSION['alert'])): ?>
        <div class="container mt-3">
            <div class="alert alert-<?php echo $_SESSION['alert']['type']; ?> alert-dismissible">
                <button type="button" class="close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <?php echo $_SESSION['alert']['message']; ?>
            </div>
        </div>
        <?php unset($_SESSION['alert']); ?>
    <?php endif; ?>
    
    <!-- محتوى الصفحة -->
    <main>
        <?php include_once $view_file; ?>
    </main>
    
    <!-- التذييل -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col">
                    <h4><?php echo SITE_NAME; ?></h4>
                    <p>منصة خدمات التواصل الاجتماعي الأولى في المنطقة العربية. نقدم خدمات متابعين، إعجابات، مشاهدات وغيرها بأسعار تنافسية وجودة عالية.</p>
                    <div class="social-links">
                        <a href="#" class="mr-2"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="mr-2"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="mr-2"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-telegram"></i></a>
                    </div>
                </div>
                <div class="col">
                    <h5>روابط سريعة</h5>
                    <ul class="footer-links">
                        <li><a href="<?php echo BASE_URL; ?>">الرئيسية</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/services">الخدمات</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/api">API</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/faq">الأسئلة الشائعة</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/contact">اتصل بنا</a></li>
                    </ul>
                </div>
                <div class="col">
                    <h5>خدمات</h5>
                    <ul class="footer-links">
                        <li><a href="<?php echo BASE_URL; ?>/services/instagram">خدمات انستجرام</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/services/facebook">خدمات فيسبوك</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/services/twitter">خدمات تويتر</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/services/youtube">خدمات يوتيوب</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/services/tiktok">خدمات تيك توك</a></li>
                    </ul>
                </div>
                <div class="col">
                    <h5>الدعم</h5>
                    <ul class="footer-links">
                        <li><a href="<?php echo BASE_URL; ?>/terms">الشروط والأحكام</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/privacy">سياسة الخصوصية</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/refund">سياسة الاسترداد</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/dashboard/tickets/create">فتح تذكرة دعم</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/dashboard/tickets">تذاكري</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="copyright">
            <div class="container">
                <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. جميع الحقوق محفوظة.</p>
            </div>
        </div>
    </footer>
    
    <!-- jQuery وملفات JavaScript -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="<?php echo BASE_URL; ?>/assets/js/main.js"></script>
    
    <!-- ملفات JavaScript الإضافية -->
    <?php if(isset($additional_js)): ?>
        <?php foreach($additional_js as $js): ?>
            <script src="<?php echo BASE_URL; ?>/assets/js/<?php echo $js; ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>
    
    <!-- رمز إضافي في نهاية الصفحة -->
    <?php if(isset($footer_code)) echo $footer_code; ?>
</body>
</html>
