<?php
/**
 * SMM Panel - Drag and Drop Template
 * 
 * This template includes drag and drop functionality in pages
 * Usage: Include this file in any page that needs drag and drop features
 */

// Include DragDropIntegration helper
use App\Helpers\DragDropIntegration;
?>

<!-- يجب أن تضاف إلى رأس الصفحة (في قسم head) -->
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/drag-drop.css">

<!-- يجب أن تضاف إلى نهاية الصفحة (قبل إغلاق body) -->
<script src="<?= BASE_URL ?>/assets/libs/sortable.min.js"></script>
<script src="<?= BASE_URL ?>/assets/js/drag-drop.js"></script>

<!-- مثال على كيفية استخدام القوائم القابلة للفرز -->
<div class="card">
    <div class="card-header">
        <h5 class="card-title">مثال على قائمة قابلة للفرز</h5>
    </div>
    <div class="card-body">
        <p>يمكنك سحب وإفلات العناصر التالية لإعادة ترتيبها:</p>
        
        <?php
        // مثال على كيفية استخدام القوائم القابلة للفرز
        $items = [
            ['id' => 1, 'name' => 'العنصر الأول'],
            ['id' => 2, 'name' => 'العنصر الثاني'],
            ['id' => 3, 'name' => 'العنصر الثالث'],
            ['id' => 4, 'name' => 'العنصر الرابع'],
            ['id' => 5, 'name' => 'العنصر الخامس'],
        ];
        
        echo DragDropIntegration::renderSortableList($items, BASE_URL . '/api/list/update-order', [
            'listClass' => 'list-group sortable-list',
            'itemClass' => 'list-group-item sortable-item',
            'listType' => 'ul'
        ]);
        ?>
    </div>
</div>

<!-- مثال على كيفية استخدام منطقة سحب وإفلات الملفات -->
<div class="card mt-4">
    <div class="card-header">
        <h5 class="card-title">مثال على سحب وإفلات الملفات</h5>
    </div>
    <div class="card-body">
        <p>يمكنك سحب وإفلات الملفات هنا لرفعها:</p>
        
        <?php
        // مثال على كيفية استخدام منطقة سحب وإفلات الملفات
        echo DragDropIntegration::renderFileDropzone(BASE_URL . '/api/upload-file', [
            'maxFiles' => 5,
            'allowedTypes' => 'image/jpeg,image/png,application/pdf',
            'maxSize' => 10,
            'message' => 'اسحب وأفلت الملفات هنا أو انقر للاختيار',
            'dropzoneClass' => 'file-dropzone my-3'
        ]);
        ?>
    </div>
</div>

<!-- توضيحات إضافية -->
<div class="alert alert-info mt-4">
    <h5>كيفية استخدام ميزات السحب والإفلات</h5>
    <p>لاستخدام ميزات السحب والإفلات في صفحاتك الخاصة، يمكنك استخدام المساعد التالي:</p>
    <pre><code>// في الملف الخاص بك
use App\Helpers\DragDropIntegration;

// لعرض أصول السحب والإفلات (CSS و JavaScript)
echo DragDropIntegration::loadAssets();

// لعرض قائمة قابلة للفرز
echo DragDropIntegration::renderSortableList($items, '/api/save-url', $options);

// لعرض منطقة سحب وإفلات الملفات
echo DragDropIntegration::renderFileDropzone('/api/upload-url', $options);

// لعرض لوحة كانبان لإدارة الطلبات
echo DragDropIntegration::renderOrderKanban($orders);
</code></pre>
</div>
