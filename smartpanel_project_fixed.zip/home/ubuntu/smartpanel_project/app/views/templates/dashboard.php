<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' | ' . SITE_NAME : SITE_NAME; ?></title>
    
    <!-- الأيقونة المفضلة -->
    <link rel="icon" type="image/x-icon" href="<?php echo BASE_URL; ?>/assets/images/favicon.ico">
    
    <!-- الخطوط -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap">
    
    <!-- CSS الأساسي -->
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/main.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- JavaScript الأساسي -->
    <script src="<?php echo BASE_URL; ?>/assets/js/jquery-3.6.0.min.js"></script>
    <script src="<?php echo BASE_URL; ?>/assets/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <!-- شريط التنقل العلوي -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
        <div class="container-fluid">
            <a class="navbar-brand d-flex align-items-center" href="<?php echo BASE_URL; ?>">
                <img src="<?php echo BASE_URL; ?>/assets/images/logo.png" alt="<?php echo SITE_NAME; ?>" height="40">
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_URL; ?>">الرئيسية</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_URL; ?>/services">الخدمات</a>
                    </li>
                </ul>
                
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <img src="<?php echo getProfileImage($_SESSION['user_id']); ?>" class="rounded-circle me-2" width="32" height="32" alt="الصورة الشخصية">
                            <span><?php echo $_SESSION['username']; ?></span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/dashboard/profile"><i class="fas fa-user-circle me-2"></i>الملف الشخصي</a></li>
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/dashboard/settings"><i class="fas fa-cog me-2"></i>الإعدادات</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/auth/logout"><i class="fas fa-sign-out-alt me-2"></i>تسجيل الخروج</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <div class="container-fluid">
        <div class="row">
            <!-- القائمة الجانبية -->
            <div class="col-lg-3 col-xl-2 px-0 bg-white shadow-sm sidebar">
                <div class="d-flex flex-column">
                    <!-- رصيد المستخدم -->
                    <div class="p-3 border-bottom text-center">
                        <h5 class="mb-1">رصيدك</h5>
                        <h3 class="text-primary mb-0"><?php echo formatCurrency($_SESSION['balance']); ?></h3>
                        <a href="<?php echo BASE_URL; ?>/dashboard/add_funds" class="btn btn-sm btn-primary mt-2">
                            <i class="fas fa-plus-circle me-1"></i> إضافة رصيد
                        </a>
                    </div>
                    
                    <!-- عناصر القائمة -->
                    <ul class="sidebar-menu list-unstyled">
                        <li class="sidebar-menu-item <?php echo (isset($active_tab) && $active_tab == 'dashboard') ? 'active' : ''; ?>">
                            <a href="<?php echo BASE_URL; ?>/dashboard">
                                <i class="fas fa-tachometer-alt"></i>
                                <span>لوحة التحكم</span>
                            </a>
                        </li>
                        <li class="sidebar-menu-item <?php echo (isset($active_tab) && $active_tab == 'new_order') ? 'active' : ''; ?>">
                            <a href="<?php echo BASE_URL; ?>/dashboard/new_order">
                                <i class="fas fa-plus-circle"></i>
                                <span>طلب جديد</span>
                            </a>
                        </li>
                        <li class="sidebar-menu-item <?php echo (isset($active_tab) && $active_tab == 'mass_order') ? 'active' : ''; ?>">
                            <a href="<?php echo BASE_URL; ?>/dashboard/mass_order">
                                <i class="fas fa-layer-group"></i>
                                <span>طلب جماعي</span>
                            </a>
                        </li>
                        <li class="sidebar-menu-item <?php echo (isset($active_tab) && $active_tab == 'orders') ? 'active' : ''; ?>">
                            <a href="<?php echo BASE_URL; ?>/dashboard/orders">
                                <i class="fas fa-list-alt"></i>
                                <span>طلباتي</span>
                            </a>
                        </li>
                        <li class="sidebar-menu-item <?php echo (isset($active_tab) && $active_tab == 'subscriptions') ? 'active' : ''; ?>">
                            <a href="<?php echo BASE_URL; ?>/dashboard/subscriptions">
                                <i class="fas fa-sync"></i>
                                <span>الاشتراكات</span>
                            </a>
                        </li>
                        <li class="sidebar-menu-item <?php echo (isset($active_tab) && $active_tab == 'transactions') ? 'active' : ''; ?>">
                            <a href="<?php echo BASE_URL; ?>/dashboard/transactions">
                                <i class="fas fa-history"></i>
                                <span>المعاملات</span>
                            </a>
                        </li>
                        <li class="sidebar-menu-item <?php echo (isset($active_tab) && $active_tab == 'api') ? 'active' : ''; ?>">
                            <a href="<?php echo BASE_URL; ?>/dashboard/api">
                                <i class="fas fa-code"></i>
                                <span>API</span>
                            </a>
                        </li>
                        <li class="sidebar-menu-item <?php echo (isset($active_tab) && $active_tab == 'tickets') ? 'active' : ''; ?>">
                            <a href="<?php echo BASE_URL; ?>/dashboard/tickets">
                                <i class="fas fa-ticket-alt"></i>
                                <span>تذاكر الدعم</span>
                            </a>
                        </li>
                        <li class="sidebar-menu-item <?php echo (isset($active_tab) && $active_tab == 'profile') ? 'active' : ''; ?>">
                            <a href="<?php echo BASE_URL; ?>/dashboard/profile">
                                <i class="fas fa-user-circle"></i>
                                <span>الملف الشخصي</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- المحتوى الرئيسي -->
            <div class="col-lg-9 col-xl-10 py-4 px-4">
                <!-- عرض رسائل النظام -->
                <?php if (isset($_SESSION['error_message']) || isset($_SESSION['success_message'])): ?>
                    <?php if (isset($_SESSION['error_message'])): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo $_SESSION['error_message']; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['error_message']); ?>
                    <?php endif; ?>
                    
                    <?php if (isset($_SESSION['success_message'])): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo $_SESSION['success_message']; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['success_message']); ?>
                    <?php endif; ?>
                <?php endif; ?>
                
                <!-- بداية محتوى الصفحة -->
                <?php echo $content; ?>
                <!-- نهاية محتوى الصفحة -->
            </div>
        </div>
    </div>
    
    <!-- JavaScript إضافي -->
    <script src="<?php echo BASE_URL; ?>/assets/js/main.js"></script>
</body>
</html>
