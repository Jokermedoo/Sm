<?php
/**
 * SMM Panel - Services Management Page with Drag and Drop
 * 
 * This page demonstrates how to use drag and drop for service management
 */

use App\Helpers\DragDropIntegration;

// Load categories and services data
// In a real implementation, this would come from the controller
$categories = [
    ['id' => 1, 'name' => 'وسائل التواصل الاجتماعي', 'order' => 1],
    ['id' => 2, 'name' => 'خدمات المواقع الإلكترونية', 'order' => 2],
    ['id' => 3, 'name' => 'خدمات التسويق', 'order' => 3],
    ['id' => 4, 'name' => 'خدمات الفيديو', 'order' => 4],
    ['id' => 5, 'name' => 'خدمات أخرى', 'order' => 5],
];

// Sample services data
$services = [
    ['id' => 1, 'name' => 'متابعين انستغرام', 'price' => 5.99, 'category_id' => 1, 'order' => 1],
    ['id' => 2, 'name' => 'لايكات فيسبوك', 'price' => 3.99, 'category_id' => 1, 'order' => 2],
    ['id' => 3, 'name' => 'مشاهدات يوتيوب', 'price' => 2.99, 'category_id' => 1, 'order' => 3],
    ['id' => 4, 'name' => 'تحسين SEO', 'price' => 99.99, 'category_id' => 2, 'order' => 1],
    ['id' => 5, 'name' => 'تصميم موقع', 'price' => 199.99, 'category_id' => 2, 'order' => 2],
    ['id' => 6, 'name' => 'حملات إعلانية', 'price' => 49.99, 'category_id' => 3, 'order' => 1],
    ['id' => 7, 'name' => 'تسويق بالبريد الإلكتروني', 'price' => 29.99, 'category_id' => 3, 'order' => 2],
    ['id' => 8, 'name' => 'مونتاج فيديو', 'price' => 79.99, 'category_id' => 4, 'order' => 1],
    ['id' => 9, 'name' => 'إنتاج محتوى', 'price' => 59.99, 'category_id' => 5, 'order' => 1],
];

// Group services by category
$servicesByCategory = [];
foreach ($services as $service) {
    $categoryId = $service['category_id'];
    if (!isset($servicesByCategory[$categoryId])) {
        $servicesByCategory[$categoryId] = [];
    }
    $servicesByCategory[$categoryId][] = $service;
}
?>

<!-- Main content -->
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0">
                    <div class="d-flex justify-content-between align-items-center">
                        <h6>إدارة الخدمات والفئات باستخدام السحب والإفلات</h6>
                        <div>
                            <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addCategoryModal">
                                <i class="fas fa-plus me-1"></i> إضافة فئة
                            </button>
                            <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#addServiceModal">
                                <i class="fas fa-plus me-1"></i> إضافة خدمة
                            </button>
                        </div>
                    </div>
                </div>
                <div class="card-body px-0 pt-0 pb-2">
                    <div class="alert alert-info mx-4 mt-3">
                        <strong>ملاحظة:</strong> يمكنك سحب وإفلات الفئات لتغيير ترتيبها، ويمكنك أيضًا سحب وإفلات الخدمات داخل نفس الفئة أو بين الفئات المختلفة.
                    </div>
                    
                    <!-- Categories container with drag and drop -->
                    <div class="p-4" data-category-container>
                        <?php foreach ($categories as $category): ?>
                            <div class="category-item mb-4" data-category-id="<?= $category['id'] ?>">
                                <div class="category-header">
                                    <span class="category-drag-handle"></span>
                                    <h5 class="mb-0"><?= htmlspecialchars($category['name']) ?></h5>
                                    <div class="ms-auto">
                                        <button class="btn btn-sm btn-outline-primary edit-category" data-id="<?= $category['id'] ?>">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger delete-category" data-id="<?= $category['id'] ?>">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="category-content">
                                    <!-- Services list with drag and drop -->
                                    <ul class="list-unstyled" data-service-list data-category-id="<?= $category['id'] ?>">
                                        <?php 
                                        if (isset($servicesByCategory[$category['id']])):
                                            foreach ($servicesByCategory[$category['id']] as $service): 
                                        ?>
                                            <li class="service-item" data-service-id="<?= $service['id'] ?>">
                                                <span class="service-drag-handle"></span>
                                                <div class="d-flex w-100 align-items-center">
                                                    <div>
                                                        <h6 class="mb-0"><?= htmlspecialchars($service['name']) ?></h6>
                                                        <small><?= $service['price'] ?> $</small>
                                                    </div>
                                                    <div class="ms-auto">
                                                        <button class="btn btn-sm btn-link edit-service" data-id="<?= $service['id'] ?>">
                                                            <i class="fas fa-edit text-primary"></i>
                                                        </button>
                                                        <button class="btn btn-sm btn-link delete-service" data-id="<?= $service['id'] ?>">
                                                            <i class="fas fa-trash text-danger"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </li>
                                        <?php 
                                            endforeach;
                                        endif;
                                        ?>
                                    </ul>
                                    
                                    <?php if (!isset($servicesByCategory[$category['id']]) || empty($servicesByCategory[$category['id']])): ?>
                                        <div class="text-center py-3 text-muted">
                                            <em>لا توجد خدمات في هذه الفئة</em>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <button class="btn btn-sm btn-outline-success mt-2 add-service-to-category" data-category-id="<?= $category['id'] ?>">
                                        <i class="fas fa-plus me-1"></i> إضافة خدمة إلى هذه الفئة
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Category Modal -->
<div class="modal fade" id="addCategoryModal" tabindex="-1" aria-labelledby="addCategoryModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addCategoryModalLabel">إضافة فئة جديدة</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="add-category-form">
                    <div class="mb-3">
                        <label for="category-name" class="form-label">اسم الفئة</label>
                        <input type="text" class="form-control" id="category-name" required>
                    </div>
                    <div class="mb-3">
                        <label for="category-description" class="form-label">وصف الفئة</label>
                        <textarea class="form-control" id="category-description" rows="3"></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                <button type="button" class="btn btn-primary" id="save-category">حفظ</button>
            </div>
        </div>
    </div>
</div>

<!-- Add Service Modal -->
<div class="modal fade" id="addServiceModal" tabindex="-1" aria-labelledby="addServiceModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addServiceModalLabel">إضافة خدمة جديدة</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="add-service-form">
                    <div class="mb-3">
                        <label for="service-name" class="form-label">اسم الخدمة</label>
                        <input type="text" class="form-control" id="service-name" required>
                    </div>
                    <div class="mb-3">
                        <label for="service-price" class="form-label">السعر ($)</label>
                        <input type="number" step="0.01" class="form-control" id="service-price" required>
                    </div>
                    <div class="mb-3">
                        <label for="service-category" class="form-label">الفئة</label>
                        <select class="form-select" id="service-category" required>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?= $category['id'] ?>"><?= htmlspecialchars($category['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="service-description" class="form-label">وصف الخدمة</label>
                        <textarea class="form-control" id="service-description" rows="3"></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                <button type="button" class="btn btn-primary" id="save-service">حفظ</button>
            </div>
        </div>
    </div>
</div>

<!-- Include drag and drop assets -->
<?= DragDropIntegration::loadAssets(true) ?>

<script>
// Custom JavaScript for the page
document.addEventListener('DOMContentLoaded', function() {
    // Handle category save
    document.getElementById('save-category').addEventListener('click', function() {
        const form = document.getElementById('add-category-form');
        if (form.checkValidity()) {
            const name = document.getElementById('category-name').value;
            const description = document.getElementById('category-description').value;
            
            // In a real app, you would send this data to the server
            console.log('Saving category:', { name, description });
            
            // Show success message
            showNotification('success', 'تم إضافة الفئة بنجاح');
            
            // Close modal
            bootstrap.Modal.getInstance(document.getElementById('addCategoryModal')).hide();
        } else {
            form.reportValidity();
        }
    });
    
    // Handle service save
    document.getElementById('save-service').addEventListener('click', function() {
        const form = document.getElementById('add-service-form');
        if (form.checkValidity()) {
            const name = document.getElementById('service-name').value;
            const price = document.getElementById('service-price').value;
            const categoryId = document.getElementById('service-category').value;
            const description = document.getElementById('service-description').value;
            
            // In a real app, you would send this data to the server
            console.log('Saving service:', { name, price, categoryId, description });
            
            // Show success message
            showNotification('success', 'تم إضافة الخدمة بنجاح');
            
            // Close modal
            bootstrap.Modal.getInstance(document.getElementById('addServiceModal')).hide();
        } else {
            form.reportValidity();
        }
    });
    
    // Edit category buttons
    document.querySelectorAll('.edit-category').forEach(button => {
        button.addEventListener('click', function() {
            const categoryId = this.dataset.id;
            console.log('Edit category:', categoryId);
            
            // In a real app, you would fetch the category data and open the edit modal
            showNotification('info', 'تحرير الفئة ' + categoryId);
        });
    });
    
    // Delete category buttons
    document.querySelectorAll('.delete-category').forEach(button => {
        button.addEventListener('click', function() {
            const categoryId = this.dataset.id;
            
            if (confirm('هل أنت متأكد من حذف هذه الفئة؟ سيتم حذف جميع الخدمات المرتبطة بها.')) {
                console.log('Delete category:', categoryId);
                
                // In a real app, you would send a request to delete the category
                showNotification('success', 'تم حذف الفئة بنجاح');
            }
        });
    });
    
    // Edit service buttons
    document.querySelectorAll('.edit-service').forEach(button => {
        button.addEventListener('click', function() {
            const serviceId = this.dataset.id;
            console.log('Edit service:', serviceId);
            
            // In a real app, you would fetch the service data and open the edit modal
            showNotification('info', 'تحرير الخدمة ' + serviceId);
        });
    });
    
    // Delete service buttons
    document.querySelectorAll('.delete-service').forEach(button => {
        button.addEventListener('click', function() {
            const serviceId = this.dataset.id;
            
            if (confirm('هل أنت متأكد من حذف هذه الخدمة؟')) {
                console.log('Delete service:', serviceId);
                
                // In a real app, you would send a request to delete the service
                showNotification('success', 'تم حذف الخدمة بنجاح');
            }
        });
    });
    
    // Add service to category buttons
    document.querySelectorAll('.add-service-to-category').forEach(button => {
        button.addEventListener('click', function() {
            const categoryId = this.dataset.categoryId;
            
            // Set the category in the modal and open it
            document.getElementById('service-category').value = categoryId;
            new bootstrap.Modal(document.getElementById('addServiceModal')).show();
        });
    });
});

// Helper function to show notifications
function showNotification(type, message) {
    // If the notification function is not available, create a simple alert
    if (typeof window.showNotification !== 'function') {
        window.showNotification = function(type, message) {
            const alertClass = type === 'success' ? 'alert-success' : 
                              type === 'error' ? 'alert-danger' : 
                              type === 'warning' ? 'alert-warning' : 'alert-info';
            
            const alertDiv = document.createElement('div');
            alertDiv.className = `alert ${alertClass} alert-dismissible fade show position-fixed top-0 end-0 m-3`;
            alertDiv.style.zIndex = '9999';
            alertDiv.innerHTML = `
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            `;
            
            document.body.appendChild(alertDiv);
            
            setTimeout(() => {
                alertDiv.classList.remove('show');
                setTimeout(() => alertDiv.remove(), 300);
            }, 3000);
        };
    }
    
    window.showNotification(type, message);
}
</script>
