<?php
/**
 * SMM Panel - Orders Kanban Board with Drag and Drop
 * 
 * This page demonstrates how to use drag and drop for order management using a Kanban board
 */

use App\Helpers\DragDropIntegration;

// Load orders data
// In a real implementation, this would come from the controller
$orders = [
    'pending' => [
        ['id' => 101, 'service_name' => 'متابعين انستغرام', 'quantity' => 1000, 'price' => 5.99, 'user_name' => 'أحمد محمد', 'date' => '2025-05-30', 'status' => 'pending'],
        ['id' => 102, 'service_name' => 'لايكات فيسبوك', 'quantity' => 500, 'price' => 3.99, 'user_name' => 'سارة علي', 'date' => '2025-05-30', 'status' => 'pending'],
        ['id' => 103, 'service_name' => 'مشاهدات يوتيوب', 'quantity' => 5000, 'price' => 10.99, 'user_name' => 'محمد خالد', 'date' => '2025-05-30', 'status' => 'pending'],
    ],
    'processing' => [
        ['id' => 98, 'service_name' => 'تصميم لوجو', 'quantity' => 1, 'price' => 50.00, 'user_name' => 'فاطمة أحمد', 'date' => '2025-05-29', 'status' => 'processing'],
        ['id' => 99, 'service_name' => 'حملة إعلانية', 'quantity' => 1, 'price' => 150.00, 'user_name' => 'عمر محمود', 'date' => '2025-05-29', 'status' => 'processing'],
    ],
    'completed' => [
        ['id' => 95, 'service_name' => 'متابعين تويتر', 'quantity' => 2000, 'price' => 15.99, 'user_name' => 'خالد عبدالله', 'date' => '2025-05-28', 'status' => 'completed'],
        ['id' => 96, 'service_name' => 'لايكات انستغرام', 'quantity' => 3000, 'price' => 20.99, 'user_name' => 'نورة محمد', 'date' => '2025-05-28', 'status' => 'completed'],
        ['id' => 97, 'service_name' => 'مشتركين يوتيوب', 'quantity' => 1000, 'price' => 40.00, 'user_name' => 'سعود فهد', 'date' => '2025-05-28', 'status' => 'completed'],
    ],
    'failed' => [
        ['id' => 94, 'service_name' => 'متابعين تيك توك', 'quantity' => 5000, 'price' => 25.99, 'user_name' => 'ليلى سعيد', 'date' => '2025-05-27', 'status' => 'failed'],
    ],
    'cancelled' => [
        ['id' => 93, 'service_name' => 'تعليقات انستغرام', 'quantity' => 100, 'price' => 15.00, 'user_name' => 'حسن علي', 'date' => '2025-05-27', 'status' => 'cancelled'],
    ],
    'refunded' => [
        ['id' => 92, 'service_name' => 'مشاهدات تيك توك', 'quantity' => 10000, 'price' => 30.00, 'user_name' => 'منى أحمد', 'date' => '2025-05-26', 'status' => 'refunded'],
    ],
];

// Status text and colors
$statuses = [
    'pending' => ['text' => 'قيد الانتظار', 'color' => 'warning'],
    'processing' => ['text' => 'قيد المعالجة', 'color' => 'info'],
    'completed' => ['text' => 'مكتمل', 'color' => 'success'],
    'failed' => ['text' => 'فشل', 'color' => 'danger'],
    'cancelled' => ['text' => 'ملغي', 'color' => 'secondary'],
    'refunded' => ['text' => 'مسترد', 'color' => 'primary'],
];

// Count orders by status
$statusCounts = [];
foreach ($orders as $status => $statusOrders) {
    $statusCounts[$status] = count($statusOrders);
}
?>

<!-- Main content -->
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0">
                    <div class="d-flex justify-content-between align-items-center">
                        <h6>إدارة الطلبات - لوحة كانبان</h6>
                        <div class="d-flex gap-2">
                            <div class="dropdown">
                                <button class="btn btn-sm btn-primary dropdown-toggle" type="button" id="filterDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-filter me-1"></i> تصفية
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="filterDropdown">
                                    <li><a class="dropdown-item" href="#" data-filter="all">كل الطلبات</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <?php foreach ($statuses as $statusKey => $statusInfo): ?>
                                        <li>
                                            <a class="dropdown-item" href="#" data-filter="<?= $statusKey ?>">
                                                <?= $statusInfo['text'] ?> 
                                                <span class="badge bg-<?= $statusInfo['color'] ?> ms-1">
                                                    <?= $statusCounts[$statusKey] ?? 0 ?>
                                                </span>
                                            </a>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                            <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#searchOrdersModal">
                                <i class="fas fa-search me-1"></i> بحث
                            </button>
                            <button class="btn btn-sm btn-info" id="refreshKanban">
                                <i class="fas fa-sync-alt me-1"></i> تحديث
                            </button>
                        </div>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="alert alert-info mx-4 mt-3">
                        <strong>ملاحظة:</strong> يمكنك سحب وإفلات الطلبات بين الحالات المختلفة لتغيير حالتها. سيتم حفظ التغييرات تلقائيًا.
                    </div>
                    
                    <!-- Kanban board for orders -->
                    <?= DragDropIntegration::renderOrderKanban($orders) ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Order Details Modal -->
<div class="modal fade" id="orderDetailsModal" tabindex="-1" aria-labelledby="orderDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="orderDetailsModalLabel">تفاصيل الطلب <span id="order-id-display"></span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="order-details-content">
                <div class="text-center py-5">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">جاري التحميل...</span>
                    </div>
                    <p class="mt-2">جاري تحميل تفاصيل الطلب...</p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                <div class="btn-group status-actions">
                    <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                        تغيير الحالة
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <?php foreach ($statuses as $statusKey => $statusInfo): ?>
                            <li>
                                <a class="dropdown-item change-status" href="#" data-status="<?= $statusKey ?>">
                                    <span class="badge bg-<?= $statusInfo['color'] ?> me-2"></span>
                                    <?= $statusInfo['text'] ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Search Orders Modal -->
<div class="modal fade" id="searchOrdersModal" tabindex="-1" aria-labelledby="searchOrdersModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="searchOrdersModalLabel">بحث عن طلبات</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="search-orders-form">
                    <div class="mb-3">
                        <label for="search-order-id" class="form-label">رقم الطلب</label>
                        <input type="text" class="form-control" id="search-order-id" placeholder="أدخل رقم الطلب">
                    </div>
                    <div class="mb-3">
                        <label for="search-user" class="form-label">اسم المستخدم</label>
                        <input type="text" class="form-control" id="search-user" placeholder="أدخل اسم المستخدم">
                    </div>
                    <div class="mb-3">
                        <label for="search-service" class="form-label">الخدمة</label>
                        <input type="text" class="form-control" id="search-service" placeholder="أدخل اسم الخدمة">
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="search-date-from" class="form-label">من تاريخ</label>
                            <input type="date" class="form-control" id="search-date-from">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="search-date-to" class="form-label">إلى تاريخ</label>
                            <input type="date" class="form-control" id="search-date-to">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">الحالة</label>
                        <div class="d-flex flex-wrap gap-2">
                            <?php foreach ($statuses as $statusKey => $statusInfo): ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="search-status-<?= $statusKey ?>" value="<?= $statusKey ?>">
                                    <label class="form-check-label" for="search-status-<?= $statusKey ?>">
                                        <?= $statusInfo['text'] ?>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                <button type="button" class="btn btn-primary" id="search-orders-button">بحث</button>
            </div>
        </div>
    </div>
</div>

<!-- Include drag and drop assets -->
<?= DragDropIntegration::loadAssets(true) ?>

<script>
// Custom JavaScript for the page
document.addEventListener('DOMContentLoaded', function() {
    // Handle order item click to show details
    document.querySelectorAll('.order-item').forEach(item => {
        item.addEventListener('click', function(e) {
            // Don't show details if dragging
            if (document.body.classList.contains('dragging-active')) return;
            
            // Don't trigger if clicking on buttons
            if (e.target.closest('button')) return;
            
            const orderId = this.dataset.orderId;
            showOrderDetails(orderId);
        });
    });
    
    // Refresh kanban button
    document.getElementById('refreshKanban').addEventListener('click', function() {
        showNotification('info', 'جاري تحديث لوحة كانبان...');
        
        // In a real app, you would fetch the latest data from the server
        setTimeout(() => {
            showNotification('success', 'تم تحديث لوحة كانبان بنجاح');
        }, 1000);
    });
    
    // Filter orders
    document.querySelectorAll('[data-filter]').forEach(filter => {
        filter.addEventListener('click', function(e) {
            e.preventDefault();
            const filterValue = this.dataset.filter;
            
            if (filterValue === 'all') {
                document.querySelectorAll('[data-status-container]').forEach(container => {
                    container.style.display = '';
                });
                showNotification('info', 'عرض جميع الحالات');
            } else {
                document.querySelectorAll('[data-status-container]').forEach(container => {
                    if (container.dataset.status === filterValue) {
                        container.style.display = '';
                    } else {
                        container.style.display = 'none';
                    }
                });
                
                const statusText = document.querySelector(`[data-filter="${filterValue}"]`).textContent.trim().split(' ')[0];
                showNotification('info', `تصفية حسب: ${statusText}`);
            }
        });
    });
    
    // Search orders button
    document.getElementById('search-orders-button').addEventListener('click', function() {
        const searchData = {
            order_id: document.getElementById('search-order-id').value,
            user: document.getElementById('search-user').value,
            service: document.getElementById('search-service').value,
            date_from: document.getElementById('search-date-from').value,
            date_to: document.getElementById('search-date-to').value,
            statuses: Array.from(document.querySelectorAll('input[id^="search-status-"]:checked')).map(cb => cb.value)
        };
        
        // In a real app, you would send this data to the server and update the kanban board
        console.log('Search data:', searchData);
        
        // Show a notification
        showNotification('info', 'جاري البحث عن الطلبات...');
        
        // Close the modal
        bootstrap.Modal.getInstance(document.getElementById('searchOrdersModal')).hide();
        
        // In a real app, you would update the kanban board with search results
        setTimeout(() => {
            showNotification('success', 'تم العثور على 3 طلبات مطابقة للبحث');
        }, 1000);
    });
    
    // Change status buttons
    document.querySelectorAll('.change-status').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            const status = this.dataset.status;
            const orderId = document.getElementById('order-id-display').textContent.replace('#', '');
            
            // In a real app, you would send a request to update the order status
            console.log('Changing order status:', { orderId, status });
            
            // Show a notification
            const statusText = this.textContent.trim();
            showNotification('success', `تم تغيير حالة الطلب #${orderId} إلى "${statusText}"`);
            
            // Close the modal
            bootstrap.Modal.getInstance(document.getElementById('orderDetailsModal')).hide();
            
            // Update the order in the kanban board
            updateOrderStatus(orderId, status);
        });
    });
});

// Function to show order details
function showOrderDetails(orderId) {
    // Set the order ID in the modal title
    document.getElementById('order-id-display').textContent = '#' + orderId;
    
    // Show the modal
    const modal = new bootstrap.Modal(document.getElementById('orderDetailsModal'));
    modal.show();
    
    // In a real app, you would fetch the order details from the server
    // For this example, we'll simulate a server request with a timeout
    setTimeout(() => {
        const order = findOrderById(orderId);
        
        if (order) {
            document.getElementById('order-details-content').innerHTML = `
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="fw-bold">رقم الطلب:</label>
                            <div>#${order.id}</div>
                        </div>
                        <div class="mb-3">
                            <label class="fw-bold">الخدمة:</label>
                            <div>${order.service_name}</div>
                        </div>
                        <div class="mb-3">
                            <label class="fw-bold">الكمية:</label>
                            <div>${order.quantity}</div>
                        </div>
                        <div class="mb-3">
                            <label class="fw-bold">السعر:</label>
                            <div>${order.price} $</div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="fw-bold">المستخدم:</label>
                            <div>${order.user_name}</div>
                        </div>
                        <div class="mb-3">
                            <label class="fw-bold">التاريخ:</label>
                            <div>${order.date}</div>
                        </div>
                        <div class="mb-3">
                            <label class="fw-bold">الحالة:</label>
                            <div>
                                <span class="badge bg-${getStatusColor(order.status)}">${getStatusText(order.status)}</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <label class="fw-bold">ملاحظات:</label>
                        <div class="border rounded p-3">
                            ${order.notes || 'لا توجد ملاحظات لهذا الطلب.'}
                        </div>
                    </div>
                </div>
            `;
        } else {
            document.getElementById('order-details-content').innerHTML = `
                <div class="alert alert-danger">
                    لم يتم العثور على بيانات لهذا الطلب.
                </div>
            `;
        }
    }, 500);
}

// Helper function to find order by ID
function findOrderById(orderId) {
    // In a real app, you would fetch this from the server
    // For this example, we'll search the orders in our JS
    for (const status in window.orders) {
        const order = window.orders[status].find(o => o.id == orderId);
        if (order) return order;
    }
    return null;
}

// Store orders data for client-side use
window.orders = <?= json_encode($orders) ?>;

// Helper function to update order status in the UI
function updateOrderStatus(orderId, newStatus) {
    const orderItem = document.querySelector(`.order-item[data-order-id="${orderId}"]`);
    if (!orderItem) return;
    
    const oldStatus = orderItem.dataset.status;
    
    // Skip if status is the same
    if (oldStatus === newStatus) return;
    
    // Get the new container
    const newContainer = document.querySelector(`[data-status-container][data-status="${newStatus}"]`);
    if (!newContainer) return;
    
    // Move the order item to the new container
    newContainer.appendChild(orderItem);
    
    // Update order data
    orderItem.dataset.status = newStatus;
    
    // Update the status badge
    const statusBadge = orderItem.querySelector('.status-badge');
    if (statusBadge) {
        statusBadge.className = `status-badge badge bg-${getStatusColor(newStatus)}`;
        statusBadge.textContent = getStatusText(newStatus);
    }
    
    // Update the internal orders data
    for (let i = 0; i < window.orders[oldStatus].length; i++) {
        if (window.orders[oldStatus][i].id == orderId) {
            const order = window.orders[oldStatus][i];
            order.status = newStatus;
            
            // Remove from old status array
            window.orders[oldStatus].splice(i, 1);
            
            // Add to new status array
            if (!window.orders[newStatus]) {
                window.orders[newStatus] = [];
            }
            window.orders[newStatus].push(order);
            
            break;
        }
    }
}

// Helper function to get status text
function getStatusText(status) {
    const statusMap = {
        'pending': 'قيد الانتظار',
        'processing': 'قيد المعالجة',
        'completed': 'مكتمل',
        'failed': 'فشل',
        'cancelled': 'ملغي',
        'refunded': 'مسترد'
    };
    
    return statusMap[status] || status;
}

// Helper function to get status color
function getStatusColor(status) {
    const colorMap = {
        'pending': 'warning',
        'processing': 'info',
        'completed': 'success',
        'failed': 'danger',
        'cancelled': 'secondary',
        'refunded': 'primary'
    };
    
    return colorMap[status] || 'secondary';
}
</script>
