<!-- قسم البطل (Hero Section) -->
<section class="hero-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 text-lg-end text-center mb-4 mb-lg-0">
                <h1 class="hero-title">أفضل خدمات التسويق عبر وسائل التواصل الاجتماعي</h1>
                <p class="hero-description">نقدم لك مجموعة متكاملة من خدمات زيادة المتابعين والإعجابات والمشاهدات لجميع منصات التواصل الاجتماعي بأسعار تنافسية وجودة عالية.</p>
                <div class="d-flex justify-content-lg-end justify-content-center gap-3">
                    <a href="<?php echo BASE_URL; ?>/services" class="btn btn-light btn-lg">استكشف خدماتنا</a>
                    <a href="<?php echo BASE_URL; ?>/auth/register" class="btn btn-secondary btn-lg">ابدأ الآن</a>
                </div>
            </div>
            <div class="col-lg-6">
                <img src="<?php echo BASE_URL; ?>/assets/images/hero-image.svg" alt="Town Media" class="img-fluid">
            </div>
        </div>
    </div>
</section>

<!-- قسم المميزات -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title d-inline-block">لماذا تختار تاون ميديا؟</h2>
            <p class="section-subtitle mt-3">نقدم لك العديد من المميزات التي تجعلنا الخيار الأمثل لخدمات التسويق الاجتماعي</p>
        </div>
        
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="feature-icon mx-auto mb-3">
                            <i class="fas fa-bolt fa-2x text-primary"></i>
                        </div>
                        <h4 class="card-title">سرعة في التنفيذ</h4>
                        <p class="card-text">نقدم خدماتنا بشكل فوري وسريع، مع بدء التنفيذ خلال دقائق من تأكيد الطلب.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="feature-icon mx-auto mb-3">
                            <i class="fas fa-shield-alt fa-2x text-primary"></i>
                        </div>
                        <h4 class="card-title">أمان كامل</h4>
                        <p class="card-text">لا نطلب كلمات مرور حساباتك أبدًا، وجميع خدماتنا آمنة 100% على حساباتك.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="feature-icon mx-auto mb-3">
                            <i class="fas fa-headset fa-2x text-primary"></i>
                        </div>
                        <h4 class="card-title">دعم فني 24/7</h4>
                        <p class="card-text">فريق الدعم الفني متاح على مدار الساعة طوال أيام الأسبوع للإجابة على استفساراتك.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- قسم الخدمات -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title d-inline-block">خدماتنا المميزة</h2>
            <p class="section-subtitle mt-3">مجموعة متنوعة من الخدمات لجميع منصات التواصل الاجتماعي</p>
        </div>
        
        <div class="row g-4">
            <?php foreach ($featured_services as $service): ?>
            <div class="col-md-4">
                <div class="card service-card h-100 border-0 shadow-sm">
                    <div class="card-body p-4">
                        <div class="service-icon">
                            <?php 
                            $icon = 'fa-globe';
                            switch(strtolower($service['category'])) {
                                case 'instagram':
                                    $icon = 'fab fa-instagram';
                                    break;
                                case 'facebook':
                                    $icon = 'fab fa-facebook-f';
                                    break;
                                case 'twitter':
                                case 'x':
                                    $icon = 'fab fa-twitter';
                                    break;
                                case 'youtube':
                                    $icon = 'fab fa-youtube';
                                    break;
                                case 'tiktok':
                                    $icon = 'fab fa-tiktok';
                                    break;
                            }
                            ?>
                            <i class="<?php echo $icon; ?>"></i>
                        </div>
                        <h4 class="card-title"><?php echo $service['name']; ?></h4>
                        <p class="card-text"><?php echo $service['description']; ?></p>
                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <span class="service-price"><?php echo formatCurrency($service['price']); ?> / 1000</span>
                            <a href="<?php echo BASE_URL; ?>/dashboard/new_order?service=<?php echo $service['id']; ?>" class="btn btn-sm btn-primary">طلب الآن</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <div class="text-center mt-5">
            <a href="<?php echo BASE_URL; ?>/services" class="btn btn-primary btn-lg">عرض جميع الخدمات</a>
        </div>
    </div>
</section>

<!-- قسم الإحصائيات -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title d-inline-block">تاون ميديا بالأرقام</h2>
            <p class="section-subtitle mt-3">إنجازاتنا وإحصائياتنا تتحدث عن نفسها</p>
        </div>
        
        <div class="row g-4">
            <div class="col-md-3 col-6">
                <div class="stat-card text-center">
                    <div class="stat-icon bg-primary-light mx-auto">
                        <i class="fas fa-users fa-2x text-primary"></i>
                    </div>
                    <div class="stat-value">5000+</div>
                    <div class="stat-label">عميل سعيد</div>
                </div>
            </div>
            
            <div class="col-md-3 col-6">
                <div class="stat-card text-center">
                    <div class="stat-icon bg-success-light mx-auto">
                        <i class="fas fa-shopping-cart fa-2x text-success"></i>
                    </div>
                    <div class="stat-value">100K+</div>
                    <div class="stat-label">طلب مكتمل</div>
                </div>
            </div>
            
            <div class="col-md-3 col-6">
                <div class="stat-card text-center">
                    <div class="stat-icon bg-info-light mx-auto">
                        <i class="fas fa-globe fa-2x text-info"></i>
                    </div>
                    <div class="stat-value">50+</div>
                    <div class="stat-label">خدمة متاحة</div>
                </div>
            </div>
            
            <div class="col-md-3 col-6">
                <div class="stat-card text-center">
                    <div class="stat-icon bg-warning-light mx-auto">
                        <i class="fas fa-star fa-2x text-warning"></i>
                    </div>
                    <div class="stat-value">4.9</div>
                    <div class="stat-label">تقييم العملاء</div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- قسم الشهادات والآراء -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title d-inline-block">آراء العملاء</h2>
            <p class="section-subtitle mt-3">ماذا يقول عملاؤنا عن خدماتنا</p>
        </div>
        
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body p-4">
                        <div class="d-flex align-items-center mb-3">
                            <div class="me-3">
                                <img src="<?php echo BASE_URL; ?>/assets/images/testimonial-1.jpg" alt="العميل" class="rounded-circle" width="60" height="60">
                            </div>
                            <div>
                                <h5 class="mb-0">أحمد محمد</h5>
                                <div class="text-warning">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </div>
                            </div>
                        </div>
                        <p class="card-text">"خدمة ممتازة وسريعة جدًا. زاد عدد متابعيني على انستغرام بشكل ملحوظ خلال فترة قصيرة. سأتعامل معكم مجددًا بالتأكيد."</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body p-4">
                        <div class="d-flex align-items-center mb-3">
                            <div class="me-3">
                                <img src="<?php echo BASE_URL; ?>/assets/images/testimonial-2.jpg" alt="العميل" class="rounded-circle" width="60" height="60">
                            </div>
                            <div>
                                <h5 class="mb-0">سارة علي</h5>
                                <div class="text-warning">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star-half-alt"></i>
                                </div>
                            </div>
                        </div>
                        <p class="card-text">"أنا سعيدة جدًا بالتعامل مع تاون ميديا. الدعم الفني ممتاز والخدمات ذات جودة عالية. أنصح به بشدة لكل من يريد تعزيز حضوره على وسائل التواصل."</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body p-4">
                        <div class="d-flex align-items-center mb-3">
                            <div class="me-3">
                                <img src="<?php echo BASE_URL; ?>/assets/images/testimonial-3.jpg" alt="العميل" class="rounded-circle" width="60" height="60">
                            </div>
                            <div>
                                <h5 class="mb-0">محمود خالد</h5>
                                <div class="text-warning">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </div>
                            </div>
                        </div>
                        <p class="card-text">"كصاحب متجر إلكتروني، ساعدتني خدمات تاون ميديا في زيادة مبيعاتي بشكل كبير من خلال زيادة متابعيني على منصات التواصل. شكرًا لكم!"</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- قسم الدعوة للعمل (CTA) -->
<section class="py-5 bg-primary text-white">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8 text-lg-end text-center mb-4 mb-lg-0">
                <h2 class="mb-3">مستعد لتعزيز حضورك على وسائل التواصل الاجتماعي؟</h2>
                <p class="mb-0 lead">انضم إلى آلاف العملاء السعداء واستفد من خدماتنا المتميزة اليوم.</p>
            </div>
            <div class="col-lg-4 text-lg-start text-center">
                <a href="<?php echo BASE_URL; ?>/auth/register" class="btn btn-light btn-lg px-4 py-3">سجل الآن وابدأ مجانًا</a>
            </div>
        </div>
    </div>
</section>

<!-- قسم الأسئلة الشائعة المصغر -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title d-inline-block">الأسئلة الشائعة</h2>
            <p class="section-subtitle mt-3">إجابات على أكثر الأسئلة شيوعًا</p>
        </div>
        
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="accordion" id="faqAccordion">
                    <div class="accordion-item border mb-3 rounded">
                        <h2 class="accordion-header" id="headingOne">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                هل خدماتكم آمنة على حسابات التواصل الاجتماعي؟
                            </button>
                        </h2>
                        <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                نعم، جميع خدماتنا آمنة تمامًا ولا تتطلب أي معلومات حساسة مثل كلمات المرور. نحن نستخدم فقط الروابط العامة أو معرفات المستخدم لتقديم خدماتنا.
                            </div>
                        </div>
                    </div>
                    
                    <div class="accordion-item border mb-3 rounded">
                        <h2 class="accordion-header" id="headingTwo">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                كم من الوقت يستغرق تنفيذ الطلبات؟
                            </button>
                        </h2>
                        <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                تبدأ معظم الطلبات في التنفيذ خلال دقائق إلى ساعات قليلة من تأكيدها. يعتمد وقت الإكمال على نوع الخدمة والكمية المطلوبة. يمكنك الاطلاع على تقديرات الوقت المحددة لكل خدمة في صفحة الخدمات.
                            </div>
                        </div>
                    </div>
                    
                    <div class="accordion-item border mb-3 rounded">
                        <h2 class="accordion-header" id="headingThree">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                هل يمكنني إلغاء طلب بعد تقديمه؟
                            </button>
                        </h2>
                        <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                يمكن إلغاء الطلبات فقط إذا كانت لا تزال في حالة "قيد الانتظار" ولم يبدأ تنفيذها بعد. بمجرد بدء تنفيذ الطلب، لا يمكن إلغاؤه أو استرداد المبلغ المدفوع.
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="text-center mt-4">
                    <a href="<?php echo BASE_URL; ?>/faq" class="btn btn-outline-primary">عرض جميع الأسئلة الشائعة</a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- قسم المدونة المصغر -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title d-inline-block">آخر منشورات المدونة</h2>
            <p class="section-subtitle mt-3">تابع أحدث المقالات والنصائح حول التسويق عبر وسائل التواصل الاجتماعي</p>
        </div>
        
        <div class="row g-4">
            <?php foreach ($recent_posts as $post): ?>
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm">
                    <?php if ($post['image']): ?>
                    <img src="<?php echo BASE_URL . '/uploads/blog/' . $post['image']; ?>" class="card-img-top" alt="<?php echo $post['title']; ?>">
                    <?php endif; ?>
                    <div class="card-body p-4">
                        <h4 class="card-title"><?php echo $post['title']; ?></h4>
                        <p class="text-muted mb-3"><i class="far fa-calendar-alt me-1"></i> <?php echo formatDate($post['created_at'], 'd/m/Y'); ?></p>
                        <p class="card-text"><?php echo substr(strip_tags($post['content']), 0, 120) . '...'; ?></p>
                        <a href="<?php echo BASE_URL . '/blog/' . $post['slug']; ?>" class="btn btn-sm btn-outline-primary">قراءة المزيد</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <div class="text-center mt-4">
            <a href="<?php echo BASE_URL; ?>/blog" class="btn btn-outline-primary">زيارة المدونة</a>
        </div>
    </div>
</section>
