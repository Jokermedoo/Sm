<?php

namespace App\Core;

class Queue {
    private static $instance = null;
    private $queuePath;
    private $logger;

    private function __construct() {
        $this->queuePath = __DIR__ . '/../../storage/queue/';
        if (!file_exists($this->queuePath)) {
            mkdir($this->queuePath, 0777, true);
        }
        $this->logger = Logger::getInstance();
    }

    public static function getInstance(): self {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function push(string $queue, array $data): bool {
        $job = [
            'id' => uniqid('job_', true),
            'queue' => $queue,
            'data' => $data,
            'attempts' => 0,
            'created_at' => time(),
            'status' => 'pending'
        ];

        $jobFile = $this->queuePath . $job['id'] . '.job';
        $result = file_put_contents($jobFile, serialize($job));
        
        if ($result !== false) {
            $this->logger->info("Job pushed to queue", ['job_id' => $job['id'], 'queue' => $queue]);
            return true;
        }

        $this->logger->error("Failed to push job to queue", ['queue' => $queue]);
        return false;
    }

    public function process(string $queue, callable $callback, int $maxJobs = 10): void {
        $jobs = $this->getJobs($queue, $maxJobs);
        
        foreach ($jobs as $jobFile) {
            $job = unserialize(file_get_contents($jobFile));
            
            if ($job['status'] !== 'pending' || $job['attempts'] >= 3) {
                continue;
            }

            try {
                $job['attempts']++;
                $job['status'] = 'processing';
                file_put_contents($jobFile, serialize($job));

                $result = $callback($job['data']);
                
                if ($result) {
                    $job['status'] = 'completed';
                    $this->logger->info("Job processed successfully", ['job_id' => $job['id']]);
                } else {
                    $job['status'] = 'failed';
                    $this->logger->error("Job processing failed", ['job_id' => $job['id']]);
                }
            } catch (\Exception $e) {
                $job['status'] = 'failed';
                $this->logger->error("Job processing exception", [
                    'job_id' => $job['id'],
                    'error' => $e->getMessage()
                ]);
            }

            file_put_contents($jobFile, serialize($job));
        }
    }

    private function getJobs(string $queue, int $limit): array {
        $jobs = [];
        $files = glob($this->queuePath . '*.job');
        
        foreach ($files as $file) {
            if (count($jobs) >= $limit) break;
            
            $job = unserialize(file_get_contents($file));
            if ($job['queue'] === $queue) {
                $jobs[] = $file;
            }
        }
        
        return $jobs;
    }

    public function cleanCompletedJobs(int $olderThan = 86400): void {
        $files = glob($this->queuePath . '*.job');
        
        foreach ($files as $file) {
            $job = unserialize(file_get_contents($file));
            if ($job['status'] === 'completed' && (time() - $job['created_at']) > $olderThan) {
                unlink($file);
            }
        }
    }
}
