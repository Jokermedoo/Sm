<?php
namespace App\Core;

class Scheduler {
    private static $instance = null;
    private $db;
    private $logger;

    private function __construct() {
        $this->db = Database::getInstance()->getConnection();
        $this->logger = Logger::getInstance();
    }

    public static function getInstance(): self {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function processQueue() {
        try {
            // معالجة الطلبات المعلقة
            $this->processPendingOrders();
            
            // تحديث حالة الطلبات الجارية
            $this->updateInProgressOrders();
            
            // معالجة الاشتراكات
            $this->processSubscriptions();
            
            // تنظيف السجلات القديمة
            $this->cleanOldRecords();
            
            return true;
        } catch (\Exception $e) {
            $this->logger->error("Scheduler error", [
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }

    private function processPendingOrders(): void {
        try {
            $sql = "SELECT * FROM orders WHERE status = 'pending' ORDER BY created_at ASC LIMIT 50";
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            $orders = $stmt->fetchAll(\PDO::FETCH_ASSOC);

            foreach ($orders as $order) {
                try {
                    // تحديث حالة الطلب إلى قيد المعالجة
                    $this->db->beginTransaction();

                    $sql = "UPDATE orders SET status = 'processing' WHERE id = ? AND status = 'pending'";
                    $stmt = $this->db->prepare($sql);
                    $stmt->execute([$order['id']]);

                    if ($stmt->rowCount() > 0) {
                        // إرسال الطلب إلى الـ API المناسب
                        $apiProvider = $this->getAPIProvider($order['service_id']);
                        if ($apiProvider) {
                            $response = $this->sendToProvider($apiProvider, $order);
                            if ($response['success']) {
                                $this->updateOrderStatus($order['id'], 'in_progress', [
                                    'api_order_id' => $response['order_id'],
                                    'start_count' => $response['start_count'] ?? 0
                                ]);
                            } else {
                                $this->updateOrderStatus($order['id'], 'error', [
                                    'error_message' => $response['message']
                                ]);
                            }
                        }
                    }

                    $this->db->commit();
                } catch (\Exception $e) {
                    $this->db->rollBack();
                    $this->logger->error("Order processing error", [
                        'order_id' => $order['id'],
                        'error' => $e->getMessage()
                    ]);
                }
            }
        } catch (\Exception $e) {
            $this->logger->error("Processing pending orders failed", [
                'error' => $e->getMessage()
            ]);
        }
    }

    private function updateInProgressOrders(): void {
        try {
            $sql = "SELECT * FROM orders WHERE status = 'in_progress' ORDER BY updated_at ASC LIMIT 50";
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            $orders = $stmt->fetchAll(\PDO::FETCH_ASSOC);

            foreach ($orders as $order) {
                try {
                    $apiProvider = $this->getAPIProvider($order['service_id']);
                    if ($apiProvider) {
                        $status = $this->checkOrderStatus($apiProvider, $order['api_order_id']);
                        
                        if ($status['success']) {
                            $updates = [
                                'remains' => $status['remains'],
                                'status' => $this->mapProviderStatus($status['status'])
                            ];
                            
                            if (isset($status['start_count'])) {
                                $updates['start_count'] = $status['start_count'];
                            }

                            $this->updateOrderStatus($order['id'], $updates['status'], $updates);
                        }
                    }
                } catch (\Exception $e) {
                    $this->logger->error("Order status update failed", [
                        'order_id' => $order['id'],
                        'error' => $e->getMessage()
                    ]);
                }
            }
        } catch (\Exception $e) {
            $this->logger->error("Updating in-progress orders failed", [
                'error' => $e->getMessage()
            ]);
        }
    }

    private function processSubscriptions(): void {
        try {
            $sql = "SELECT * FROM subscriptions 
                    WHERE status = 'active' 
                    AND posts_done < posts 
                    AND (last_check IS NULL OR last_check <= DATE_SUB(NOW(), INTERVAL delay HOUR))
                    LIMIT 50";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            $subscriptions = $stmt->fetchAll(\PDO::FETCH_ASSOC);

            foreach ($subscriptions as $sub) {
                try {
                    $this->db->beginTransaction();

                    // إنشاء طلب جديد للاشتراك
                    $orderData = [
                        'user_id' => $sub['user_id'],
                        'service_id' => $sub['service_id'],
                        'link' => $sub['link'],
                        'quantity' => $sub['quantity'],
                        'subscription_id' => $sub['id'],
                        'status' => 'pending'
                    ];

                    $sql = "INSERT INTO orders SET " . 
                           implode(', ', array_map(fn($k) => "$k = :$k", array_keys($orderData)));
                    
                    $stmt = $this->db->prepare($sql);
                    foreach ($orderData as $key => $value) {
                        $stmt->bindValue(":$key", $value);
                    }
                    $stmt->execute();

                    // تحديث عداد الاشتراك
                    $sql = "UPDATE subscriptions 
                            SET posts_done = posts_done + 1,
                                last_check = NOW()
                            WHERE id = ?";
                    
                    $stmt = $this->db->prepare($sql);
                    $stmt->execute([$sub['id']]);

                    // إذا اكتمل عدد المنشورات، تغيير الحالة إلى مكتمل
                    if ($sub['posts_done'] + 1 >= $sub['posts']) {
                        $sql = "UPDATE subscriptions SET status = 'completed' WHERE id = ?";
                        $stmt = $this->db->prepare($sql);
                        $stmt->execute([$sub['id']]);
                    }

                    $this->db->commit();
                } catch (\Exception $e) {
                    $this->db->rollBack();
                    $this->logger->error("Subscription processing failed", [
                        'subscription_id' => $sub['id'],
                        'error' => $e->getMessage()
                    ]);
                }
            }
        } catch (\Exception $e) {
            $this->logger->error("Processing subscriptions failed", [
                'error' => $e->getMessage()
            ]);
        }
    }

    private function cleanOldRecords(): void {
        try {
            // حذف سجلات API القديمة
            $this->db->exec(
                "DELETE FROM api_logs 
                WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)"
            );

            // حذف الإشعارات المقروءة القديمة
            $this->db->exec(
                "DELETE FROM notifications 
                WHERE is_read = 1 
                AND created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)"
            );

            // أرشفة الطلبات القديمة المكتملة
            $this->db->exec(
                "INSERT INTO orders_archive 
                SELECT * FROM orders 
                WHERE status IN ('completed', 'canceled', 'refunded') 
                AND created_at < DATE_SUB(NOW(), INTERVAL 90 DAY)"
            );

            $this->db->exec(
                "DELETE FROM orders 
                WHERE status IN ('completed', 'canceled', 'refunded') 
                AND created_at < DATE_SUB(NOW(), INTERVAL 90 DAY)"
            );

        } catch (\Exception $e) {
            $this->logger->error("Cleaning old records failed", [
                'error' => $e->getMessage()
            ]);
        }
    }

    private function getAPIProvider(int $serviceId) {
        try {
            $sql = "SELECT ap.* 
                    FROM services s 
                    JOIN api_providers ap ON s.api_provider_id = ap.id 
                    WHERE s.id = ? AND ap.status = 'active'";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$serviceId]);
            return $stmt->fetch(\PDO::FETCH_ASSOC);
        } catch (\Exception $e) {
            $this->logger->error("Failed to get API provider", [
                'service_id' => $serviceId,
                'error' => $e->getMessage()
            ]);
            return null;
        }
    }

    private function sendToProvider(array $provider, array $order): array {
        // هنا يتم إضافة منطق إرسال الطلب إلى مزود API
        // يجب تنفيذ هذا حسب API كل مزود
        return [
            'success' => true,
            'order_id' => 'test_123',
            'start_count' => 0
        ];
    }

    private function checkOrderStatus(array $provider, string $apiOrderId): array {
        // هنا يتم إضافة منطق التحقق من حالة الطلب من مزود API
        // يجب تنفيذ هذا حسب API كل مزود
        return [
            'success' => true,
            'status' => 'completed',
            'remains' => 0,
            'start_count' => 100
        ];
    }

    private function updateOrderStatus(int $orderId, string $status, array $data = []): bool {
        try {
            $updates = ['status' => $status];
            $updates = array_merge($updates, $data);

            $sql = "UPDATE orders SET " . 
                   implode(', ', array_map(fn($k) => "$k = :$k", array_keys($updates))) . 
                   " WHERE id = :id";

            $stmt = $this->db->prepare($sql);
            $updates['id'] = $orderId;
            
            foreach ($updates as $key => $value) {
                $stmt->bindValue(":$key", $value);
            }

            return $stmt->execute();
        } catch (\Exception $e) {
            $this->logger->error("Failed to update order status", [
                'order_id' => $orderId,
                'status' => $status,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }

    private function mapProviderStatus(string $status): string {
        $statusMap = [
            'pending' => 'pending',
            'in_progress' => 'in_progress',
            'processing' => 'processing',
            'completed' => 'completed',
            'canceled' => 'canceled',
            'failed' => 'error',
            'partial' => 'partial'
        ];

        return $statusMap[$status] ?? 'error';
    }
}
