<?php
/**
 * نظام الترقية الآلي
 */

class AutoUpgradeSystem {
    private const UPDATE_URL = 'https://updates.smm-panel.com/v4/';
    
    public function performUpgrade(): void {
        $this->preChecks();
        $this->backupSystem();
        $this->downloadUpgrade();
        $this->applyUpgrade();
        $this->postChecks();
    }
    
    private function preChecks(): void {
        if (!fsockopen('www.smm-panel.com', 80)) {
            throw new UpgradeException("الاتصال بالإنترنت غير متوفر");
        }
        
        if (memory_get_usage(true) > (512 * 1024 * 1024)) {
            throw new UpgradeException("لا يوجد ذاكرة كافية لاتمام التحديث");
        }
    }
    
    private function backupSystem(): void {
        BackupManager::createSnapshot([
            'include' => ['/app', '/config', '/database'],
            'exclude' => ['/temp', '/cache'],
            'destination' => '/backups/' . date('Ymd-His')
        ]);
    }

    private function downloadUpgrade(): void {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, self::UPDATE_URL . 'latest.zip');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        
        $data = curl_exec($ch);
        if(curl_errno($ch)) {
            throw new UpgradeException("فشل في تحميل التحديث: " . curl_error($ch));
        }
        curl_close($ch);
        
        file_put_contents('/tmp/latest_upgrade.zip', $data);
    }

    private function applyUpgrade(): void {
        $zip = new ZipArchive;
        if ($zip->open('/tmp/latest_upgrade.zip') === TRUE) {
            $zip->extractTo('/tmp/upgrade');
            $zip->close();
            
            // تنفيذ سكربت الترقية
            system('php /tmp/upgrade/install.php');
        } else {
            throw new UpgradeException("فشل في فتح ملف التحديث");
        }
    }

    private function postChecks(): void {
        if (!file_exists('/var/www/html/index.php')) {
            throw new UpgradeException("فشل في الترقية، الملفات الرئيسية مفقودة");
        }
        
        // إعادة تشغيل الخدمات
        system('sudo systemctl restart apache2');
        system('sudo systemctl restart mysql');
    }
}
