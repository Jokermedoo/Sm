<?php
/**
 * نظام الأمان الشامل المتكامل - الإصدار 2.1
 * تم تطويره وتحديثه في 31-05-2025 لمنصة SMM Panel السعودية
 * 
 * التحسينات:
 * - إزالة الاعتماد على security_helpers.php (دمج الوظائف أو استخدام Autoloading)
 * - الاعتماد على إعدادات الأخطاء والجلسات المركزية من index.php و config.php
 * - استخدام ROOT_PATH بدلاً من BASEPATH غير المعرف
 * - تحسينات طفيفة على تسجيل الأحداث (استخدام Monolog يتطلب تكوين إضافي)
 * - إزالة وظائف التشفير/فك التشفير المباشرة (يفضل استخدام مكتبة مخصصة أو خدمة)
 */

declare(strict_types=1);

// يفترض أن Autoloader و config.php قد تم تحميلهما بالفعل
// require_once __DIR__ . '/../app/core/AdvancedUserSystem.php'; // يجب أن يتم تحميلها عبر Autoloader
// require_once __DIR__ . '/../app/core/UnifiedPaymentSystem.php'; // يجب أن يتم تحميلها عبر Autoloader
// require_once __DIR__ . '/../app/core/AutoUpgradeSystem.php'; // يجب أن يتم تحميلها عبر Autoloader

use App\Core\Logger; // افتراض وجود فئة Logger بسيطة أو استخدام Monolog

class Security {
    
    private string $session_id;
    private int $last_activity;
    private string $user_ip;
    // private $userSystem; // يجب حقنه كـ dependency إذا لزم الأمر
    private string $log_file;
    private $logger; // كائن Logger

    public function __construct(/* LoggerInterface $logger */) {
        // --- إعدادات الأمان الأساسية ---
        // تم نقل إعدادات الأخطاء والجلسات إلى index.php و config.php
        // $this->startSecureSession(); // تم البدء بها في index.php

        // تهيئة متغيرات الجلسة والمعلومات
        $this->session_id = session_id() ?: 'unknown';
        $this->last_activity = (int)($_SESSION['LAST_ACTIVITY'] ?? 0);
        $this->user_ip = $this->getClientIp();
        
        // استخدام Logger (مثال بسيط، يفضل Monolog)
        // $this->logger = $logger; // حقن الـ Logger
        // مسار ملف السجل من الإعدادات
        $this->log_file = LOGS_PATH . '/security_' . date('Y-m-d') . '.log'; 

        // تسجيل زيارة الصفحة في السجل
        $this->logPageVisit();
        
        // التحقق من انتهاء صلاحية الجلسة وسرقتها
        if ($this->checkSessionExpiry(SESSION_LIFETIME)) {
            // تم إعادة تعيين الجلسة داخل الدالة
            // قد تحتاج إلى إعادة توجيه المستخدم لصفحة الدخول
            // header('Location: /login?reason=session_expired'); exit;
        }
        if ($this->checkSessionHijacking()) {
             // تم إعادة تعيين الجلسة داخل الدالة
            // قد تحتاج إلى إعادة توجيه المستخدم لصفحة الدخول
            // header('Location: /login?reason=session_hijacked'); exit;
        }
    }

    // تم نقل startSecureSession إلى index.php
    /*
    private function startSecureSession() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start([
                'cookie_httponly' => 1,
                'cookie_secure' => filter_var(getenv('SESSION_SECURE_COOKIE'), FILTER_VALIDATE_BOOLEAN) ? 1 : 0,
                'cookie_samesite' => 'Strict', // أو Lax حسب الحاجة
                'use_strict_mode' => 1,
                'gc_maxlifetime' => SESSION_LIFETIME,
                'cookie_lifetime' => 0 // تنتهي عند إغلاق المتصفح
            ]);
        }
    }
    */

    public function getClientIp(): string {
        // (نفس الكود السابق للحصول على IP)
        // ... (الكود للحصول على IP من $_SERVER)
        if (isset($_SERVER['HTTP_CLIENT_IP'])) {
            $ipAddress = $_SERVER['HTTP_CLIENT_IP'];
        } else if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ipAddresses = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $ipAddress = trim($ipAddresses[0]);
        } else if (isset($_SERVER['REMOTE_ADDR'])) {
            $ipAddress = $_SERVER['REMOTE_ADDR'];
        } else {
            $ipAddress = 'UNKNOWN';
        }
        // إضافة فلترة أساسية
        return filter_var($ipAddress, FILTER_VALIDATE_IP) ?: 'INVALID_IP';
    }

    /**
     * تنظيف المدخلات (يفضل استخدام مكتبة مخصصة أو فلترة حسب السياق)
     */
    public function sanitizeInput($data, bool $encode = true) {
        if (is_array($data)) {
            return array_map([$this, 'sanitizeInput'], $data, array_fill(0, count($data), $encode));
        }
        
        $data = trim((string)$data);
        
        // إزالة magic quotes إذا كانت مفعلة (قديمة)
        // if (get_magic_quotes_gpc()) { $data = stripslashes($data); }
        
        if ($encode) {
            $data = htmlspecialchars($data, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        }
        
        // يمكن إضافة تنظيف إضافي هنا (مثل إزالة رموز التحكم)
        
        return $data;
    }

    public function verifyCsrfToken(string $token): bool {
        if (empty($token) || empty($_SESSION[CSRF_TOKEN_NAME])) {
            $this->logSecurityEvent('CSRF_MISSING_TOKEN', 'محاولة إرسال نموذج بدون رمز CSRF');
            return false;
        }

        // استخدام hash_equals للحماية من هجمات التوقيت
        if (!hash_equals($_SESSION[CSRF_TOKEN_NAME], $token)) {
            $this->logSecurityEvent('CSRF_INVALID_TOKEN', 'رمز CSRF غير صحيح');
            // لا تسجل الرمز المرسل في السجل
            return false;
        }
        
        // (اختياري) إزالة الرمز بعد استخدامه لمنع إعادة الإرسال
        // unset($_SESSION[CSRF_TOKEN_NAME]);

        return true;
    }

    public function generateCsrfToken(): string {
        // تجديد الرمز إذا لم يكن موجودًا أو بناءً على منطق معين
        if (empty($_SESSION[CSRF_TOKEN_NAME])) {
             $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
        }
        return $_SESSION[CSRF_TOKEN_NAME];
    }

    public function getCsrfToken(): string {
        return $this->generateCsrfToken(); // التأكد من وجوده دائمًا
    }

    public function csrfField(): string {
        $token = $this->getCsrfToken();
        return '<input type="hidden" name="' . CSRF_TOKEN_NAME . '" value="' . htmlspecialchars($token, ENT_QUOTES) . '">';
    }

    public function checkRateLimit(string $key, int $maxRequests = 10, int $timeWindow = 60): bool {
        $currentTime = time();
        $identifier = $key . '_' . $this->user_ip;
        
        $rateLimits = $_SESSION['rate_limits'] ?? [];
        $rateLimit = $rateLimits[$identifier] ?? ['count' => 0, 'window_start' => $currentTime];
        
        if (($currentTime - $rateLimit['window_start']) > $timeWindow) {
            $rateLimit = ['count' => 0, 'window_start' => $currentTime];
        }
        
        $rateLimit['count']++;
        $_SESSION['rate_limits'][$identifier] = $rateLimit; // تحديث الجلسة
        
        if ($rateLimit['count'] > $maxRequests) {
            $this->logSecurityEvent('RATE_LIMIT_EXCEEDED', 'تجاوز معدل الطلبات: ' . $key);
            return false;
        }
        
        return true;
    }

    public function logSecurityEvent(string $type, string $message, string $severity = 'متوسط', array $data = []): void {
        $event = [
            'time' => date('Y-m-d H:i:s'),
            'type' => $type,
            'ip' => $this->user_ip,
            'session_id' => $this->session_id,
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'غير معروف',
            'message' => $message,
            'severity' => $severity,
            'url' => $_SERVER['REQUEST_URI'] ?? '',
            'data' => $data // كن حذرًا بشأن تسجيل بيانات حساسة هنا
        ];
        
        // استخدام Logger إذا كان متاحًا
        /*
        if ($this->logger) {
            $level = match(strtolower($severity)) {
                'high', 'عالي' => \Psr\Log\LogLevel::CRITICAL,
                'medium', 'متوسط' => \Psr\Log\LogLevel::WARNING,
                default => \Psr\Log\LogLevel::INFO,
            };
            $this->logger->log($level, $message, $event); 
        } else { ... }
        */
        
        // تسجيل الحدث في ملف السجل (كحل بديل)
        try {
            $logEntry = json_encode($event, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . "\n";
            // التأكد من أن المجلد قابل للكتابة
            if (is_writable(dirname($this->log_file))) {
                 file_put_contents($this->log_file, $logEntry, FILE_APPEND | LOCK_EX);
            } else {
                 error_log("Security Log Error: Directory not writable: " . dirname($this->log_file));
            }
        } catch (\Throwable $e) {
            error_log("Security Log Error: Failed to write to log file: " . $e->getMessage());
        }
        
        // تخزين الأحداث الأخيرة في الجلسة (اختياري)
        $securityEvents = $_SESSION['security_events'] ?? [];
        array_unshift($securityEvents, $event);
        $_SESSION['security_events'] = array_slice($securityEvents, 0, 10); // الاحتفاظ بآخر 10
    }

    private function logPageVisit(): void {
        $currentPage = $_SERVER['REQUEST_URI'] ?? '';
        $previousPage = $_SESSION['previous_page'] ?? '';
        
        if ($currentPage !== $previousPage) {
            // لا تسجل كل زيارة كحدث أمني، قد يكون هذا مفرطًا
            // $this->logSecurityEvent('PAGE_VIEW', 'زيارة صفحة: ' . $currentPage, 'منخفض');
            $_SESSION['previous_page'] = $currentPage;
        }
        
        $_SESSION['LAST_ACTIVITY'] = time();
    }

    public function checkSessionExpiry(int $sessionTimeout): bool {
        $currentTime = time();
        if ($this->last_activity > 0 && ($currentTime - $this->last_activity) > $sessionTimeout) {
            $this->logSecurityEvent('SESSION_EXPIRED', 'انتهت صلاحية الجلسة بعد ' . $sessionTimeout . ' ثانية من عدم النشاط');
            $this->resetSession('expired');
            return true;
        }
        return false;
    }

    public function resetSession(string $reason = 'manual'): void {
        $securityEvents = $_SESSION['security_events'] ?? []; // حفظ السجل
        session_unset();
        session_destroy(); // تدمير بيانات الجلسة القديمة
        // بدء جلسة جديدة بمعرف جديد
        session_start([
             'cookie_httponly' => 1,
             'cookie_secure' => filter_var(getenv('SESSION_SECURE_COOKIE'), FILTER_VALIDATE_BOOLEAN) ? 1 : 0,
             'cookie_samesite' => 'Strict', // أو Lax
             'use_strict_mode' => 1,
             'gc_maxlifetime' => SESSION_LIFETIME,
             'cookie_lifetime' => 0
        ]);
        session_regenerate_id(true); // تجديد المعرف
        $this->session_id = session_id() ?: 'unknown'; // تحديث المعرف
        $_SESSION['security_events'] = $securityEvents; // استعادة السجل
        $_SESSION['LAST_ACTIVITY'] = time();
        $_SESSION['reset_reason'] = $reason; // سبب إعادة التعيين
    }

    public function checkSessionHijacking(): bool {
        if (!isset($_SESSION['USER_IP'])) {
            $_SESSION['USER_IP'] = $this->user_ip;
            return false;
        }
        
        if ($_SESSION['USER_IP'] !== $this->user_ip) {
            $this->logSecurityEvent('SESSION_HIJACKING', 'تغير عنوان IP للجلسة من ' . $_SESSION['USER_IP'] . ' إلى ' . $this->user_ip, 'عالي');
            $this->resetSession('hijacked');
            return true;
        }
        return false;
    }

    public function checkBruteForce(string $username, bool $success = false): bool {
        $key = 'login_' . strtolower($username) . '_' . $this->user_ip;
        $loginAttempts = $_SESSION['login_attempts'] ?? [];
        $attempts = $loginAttempts[$key] ?? ['count' => 0, 'first_attempt' => time(), 'last_attempt' => time()];
        
        $attempts['last_attempt'] = time();
        
        if ($success) {
            unset($_SESSION['login_attempts'][$key]); // إزالة السجل عند النجاح
            return false;
        }
        
        $attempts['count']++;
        $_SESSION['login_attempts'][$key] = $attempts; // تحديث الجلسة
        
        $this->logSecurityEvent('LOGIN_FAILURE', 'محاولة تسجيل دخول فاشلة: ' . $username, 'متوسط', ['attempts' => $attempts['count']]);
        
        // استخدام الثوابت من config.php
        if ($attempts['count'] >= MAX_LOGIN_ATTEMPTS && ($attempts['last_attempt'] - $attempts['first_attempt']) <= LOGIN_TIMEOUT) {
            $this->logSecurityEvent('BRUTE_FORCE', 'محاولة قوة غاشمة على حساب: ' . $username, 'عالي', [
                'attempts' => $attempts['count'],
                'time_frame' => ($attempts['last_attempt'] - $attempts['first_attempt']) . ' ثانية'
            ]);
            // (اختياري) حظر IP أو الحساب مؤقتًا
            // blockIP($this->user_ip, 'Brute force attempt', LOGIN_TIMEOUT * 2);
            return true;
        }
        
        // إعادة تعيين العداد إذا مرت فترة طويلة منذ المحاولة الأولى
        if (($attempts['last_attempt'] - $attempts['first_attempt']) > LOGIN_TIMEOUT) {
             $_SESSION['login_attempts'][$key] = ['count' => 1, 'first_attempt' => time(), 'last_attempt' => time()];
        }

        return false;
    }

    public function verifyPassword(string $password, string $hash): bool {
        // التأكد من أن الهاش غير فارغ وصالح
        if (empty($hash) || strlen($hash) < 20) { // طول هاش bcrypt عادة 60
            return false;
        }
        return password_verify($password, $hash);
    }

    public function hashPassword(string $password): string {
        // استخدام التكلفة من الإعدادات
        return password_hash($password, PASSWORD_BCRYPT, ['cost' => HASH_COST]);
    }

    // --- وظائف OTP وقياس قوة كلمة المرور والتشفير/فك التشفير --- 
    // (نفس الكود السابق، مع التأكد من استخدام random_bytes حيثما أمكن)
    // ... (كود generateOTP, verifyOTP, measurePasswordStrength)
    // تم إزالة encryptData/decryptData - يجب استخدام مكتبة مخصصة أو خدمة

    // ... (بقية الوظائف من security.php مثل measurePasswordStrength, generateOTP, verifyOTP)
    // يجب مراجعتها وتحديثها بنفس الطريقة

}

