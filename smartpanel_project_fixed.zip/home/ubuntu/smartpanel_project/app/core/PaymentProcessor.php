<?php
/**
 * PaymentProcessor
 * نظام معالجة المدفوعات ودعم طرق الدفع المختلفة
 */
class PaymentProcessor {
    private $db;
    private $userModel;
    private $transactionModel;
    
    /**
     * إنشاء كائن معالج المدفوعات
     */
    public function __construct($dbConnection) {
        $this->db = $dbConnection;
        $this->userModel = new UserModel();
        $this->transactionModel = new TransactionModel();
    }
    
    /**
     * بدء عملية الدفع
     * 
     * @param int $user_id معرف المستخدم
     * @param float $amount المبلغ
     * @param string $payment_method طريقة الدفع
     * @param string $description وصف المعاملة
     * @return array|bool معلومات المعاملة أو false إذا فشلت العملية
     */
    public function initializePayment($user_id, $amount, $payment_method, $description = '') {
        try {
            // التحقق من البيانات
            if (empty($user_id) || empty($amount) || empty($payment_method)) {
                return false;
            }
            
            // إنشاء معاملة بحالة معلقة
            $transaction_data = [
                'user_id' => $user_id,
                'amount' => $amount,
                'type' => 'deposit',
                'status' => 'pending',
                'description' => $description,
                'payment_method' => $payment_method
            ];
            
            $transaction_id = $this->transactionModel->createTransaction($transaction_data);
            
            if (!$transaction_id) {
                return false;
            }
            
            // توجيه المستخدم لطريقة الدفع المناسبة
            $payment_data = [
                'transaction_id' => $transaction_id,
                'payment_method' => $payment_method,
                'amount' => $amount,
                'redirect_url' => $this->getPaymentRedirectUrl($payment_method, $transaction_id, $amount)
            ];
            
            return $payment_data;
        } catch (Exception $e) {
            $this->logError('PaymentProcessor::initializePayment - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على رابط إعادة التوجيه للدفع
     * 
     * @param string $payment_method طريقة الدفع
     * @param int $transaction_id معرف المعاملة
     * @param float $amount المبلغ
     * @return string رابط إعادة التوجيه
     */
    private function getPaymentRedirectUrl($payment_method, $transaction_id, $amount) {
        $redirect_url = '';
        
        switch ($payment_method) {
            case 'paypal':
                $redirect_url = $this->initializePayPal($transaction_id, $amount);
                break;
            case 'stripe':
                $redirect_url = $this->initializeStripe($transaction_id, $amount);
                break;
            case 'bank_transfer':
                $redirect_url = BASE_URL . '/dashboard/bank_transfer/' . $transaction_id;
                break;
            default:
                $redirect_url = BASE_URL . '/dashboard/payment_methods';
        }
        
        return $redirect_url;
    }
    
    /**
     * بدء عملية الدفع عبر PayPal
     * 
     * @param int $transaction_id معرف المعاملة
     * @param float $amount المبلغ
     * @return string رابط PayPal
     */
    private function initializePayPal($transaction_id, $amount) {
        // هنا يتم التكامل مع PayPal API
        // هذا مثال بسيط، يجب استبداله بالتكامل الفعلي مع PayPal
        
        $paypal_url = "https://www.sandbox.paypal.com/cgi-bin/webscr";
        $paypal_email = PAYPAL_EMAIL;
        $return_url = BASE_URL . "/dashboard/payment_success";
        $cancel_url = BASE_URL . "/dashboard/payment_cancel";
        $notify_url = BASE_URL . "/dashboard/ipn_handler";
        
        $querystring = "?business=" . urlencode($paypal_email) . 
                       "&cmd=_xclick" . 
                       "&currency_code=" . urlencode(CURRENCY_CODE) . 
                       "&amount=" . urlencode($amount) . 
                       "&item_name=" . urlencode("إيداع رصيد") . 
                       "&item_number=" . urlencode($transaction_id) . 
                       "&return=" . urlencode($return_url) . 
                       "&cancel_return=" . urlencode($cancel_url) . 
                       "&notify_url=" . urlencode($notify_url);
        
        return $paypal_url . $querystring;
    }
    
    /**
     * بدء عملية الدفع عبر Stripe
     * 
     * @param int $transaction_id معرف المعاملة
     * @param float $amount المبلغ
     * @return string رابط Stripe
     */
    private function initializeStripe($transaction_id, $amount) {
        // هنا يتم التكامل مع Stripe API
        // هذا مثال بسيط، يجب استبداله بالتكامل الفعلي مع Stripe
        
        $stripe_url = BASE_URL . "/dashboard/stripe_payment/" . $transaction_id;
        
        return $stripe_url;
    }
    
    /**
     * التحقق من حالة الدفع
     * 
     * @param int $transaction_id معرف المعاملة
     * @return bool|string حالة الدفع أو false إذا فشلت العملية
     */
    public function checkPaymentStatus($transaction_id) {
        try {
            // جلب معلومات المعاملة
            $transaction = $this->transactionModel->getTransactionById($transaction_id);
            
            if (!$transaction) {
                return false;
            }
            
            return $transaction['status'];
        } catch (Exception $e) {
            $this->logError('PaymentProcessor::checkPaymentStatus - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * تحديث حالة الدفع
     * 
     * @param int $transaction_id معرف المعاملة
     * @param string $status الحالة الجديدة
     * @param array $payment_data بيانات الدفع الإضافية
     * @return bool نجاح أو فشل العملية
     */
    public function updatePaymentStatus($transaction_id, $status, $payment_data = []) {
        try {
            // التحقق من وجود المعاملة
            $transaction = $this->transactionModel->getTransactionById($transaction_id);
            
            if (!$transaction) {
                return false;
            }
            
            // تحديث حالة المعاملة
            $result = $this->transactionModel->updateTransactionStatus($transaction_id, $status);
            
            if (!$result) {
                return false;
            }
            
            // إذا كانت الحالة مكتملة، أضف الرصيد للمستخدم
            if ($status == 'completed' && $transaction['type'] == 'deposit') {
                $this->userModel->updateBalance($transaction['user_id'], $transaction['amount']);
                
                // إنشاء إشعار للمستخدم
                $notification = new NotificationSystem();
                $notification->createNotification(
                    $transaction['user_id'],
                    'إيداع ناجح',
                    'تم إضافة ' . formatCurrency($transaction['amount']) . ' إلى رصيدك بنجاح.',
                    'success',
                    BASE_URL . '/dashboard/transactions'
                );
            }
            
            return true;
        } catch (Exception $e) {
            $this->logError('PaymentProcessor::updatePaymentStatus - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * معالجة استرداد المبلغ
     * 
     * @param int $transaction_id معرف المعاملة
     * @param float $amount المبلغ المسترد (اختياري، استرداد كامل المبلغ إذا لم يتم تحديده)
     * @return bool نجاح أو فشل العملية
     */
    public function processRefund($transaction_id, $amount = null) {
        try {
            // التحقق من وجود المعاملة
            $transaction = $this->transactionModel->getTransactionById($transaction_id);
            
            if (!$transaction || $transaction['status'] != 'completed') {
                return false;
            }
            
            // تحديد المبلغ المسترد
            $refund_amount = ($amount !== null) ? $amount : $transaction['amount'];
            
            if ($refund_amount <= 0 || $refund_amount > $transaction['amount']) {
                return false;
            }
            
            // إنشاء معاملة استرداد
            $refund_data = [
                'user_id' => $transaction['user_id'],
                'amount' => $refund_amount,
                'type' => 'refund',
                'status' => 'completed',
                'description' => 'استرداد للمعاملة #' . $transaction_id,
                'reference_id' => $transaction_id
            ];
            
            $refund_id = $this->transactionModel->createTransaction($refund_data);
            
            if (!$refund_id) {
                return false;
            }
            
            // إنشاء إشعار للمستخدم
            $notification = new NotificationSystem();
            $notification->createNotification(
                $transaction['user_id'],
                'تم استرداد المبلغ',
                'تم استرداد مبلغ ' . formatCurrency($refund_amount) . ' بنجاح.',
                'info',
                BASE_URL . '/dashboard/transactions'
            );
            
            return true;
        } catch (Exception $e) {
            $this->logError('PaymentProcessor::processRefund - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على طرق الدفع المتاحة
     * 
     * @param bool $active جلب طرق الدفع النشطة فقط
     * @return array قائمة بطرق الدفع
     */
    public function getPaymentMethods($active = true) {
        try {
            $sql = "SELECT * FROM payment_methods";
            
            if ($active) {
                $sql .= " WHERE status = 'active'";
            }
            
            $sql .= " ORDER BY sort_order";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            $this->logError('PaymentProcessor::getPaymentMethods - ' . $e->getMessage());
            return [];
        }
    }
    
    private function logError($message) {
        // تسجيل الأخطاء في ملف آمن خارج مسار الويب
        $logMessage = sprintf("[%s] %s\n", date('Y-m-d H:i:s'), $message);
        file_put_contents('/var/log/secure_payment.log', $logMessage, FILE_APPEND | LOCK_EX);
    }
}

// تعطيل وضع التصحيح في الإنتاج
define('DEBUG_MODE', false);

// إخفاء الأخطاء
ini_set('display_errors', '0');
