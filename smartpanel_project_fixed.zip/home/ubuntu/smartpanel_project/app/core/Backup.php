<?php

namespace App\Core;

class Backup {
    private static $instance = null;
    private $backupPath;
    private $logger;
    private $maxBackups = 5;

    private function __construct() {
        $this->backupPath = __DIR__ . '/../../storage/backups/';
        if (!file_exists($this->backupPath)) {
            mkdir($this->backupPath, 0777, true);
        }
        $this->logger = Logger::getInstance();
    }

    public static function getInstance(): self {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function createDatabaseBackup(array $dbConfig): bool {
        $timestamp = date('Y-m-d_H-i-s');
        $filename = $this->backupPath . "db_backup_{$timestamp}.sql";
        
        $command = sprintf(
            "mysqldump -h %s -u %s -p%s %s > %s",
            escapeshellarg($dbConfig['host']),
            escapeshellarg($dbConfig['username']),
            escapeshellarg($dbConfig['password']),
            escapeshellarg($dbConfig['database']),
            escapeshellarg($filename)
        );

        exec($command . " 2>&1", $output, $returnCode);

        if ($returnCode === 0) {
            $this->logger->info("Database backup created successfully", ['file' => $filename]);
            $this->compressBackup($filename);
            $this->cleanOldBackups();
            return true;
        }

        $this->logger->error("Database backup failed", ['error' => implode("\n", $output)]);
        return false;
    }

    public function createFileBackup(): bool {
        $timestamp = date('Y-m-d_H-i-s');
        $filename = $this->backupPath . "files_backup_{$timestamp}.zip";
        
        $zip = new \ZipArchive();
        if ($zip->open($filename, \ZipArchive::CREATE) === true) {
            $this->addFolderToZip(__DIR__ . '/../../', $zip, '');
            $zip->close();
            
            $this->logger->info("Files backup created successfully", ['file' => $filename]);
            $this->cleanOldBackups();
            return true;
        }

        $this->logger->error("Files backup failed");
        return false;
    }

    private function addFolderToZip($folder, \ZipArchive $zip, $prefix) {
        $excludeDirs = ['.git', 'vendor', 'node_modules', 'storage/backups'];
        
        $dir = new \RecursiveDirectoryIterator($folder);
        $iterator = new \RecursiveIteratorIterator($dir);
        
        foreach ($iterator as $file) {
            if (!$file->isDir()) {
                $filePath = $file->getRealPath();
                $relativePath = $prefix . substr($filePath, strlen($folder));
                
                // Skip excluded directories
                $shouldSkip = false;
                foreach ($excludeDirs as $excludeDir) {
                    if (strpos($relativePath, $excludeDir . DIRECTORY_SEPARATOR) === 0) {
                        $shouldSkip = true;
                        break;
                    }
                }
                
                if (!$shouldSkip) {
                    $zip->addFile($filePath, $relativePath);
                }
            }
        }
    }

    private function compressBackup(string $filename): void {
        $zip = new \ZipArchive();
        $zipName = $filename . '.zip';
        
        if ($zip->open($zipName, \ZipArchive::CREATE) === true) {
            $zip->addFile($filename, basename($filename));
            $zip->close();
            unlink($filename);
        }
    }

    private function cleanOldBackups(): void {
        $files = glob($this->backupPath . '*');
        usort($files, function($a, $b) {
            return filemtime($b) - filemtime($a);
        });

        if (count($files) > $this->maxBackups) {
            for ($i = $this->maxBackups; $i < count($files); $i++) {
                unlink($files[$i]);
                $this->logger->info("Removed old backup", ['file' => $files[$i]]);
            }
        }
    }
}
