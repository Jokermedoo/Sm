<?php

namespace App\Core;

use Monolog\Logger as MonologLogger;
use Monolog\Handler\StreamHandler;
use Monolog\Handler\RotatingFileHandler;
use Monolog\Formatter\LineFormatter;

class Logger {
    private static $instance = null;
    private $logger;

    private function __construct() {
        $this->logger = new MonologLogger('SMM_Panel');
        
        // Create logs directory if it doesn't exist
        if (!file_exists(__DIR__ . '/../../logs')) {
            mkdir(__DIR__ . '/../../logs', 0777, true);
        }

        // Add daily rotating file handler
        $handler = new RotatingFileHandler(
            __DIR__ . '/../../logs/app.log',
            30, // Keep last 30 days of logs
            MonologLogger::DEBUG
        );

        // Custom format for logs
        $dateFormat = "Y-m-d H:i:s";
        $output = "[%datetime%] %channel%.%level_name%: %message% %context% %extra%\n";
        $formatter = new LineFormatter($output, $dateFormat);
        $handler->setFormatter($formatter);

        $this->logger->pushHandler($handler);
    }

    public static function getInstance(): self {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function debug($message, array $context = []): void {
        $this->logger->debug($message, $context);
    }

    public function info($message, array $context = []): void {
        $this->logger->info($message, $context);
    }

    public function warning($message, array $context = []): void {
        $this->logger->warning($message, $context);
    }

    public function error($message, array $context = []): void {
        $this->logger->error($message, $context);
    }

    public function critical($message, array $context = []): void {
        $this->logger->critical($message, $context);
    }
}
