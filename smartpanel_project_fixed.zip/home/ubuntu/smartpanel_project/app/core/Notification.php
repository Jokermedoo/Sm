<?php
namespace App\Core;

class Notification {
    private static $instance = null;
    private $logger;

    private function __construct() {
        $this->logger = Logger::getInstance();
    }

    public static function getInstance(): self {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function send(int $userId, string $title, string $message, string $type = 'info'): bool {
        try {
            $db = Database::getInstance()->getConnection();
            $stmt = $db->prepare(
                "INSERT INTO notifications (user_id, title, message, type) 
                VALUES (?, ?, ?, ?)"
            );
            
            return $stmt->execute([$userId, $title, $message, $type]);
        } catch (\Exception $e) {
            $this->logger->error("Failed to send notification", [
                'user_id' => $userId,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }

    public function getUserNotifications(int $userId, int $limit = 10): array {
        try {
            $db = Database::getInstance()->getConnection();
            $stmt = $db->prepare(
                "SELECT * FROM notifications 
                WHERE user_id = ? 
                ORDER BY created_at DESC 
                LIMIT ?"
            );
            
            $stmt->execute([$userId, $limit]);
            return $stmt->fetchAll(\PDO::FETCH_ASSOC);
        } catch (\Exception $e) {
            $this->logger->error("Failed to get notifications", [
                'user_id' => $userId,
                'error' => $e->getMessage()
            ]);
            return [];
        }
    }

    public function markAsRead(int $notificationId): bool {
        try {
            $db = Database::getInstance()->getConnection();
            $stmt = $db->prepare(
                "UPDATE notifications 
                SET is_read = 1 
                WHERE id = ?"
            );
            
            return $stmt->execute([$notificationId]);
        } catch (\Exception $e) {
            $this->logger->error("Failed to mark notification as read", [
                'notification_id' => $notificationId,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }

    public function getUnreadCount(int $userId): int {
        try {
            $db = Database::getInstance()->getConnection();
            $stmt = $db->prepare(
                "SELECT COUNT(*) FROM notifications 
                WHERE user_id = ? AND is_read = 0"
            );
            
            $stmt->execute([$userId]);
            return (int) $stmt->fetchColumn();
        } catch (\Exception $e) {
            $this->logger->error("Failed to get unread count", [
                'user_id' => $userId,
                'error' => $e->getMessage()
            ]);
            return 0;
        }
    }

    public function deleteOldNotifications(int $daysOld = 30): bool {
        try {
            $db = Database::getInstance()->getConnection();
            $stmt = $db->prepare(
                "DELETE FROM notifications 
                WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)"
            );
            
            return $stmt->execute([$daysOld]);
        } catch (\Exception $e) {
            $this->logger->error("Failed to delete old notifications", [
                'days_old' => $daysOld,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }
}
