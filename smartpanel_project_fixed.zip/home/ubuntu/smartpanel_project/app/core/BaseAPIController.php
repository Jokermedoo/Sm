<?php

class BaseAPIController {
    protected $apiModel;

    public function __construct() {
        // Ensure APIModel is available. You might need to adjust autoloading or include paths if necessary.
        if (class_exists('APIModel')) {
            $this->apiModel = new APIModel();
        } else {
            // Fallback or error handling if APIModel isn't found immediately
            // This might happen if autoloading isn't set up for the 'core' directory yet
            // or if the file needs to be explicitly required.
            // For now, we'll assume it will be available via autoloader.
            // If not, we might need to add: require_once __DIR__ . '/../models/APIModel.php';
            // However, relying on the existing autoloader in app/autoload.php is preferred.
            $this->apiModel = new APIModel(); 
        }
        
        // Set response header to JSON
        header('Content-Type: application/json');
    }

    /**
     * Validate API Key
     */
    protected function validateApiKey() {
        $api_key = isset($_REQUEST['api_key']) ? $_REQUEST['api_key'] : '';
        
        if (empty($api_key)) {
            $this->sendError('API key is required', 401);
            return false; // Explicitly return false
        }
        
        $user_id = $this->apiModel->validateApiKey($api_key);
        
        if (!$user_id) {
            $this->sendError('Invalid API key', 401);
            return false; // Explicitly return false
        }
        
        return $user_id;
    }
    
    /**
     * Send error response
     */
    protected function sendError($message, $code = 400) {
        http_response_code($code);
        echo json_encode([
            'status' => 'error',
            'message' => $message
        ]);
        exit;
    }
    
    /**
     * Send success response
     */
    protected function sendResponse($data) {
        http_response_code(200);
        echo json_encode([
            'status' => 'success',
            'data' => $data
        ]);
        exit;
    }
}