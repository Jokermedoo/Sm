<?php
/**
 * ErrorHandler.php - معالج الأخطاء المركزي للنظام
 */

class ErrorHandler {
    /**
     * تسجيل الأخطاء والاستثناءات
     */
    private static function logError($error) {
        $log_file = LOGS_PATH . '/errors_' . date('Y-m-d') . '.log';
        $timestamp = date('Y-m-d H:i:s');
        
        $log_message = sprintf(
            "[%s] %s: %s in %s on line %d\n",
            $timestamp,
            $error['type'],
            $error['message'],
            $error['file'],
            $error['line']
        );
        
        if (isset($error['trace'])) {
            $log_message .= "Stack trace:\n" . $error['trace'] . "\n";
        }
        
        error_log($log_message, 3, $log_file);
        
        // إرسال إشعار للمدير في حالة الأخطاء الخطيرة
        if (in_array($error['type'], ['Fatal Error', 'Exception'])) {
            self::notifyAdmin($error);
        }
    }
    
    /**
     * معالجة الأخطاء العادية
     */
    public static function handleError($errno, $errstr, $errfile, $errline) {
        if (!(error_reporting() & $errno)) {
            return false;
        }
        
        $error = [
            'type' => self::getErrorType($errno),
            'message' => $errstr,
            'file' => $errfile,
            'line' => $errline
        ];
        
        self::logError($error);
        
        if (DEBUG_MODE) {
            throw new ErrorException($errstr, 0, $errno, $errfile, $errline);
        } else {
            self::showErrorPage($error);
        }
        
        return true;
    }
    
    /**
     * معالجة الاستثناءات غير المعالجة
     */
    public static function handleException($exception) {
        $error = [
            'type' => get_class($exception),
            'message' => $exception->getMessage(),
            'file' => $exception->getFile(),
            'line' => $exception->getLine(),
            'trace' => $exception->getTraceAsString()
        ];
        
        self::logError($error);
        
        if (DEBUG_MODE) {
            throw $exception;
        } else {
            self::showErrorPage($error);
        }
    }
    
    /**
     * معالجة الأخطاء القاتلة
     */
    public static function handleFatalError() {
        $error = error_get_last();
        
        if ($error !== null && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
            self::handleError($error['type'], $error['message'], $error['file'], $error['line']);
        }
    }
    
    /**
     * تحويل رقم الخطأ إلى نص وصفي
     */
    private static function getErrorType($errno) {
        switch ($errno) {
            case E_ERROR:
                return 'Fatal Error';
            case E_WARNING:
                return 'Warning';
            case E_PARSE:
                return 'Parse Error';
            case E_NOTICE:
                return 'Notice';
            case E_CORE_ERROR:
                return 'Core Error';
            case E_CORE_WARNING:
                return 'Core Warning';
            case E_COMPILE_ERROR:
                return 'Compile Error';
            case E_COMPILE_WARNING:
                return 'Compile Warning';
            case E_USER_ERROR:
                return 'User Error';
            case E_USER_WARNING:
                return 'User Warning';
            case E_USER_NOTICE:
                return 'User Notice';
            case E_STRICT:
                return 'Strict Standards';
            case E_RECOVERABLE_ERROR:
                return 'Recoverable Error';
            case E_DEPRECATED:
                return 'Deprecated';
            case E_USER_DEPRECATED:
                return 'User Deprecated';
            default:
                return 'Unknown Error';
        }
    }
    
    /**
     * عرض صفحة الخطأ للمستخدم
     */
    private static function showErrorPage($error) {
        http_response_code(500);
        require_once VIEWS_PATH . '/error.php';
        exit;
    }
    
    /**
     * إرسال إشعار للمدير عن الخطأ
     */
    private static function notifyAdmin($error) {
        try {
            $subject = 'خطأ في النظام: ' . $error['type'];
            $message = sprintf(
                "حدث خطأ في النظام:\n\nالنوع: %s\nالرسالة: %s\nالملف: %s\nالسطر: %d\n\nتفاصيل الخطأ:\n%s",
                $error['type'],
                $error['message'],
                $error['file'],
                $error['line'],
                isset($error['trace']) ? $error['trace'] : 'لا يوجد تتبع للخطأ'
            );
            
            notifyAdmin($subject, $message, 'error');
        } catch (Exception $e) {
            error_log('Failed to send admin notification: ' . $e->getMessage());
        }
    }
    
    /**
     * تنظيف ملفات السجلات القديمة
     */
    public static function cleanOldLogs($days = 30) {
        $log_dir = LOGS_PATH;
        if (!is_dir($log_dir)) return;
        
        $files = glob($log_dir . '/errors_*.log');
        $now = time();
        
        foreach ($files as $file) {
            if (is_file($file)) {
                if ($now - filemtime($file) >= 60 * 60 * 24 * $days) {
                    unlink($file);
                }
            }
        }
    }
    
    /**
     * تهيئة معالج الأخطاء
     */
    public static function init() {
        // تعيين معالجات الأخطاء والاستثناءات
        set_error_handler([__CLASS__, 'handleError']);
        set_exception_handler([__CLASS__, 'handleException']);
        register_shutdown_function([__CLASS__, 'handleFatalError']);
        
        // تنظيف السجلات القديمة عند بدء التشغيل
        self::cleanOldLogs();
    }
}

// تهيئة معالج الأخطاء
ErrorHandler::init();
