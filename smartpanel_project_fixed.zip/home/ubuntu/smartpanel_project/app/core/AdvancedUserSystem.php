<?php
/**
 * نظام المستخدمين المتقدم مع تعزيزات أمنية
 */

class AdvancedUserSystem {
    private const PASSWORD_ITERATIONS = 100000;

    public function registerUser(string $name, string $email, string $password): array {
        $validation = $this->validateCredentials($email, $password);
        if (!$validation['valid']) return $validation;
        
        $encryption_key = openssl_random_pseudo_bytes(32);
        $iv = random_bytes(16);
        
        $stmt = DB::prepare("INSERT INTO users (name, email, password, encryption_key, iv) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([
            $name,
            $email,
            password_hash($password, PASSWORD_ARGON2ID),
            base64_encode($encryption_key),
            base64_encode($iv)
        ]);
        
        return ['success' => true, 'message' => 'تم إنشاء الحساب بنجاح'];
    }

    private function validateCredentials(string $email, string $password): array {
        $sanitized_email = filter_var($email, FILTER_SANITIZE_EMAIL);
        $domain = explode('@', $sanitized_email)[1] ?? '';
        
        $disposable_domains = ['tempr.email', 'mailinator.com'];
        if (in_array($domain, $disposable_domains)) {
            return ['valid' => false, 'error' => 'نوع البريد الإلكتروني غير مسموح'];
        }
        
        if (!$this->isStrongPassword($password)) {
            return [
                'valid' => false,
                'error' => 'كلمة المرور يجب تحتوي على: أحرف كبيرة وصغيرة, أرقام, رموز, 8 خانات على الأقل'
            ];
        }
        
        return ['valid' => true];
    }

    private function isStrongPassword(string $password): bool {
        return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/', $password);
    }

    public function login(string $email, string $password, ?string $otp = null): array {
        $stmt = DB::prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if (!$user || !password_verify($password, $user['password'])) {
            return ['success' => false, 'error' => 'بيانات الاعتماد غير صحيحة'];
        }
        
        if ($user['2fa_enabled'] && !$this->verify2FA($user, $otp)) {
            return ['success' => false, 'error' => 'رمز التحقق غير صحيح'];
        }
        
        $this->createSecureSession($user);
        
        AuditLogger::log($user['id'], 'user_login', [
            'ip' => $_SERVER['REMOTE_ADDR'],
            'device' => $_SERVER['HTTP_USER_AGENT']
        ]);
        
        return ['success' => true, 'redirect' => '/dashboard'];
    }

    private function createSecureSession(array $user): void {
        session_start();
        session_regenerate_id(true);
        
        $_SESSION = [
            'user_id' => $user['id'],
            'user_name' => $user['name'],
            'auth_token' => bin2hex(random_bytes(32)),
            'created_at' => time(),
            'last_activity' => time()
        ];
        
        $_SESSION['fingerprint'] = $this->createClientFingerprint();
    }

    private function createClientFingerprint(): string {
        return hash('sha256', 
            $_SERVER['HTTP_USER_AGENT'] . 
            $_SERVER['REMOTE_ADDR'] . 
            $_SERVER['HTTP_ACCEPT_LANGUAGE']
        );
    }
}
