<?php
/**
 * SessionManager.php - إدارة جلسات المستخدمين
 */

class SessionManager {
    /**
     * بدء الجلسة مع إعدادات أمان محسنة
     */
    public static function start() {
        if (session_status() === PHP_SESSION_NONE) {
            // تعيين إعدادات الجلسة
            ini_set('session.cookie_httponly', 1);
            ini_set('session.use_only_cookies', 1);
            ini_set('session.cookie_secure', isset($_SERVER['HTTPS']));
            ini_set('session.cookie_samesite', 'Strict');
            ini_set('session.gc_maxlifetime', SESSION_LIFETIME);
            
            // تعيين اسم الجلسة
            session_name(SESSION_NAME);
            
            // بدء الجلسة
            session_start();
            
            // تجديد معرف الجلسة دورياً
            if (!isset($_SESSION['last_regeneration']) || 
                time() - $_SESSION['last_regeneration'] > 300) {
                session_regenerate_id(true);
                $_SESSION['last_regeneration'] = time();
            }
        }
    }
    
    /**
     * إنهاء الجلسة
     */
    public static function destroy() {
        // حذف متغيرات الجلسة
        $_SESSION = [];
        
        // حذف ملف تعريف الجلسة
        if (isset($_COOKIE[session_name()])) {
            setcookie(session_name(), '', time() - 3600, '/');
        }
        
        // إنهاء الجلسة
        session_destroy();
    }
    
    /**
     * تخزين بيانات في الجلسة
     */
    public static function set($key, $value) {
        $_SESSION[$key] = $value;
    }
    
    /**
     * استرجاع بيانات من الجلسة
     */
    public static function get($key, $default = null) {
        return $_SESSION[$key] ?? $default;
    }
    
    /**
     * حذف بيانات من الجلسة
     */
    public static function remove($key) {
        unset($_SESSION[$key]);
    }
    
    /**
     * التحقق من وجود بيانات في الجلسة
     */
    public static function has($key) {
        return isset($_SESSION[$key]);
    }
    
    /**
     * تخزين رسالة تنبيه مؤقتة
     */
    public static function setFlash($type, $message) {
        $_SESSION['flash'] = [
            'type' => $type,
            'message' => $message
        ];
    }
    
    /**
     * استرجاع رسالة التنبيه المؤقتة
     */
    public static function getFlash() {
        if (isset($_SESSION['flash'])) {
            $flash = $_SESSION['flash'];
            unset($_SESSION['flash']);
            return $flash;
        }
        return null;
    }
    
    /**
     * تحديث وقت آخر نشاط للمستخدم
     */
    public static function updateLastActivity() {
        $_SESSION['last_activity'] = time();
    }
    
    /**
     * التحقق من انتهاء صلاحية الجلسة
     */
    public static function isExpired() {
        return isset($_SESSION['last_activity']) && 
               (time() - $_SESSION['last_activity'] > SESSION_LIFETIME);
    }
    
    /**
     * إعادة تعيين مهلة الجلسة
     */
    public static function resetTimeout() {
        self::updateLastActivity();
    }
    
    /**
     * تخزين بيانات المستخدم في الجلسة
     */
    public static function setUserData($user) {
        self::set('user_id', $user['id']);
        self::set('username', $user['username']);
        self::set('email', $user['email']);
        self::set('role', $user['role']);
        self::set('last_login', time());
    }
    
    /**
     * حذف بيانات المستخدم من الجلسة
     */
    public static function clearUserData() {
        self::remove('user_id');
        self::remove('username');
        self::remove('email');
        self::remove('role');
        self::remove('last_login');
    }
    
    /**
     * التحقق من نشاط المستخدم وتجديد الجلسة إذا لزم الأمر
     */
    public static function checkActivityAndRenew() {
        if (!isset($_SESSION['last_activity'])) {
            $_SESSION['last_activity'] = time();
            return true;
        }
        
        $inactive = time() - $_SESSION['last_activity'];
        
        if ($inactive >= SESSION_LIFETIME) {
            self::destroy();
            return false;
        }
        
        if ($inactive >= (SESSION_LIFETIME / 2)) {
            self::regenerateId();
        }
        
        $_SESSION['last_activity'] = time();
        return true;
    }
    
    /**
     * تدمير الجلسة
     */
    public static function end() {
        self::destroy();
    }
}
