<?php
/**
 * NotificationSystem
 * نظام إدارة الإشعارات الداخلية والخارجية
 */
class NotificationSystem {
    private $db;
    
    /**
     * إنشاء نظام الإشعارات
     */
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * إنشاء إشعار جديد للمستخدم
     * 
     * @param int $user_id معرف المستخدم
     * @param string $title عنوان الإشعار
     * @param string $message نص الإشعار
     * @param string $type نوع الإشعار (success, info, warning, error)
     * @param string $link رابط الإشعار (اختياري)
     * @return int|bool معرف الإشعار أو false في حالة الفشل
     */
    public function createNotification($user_id, $title, $message, $type = 'info', $link = '') {
        try {
            $sql = "INSERT INTO notifications (user_id, title, message, type, link, is_read, created_at) 
                    VALUES (:user_id, :title, :message, :type, :link, 0, :created_at)";
            
            $params = [
                ':user_id' => $user_id,
                ':title' => $title,
                ':message' => $message,
                ':type' => $type,
                ':link' => $link,
                ':created_at' => date('Y-m-d H:i:s')
            ];
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            
            $notification_id = $this->db->lastInsertId();
            
            // إرسال إشعار عبر البريد الإلكتروني إذا كان مهماً
            if ($type == 'error' || $type == 'warning') {
                $this->sendEmailNotification($user_id, $title, $message);
            }
            
            return $notification_id;
        } catch (Exception $e) {
            logError('NotificationSystem::createNotification - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على إشعارات المستخدم
     * 
     * @param int $user_id معرف المستخدم
     * @param int $limit عدد الإشعارات المطلوبة
     * @param bool $unread_only جلب الإشعارات غير المقروءة فقط
     * @return array قائمة الإشعارات
     */
    public function getUserNotifications($user_id, $limit = 10, $unread_only = false) {
        try {
            $sql = "SELECT * FROM notifications WHERE user_id = :user_id";
            
            if ($unread_only) {
                $sql .= " AND is_read = 0";
            }
            
            $sql .= " ORDER BY created_at DESC LIMIT :limit";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':user_id', $user_id);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('NotificationSystem::getUserNotifications - ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * الحصول على الإشعارات غير المقروءة
     * 
     * @param int $user_id معرف المستخدم
     * @param int $limit عدد الإشعارات المطلوبة
     * @return array قائمة الإشعارات غير المقروءة
     */
    public function getUnreadNotifications($user_id, $limit = 10) {
        return $this->getUserNotifications($user_id, $limit, true);
    }
    
    /**
     * تعليم إشعار كمقروء
     * 
     * @param int $notification_id معرف الإشعار
     * @param int $user_id معرف المستخدم (للتحقق من ملكية الإشعار)
     * @return bool نجاح أو فشل العملية
     */
    public function markAsRead($notification_id, $user_id) {
        try {
            $sql = "UPDATE notifications SET is_read = 1 WHERE id = :id AND user_id = :user_id";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':id', $notification_id);
            $stmt->bindValue(':user_id', $user_id);
            $stmt->execute();
            
            return $stmt->rowCount() > 0;
        } catch (Exception $e) {
            logError('NotificationSystem::markAsRead - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * تعليم جميع إشعارات المستخدم كمقروءة
     * 
     * @param int $user_id معرف المستخدم
     * @return bool نجاح أو فشل العملية
     */
    public function markAllAsRead($user_id) {
        try {
            $sql = "UPDATE notifications SET is_read = 1 WHERE user_id = :user_id AND is_read = 0";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':user_id', $user_id);
            $stmt->execute();
            
            return true;
        } catch (Exception $e) {
            logError('NotificationSystem::markAllAsRead - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * عدد الإشعارات غير المقروءة
     * 
     * @param int $user_id معرف المستخدم
     * @return int عدد الإشعارات غير المقروءة
     */
    public function countUnreadNotifications($user_id) {
        try {
            $sql = "SELECT COUNT(*) FROM notifications WHERE user_id = :user_id AND is_read = 0";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':user_id', $user_id);
            $stmt->execute();
            
            return $stmt->fetchColumn();
        } catch (Exception $e) {
            logError('NotificationSystem::countUnreadNotifications - ' . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * حذف إشعار
     * 
     * @param int $notification_id معرف الإشعار
     * @param int $user_id معرف المستخدم (للتحقق من ملكية الإشعار)
     * @return bool نجاح أو فشل العملية
     */
    public function deleteNotification($notification_id, $user_id) {
        try {
            $sql = "DELETE FROM notifications WHERE id = :id AND user_id = :user_id";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':id', $notification_id);
            $stmt->bindValue(':user_id', $user_id);
            $stmt->execute();
            
            return $stmt->rowCount() > 0;
        } catch (Exception $e) {
            logError('NotificationSystem::deleteNotification - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * حذف جميع إشعارات المستخدم
     * 
     * @param int $user_id معرف المستخدم
     * @return bool نجاح أو فشل العملية
     */
    public function deleteAllNotifications($user_id) {
        try {
            $sql = "DELETE FROM notifications WHERE user_id = :user_id";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':user_id', $user_id);
            $stmt->execute();
            
            return true;
        } catch (Exception $e) {
            logError('NotificationSystem::deleteAllNotifications - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * إرسال إشعار عبر البريد الإلكتروني
     * 
     * @param int $user_id معرف المستخدم
     * @param string $subject عنوان الرسالة
     * @param string $message نص الرسالة
     * @return bool نجاح أو فشل العملية
     */
    public function sendEmailNotification($user_id, $subject, $message) {
        try {
            // جلب معلومات المستخدم
            $sql = "SELECT email, username FROM users WHERE id = :user_id";
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':user_id', $user_id);
            $stmt->execute();
            
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$user) {
                return false;
            }
            
            // جلب إعدادات البريد الإلكتروني
            $settings = $this->getEmailSettings();
            
            // إعداد محتوى البريد الإلكتروني
            $to = $user['email'];
            $headers = "From: {$settings['from_name']} <{$settings['from_email']}>\r\n";
            $headers .= "Reply-To: {$settings['from_email']}\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
            
            // إنشاء قالب البريد الإلكتروني
            $email_content = $this->getEmailTemplate($user['username'], $subject, $message);
            
            // إرسال البريد الإلكتروني
            return mail($to, $subject, $email_content, $headers);
        } catch (Exception $e) {
            logError('NotificationSystem::sendEmailNotification - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * إرسال إشعار عبر الرسائل القصيرة
     * 
     * @param int $user_id معرف المستخدم
     * @param string $message نص الرسالة
     * @return bool نجاح أو فشل العملية
     */
    public function sendSmsNotification($user_id, $message) {
        try {
            // جلب معلومات المستخدم
            $sql = "SELECT phone FROM users WHERE id = :user_id";
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':user_id', $user_id);
            $stmt->execute();
            
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$user || empty($user['phone'])) {
                return false;
            }
            
            // جلب إعدادات الرسائل القصيرة
            $settings = $this->getSmsSettings();
            
            // هنا يمكن إضافة التكامل مع خدمات الرسائل القصيرة مثل Twilio أو Nexmo
            // هذا مثال باستخدام واجهة برمجة تطبيقات خيالية
            
            /*
            $sms_api_url = $settings['api_url'];
            $sms_api_key = $settings['api_key'];
            
            $params = [
                'api_key' => $sms_api_key,
                'to' => $user['phone'],
                'message' => $message
            ];
            
            // إرسال الطلب إلى واجهة برمجة التطبيقات
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $sms_api_url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($ch);
            curl_close($ch);
            
            return $response && json_decode($response)->success;
            */
            
            // في الوقت الحالي، نعود بنجاح دون إرسال رسالة فعلية
            return true;
        } catch (Exception $e) {
            logError('NotificationSystem::sendSmsNotification - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * إرسال إشعار جماعي لمجموعة من المستخدمين
     * 
     * @param array $user_ids مصفوفة معرفات المستخدمين
     * @param string $title عنوان الإشعار
     * @param string $message نص الإشعار
     * @param string $type نوع الإشعار
     * @param string $link الرابط (اختياري)
     * @return array نتائج الإرسال
     */
    public function sendBulkNotifications($user_ids, $title, $message, $type = 'info', $link = '') {
        $results = ['success' => [], 'failed' => []];
        $timestamp = date('Y-m-d H:i:s');
        
        try {
            $this->db->beginTransaction();
            
            $sql = "INSERT INTO notifications (user_id, title, message, type, link, is_read, created_at) 
                    VALUES (:user_id, :title, :message, :type, :link, 0, :created_at)";
            
            $stmt = $this->db->prepare($sql);
            
            foreach ($user_ids as $user_id) {
                try {
                    $stmt->execute([
                        'user_id' => $user_id,
                        'title' => $title,
                        'message' => $message,
                        'type' => $type,
                        'link' => $link,
                        'created_at' => $timestamp
                    ]);
                    $results['success'][] = $user_id;
                } catch (\Exception $e) {
                    $results['failed'][] = $user_id;
                }
            }
            
            $this->db->commit();
            return $results;
        } catch (\Exception $e) {
            $this->db->rollback();
            throw $e;
        }
    }
    
    /**
     * التحقق من وجود إشعارات جديدة
     */
