<?php

namespace App\Core;

class Cache {
    private static $instance = null;
    private $cachePath;
    private $defaultTTL = 3600; // 1 hour default TTL

    private function __construct() {
        $this->cachePath = __DIR__ . '/../../storage/cache/';
        if (!file_exists($this->cachePath)) {
            mkdir($this->cachePath, 0777, true);
        }
    }

    public static function getInstance(): self {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function set(string $key, $value, int $ttl = null): bool {
        $ttl = $ttl ?? $this->defaultTTL;
        $cacheData = [
            'expiry' => time() + $ttl,
            'value' => $value
        ];

        return file_put_contents(
            $this->getCacheFilePath($key),
            serialize($cacheData)
        ) !== false;
    }

    public function get(string $key, $default = null) {
        $cacheFile = $this->getCacheFilePath($key);
        
        if (!file_exists($cacheFile)) {
            return $default;
        }

        $cacheData = unserialize(file_get_contents($cacheFile));
        
        if ($cacheData['expiry'] < time()) {
            $this->delete($key);
            return $default;
        }

        return $cacheData['value'];
    }

    public function delete(string $key): bool {
        $cacheFile = $this->getCacheFilePath($key);
        if (file_exists($cacheFile)) {
            return unlink($cacheFile);
        }
        return true;
    }

    public function clear(): bool {
        $files = glob($this->cachePath . '*');
        foreach ($files as $file) {
            if (is_file($file)) {
                unlink($file);
            }
        }
        return true;
    }

    private function getCacheFilePath(string $key): string {
        return $this->cachePath . md5($key) . '.cache';
    }
}
