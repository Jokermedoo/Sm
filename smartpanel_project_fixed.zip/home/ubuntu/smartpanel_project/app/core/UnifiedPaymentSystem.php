<?php
/**
 * نظام الدفع السعودي الموحد
 */

class UnifiedPaymentSystem {
    private const GATEWAYS = [
        'stc_pay' => 'STCPayProcessor',
        'mada' => 'MadaProcessor',
        'apple_pay' => 'ApplePayProcessor'
    ];

    public function processPayment(float $amount, array $paymentMethod): array {
        $this->validatePaymentAmount($amount);
        
        if (!$this->passAMLchecks($paymentMethod)) {
            throw new Exception('تم إيقاف المعاملة لعدم توافق معايير مكافحة غسيل الأموال');
        }
        
        $processor = $this->getProcessor($paymentMethod['gateway']);
        $response = $processor->charge($amount, $paymentMethod['token']);
        
        if (!$this->isShariaCompliant($response)) {
            throw new Exception('المعاملة لا تتوافق مع الشريعة الإسلامية');
        }
        
        return $response;
    }
    
    private function validatePaymentAmount(float $amount): void {
        $min = 5; // 5 ريال
        $max = 10000; // 10,000 ريال
        
        if ($amount < $min || $amount > $max) {
            throw new Exception("المبلغ يجب يكون بين {$min} و {$max} ريال سعودي");
        }
    }
    
    private function passAMLchecks(array $paymentMethod): bool {
        $riskScore = 0;
        
        if (AMLService::isStolenCard($paymentMethod['token'])) {
            $riskScore += 95;
        }
        
        $tz = new DateTimeZone('Asia/Riyadh');
        $now = new DateTime('now', $tz);
        $hour = (int) $now->format('H');
        
        if ($hour < 8 || $hour > 21) $riskScore += 30;
        
        return $riskScore < 80;
    }

    private function isShariaCompliant(array $transaction): bool {
        // التحقق من توافق المعاملة مع الشريعة الإسلامية
        return !isset($transaction['interest']) || $transaction['interest'] == 0;
    }

    private function getProcessor(string $gateway) {
        if (!isset(self::GATEWAYS[$gateway])) {
            throw new Exception('بوابة الدفع غير مدعومة');
        }

        $processorClass = self::GATEWAYS[$gateway];
        return new $processorClass();
    }
}
