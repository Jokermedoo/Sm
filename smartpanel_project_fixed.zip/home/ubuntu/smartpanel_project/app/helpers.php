<?php
/**
 * helpers.php - دوال مساعدة إضافية للنظام
 */

/**
 * تنسيق المبلغ المالي
 */
function formatCurrency($amount, $currency = null) {
    $currency = $currency ?? SITE_CURRENCY;
    return number_format($amount, 2) . ' ' . $currency;
}

/**
 * تنسيق التاريخ والوقت
 */
function formatDateTime($datetime, $format = 'Y-m-d H:i:s') {
    return date($format, strtotime($datetime));
}

/**
 * تنظيف وتأمين النص المدخل
 */
function sanitizeInput($input) {
    if (is_array($input)) {
        return array_map('sanitizeInput', $input);
    }
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * توليد رمز عشوائي
 */
function generateRandomCode($length = 32) {
    return bin2hex(random_bytes($length / 2));
}

/**
 * التحقق من صحة البريد الإلكتروني
 */
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * تحويل حجم الملف إلى صيغة مقروءة
 */
function formatFileSize($bytes) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    return round($bytes / pow(1024, $pow), 2) . ' ' . $units[$pow];
}

/**
 * إنشاء اختصار للنص
 */
function truncateText($text, $length = 100, $ending = '...') {
    if (mb_strlen($text) <= $length) {
        return $text;
    }
    return mb_substr($text, 0, $length - mb_strlen($ending)) . $ending;
}

/**
 * التحقق من صلاحية كلمة المرور
 */
function isValidPassword($password) {
    // على الأقل 8 أحرف
    if (strlen($password) < 8) return false;
    
    // يجب أن تحتوي على حرف كبير
    if (!preg_match('/[A-Z]/', $password)) return false;
    
    // يجب أن تحتوي على حرف صغير
    if (!preg_match('/[a-z]/', $password)) return false;
    
    // يجب أن تحتوي على رقم
    if (!preg_match('/[0-9]/', $password)) return false;
    
    // يجب أن تحتوي على رمز خاص
    if (!preg_match('/[^A-Za-z0-9]/', $password)) return false;
    
    return true;
}

/**
 * تحويل النص إلى slug صالح للروابط
 */
function slugify($text) {
    // تحويل إلى أحرف صغيرة
    $text = mb_strtolower($text);
    
    // استبدال الحروف العربية بما يقابلها
    $arabic_map = [
        'أ' => 'a', 'ب' => 'b', 'ت' => 't', 'ث' => 'th',
        'ج' => 'j', 'ح' => 'h', 'خ' => 'kh', 'د' => 'd',
        'ذ' => 'th', 'ر' => 'r', 'ز' => 'z', 'س' => 's',
        'ش' => 'sh', 'ص' => 's', 'ض' => 'd', 'ط' => 't',
        'ظ' => 'th', 'ع' => 'a', 'غ' => 'gh', 'ف' => 'f',
        'ق' => 'q', 'ك' => 'k', 'ل' => 'l', 'م' => 'm',
        'ن' => 'n', 'ه' => 'h', 'و' => 'w', 'ي' => 'y',
        'ة' => 'a', 'ى' => 'a', 'ء' => 'a'
    ];
    
    $text = str_replace(array_keys($arabic_map), array_values($arabic_map), $text);
    
    // استبدال المسافات بشرطات
    $text = preg_replace('/\s+/', '-', $text);
    
    // إزالة الأحرف غير المسموح بها
    $text = preg_replace('/[^a-z0-9\-]/', '', $text);
    
    // إزالة الشرطات المتكررة
    $text = preg_replace('/-+/', '-', $text);
    
    // إزالة الشرطات من البداية والنهاية
    return trim($text, '-');
}

/**
 * التحقق من وجود تحديثات للنظام
 */
function checkForUpdates() {
    $current_version = '1.0.0';
    $update_url = 'https://api.townmedia.com/updates/check';
    
    try {
        $ch = curl_init($update_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'User-Agent: TownMedia-SMM/' . $current_version,
            'Accept: application/json'
        ]);
        
        $response = curl_exec($ch);
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($status === 200) {
            $data = json_decode($response, true);
            if ($data && version_compare($data['latest_version'], $current_version, '>')) {
                return [
                    'has_update' => true,
                    'current_version' => $current_version,
                    'latest_version' => $data['latest_version'],
                    'update_url' => $data['download_url'],
                    'release_notes' => $data['release_notes']
                ];
            }
        }
    } catch (Exception $e) {
        logError('Update check failed: ' . $e->getMessage());
    }
    
    return ['has_update' => false];
}

/**
 * تحويل التاريخ إلى صيغة نصية مناسبة
 */
function timeAgo($datetime) {
    $time = strtotime($datetime);
    $now = time();
    $diff = $now - $time;
    
    if ($diff < 60) {
        return 'منذ لحظات';
    } elseif ($diff < 3600) {
        $minutes = floor($diff / 60);
        return 'منذ ' . $minutes . ' دقيقة';
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return 'منذ ' . $hours . ' ساعة';
    } elseif ($diff < 604800) {
        $days = floor($diff / 86400);
        return 'منذ ' . $days . ' يوم';
    } else {
        return date('Y-m-d', $time);
    }
}

/**
 * توليد رابط تأكيد البريد الإلكتروني
 */
function generateEmailVerificationLink($user_id, $token) {
    return BASE_URL . '/verify-email?id=' . $user_id . '&token=' . $token;
}

/**
 * إرسال إشعار للمدير
 */
function notifyAdmin($subject, $message, $type = 'info') {
    try {
        $notification = new NotificationSystem();
        return $notification->sendAdminNotification($subject, $message, $type);
    } catch (Exception $e) {
        logError('Admin notification failed: ' . $e->getMessage());
        return false;
    }
}
