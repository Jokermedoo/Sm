<?php
/**
 * Settings Model
 * يتعامل مع جميع عمليات قاعدة البيانات المتعلقة بإعدادات النظام
 */
class SettingsModel {
    private $db;
    private $settings_cache = [];
    
    /**
     * إنشاء كائن النموذج
     */
    public function __construct() {
        $this->db = Database::getInstance();
        $this->loadAllSettings();
    }
    
    /**
     * تحميل جميع الإعدادات إلى ذاكرة التخزين المؤقت
     */
    private function loadAllSettings() {
        try {
            $sql = "SELECT * FROM settings";
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            
            $settings = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($settings as $setting) {
                $this->settings_cache[$setting['key']] = $setting['value'];
            }
        } catch (Exception $e) {
            logError('SettingsModel::loadAllSettings - ' . $e->getMessage());
        }
    }
    
    /**
     * الحصول على قيمة إعداد
     * 
     * @param string $key مفتاح الإعداد
     * @param mixed $default القيمة الافتراضية إذا لم يكن الإعداد موجودًا
     * @return mixed قيمة الإعداد
     */
    public function get($key, $default = null) {
        // التحقق من وجود الإعداد في ذاكرة التخزين المؤقت
        if (isset($this->settings_cache[$key])) {
            return $this->settings_cache[$key];
        }
        
        try {
            $sql = "SELECT value FROM settings WHERE `key` = :key";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':key', $key);
            $stmt->execute();
            
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($result) {
                // تخزين في ذاكرة التخزين المؤقت
                $this->settings_cache[$key] = $result['value'];
                return $result['value'];
            }
            
            return $default;
        } catch (Exception $e) {
            logError('SettingsModel::get - ' . $e->getMessage());
            return $default;
        }
    }
    
    /**
     * تعيين قيمة إعداد
     * 
     * @param string $key مفتاح الإعداد
     * @param mixed $value قيمة الإعداد
     * @param string $group مجموعة الإعداد (اختياري)
     * @return bool نجاح أو فشل العملية
     */
    public function set($key, $value, $group = 'general') {
        try {
            // التحقق من وجود الإعداد
            $sql = "SELECT COUNT(*) FROM settings WHERE `key` = :key";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':key', $key);
            $stmt->execute();
            
            $exists = $stmt->fetchColumn() > 0;
            
            if ($exists) {
                // تحديث الإعداد الموجود
                $sql = "UPDATE settings SET `value` = :value, updated_at = NOW() WHERE `key` = :key";
                $stmt = $this->db->prepare($sql);
                $stmt->bindParam(':key', $key);
                $stmt->bindParam(':value', $value);
                $stmt->execute();
            } else {
                // إنشاء إعداد جديد
                $sql = "INSERT INTO settings (`key`, `value`, `group`, created_at) VALUES (:key, :value, :group, NOW())";
                $stmt = $this->db->prepare($sql);
                $stmt->bindParam(':key', $key);
                $stmt->bindParam(':value', $value);
                $stmt->bindParam(':group', $group);
                $stmt->execute();
            }
            
            // تحديث ذاكرة التخزين المؤقت
            $this->settings_cache[$key] = $value;
            
            return true;
        } catch (Exception $e) {
            logError('SettingsModel::set - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * حذف إعداد
     * 
     * @param string $key مفتاح الإعداد
     * @return bool نجاح أو فشل العملية
     */
    public function delete($key) {
        try {
            $sql = "DELETE FROM settings WHERE `key` = :key";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':key', $key);
            $stmt->execute();
            
            // حذف من ذاكرة التخزين المؤقت
            if (isset($this->settings_cache[$key])) {
                unset($this->settings_cache[$key]);
            }
            
            return true;
        } catch (Exception $e) {
            logError('SettingsModel::delete - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على جميع الإعدادات
     * 
     * @param string $group مجموعة الإعدادات (اختياري لتصفية النتائج)
     * @return array قائمة الإعدادات
     */
    public function getAll($group = null) {
        try {
            $sql = "SELECT * FROM settings";
            $params = [];
            
            if ($group) {
                $sql .= " WHERE `group` = :group";
                $params[':group'] = $group;
            }
            
            $sql .= " ORDER BY `key`";
            
            $stmt = $this->db->prepare($sql);
            
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('SettingsModel::getAll - ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * الحصول على قائمة مجموعات الإعدادات
     * 
     * @return array قائمة المجموعات
     */
    public function getGroups() {
        try {
            $sql = "SELECT DISTINCT `group` FROM settings ORDER BY `group`";
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_COLUMN);
        } catch (Exception $e) {
            logError('SettingsModel::getGroups - ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * تحديث مجموعة من الإعدادات دفعة واحدة
     * 
     * @param array $settings مصفوفة من الإعدادات (المفتاح => القيمة)
     * @param string $group مجموعة الإعدادات
     * @return bool نجاح أو فشل العملية
     */
    public function updateBatch($settings, $group = 'general') {
        try {
            $this->db->beginTransaction();
            
            foreach ($settings as $key => $value) {
                $this->set($key, $value, $group);
            }
            
            $this->db->commit();
            
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            logError('SettingsModel::updateBatch - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على إعدادات النظام الأساسية
     * 
     * @return array إعدادات النظام
     */
    public function getSystemSettings() {
        $settings = [];
        
        // إعدادات الموقع
        $settings['site_name'] = $this->get('site_name', 'Town Media');
        $settings['site_description'] = $this->get('site_description', 'منصة خدمات التواصل الاجتماعي');
        $settings['site_keywords'] = $this->get('site_keywords', 'smm, social media, marketing');
        $settings['site_logo'] = $this->get('site_logo', 'assets/img/logo.png');
        $settings['site_favicon'] = $this->get('site_favicon', 'assets/img/favicon.ico');
        $settings['site_currency'] = $this->get('site_currency', 'USD');
        $settings['site_currency_symbol'] = $this->get('site_currency_symbol', '$');
        $settings['site_email'] = $this->get('site_email', 'info@townmedia.com');
        $settings['site_phone'] = $this->get('site_phone', '+1234567890');
        $settings['site_address'] = $this->get('site_address', '');
        
        // إعدادات الطلبات
        $settings['min_order_amount'] = $this->get('min_order_amount', '1');
        $settings['max_order_amount'] = $this->get('max_order_amount', '1000');
        $settings['enable_api'] = $this->get('enable_api', '1');
        $settings['enable_service_list'] = $this->get('enable_service_list', '1');
        $settings['maintenance_mode'] = $this->get('maintenance_mode', '0');
        
        // إعدادات الأمان
        $settings['recaptcha_site_key'] = $this->get('recaptcha_site_key', '');
        $settings['recaptcha_secret_key'] = $this->get('recaptcha_secret_key', '');
        $settings['enable_recaptcha'] = $this->get('enable_recaptcha', '0');
        
        // إعدادات البريد الإلكتروني
        $settings['mail_driver'] = $this->get('mail_driver', 'smtp');
        $settings['mail_host'] = $this->get('mail_host', 'smtp.gmail.com');
        $settings['mail_port'] = $this->get('mail_port', '587');
        $settings['mail_username'] = $this->get('mail_username', '');
        $settings['mail_password'] = $this->get('mail_password', '');
        $settings['mail_encryption'] = $this->get('mail_encryption', 'tls');
        $settings['mail_from_address'] = $this->get('mail_from_address', 'noreply@townmedia.com');
        $settings['mail_from_name'] = $this->get('mail_from_name', 'Town Media');
        
        // إعدادات وسائل التواصل الاجتماعي
        $settings['social_facebook'] = $this->get('social_facebook', '');
        $settings['social_twitter'] = $this->get('social_twitter', '');
        $settings['social_instagram'] = $this->get('social_instagram', '');
        $settings['social_linkedin'] = $this->get('social_linkedin', '');
        $settings['social_youtube'] = $this->get('social_youtube', '');
        
        // إعدادات الإشعارات
        $settings['notification_new_order'] = $this->get('notification_new_order', '1');
        $settings['notification_new_user'] = $this->get('notification_new_user', '1');
        $settings['notification_new_payment'] = $this->get('notification_new_payment', '1');
        $settings['notification_new_ticket'] = $this->get('notification_new_ticket', '1');
        
        // إعدادات التصميم
        $settings['theme_color'] = $this->get('theme_color', '#2563EB');
        $settings['theme_layout'] = $this->get('theme_layout', 'default');
        $settings['enable_rtl'] = $this->get('enable_rtl', '1');
        
        return $settings;
    }
    
    /**
     * التحقق من وضع الصيانة
     * 
     * @return bool هل الموقع في وضع الصيانة
     */
    public function isMaintenanceMode() {
        return $this->get('maintenance_mode', '0') == '1';
    }
    
    /**
     * التحقق من تفعيل reCAPTCHA
     * 
     * @return bool هل reCAPTCHA مفعلة
     */
    public function isRecaptchaEnabled() {
        return $this->get('enable_recaptcha', '0') == '1' && 
               !empty($this->get('recaptcha_site_key')) && 
               !empty($this->get('recaptcha_secret_key'));
    }
    
    /**
     * التحقق من تفعيل API
     * 
     * @return bool هل API مفعلة
     */
    public function isAPIEnabled() {
        return $this->get('enable_api', '1') == '1';
    }
    
    /**
     * الحصول على إعدادات البريد الإلكتروني
     * 
     * @return array إعدادات البريد الإلكتروني
     */
    public function getMailSettings() {
        $settings = [];
        $settings['driver'] = $this->get('mail_driver', 'smtp');
        $settings['host'] = $this->get('mail_host', 'smtp.gmail.com');
        $settings['port'] = $this->get('mail_port', '587');
        $settings['username'] = $this->get('mail_username', '');
        $settings['password'] = $this->get('mail_password', '');
        $settings['encryption'] = $this->get('mail_encryption', 'tls');
        $settings['from_address'] = $this->get('mail_from_address', 'noreply@townmedia.com');
        $settings['from_name'] = $this->get('mail_from_name', 'Town Media');
        
        return $settings;
    }
    
    /**
     * تعيين الإعدادات الافتراضية
     * 
     * @return bool نجاح أو فشل العملية
     */
    public function setDefaultSettings() {
        try {
            $this->db->beginTransaction();
            
            // إعدادات الموقع
            $this->set('site_name', 'Town Media', 'site');
            $this->set('site_description', 'منصة خدمات التواصل الاجتماعي', 'site');
            $this->set('site_keywords', 'smm, social media, marketing', 'site');
            $this->set('site_logo', 'assets/img/logo.png', 'site');
            $this->set('site_favicon', 'assets/img/favicon.ico', 'site');
            $this->set('site_currency', 'USD', 'site');
            $this->set('site_currency_symbol', '$', 'site');
            $this->set('site_email', 'info@townmedia.com', 'site');
            $this->set('site_phone', '+1234567890', 'site');
            
            // إعدادات الطلبات
            $this->set('min_order_amount', '1', 'order');
            $this->set('max_order_amount', '1000', 'order');
            $this->set('enable_api', '1', 'order');
            $this->set('enable_service_list', '1', 'order');
            $this->set('maintenance_mode', '0', 'order');
            
            // إعدادات الأمان
            $this->set('recaptcha_site_key', '', 'security');
            $this->set('recaptcha_secret_key', '', 'security');
            $this->set('enable_recaptcha', '0', 'security');
            
            // إعدادات البريد الإلكتروني
            $this->set('mail_driver', 'smtp', 'mail');
            $this->set('mail_host', 'smtp.gmail.com', 'mail');
            $this->set('mail_port', '587', 'mail');
            $this->set('mail_username', '', 'mail');
            $this->set('mail_password', '', 'mail');
            $this->set('mail_encryption', 'tls', 'mail');
            $this->set('mail_from_address', 'noreply@townmedia.com', 'mail');
            $this->set('mail_from_name', 'Town Media', 'mail');
            
            // إعدادات وسائل التواصل الاجتماعي
            $this->set('social_facebook', '', 'social');
            $this->set('social_twitter', '', 'social');
            $this->set('social_instagram', '', 'social');
            $this->set('social_linkedin', '', 'social');
            $this->set('social_youtube', '', 'social');
            
            // إعدادات الإشعارات
            $this->set('notification_new_order', '1', 'notification');
            $this->set('notification_new_user', '1', 'notification');
            $this->set('notification_new_payment', '1', 'notification');
            $this->set('notification_new_ticket', '1', 'notification');
            
            // إعدادات التصميم
            $this->set('theme_color', '#2563EB', 'theme');
            $this->set('theme_layout', 'default', 'theme');
            $this->set('enable_rtl', '1', 'theme');
            
            $this->db->commit();
            
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            logError('SettingsModel::setDefaultSettings - ' . $e->getMessage());
            return false;
        }
    }
}
