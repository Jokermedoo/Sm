<?php
/**
 * Service Model
 * يتعامل مع جميع عمليات قاعدة البيانات المتعلقة بالخدمات
 */
class ServiceModel {
    private $db;
    
    /**
     * إنشاء كائن النموذج
     */
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * الحصول على جميع الفئات
     * 
     * @param bool $active جلب الفئات النشطة فقط
     * @return array قائمة الفئات
     */
    public function getAllCategories($active = true) {
        try {
            $sql = "SELECT * FROM categories";
            
            if ($active) {
                $sql .= " WHERE status = 'active'";
            }
            
            $sql .= " ORDER BY sort_order";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('ServiceModel::getAllCategories - ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * الحصول على الخدمات حسب الفئة
     * 
     * @param int $category_id معرف الفئة
     * @param bool $active جلب الخدمات النشطة فقط
     * @return array قائمة الخدمات
     */
    public function getServicesByCategory($category_id, $active = true) {
        try {
            $sql = "SELECT * FROM services WHERE category_id = :category_id";
            
            if ($active) {
                $sql .= " AND status = 'active'";
            }
            
            $sql .= " ORDER BY sort_order";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':category_id', $category_id);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('ServiceModel::getServicesByCategory - ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * الحصول على معلومات خدمة معينة
     * 
     * @param int $service_id معرف الخدمة
     * @return array|bool بيانات الخدمة أو false إذا لم تكن موجودة
     */
    public function getServiceById($service_id) {
        try {
            $sql = "SELECT s.*, c.name as category_name 
                    FROM services s 
                    JOIN categories c ON s.category_id = c.id 
                    WHERE s.id = :service_id";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':service_id', $service_id);
            $stmt->execute();
            
            $service = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$service) {
                return false;
            }
            
            return $service;
        } catch (Exception $e) {
            logError('ServiceModel::getServiceById - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * حساب سعر الطلب بناءً على الخدمة والكمية
     * 
     * @param int $service_id معرف الخدمة
     * @param int $quantity الكمية المطلوبة
     * @return float|bool السعر المحسوب أو false إذا فشل
     */
    public function calculatePrice($service_id, $quantity) {
        try {
            $service = $this->getServiceById($service_id);
            
            if (!$service) {
                return false;
            }
            
            // التحقق من الحد الأدنى والأقصى للكمية
            if ($quantity < $service['min'] || $quantity > $service['max']) {
                return false;
            }
            
            // حساب السعر
            $price = ($service['price'] / 1000) * $quantity;
            
            // التعامل مع الخصم حسب الكمية إذا كان متاحًا
            if (!empty($service['volume_discounts'])) {
                $discounts = json_decode($service['volume_discounts'], true);
                
                if (is_array($discounts)) {
                    foreach ($discounts as $discount) {
                        if ($quantity >= $discount['quantity']) {
                            $price = ($discount['price'] / 1000) * $quantity;
                            break;
                        }
                    }
                }
            }
            
            return round($price, 2);
        } catch (Exception $e) {
            logError('ServiceModel::calculatePrice - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على الخدمات المميزة للصفحة الرئيسية
     * 
     * @param int $limit عدد الخدمات المطلوبة
     * @return array قائمة الخدمات المميزة
     */
    public function getFeaturedServices($limit = 6) {
        try {
            $sql = "SELECT s.*, c.name as category_name 
                    FROM services s 
                    JOIN categories c ON s.category_id = c.id 
                    WHERE s.status = 'active' AND s.featured = 1 
                    ORDER BY s.sort_order 
                    LIMIT :limit";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('ServiceModel::getFeaturedServices - ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * البحث عن الخدمات
     * 
     * @param string $keyword كلمة البحث
     * @param int $limit عدد النتائج
     * @return array نتائج البحث
     */
    public function searchServices($keyword, $limit = 10) {
        try {
            $sql = "SELECT s.*, c.name as category_name 
                    FROM services s 
                    JOIN categories c ON s.category_id = c.id 
                    WHERE s.status = 'active' 
                    AND (s.name LIKE :keyword OR s.description LIKE :keyword OR c.name LIKE :keyword) 
                    ORDER BY s.sort_order 
                    LIMIT :limit";
            
            $keyword = '%' . $keyword . '%';
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':keyword', $keyword);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('ServiceModel::searchServices - ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * الحصول على خدمات مشابهة
     * 
     * @param int $service_id معرف الخدمة الحالية
     * @param int $limit عدد الخدمات المطلوبة
     * @return array قائمة الخدمات المشابهة
     */
    public function getSimilarServices($service_id, $limit = 4) {
        try {
            // الحصول على الخدمة الحالية لمعرفة الفئة
            $current_service = $this->getServiceById($service_id);
            
            if (!$current_service) {
                return [];
            }
            
            $category_id = $current_service['category_id'];
            
            $sql = "SELECT s.*, c.name as category_name 
                    FROM services s 
                    JOIN categories c ON s.category_id = c.id 
                    WHERE s.status = 'active' 
                    AND s.category_id = :category_id 
                    AND s.id != :service_id 
                    ORDER BY s.sort_order 
                    LIMIT :limit";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':category_id', $category_id);
            $stmt->bindParam(':service_id', $service_id);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('ServiceModel::getSimilarServices - ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * تحديث عدد الطلبات لخدمة معينة
     * 
     * @param int $service_id معرف الخدمة
     * @return bool نجاح أو فشل العملية
     */
    public function incrementServiceOrderCount($service_id) {
        try {
            $sql = "UPDATE services SET orders_count = orders_count + 1 WHERE id = :service_id";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':service_id', $service_id);
            
            return $stmt->execute();
        } catch (Exception $e) {
            logError('ServiceModel::incrementServiceOrderCount - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على الخدمات الأكثر طلبًا
     * 
     * @param int $limit عدد الخدمات المطلوبة
     * @return array قائمة الخدمات الأكثر طلبًا
     */
    public function getMostOrderedServices($limit = 5) {
        try {
            $sql = "SELECT s.*, c.name as category_name 
                    FROM services s 
                    JOIN categories c ON s.category_id = c.id 
                    WHERE s.status = 'active' 
                    ORDER BY s.orders_count DESC 
                    LIMIT :limit";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('ServiceModel::getMostOrderedServices - ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * التحقق من صلاحية خدمة للطلب
     * 
     * @param int $service_id معرف الخدمة
     * @param int $quantity الكمية المطلوبة
     * @return bool|array صالح أم لا مع رسالة الخطأ إن وجدت
     */
    public function validateServiceOrder($service_id, $quantity) {
        try {
            $service = $this->getServiceById($service_id);
            
            if (!$service) {
                return [
                    'valid' => false,
                    'message' => 'الخدمة غير موجودة'
                ];
            }
            
            if ($service['status'] != 'active') {
                return [
                    'valid' => false,
                    'message' => 'الخدمة غير متاحة حاليًا'
                ];
            }
            
            if ($quantity < $service['min']) {
                return [
                    'valid' => false,
                    'message' => 'الكمية أقل من الحد الأدنى (' . $service['min'] . ')'
                ];
            }
            
            if ($quantity > $service['max']) {
                return [
                    'valid' => false,
                    'message' => 'الكمية أكبر من الحد الأقصى (' . $service['max'] . ')'
                ];
            }
            
            return [
                'valid' => true,
                'message' => ''
            ];
        } catch (Exception $e) {
            logError('ServiceModel::validateServiceOrder - ' . $e->getMessage());
            return [
                'valid' => false,
                'message' => 'حدث خطأ أثناء التحقق من الخدمة'
            ];
        }
    }
}
