<?php
/**
 * نموذج الدفع - Payment Model
 * يتعامل مع جميع عمليات الدفع ومعالجتها وتتبعها
 * 
 * تم تحسينه بتاريخ: 30-05-2025
 * - دعم بوابات دفع متعددة
 * - تحسين الأمان وتشفير البيانات
 * - آلية إعادة المحاولة للتعامل مع أخطاء الاتصال
 * - تحسين تسجيل العمليات وتتبعها
 */

// Constants for Payment Statuses
define('PAYMENT_STATUS_PENDING', 'pending');       // بانتظار المعالجة
define('PAYMENT_STATUS_PROCESSING', 'processing'); // قيد المعالجة
define('PAYMENT_STATUS_COMPLETED', 'completed');   // مكتمل
define('PAYMENT_STATUS_FAILED', 'failed');         // فشل
define('PAYMENT_STATUS_CANCELLED', 'cancelled');   // ملغي
define('PAYMENT_STATUS_REFUNDED', 'refunded');     // مسترد

class Payment {
    private $db;
    private $config;
    private $logger;
    private $user_id;
    private $gateway;
    
    /**
     * Constructor
     */
    public function __construct($user_id = null) {
        $this->db = new Database();
        $this->user_id = $user_id;
        
        // تحميل ملف التكوين
        $config_path = ROOT_PATH . '/smm-store/app/config/payment_config.php';
        if (file_exists($config_path)) {
            $this->config = require $config_path;
        } else {
            // استخدام التكوين الافتراضي إذا لم يكن ملف التكوين موجودًا
            $this->config = [
                'general' => [
                    'environment' => 'sandbox',
                    'currency' => 'SAR',
                    'default_gateway' => 'mada',
                    'transaction_expiry' => 900,
                    'max_retry_attempts' => 3,
                    'test_mode' => true,
                ],
                'gateways' => [
                    'mada' => [
                        'name' => 'بطاقة مدى',
                        'enabled' => true,
                        'fee' => 0.02,
                        'min_amount' => 5,
                        'is_islamic' => true,
                    ],
                ],
            ];
        }
        
        // تسجيل الحدث للعمليات
        $this->initLogger();
    }
    
    /**
     * تهيئة مسجل الأحداث
     */
    private function initLogger() {
        if (!is_dir(ROOT_PATH . '/logs')) {
            mkdir(ROOT_PATH . '/logs', 0755, true);
        }
        
        $this->logger = new Logger();
    }
    
    /**
     * تعيين بوابة الدفع
     */
    public function setGateway($gateway) {
        if (isset($this->config['gateways'][$gateway]) && $this->config['gateways'][$gateway]['enabled']) {
            $this->gateway = $gateway;
            return true;
        }
        
        // استخدام البوابة الافتراضية إذا كانت البوابة المحددة غير صالحة
        $this->gateway = $this->config['general']['default_gateway'];
        return false;
    }
    
    /**
     * الحصول على بوابات الدفع المتاحة
     */
    public function getAvailableGateways($islamic_only = false) {
        $available = [];
        
        foreach ($this->config['gateways'] as $code => $gateway) {
            if (!$gateway['enabled']) {
                continue;
            }
            
            // فلترة البوابات حسب التوافق مع الشريعة الإسلامية إذا كان مطلوبًا
            if ($islamic_only && !$gateway['is_islamic']) {
                continue;
            }
            
            $available[$code] = [
                'code' => $code,
                'name' => $gateway['name'],
                'fee' => $gateway['fee'],
                'min_amount' => $gateway['min_amount'],
                'icon' => $gateway['icon'] ?? 'default-payment-icon.png',
                'priority' => $gateway['priority'] ?? 0,
                'is_islamic' => $gateway['is_islamic'] ?? false,
            ];
        }
        
        // ترتيب البوابات حسب الأولوية
        usort($available, function($a, $b) {
            return $b['priority'] - $a['priority'];
        });
        
        return $available;
    }
    
    /**
     * إنشاء معاملة دفع جديدة
     */
    public function createTransaction($amount, $description, $reference = null) {
        if (!$this->user_id) {
            return ['success' => false, 'message' => 'يجب تسجيل الدخول لإجراء عملية دفع'];
        }
        
        if (!$this->gateway) {
            $this->setGateway($this->config['general']['default_gateway']);
        }
        
        // التحقق من المبلغ الأدنى
        if ($amount < $this->config['gateways'][$this->gateway]['min_amount']) {
            return [
                'success' => false, 
                'message' => 'المبلغ أقل من الحد الأدنى المطلوب: ' . $this->config['gateways'][$this->gateway]['min_amount'] . ' ' . $this->config['general']['currency']
            ];
        }
        
        // حساب الرسوم
        $fee = $this->calculateFee($amount);
        $total = $amount + $fee;
        
        // إنشاء رمز المعاملة
        $transaction_id = $this->generateTransactionId();
        
        // إنشاء رمز الأمان
        $security_token = $this->generateSecurityToken();
        
        // تعيين وقت انتهاء الصلاحية
        $expiry_time = time() + $this->config['general']['transaction_expiry'];
        
        // إنشاء سجل المعاملة في قاعدة البيانات
        $query = "INSERT INTO payment_transactions (
                user_id, transaction_id, gateway, amount, fee, total_amount, 
                description, status, reference_id, security_token, expiry_time, created_at
            ) VALUES (
                :user_id, :transaction_id, :gateway, :amount, :fee, :total_amount,
                :description, :status, :reference_id, :security_token, :expiry_time, NOW()
            )";
        
        $params = [
            ':user_id' => $this->user_id,
            ':transaction_id' => $transaction_id,
            ':gateway' => $this->gateway,
            ':amount' => $amount,
            ':fee' => $fee,
            ':total_amount' => $total,
            ':description' => $description,
            ':status' => PAYMENT_STATUS_PENDING,
            ':reference_id' => $reference ?: 'REF-' . time(),
            ':security_token' => password_hash($security_token, PASSWORD_DEFAULT),
            ':expiry_time' => date('Y-m-d H:i:s', $expiry_time)
        ];
        
        try {
            $this->db->query($query);
            $this->db->bindMultiple($params);
            $this->db->execute();
            
            // تسجيل بدء المعاملة
            $this->logger->info('PAYMENT_TRANSACTION_CREATED', [
                'transaction_id' => $transaction_id,
                'user_id' => $this->user_id,
                'gateway' => $this->gateway,
                'amount' => $amount,
                'total' => $total
            ]);
            
            return [
                'success' => true,
                'transaction_id' => $transaction_id,
                'security_token' => $security_token,
                'amount' => $amount,
                'fee' => $fee,
                'total' => $total,
                'gateway' => $this->gateway,
                'gateway_name' => $this->config['gateways'][$this->gateway]['name'],
                'expiry_time' => $expiry_time,
                'currency' => $this->config['general']['currency']
            ];
        } catch (Exception $e) {
            $this->logger->error('PAYMENT_TRANSACTION_CREATE_FAILED', [
                'error' => $e->getMessage(),
                'user_id' => $this->user_id
            ]);
            
            return ['success' => false, 'message' => 'فشل في إنشاء المعاملة: ' . $e->getMessage()];
        }
    }
