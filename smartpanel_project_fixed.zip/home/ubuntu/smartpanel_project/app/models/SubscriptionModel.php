<?php
/**
 * SubscriptionModel
 * نموذج إدارة الاشتراكات
 */
class SubscriptionModel {
    private $db;
    
    /**
     * إنشاء نموذج الاشتراكات
     */
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * إنشاء اشتراك جديد
     * 
     * @param array $data بيانات الاشتراك
     * @return int|bool معرف الاشتراك أو false في حالة الفشل
     */
    public function createSubscription($data) {
        try {
            $sql = "INSERT INTO subscriptions (user_id, service_id, link, quantity, posts, status, start_date, expiry_date) 
                    VALUES (:user_id, :service_id, :link, :quantity, :posts, :status, :start_date, :expiry_date)";
            
            $start_date = date('Y-m-d H:i:s');
            $expiry_date = date('Y-m-d H:i:s', strtotime('+30 days'));
            
            $params = [
                ':user_id' => $data['user_id'],
                ':service_id' => $data['service_id'],
                ':link' => $data['link'],
                ':quantity' => $data['quantity'],
                ':posts' => $data['posts'] ?? 0,
                ':status' => $data['status'] ?? 'active',
                ':start_date' => $data['start_date'] ?? $start_date,
                ':expiry_date' => $data['expiry_date'] ?? $expiry_date
            ];
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            
            return $this->db->lastInsertId();
        } catch (Exception $e) {
            logError('SubscriptionModel::createSubscription - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * تحديث حالة الاشتراك
     * 
     * @param int $subscription_id معرف الاشتراك
     * @param string $status الحالة الجديدة
     * @return bool نجاح أو فشل التحديث
     */
    public function updateSubscriptionStatus($subscription_id, $status) {
        try {
            $sql = "UPDATE subscriptions SET status = :status WHERE id = :id";
            
            $params = [
                ':id' => $subscription_id,
                ':status' => $status
            ];
            
            $stmt = $this->db->prepare($sql);
            return $stmt->execute($params);
        } catch (Exception $e) {
            logError('SubscriptionModel::updateSubscriptionStatus - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * تحديث معلومات الاشتراك
     * 
     * @param int $subscription_id معرف الاشتراك
     * @param array $data البيانات المراد تحديثها
     * @return bool نجاح أو فشل التحديث
     */
    public function updateSubscription($subscription_id, $data) {
        try {
            $updates = [];
            $params = [':id' => $subscription_id];
            
            foreach ($data as $key => $value) {
                if ($key != 'id') {
                    $updates[] = "$key = :$key";
                    $params[":$key"] = $value;
                }
            }
            
            if (empty($updates)) {
                return false;
            }
            
            $sql = "UPDATE subscriptions SET " . implode(', ', $updates) . " WHERE id = :id";
            
            $stmt = $this->db->prepare($sql);
            return $stmt->execute($params);
        } catch (Exception $e) {
            logError('SubscriptionModel::updateSubscription - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * حذف اشتراك
     * 
     * @param int $subscription_id معرف الاشتراك
     * @return bool نجاح أو فشل الحذف
     */
    public function deleteSubscription($subscription_id) {
        try {
            $sql = "DELETE FROM subscriptions WHERE id = :id";
            
            $params = [':id' => $subscription_id];
            
            $stmt = $this->db->prepare($sql);
            return $stmt->execute($params);
        } catch (Exception $e) {
            logError('SubscriptionModel::deleteSubscription - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على اشتراك بواسطة المعرف
     * 
     * @param int $subscription_id معرف الاشتراك
     * @return array|bool بيانات الاشتراك أو false إذا لم يتم العثور عليه
     */
    public function getSubscriptionById($subscription_id) {
        try {
            $sql = "SELECT s.*, srv.name as service_name, srv.category_id, c.name as category_name 
                    FROM subscriptions s
                    LEFT JOIN services srv ON s.service_id = srv.id
                    LEFT JOIN categories c ON srv.category_id = c.id
                    WHERE s.id = :id";
            
            $params = [':id' => $subscription_id];
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('SubscriptionModel::getSubscriptionById - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على اشتراكات المستخدم
     * 
     * @param int $user_id معرف المستخدم
     * @param int $offset موضع البداية
     * @param int $limit عدد العناصر
     * @param string $status حالة الاشتراكات (اختياري)
     * @return array قائمة الاشتراكات
     */
    public function getUserSubscriptions($user_id, $offset = 0, $limit = 10, $status = null) {
        try {
            $sql = "SELECT s.*, srv.name as service_name, srv.category_id, c.name as category_name 
                    FROM subscriptions s
                    LEFT JOIN services srv ON s.service_id = srv.id
                    LEFT JOIN categories c ON srv.category_id = c.id
                    WHERE s.user_id = :user_id";
            
            $params = [':user_id' => $user_id];
            
            if ($status) {
                $sql .= " AND s.status = :status";
                $params[':status'] = $status;
            }
            
            $sql .= " ORDER BY s.id DESC LIMIT :offset, :limit";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            
            foreach ($params as $key => $value) {
                if ($key != ':offset' && $key != ':limit') {
                    $stmt->bindValue($key, $value);
                }
            }
            
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('SubscriptionModel::getUserSubscriptions - ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * عدد اشتراكات المستخدم
     * 
     * @param int $user_id معرف المستخدم
     * @param string $status حالة الاشتراكات (اختياري)
     * @return int عدد الاشتراكات
     */
    public function countSubscriptionsByUser($user_id, $status = null) {
        try {
            $sql = "SELECT COUNT(*) FROM subscriptions WHERE user_id = :user_id";
            
            $params = [':user_id' => $user_id];
            
            if ($status) {
                $sql .= " AND status = :status";
                $params[':status'] = $status;
            }
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            
            return $stmt->fetchColumn();
        } catch (Exception $e) {
            logError('SubscriptionModel::countSubscriptionsByUser - ' . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * الحصول على جميع الاشتراكات
     * 
     * @param int $offset موضع البداية
     * @param int $limit عدد العناصر
     * @param string $status حالة الاشتراكات (اختياري)
     * @return array قائمة الاشتراكات
     */
    public function getAllSubscriptions($offset = 0, $limit = 10, $status = null) {
        try {
            $sql = "SELECT s.*, srv.name as service_name, u.username, u.email
                    FROM subscriptions s
                    LEFT JOIN services srv ON s.service_id = srv.id
                    LEFT JOIN users u ON s.user_id = u.id";
            
            $params = [];
            
            if ($status) {
                $sql .= " WHERE s.status = :status";
                $params[':status'] = $status;
            }
            
            $sql .= " ORDER BY s.id DESC LIMIT :offset, :limit";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            
            foreach ($params as $key => $value) {
                if ($key != ':offset' && $key != ':limit') {
                    $stmt->bindValue($key, $value);
                }
            }
            
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('SubscriptionModel::getAllSubscriptions - ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * إجمالي عدد الاشتراكات
     * 
     * @param string $status حالة الاشتراكات (اختياري)
     * @return int عدد الاشتراكات
     */
    public function countAllSubscriptions($status = null) {
        try {
            $sql = "SELECT COUNT(*) FROM subscriptions";
            
            $params = [];
            
            if ($status) {
                $sql .= " WHERE status = :status";
                $params[':status'] = $status;
            }
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            
            return $stmt->fetchColumn();
        } catch (Exception $e) {
            logError('SubscriptionModel::countAllSubscriptions - ' . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * تحديث الاشتراكات منتهية الصلاحية
     * 
     * @return int عدد الاشتراكات التي تم تحديثها
     */
    public function updateExpiredSubscriptions() {
        try {
            $now = date('Y-m-d H:i:s');
            
            $sql = "UPDATE subscriptions SET status = 'expired' WHERE status = 'active' AND expiry_date < :now";
            
            $params = [':now' => $now];
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            
            return $stmt->rowCount();
        } catch (Exception $e) {
            logError('SubscriptionModel::updateExpiredSubscriptions - ' . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * إنشاء طلب جديد لاشتراك
     * 
     * @param int $subscription_id معرف الاشتراك
     * @return int|bool معرف الطلب أو false في حالة الفشل
     */
    public function createOrderFromSubscription($subscription_id) {
        try {
            // جلب معلومات الاشتراك
            $subscription = $this->getSubscriptionById($subscription_id);
            
            if (!$subscription || $subscription['status'] != 'active') {
                return false;
            }
            
            // إنشاء طلب جديد
            $orderModel = new OrderModel();
            
            $order_data = [
                'user_id' => $subscription['user_id'],
                'service_id' => $subscription['service_id'],
                'link' => $subscription['link'],
                'quantity' => $subscription['quantity'],
                'status' => 'pending',
                'subscription_id' => $subscription_id
            ];
            
            // حساب السعر
            $serviceModel = new ServiceModel();
            $price = $serviceModel->calculatePrice($subscription['service_id'], $subscription['quantity']);
            
            if ($price !== false) {
                $order_data['price'] = $price;
            }
            
            // إنشاء الطلب
            $order_id = $orderModel->createOrder($order_data);
            
            if ($order_id) {
                // تحديث عدد المنشورات في الاشتراك
                $this->updateSubscription($subscription_id, ['posts' => $subscription['posts'] + 1]);
            }
            
            return $order_id;
        } catch (Exception $e) {
            logError('SubscriptionModel::createOrderFromSubscription - ' . $e->getMessage());
            return false;
        }
    }
}
