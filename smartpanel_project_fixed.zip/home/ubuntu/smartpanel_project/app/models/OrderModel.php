<?php
/**
 * Order Model
 * يتعامل مع جميع عمليات قاعدة البيانات المتعلقة بالطلبات
 */
class OrderModel {
    private $db;
    
    /**
     * إنشاء كائن النموذج
     */
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * إنشاء طلب جديد
     * 
     * @param array $data بيانات الطلب
     * @return int|bool معرف الطلب إذا نجح أو false إذا فشل
     */
    public function createOrder($data) {
        try {
            // التحقق من وجود رصيد كافٍ
            $user_id = $_SESSION['user_id'];
            $balance = $this->getUserBalance($user_id);
            
            if ($balance < $data['price']) {
                return false;
            }
            
            // البدء بمعاملة قاعدة البيانات
            $this->db->beginTransaction();
            
            // إنشاء الطلب
            $sql = "INSERT INTO orders (user_id, service_id, link, quantity, comments, price, status, created_at) 
                    VALUES (:user_id, :service_id, :link, :quantity, :comments, :price, 'pending', NOW())";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindParam(':service_id', $data['service_id']);
            $stmt->bindParam(':link', $data['link']);
            $stmt->bindParam(':quantity', $data['quantity']);
            $stmt->bindParam(':comments', $data['comments']);
            $stmt->bindParam(':price', $data['price']);
            $stmt->execute();
            
            $order_id = $this->db->lastInsertId();
            
            // تحديث رصيد المستخدم
            $this->updateUserBalance($user_id, -$data['price']);
            
            // إنشاء معاملة
            $this->createTransaction([
                'user_id' => $user_id,
                'type' => 'order',
                'amount' => $data['price'],
                'description' => 'طلب #' . $order_id,
                'status' => 'completed',
                'order_id' => $order_id
            ]);
            
            // إتمام المعاملة
            $this->db->commit();
            
            return $order_id;
        } catch (Exception $e) {
            // التراجع عن المعاملة في حالة حدوث خطأ
            $this->db->rollBack();
            logError('OrderModel::createOrder - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على تفاصيل الطلب بواسطة المعرف
     * 
     * @param int $order_id معرف الطلب
     * @return array|bool بيانات الطلب أو false إذا لم يتم العثور عليه
     */
    public function getOrderById($order_id) {
        try {
            $sql = "SELECT o.*, s.name as service_name, s.category 
                    FROM orders o 
                    JOIN services s ON o.service_id = s.id 
                    WHERE o.id = :order_id";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':order_id', $order_id);
            $stmt->execute();
            
            $order = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$order) {
                return false;
            }
            
            return $order;
        } catch (Exception $e) {
            logError('OrderModel::getOrderById - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على قائمة طلبات المستخدم
     * 
     * @param int $user_id معرف المستخدم
     * @param array $filters مرشحات للبحث
     * @param int $page رقم الصفحة
     * @param int $limit عدد العناصر في الصفحة
     * @return array قائمة الطلبات
     */
    public function getUserOrders($user_id, $filters = [], $page = 1, $limit = 10) {
        try {
            $offset = ($page - 1) * $limit;
            
            // بناء استعلام SQL
            $sql = "SELECT o.*, s.name as service_name, s.category 
                    FROM orders o 
                    JOIN services s ON o.service_id = s.id 
                    WHERE o.user_id = :user_id";
            
            $params = [':user_id' => $user_id];
            
            // إضافة المرشحات
            if (!empty($filters['status'])) {
                $sql .= " AND o.status = :status";
                $params[':status'] = $filters['status'];
            }
            
            if (!empty($filters['order_id'])) {
                $sql .= " AND o.id = :order_id";
                $params[':order_id'] = $filters['order_id'];
            }
            
            if (!empty($filters['link'])) {
                $sql .= " AND o.link LIKE :link";
                $params[':link'] = '%' . $filters['link'] . '%';
            }
            
            // إضافة الترتيب والحد
            $sql .= " ORDER BY o.created_at DESC LIMIT :limit OFFSET :offset";
            
            $stmt = $this->db->prepare($sql);
            
            // ربط المعلمات
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('OrderModel::getUserOrders - ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * الحصول على العدد الإجمالي لطلبات المستخدم (للترقيم)
     * 
     * @param int $user_id معرف المستخدم
     * @param array $filters مرشحات للبحث
     * @return int العدد الإجمالي للطلبات
     */
    public function countUserOrders($user_id, $filters = []) {
        try {
            // بناء استعلام SQL
            $sql = "SELECT COUNT(*) as total FROM orders WHERE user_id = :user_id";
            
            $params = [':user_id' => $user_id];
            
            // إضافة المرشحات
            if (!empty($filters['status'])) {
                $sql .= " AND status = :status";
                $params[':status'] = $filters['status'];
            }
            
            if (!empty($filters['order_id'])) {
                $sql .= " AND id = :order_id";
                $params[':order_id'] = $filters['order_id'];
            }
            
            if (!empty($filters['link'])) {
                $sql .= " AND link LIKE :link";
                $params[':link'] = '%' . $filters['link'] . '%';
            }
            
            $stmt = $this->db->prepare($sql);
            
            // ربط المعلمات
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            return $result['total'];
        } catch (Exception $e) {
            logError('OrderModel::countUserOrders - ' . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * إلغاء طلب
     * 
     * @param int $order_id معرف الطلب
     * @param int $user_id معرف المستخدم
     * @return bool نجاح أو فشل العملية
     */
    public function cancelOrder($order_id, $user_id) {
        try {
            // التحقق من أن الطلب للمستخدم الحالي وفي حالة قيد الانتظار
            $sql = "SELECT * FROM orders WHERE id = :order_id AND user_id = :user_id AND status = 'pending'";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':order_id', $order_id);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();
            
            $order = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$order) {
                return false;
            }
            
            // البدء بمعاملة قاعدة البيانات
            $this->db->beginTransaction();
            
            // تحديث حالة الطلب
            $sql = "UPDATE orders SET status = 'canceled', canceled_at = NOW() WHERE id = :order_id";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':order_id', $order_id);
            $stmt->execute();
            
            // إرجاع المبلغ إلى رصيد المستخدم
            $this->updateUserBalance($user_id, $order['price']);
            
            // إنشاء معاملة للاسترداد
            $this->createTransaction([
                'user_id' => $user_id,
                'type' => 'refund',
                'amount' => $order['price'],
                'description' => 'استرداد للطلب #' . $order_id,
                'status' => 'completed',
                'order_id' => $order_id
            ]);
            
            // إتمام المعاملة
            $this->db->commit();
            
            return true;
        } catch (Exception $e) {
            // التراجع عن المعاملة في حالة حدوث خطأ
            $this->db->rollBack();
            logError('OrderModel::cancelOrder - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على الطلبات المشابهة (للمستخدم نفسه)
     * 
     * @param int $order_id معرف الطلب الحالي
     * @param int $user_id معرف المستخدم
     * @param int $limit عدد الطلبات المطلوبة
     * @return array قائمة بالطلبات المشابهة
     */
    public function getSimilarOrders($order_id, $user_id, $limit = 5) {
        try {
            // الحصول على معرف الخدمة للطلب الحالي
            $sql = "SELECT service_id FROM orders WHERE id = :order_id";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':order_id', $order_id);
            $stmt->execute();
            
            $current_order = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$current_order) {
                return [];
            }
            
            // الحصول على الطلبات المشابهة
            $sql = "SELECT o.*, s.name as service_name 
                    FROM orders o 
                    JOIN services s ON o.service_id = s.id 
                    WHERE o.user_id = :user_id 
                    AND o.service_id = :service_id 
                    AND o.id != :order_id 
                    ORDER BY o.created_at DESC 
                    LIMIT :limit";
                    
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindParam(':service_id', $current_order['service_id']);
            $stmt->bindParam(':order_id', $order_id);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('OrderModel::getSimilarOrders - ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * تحديث رصيد المستخدم
     * 
     * @param int $user_id معرف المستخدم
     * @param float $amount المبلغ (موجب للإضافة، سالب للخصم)
     * @return bool نجاح أو فشل العملية
     */
    private function updateUserBalance($user_id, $amount) {
        try {
            $sql = "UPDATE users SET balance = balance + :amount WHERE id = :user_id";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':amount', $amount);
            $stmt->bindParam(':user_id', $user_id);
            return $stmt->execute();
        } catch (Exception $e) {
            logError('OrderModel::updateUserBalance - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على رصيد المستخدم
     * 
     * @param int $user_id معرف المستخدم
     * @return float رصيد المستخدم
     */
    private function getUserBalance($user_id) {
        try {
            $sql = "SELECT balance FROM users WHERE id = :user_id";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();
            
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            return $result ? $result['balance'] : 0;
        } catch (Exception $e) {
            logError('OrderModel::getUserBalance - ' . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * إنشاء معاملة مالية
     * 
     * @param array $data بيانات المعاملة
     * @return int|bool معرف المعاملة إذا نجح أو false إذا فشل
     */
    private function createTransaction($data) {
        try {
            $sql = "INSERT INTO transactions (user_id, type, amount, description, status, order_id, created_at) 
                    VALUES (:user_id, :type, :amount, :description, :status, :order_id, NOW())";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':user_id', $data['user_id']);
            $stmt->bindParam(':type', $data['type']);
            $stmt->bindParam(':amount', $data['amount']);
            $stmt->bindParam(':description', $data['description']);
            $stmt->bindParam(':status', $data['status']);
            $stmt->bindParam(':order_id', $data['order_id']);
            $stmt->execute();
            
            return $this->db->lastInsertId();
        } catch (Exception $e) {
            logError('OrderModel::createTransaction - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * إعادة ترتيب طلب موجود
     * 
     * @param int $order_id معرف الطلب
     * @return array|bool بيانات الطلب للإعادة أو false إذا فشل
     */
    public function getOrderForReorder($order_id) {
        try {
            $sql = "SELECT o.service_id, o.link, o.quantity, o.comments, s.name as service_name 
                    FROM orders o 
                    JOIN services s ON o.service_id = s.id 
                    WHERE o.id = :order_id";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':order_id', $order_id);
            $stmt->execute();
            
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('OrderModel::getOrderForReorder - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على إحصائيات طلبات المستخدم
     * 
     * @param int $user_id معرف المستخدم
     * @return array إحصائيات الطلبات
     */
    public function getUserOrderStats($user_id) {
        try {
            $sql = "SELECT 
                    COUNT(*) as total_orders,
                    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_orders,
                    SUM(CASE WHEN status = 'processing' THEN 1 ELSE 0 END) as processing_orders,
                    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_orders,
                    SUM(CASE WHEN status = 'canceled' THEN 1 ELSE 0 END) as canceled_orders,
                    SUM(CASE WHEN status = 'partial' THEN 1 ELSE 0 END) as partial_orders,
                    SUM(price) as total_spent
                    FROM orders 
                    WHERE user_id = :user_id";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();
            
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('OrderModel::getUserOrderStats - ' . $e->getMessage());
            return [
                'total_orders' => 0,
                'pending_orders' => 0,
                'processing_orders' => 0,
                'completed_orders' => 0,
                'canceled_orders' => 0,
                'partial_orders' => 0,
                'total_spent' => 0
            ];
        }
    }
}
