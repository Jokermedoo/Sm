<?php
/**
 * Transaction Model
 * يتعامل مع جميع عمليات قاعدة البيانات المتعلقة بالمعاملات المالية
 */
class TransactionModel {
    private $db;
    
    /**
     * إنشاء كائن النموذج
     */
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * إنشاء معاملة جديدة
     * 
     * @param array $data بيانات المعاملة
     * @return int|bool معرف المعاملة إذا نجح أو false إذا فشل
     */
    public function createTransaction($data) {
        try {
            $sql = "INSERT INTO transactions (user_id, type, amount, description, status, payment_method, transaction_ref, order_id, created_at) 
                    VALUES (:user_id, :type, :amount, :description, :status, :payment_method, :transaction_ref, :order_id, NOW())";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':user_id', $data['user_id']);
            $stmt->bindParam(':type', $data['type']);
            $stmt->bindParam(':amount', $data['amount']);
            $stmt->bindParam(':description', $data['description']);
            $stmt->bindParam(':status', $data['status']);
            $stmt->bindParam(':payment_method', $data['payment_method']);
            $stmt->bindParam(':transaction_ref', $data['transaction_ref']);
            $stmt->bindParam(':order_id', $data['order_id']);
            $stmt->execute();
            
            return $this->db->lastInsertId();
        } catch (Exception $e) {
            logError('TransactionModel::createTransaction - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على تفاصيل المعاملة بواسطة المعرف
     * 
     * @param int $transaction_id معرف المعاملة
     * @return array|bool بيانات المعاملة أو false إذا لم يتم العثور عليها
     */
    public function getTransactionById($transaction_id) {
        try {
            $sql = "SELECT * FROM transactions WHERE id = :transaction_id";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':transaction_id', $transaction_id);
            $stmt->execute();
            
            $transaction = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$transaction) {
                return false;
            }
            
            return $transaction;
        } catch (Exception $e) {
            logError('TransactionModel::getTransactionById - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على قائمة المعاملات للمستخدم
     * 
     * @param int $user_id معرف المستخدم
     * @param array $filters مرشحات للبحث
     * @param int $page رقم الصفحة
     * @param int $limit عدد العناصر في الصفحة
     * @return array قائمة المعاملات
     */
    public function getUserTransactions($user_id, $filters = [], $page = 1, $limit = 10) {
        try {
            $offset = ($page - 1) * $limit;
            
            // بناء استعلام SQL
            $sql = "SELECT * FROM transactions WHERE user_id = :user_id";
            
            $params = [':user_id' => $user_id];
            
            // إضافة المرشحات
            if (!empty($filters['type'])) {
                $sql .= " AND type = :type";
                $params[':type'] = $filters['type'];
            }
            
            if (!empty($filters['status'])) {
                $sql .= " AND status = :status";
                $params[':status'] = $filters['status'];
            }
            
            if (!empty($filters['search'])) {
                $sql .= " AND (description LIKE :search OR transaction_ref LIKE :search)";
                $params[':search'] = '%' . $filters['search'] . '%';
            }
            
            // إضافة الترتيب والحد
            $sql .= " ORDER BY created_at DESC LIMIT :limit OFFSET :offset";
            
            $stmt = $this->db->prepare($sql);
            
            // ربط المعلمات
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('TransactionModel::getUserTransactions - ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * الحصول على العدد الإجمالي لمعاملات المستخدم (للترقيم)
     * 
     * @param int $user_id معرف المستخدم
     * @param array $filters مرشحات للبحث
     * @return int العدد الإجمالي للمعاملات
     */
    public function countUserTransactions($user_id, $filters = []) {
        try {
            // بناء استعلام SQL
            $sql = "SELECT COUNT(*) as total FROM transactions WHERE user_id = :user_id";
            
            $params = [':user_id' => $user_id];
            
            // إضافة المرشحات
            if (!empty($filters['type'])) {
                $sql .= " AND type = :type";
                $params[':type'] = $filters['type'];
            }
            
            if (!empty($filters['status'])) {
                $sql .= " AND status = :status";
                $params[':status'] = $filters['status'];
            }
            
            if (!empty($filters['search'])) {
                $sql .= " AND (description LIKE :search OR transaction_ref LIKE :search)";
                $params[':search'] = '%' . $filters['search'] . '%';
            }
            
            $stmt = $this->db->prepare($sql);
            
            // ربط المعلمات
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            return $result['total'];
        } catch (Exception $e) {
            logError('TransactionModel::countUserTransactions - ' . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * تحديث حالة المعاملة
     * 
     * @param int $transaction_id معرف المعاملة
     * @param string $status الحالة الجديدة
     * @param string $transaction_ref المرجع الخارجي للمعاملة (اختياري)
     * @return bool نجاح أو فشل العملية
     */
    public function updateTransactionStatus($transaction_id, $status, $transaction_ref = null) {
        try {
            $sql = "UPDATE transactions SET status = :status";
            
            $params = [
                ':transaction_id' => $transaction_id,
                ':status' => $status
            ];
            
            if ($transaction_ref) {
                $sql .= ", transaction_ref = :transaction_ref";
                $params[':transaction_ref'] = $transaction_ref;
            }
            
            $sql .= ", updated_at = NOW() WHERE id = :transaction_id";
            
            $stmt = $this->db->prepare($sql);
            
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            
            return $stmt->execute();
        } catch (Exception $e) {
            logError('TransactionModel::updateTransactionStatus - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * إنشاء معاملة إيداع جديدة
     * 
     * @param array $data بيانات الإيداع
     * @return int|bool معرف المعاملة إذا نجح أو false إذا فشل
     */
    public function createDeposit($data) {
        try {
            // البدء بمعاملة قاعدة البيانات
            $this->db->beginTransaction();
            
            // إنشاء المعاملة
            $transaction_data = [
                'user_id' => $data['user_id'],
                'type' => 'deposit',
                'amount' => $data['amount'],
                'description' => $data['description'] ?? 'إيداع رصيد',
                'status' => 'pending',
                'payment_method' => $data['payment_method'],
                'transaction_ref' => $data['transaction_ref'] ?? null,
                'order_id' => null
            ];
            
            $transaction_id = $this->createTransaction($transaction_data);
            
            if (!$transaction_id) {
                $this->db->rollBack();
                return false;
            }
            
            // إتمام المعاملة
            $this->db->commit();
            
            return $transaction_id;
        } catch (Exception $e) {
            // التراجع عن المعاملة في حالة حدوث خطأ
            $this->db->rollBack();
            logError('TransactionModel::createDeposit - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * إكمال معاملة إيداع
     * 
     * @param int $transaction_id معرف المعاملة
     * @param string $transaction_ref المرجع الخارجي للمعاملة (اختياري)
     * @return bool نجاح أو فشل العملية
     */
    public function completeDeposit($transaction_id, $transaction_ref = null) {
        try {
            // الحصول على تفاصيل المعاملة
            $transaction = $this->getTransactionById($transaction_id);
            
            if (!$transaction || $transaction['type'] != 'deposit' || $transaction['status'] != 'pending') {
                return false;
            }
            
            // البدء بمعاملة قاعدة البيانات
            $this->db->beginTransaction();
            
            // تحديث حالة المعاملة
            $this->updateTransactionStatus($transaction_id, 'completed', $transaction_ref);
            
            // تحديث رصيد المستخدم
            $user_model = new UserModel();
            $user = $user_model->getUserById($transaction['user_id']);
            
            if (!$user) {
                $this->db->rollBack();
                return false;
            }
            
            $new_balance = $user['balance'] + $transaction['amount'];
            
            $sql = "UPDATE users SET balance = :balance, updated_at = NOW() WHERE id = :user_id";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':balance', $new_balance);
            $stmt->bindParam(':user_id', $transaction['user_id']);
            $stmt->execute();
            
            // إتمام المعاملة
            $this->db->commit();
            
            return true;
        } catch (Exception $e) {
            // التراجع عن المعاملة في حالة حدوث خطأ
            $this->db->rollBack();
            logError('TransactionModel::completeDeposit - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * إلغاء معاملة إيداع
     * 
     * @param int $transaction_id معرف المعاملة
     * @param string $reason سبب الإلغاء (اختياري)
     * @return bool نجاح أو فشل العملية
     */
    public function cancelDeposit($transaction_id, $reason = null) {
        try {
            // الحصول على تفاصيل المعاملة
            $transaction = $this->getTransactionById($transaction_id);
            
            if (!$transaction || $transaction['type'] != 'deposit' || $transaction['status'] != 'pending') {
                return false;
            }
            
            // تحديث المعاملة
            $description = $transaction['description'];
            if ($reason) {
                $description .= ' (ملغي: ' . $reason . ')';
            }
            
            $sql = "UPDATE transactions SET status = 'canceled', description = :description, updated_at = NOW() WHERE id = :transaction_id";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':description', $description);
            $stmt->bindParam(':transaction_id', $transaction_id);
            
            return $stmt->execute();
        } catch (Exception $e) {
            logError('TransactionModel::cancelDeposit - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على آخر الإيداعات للمستخدم
     * 
     * @param int $user_id معرف المستخدم
     * @param int $limit عدد المعاملات المطلوبة
     * @return array قائمة المعاملات
     */
    public function getRecentDeposits($user_id, $limit = 5) {
        try {
            $sql = "SELECT * FROM transactions 
                    WHERE user_id = :user_id AND type = 'deposit' 
                    ORDER BY created_at DESC 
                    LIMIT :limit";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('TransactionModel::getRecentDeposits - ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * الحصول على آخر المعاملات للمستخدم (من جميع الأنواع)
     * 
     * @param int $user_id معرف المستخدم
     * @param int $limit عدد المعاملات المطلوبة
     * @return array قائمة المعاملات
     */
    public function getRecentTransactions($user_id, $limit = 5) {
        try {
            $sql = "SELECT * FROM transactions 
                    WHERE user_id = :user_id 
                    ORDER BY created_at DESC 
                    LIMIT :limit";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('TransactionModel::getRecentTransactions - ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * الحصول على إحصائيات المعاملات للمستخدم
     * 
     * @param int $user_id معرف المستخدم
     * @return array إحصائيات المعاملات
     */
    public function getUserTransactionStats($user_id) {
        try {
            $sql = "SELECT 
                    SUM(CASE WHEN type = 'deposit' AND status = 'completed' THEN amount ELSE 0 END) as total_deposits,
                    SUM(CASE WHEN type = 'order' AND status = 'completed' THEN amount ELSE 0 END) as total_spent,
                    SUM(CASE WHEN type = 'refund' AND status = 'completed' THEN amount ELSE 0 END) as total_refunds
                    FROM transactions 
                    WHERE user_id = :user_id";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();
            
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$result) {
                return [
                    'total_deposits' => 0,
                    'total_spent' => 0,
                    'total_refunds' => 0
                ];
            }
            
            return $result;
        } catch (Exception $e) {
            logError('TransactionModel::getUserTransactionStats - ' . $e->getMessage());
            return [
                'total_deposits' => 0,
                'total_spent' => 0,
                'total_refunds' => 0
            ];
        }
    }
    
    /**
     * الحصول على قائمة طرق الدفع المتاحة
     * 
     * @param bool $active جلب طرق الدفع النشطة فقط
     * @return array قائمة طرق الدفع
     */
    public function getPaymentMethods($active = true) {
        try {
            $sql = "SELECT * FROM payment_methods";
            
            if ($active) {
                $sql .= " WHERE status = 'active'";
            }
            
            $sql .= " ORDER BY sort_order";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('TransactionModel::getPaymentMethods - ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * الحصول على تفاصيل طريقة دفع
     * 
     * @param int $method_id معرف طريقة الدفع
     * @return array|bool بيانات طريقة الدفع أو false إذا لم تكن موجودة
     */
    public function getPaymentMethodById($method_id) {
        try {
            $sql = "SELECT * FROM payment_methods WHERE id = :method_id";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':method_id', $method_id);
            $stmt->execute();
            
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('TransactionModel::getPaymentMethodById - ' . $e->getMessage());
            return false;
        }
    }
}
