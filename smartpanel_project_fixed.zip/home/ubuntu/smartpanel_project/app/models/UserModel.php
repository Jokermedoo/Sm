<?php
/**
 * User Model
 * يتعامل مع جميع عمليات قاعدة البيانات المتعلقة بالمستخدمين والمصادقة
 */
class UserModel {
    private $db;
    
    /**
     * إنشاء كائن النموذج
     */
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * تسجيل مستخدم جديد
     * 
     * @param array $data بيانات المستخدم
     * @return array نتيجة العملية مع رسالة ومعرف المستخدم إن وجد
     */
    public function register($data) {
        try {
            // التحقق من وجود المستخدم
            if ($this->isEmailExists($data['email'])) {
                return [
                    'success' => false,
                    'message' => 'البريد الإلكتروني مستخدم بالفعل'
                ];
            }
            
            if ($this->isUsernameExists($data['username'])) {
                return [
                    'success' => false,
                    'message' => 'اسم المستخدم مستخدم بالفعل'
                ];
            }
            
            // تشفير كلمة المرور
            $password_hash = password_hash($data['password'], PASSWORD_DEFAULT);
            
            // إنشاء رمز التفعيل
            $activation_code = md5(uniqid(rand(), true));
            
            // إضافة المستخدم
            $sql = "INSERT INTO users (username, email, password, full_name, role, status, activation_code, created_at) 
                    VALUES (:username, :email, :password, :full_name, 'user', 'inactive', :activation_code, NOW())";
                    
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':username', $data['username']);
            $stmt->bindParam(':email', $data['email']);
            $stmt->bindParam(':password', $password_hash);
            $stmt->bindParam(':full_name', $data['full_name']);
            $stmt->bindParam(':activation_code', $activation_code);
            $stmt->execute();
            
            $user_id = $this->db->lastInsertId();
            
            // إرسال بريد التفعيل
            $activation_link = BASE_URL . '/auth/activate/' . $user_id . '/' . $activation_code;
            $email_sent = $this->sendActivationEmail($data['email'], $data['username'], $activation_link);
            
            return [
                'success' => true,
                'user_id' => $user_id,
                'message' => 'تم التسجيل بنجاح. يرجى تفعيل حسابك من خلال الرابط المرسل إلى بريدك الإلكتروني.',
                'email_sent' => $email_sent
            ];
        } catch (Exception $e) {
            logError('UserModel::register - ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'حدث خطأ أثناء التسجيل. يرجى المحاولة مرة أخرى.'
            ];
        }
    }
    
    /**
     * تسجيل الدخول
     * 
     * @param string $username اسم المستخدم أو البريد الإلكتروني
     * @param string $password كلمة المرور
     * @param bool $remember_me تذكرني
     * @return array نتيجة العملية مع رسالة وبيانات المستخدم إن وجدت
     */
    public function login($username, $password, $remember_me = false) {
        try {
            // التحقق من وجود المستخدم
            $sql = "SELECT * FROM users WHERE (username = :username OR email = :email)";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':username', $username);
            $stmt->bindParam(':email', $username);
            $stmt->execute();
            
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$user) {
                return [
                    'success' => false,
                    'message' => 'اسم المستخدم أو كلمة المرور غير صحيحة'
                ];
            }
            
            // التحقق من كلمة المرور
            if (!password_verify($password, $user['password'])) {
                // تسجيل محاولة فاشلة
                $this->incrementFailedLogins($user['id']);
                
                return [
                    'success' => false,
                    'message' => 'اسم المستخدم أو كلمة المرور غير صحيحة'
                ];
            }
            
            // التحقق من حالة الحساب
            if ($user['status'] === 'inactive') {
                return [
                    'success' => false,
                    'message' => 'الحساب غير مفعل. يرجى تفعيل حسابك من خلال الرابط المرسل إلى بريدك الإلكتروني.'
                ];
            }
            
            if ($user['status'] === 'banned') {
                return [
                    'success' => false,
                    'message' => 'تم حظر الحساب. يرجى التواصل مع الدعم الفني.'
                ];
            }
            
            // إعادة تعيين عدد محاولات تسجيل الدخول الفاشلة
            $this->resetFailedLogins($user['id']);
            
            // تحديث آخر تسجيل دخول
            $this->updateLastLogin($user['id']);
            
            // إنشاء جلسة
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['balance'] = $user['balance'];
            
            // إنشاء رمز تذكرني إذا طلب المستخدم
            if ($remember_me) {
                $token = $this->createRememberToken($user['id']);
                
                if ($token) {
                    // إعداد ملف تعريف الارتباط لمدة 30 يومًا
                    setcookie('remember_token', $token, time() + (86400 * 30), '/', '', false, true);
                }
            }
            
            return [
                'success' => true,
                'message' => 'تم تسجيل الدخول بنجاح',
                'user' => $user
            ];
        } catch (Exception $e) {
            logError('UserModel::login - ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'حدث خطأ أثناء تسجيل الدخول. يرجى المحاولة مرة أخرى.'
            ];
        }
    }
    
    /**
     * تفعيل حساب المستخدم
     * 
     * @param int $user_id معرف المستخدم
     * @param string $activation_code رمز التفعيل
     * @return array نتيجة العملية مع رسالة
     */
    public function activateAccount($user_id, $activation_code) {
        try {
            $sql = "SELECT * FROM users WHERE id = :user_id AND activation_code = :activation_code AND status = 'inactive'";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindParam(':activation_code', $activation_code);
            $stmt->execute();
            
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$user) {
                return [
                    'success' => false,
                    'message' => 'رمز التفعيل غير صالح أو تم تفعيل الحساب بالفعل'
                ];
            }
            
            // تفعيل الحساب
            $sql = "UPDATE users SET status = 'active', activation_code = NULL, updated_at = NOW() WHERE id = :user_id";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();
            
            return [
                'success' => true,
                'message' => 'تم تفعيل الحساب بنجاح. يمكنك الآن تسجيل الدخول.'
            ];
        } catch (Exception $e) {
            logError('UserModel::activateAccount - ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'حدث خطأ أثناء تفعيل الحساب. يرجى المحاولة مرة أخرى.'
            ];
        }
    }
    
    /**
     * إعادة تعيين كلمة المرور (طلب)
     * 
     * @param string $email البريد الإلكتروني
     * @return array نتيجة العملية مع رسالة
     */
    public function requestPasswordReset($email) {
        try {
            // التحقق من وجود المستخدم
            $sql = "SELECT * FROM users WHERE email = :email";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$user) {
                return [
                    'success' => false,
                    'message' => 'البريد الإلكتروني غير مسجل في النظام'
                ];
            }
            
            // إنشاء رمز إعادة تعيين كلمة المرور
            $reset_token = md5(uniqid(rand(), true));
            $expires_at = date('Y-m-d H:i:s', strtotime('+1 hour'));
            
            // حفظ الرمز في قاعدة البيانات
            $sql = "INSERT INTO password_resets (user_id, token, expires_at, created_at) 
                    VALUES (:user_id, :token, :expires_at, NOW())";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':user_id', $user['id']);
            $stmt->bindParam(':token', $reset_token);
            $stmt->bindParam(':expires_at', $expires_at);
            $stmt->execute();
            
            // إرسال بريد إعادة تعيين كلمة المرور
            $reset_link = BASE_URL . '/auth/reset-password/' . $reset_token;
            $email_sent = $this->sendPasswordResetEmail($email, $user['username'], $reset_link);
            
            return [
                'success' => true,
                'message' => 'تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني.',
                'email_sent' => $email_sent
            ];
        } catch (Exception $e) {
            logError('UserModel::requestPasswordReset - ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'حدث خطأ أثناء طلب إعادة تعيين كلمة المرور. يرجى المحاولة مرة أخرى.'
            ];
        }
    }
    
    /**
     * التحقق من صلاحية رمز إعادة تعيين كلمة المرور
     * 
     * @param string $token الرمز
     * @return array نتيجة التحقق مع معرف المستخدم إن وجد
     */
    public function validateResetToken($token) {
        try {
            $sql = "SELECT * FROM password_resets WHERE token = :token AND expires_at > NOW() AND used = 0";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':token', $token);
            $stmt->execute();
            
            $reset = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$reset) {
                return [
                    'valid' => false,
                    'message' => 'رمز إعادة تعيين كلمة المرور غير صالح أو منتهي الصلاحية'
                ];
            }
            
            return [
                'valid' => true,
                'user_id' => $reset['user_id']
            ];
        } catch (Exception $e) {
            logError('UserModel::validateResetToken - ' . $e->getMessage());
            return [
                'valid' => false,
                'message' => 'حدث خطأ أثناء التحقق من رمز إعادة تعيين كلمة المرور'
            ];
        }
    }
    
    /**
     * إعادة تعيين كلمة المرور
     * 
     * @param string $token الرمز
     * @param string $password كلمة المرور الجديدة
     * @return array نتيجة العملية مع رسالة
     */
    public function resetPassword($token, $password) {
        try {
            // التحقق من صلاحية الرمز
            $validate_result = $this->validateResetToken($token);
            
            if (!$validate_result['valid']) {
                return [
                    'success' => false,
                    'message' => $validate_result['message']
                ];
            }
            
            $user_id = $validate_result['user_id'];
            
            // تشفير كلمة المرور الجديدة
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            
            // تحديث كلمة المرور
            $sql = "UPDATE users SET password = :password, updated_at = NOW() WHERE id = :user_id";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':password', $password_hash);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();
            
            // تحديث حالة الرمز
            $sql = "UPDATE password_resets SET used = 1 WHERE token = :token";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':token', $token);
            $stmt->execute();
            
            return [
                'success' => true,
                'message' => 'تم إعادة تعيين كلمة المرور بنجاح. يمكنك الآن تسجيل الدخول.'
            ];
        } catch (Exception $e) {
            logError('UserModel::resetPassword - ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'حدث خطأ أثناء إعادة تعيين كلمة المرور. يرجى المحاولة مرة أخرى.'
            ];
        }
    }
    
    /**
     * التحقق من وجود بريد إلكتروني
     * 
     * @param string $email البريد الإلكتروني
     * @return bool موجود أم لا
     */
    public function isEmailExists($email) {
        try {
            $sql = "SELECT COUNT(*) FROM users WHERE email = :email";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            
            return $stmt->fetchColumn() > 0;
        } catch (Exception $e) {
            logError('UserModel::isEmailExists - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * التحقق من وجود اسم مستخدم
     * 
     * @param string $username اسم المستخدم
     * @return bool موجود أم لا
     */
    public function isUsernameExists($username) {
        try {
            $sql = "SELECT COUNT(*) FROM users WHERE username = :username";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':username', $username);
            $stmt->execute();
            
            return $stmt->fetchColumn() > 0;
        } catch (Exception $e) {
            logError('UserModel::isUsernameExists - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على معلومات المستخدم
     * 
     * @param int $user_id معرف المستخدم
     * @return array|bool بيانات المستخدم أو false إذا لم يكن موجودًا
     */
    public function getUserById($user_id) {
        try {
            $sql = "SELECT * FROM users WHERE id = :user_id";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();
            
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('UserModel::getUserById - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * تحديث معلومات المستخدم
     * 
     * @param int $user_id معرف المستخدم
     * @param array $data البيانات المراد تحديثها
     * @return array نتيجة العملية مع رسالة
     */
    public function updateProfile($user_id, $data) {
        try {
            $allowed_fields = ['full_name', 'phone', 'address', 'country', 'city', 'postal_code'];
            $update_fields = [];
            $params = [':user_id' => $user_id];
            
            foreach ($data as $field => $value) {
                if (in_array($field, $allowed_fields)) {
                    $update_fields[] = "$field = :$field";
                    $params[":$field"] = $value;
                }
            }
            
            if (empty($update_fields)) {
                return [
                    'success' => false,
                    'message' => 'لم يتم تحديد أي حقول للتحديث'
                ];
            }
            
            $update_fields[] = "updated_at = NOW()";
            
            $sql = "UPDATE users SET " . implode(', ', $update_fields) . " WHERE id = :user_id";
            $stmt = $this->db->prepare($sql);
            
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            
            $stmt->execute();
            
            return [
                'success' => true,
                'message' => 'تم تحديث المعلومات الشخصية بنجاح'
            ];
        } catch (Exception $e) {
            logError('UserModel::updateProfile - ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'حدث خطأ أثناء تحديث المعلومات الشخصية'
            ];
        }
    }
    
    /**
     * تغيير كلمة المرور
     * 
     * @param int $user_id معرف المستخدم
     * @param string $current_password كلمة المرور الحالية
     * @param string $new_password كلمة المرور الجديدة
     * @return array نتيجة العملية مع رسالة
     */
    public function changePassword($user_id, $current_password, $new_password) {
        try {
            // الحصول على معلومات المستخدم
            $user = $this->getUserById($user_id);
            
            if (!$user) {
                return [
                    'success' => false,
                    'message' => 'المستخدم غير موجود'
                ];
            }
            
            // التحقق من كلمة المرور الحالية
            if (!password_verify($current_password, $user['password'])) {
                return [
                    'success' => false,
                    'message' => 'كلمة المرور الحالية غير صحيحة'
                ];
            }
            
            // تشفير كلمة المرور الجديدة
            $password_hash = password_hash($new_password, PASSWORD_DEFAULT);
            
            // تحديث كلمة المرور
            $sql = "UPDATE users SET password = :password, updated_at = NOW() WHERE id = :user_id";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':password', $password_hash);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();
            
            return [
                'success' => true,
                'message' => 'تم تغيير كلمة المرور بنجاح'
            ];
        } catch (Exception $e) {
            logError('UserModel::changePassword - ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'حدث خطأ أثناء تغيير كلمة المرور'
            ];
        }
    }
    
    /**
     * تحديث إعدادات الإشعارات
     * 
     * @param int $user_id معرف المستخدم
     * @param array $settings إعدادات الإشعارات
     * @return array نتيجة العملية مع رسالة
     */
    public function updateNotificationSettings($user_id, $settings) {
        try {
            $allowed_fields = ['email_notifications', 'sms_notifications', 'marketing_emails'];
            $update_fields = [];
            $params = [':user_id' => $user_id];
            
            foreach ($settings as $field => $value) {
                if (in_array($field, $allowed_fields)) {
                    $update_fields[] = "$field = :$field";
                    $params[":$field"] = $value ? 1 : 0;
                }
            }
            
            if (empty($update_fields)) {
                return [
                    'success' => false,
                    'message' => 'لم يتم تحديد أي إعدادات للتحديث'
                ];
            }
            
            $update_fields[] = "updated_at = NOW()";
            
            $sql = "UPDATE users SET " . implode(', ', $update_fields) . " WHERE id = :user_id";
            $stmt = $this->db->prepare($sql);
            
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            
            $stmt->execute();
            
            return [
                'success' => true,
                'message' => 'تم تحديث إعدادات الإشعارات بنجاح'
            ];
        } catch (Exception $e) {
            logError('UserModel::updateNotificationSettings - ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'حدث خطأ أثناء تحديث إعدادات الإشعارات'
            ];
        }
    }
    
    /**
     * تحديث الصورة الشخصية
     * 
     * @param int $user_id معرف المستخدم
     * @param string $avatar_path مسار الصورة الشخصية
     * @return array نتيجة العملية مع رسالة
     */
    public function updateAvatar($user_id, $avatar_path) {
        try {
            $sql = "UPDATE users SET avatar = :avatar, updated_at = NOW() WHERE id = :user_id";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':avatar', $avatar_path);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();
            
            return [
                'success' => true,
                'message' => 'تم تحديث الصورة الشخصية بنجاح'
            ];
        } catch (Exception $e) {
            logError('UserModel::updateAvatar - ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'حدث خطأ أثناء تحديث الصورة الشخصية'
            ];
        }
    }
}
