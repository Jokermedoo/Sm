<?php
/**
 * API Model
 * يتعامل مع جميع عمليات قاعدة البيانات المتعلقة بـ API وخدمات الطرف الثالث
 */
class APIModel {
    private $db;
    
    /**
     * إنشاء كائن النموذج
     */
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * التحقق من صحة مفتاح API
     * 
     * @param string $api_key مفتاح API
     * @return array|bool بيانات المستخدم إذا كان المفتاح صحيحًا أو false إذا كان غير صحيح
     */
    public function validateAPIKey($api_key) {
        try {
            $sql = "SELECT u.* FROM users u
                    JOIN api_keys a ON u.id = a.user_id
                    WHERE a.api_key = :api_key AND a.status = 'active'";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':api_key', $api_key);
            $stmt->execute();
            
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$user) {
                return false;
            }
            
            return $user;
        } catch (Exception $e) {
            logError('APIModel::validateAPIKey - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * إنشاء مفتاح API جديد للمستخدم
     * 
     * @param int $user_id معرف المستخدم
     * @return string|bool مفتاح API الجديد أو false إذا فشل
     */
    public function generateAPIKey($user_id) {
        try {
            // توليد مفتاح API فريد
            $api_key = $this->generateUniqueAPIKey();
            
            // حذف المفاتيح القديمة للمستخدم
            $this->deleteUserAPIKeys($user_id);
            
            // إضافة المفتاح الجديد
            $sql = "INSERT INTO api_keys (user_id, api_key, status, created_at) 
                    VALUES (:user_id, :api_key, 'active', NOW())";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindParam(':api_key', $api_key);
            $stmt->execute();
            
            return $api_key;
        } catch (Exception $e) {
            logError('APIModel::generateAPIKey - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * حذف جميع مفاتيح API للمستخدم
     * 
     * @param int $user_id معرف المستخدم
     * @return bool نجاح أو فشل العملية
     */
    public function deleteUserAPIKeys($user_id) {
        try {
            $sql = "DELETE FROM api_keys WHERE user_id = :user_id";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':user_id', $user_id);
            
            return $stmt->execute();
        } catch (Exception $e) {
            logError('APIModel::deleteUserAPIKeys - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على مفتاح API الحالي للمستخدم
     * 
     * @param int $user_id معرف المستخدم
     * @return string|bool مفتاح API أو false إذا لم يكن هناك مفتاح
     */
    public function getUserAPIKey($user_id) {
        try {
            $sql = "SELECT api_key FROM api_keys 
                    WHERE user_id = :user_id AND status = 'active'
                    ORDER BY created_at DESC LIMIT 1";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();
            
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$result) {
                return false;
            }
            
            return $result['api_key'];
        } catch (Exception $e) {
            logError('APIModel::getUserAPIKey - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * تسجيل طلب API
     * 
     * @param array $data بيانات الطلب
     * @return int|bool معرف السجل أو false إذا فشل
     */
    public function logAPIRequest($data) {
        try {
            $sql = "INSERT INTO api_logs (user_id, endpoint, method, request_data, response_data, ip_address, status_code, created_at) 
                    VALUES (:user_id, :endpoint, :method, :request_data, :response_data, :ip_address, :status_code, NOW())";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':user_id', $data['user_id']);
            $stmt->bindParam(':endpoint', $data['endpoint']);
            $stmt->bindParam(':method', $data['method']);
            $stmt->bindParam(':request_data', $data['request_data']);
            $stmt->bindParam(':response_data', $data['response_data']);
            $stmt->bindParam(':ip_address', $data['ip_address']);
            $stmt->bindParam(':status_code', $data['status_code']);
            $stmt->execute();
            
            return $this->db->lastInsertId();
        } catch (Exception $e) {
            logError('APIModel::logAPIRequest - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على سجلات طلبات API للمستخدم
     * 
     * @param int $user_id معرف المستخدم
     * @param array $filters مرشحات للبحث
     * @param int $page رقم الصفحة
     * @param int $limit عدد العناصر في الصفحة
     * @return array قائمة السجلات
     */
    public function getUserAPILogs($user_id, $filters = [], $page = 1, $limit = 10) {
        try {
            $offset = ($page - 1) * $limit;
            
            // بناء استعلام SQL
            $sql = "SELECT * FROM api_logs WHERE user_id = :user_id";
            
            $params = [':user_id' => $user_id];
            
            // إضافة المرشحات
            if (!empty($filters['endpoint'])) {
                $sql .= " AND endpoint = :endpoint";
                $params[':endpoint'] = $filters['endpoint'];
            }
            
            if (!empty($filters['method'])) {
                $sql .= " AND method = :method";
                $params[':method'] = $filters['method'];
            }
            
            if (!empty($filters['status_code'])) {
                $sql .= " AND status_code = :status_code";
                $params[':status_code'] = $filters['status_code'];
            }
            
            if (!empty($filters['date_from'])) {
                $sql .= " AND created_at >= :date_from";
                $params[':date_from'] = $filters['date_from'] . ' 00:00:00';
            }
            
            if (!empty($filters['date_to'])) {
                $sql .= " AND created_at <= :date_to";
                $params[':date_to'] = $filters['date_to'] . ' 23:59:59';
            }
            
            // إضافة الترتيب والحد
            $sql .= " ORDER BY created_at DESC LIMIT :limit OFFSET :offset";
            
            $stmt = $this->db->prepare($sql);
            
            // ربط المعلمات
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('APIModel::getUserAPILogs - ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * حساب عدد سجلات طلبات API للمستخدم
     * 
     * @param int $user_id معرف المستخدم
     * @param array $filters مرشحات للبحث
     * @return int عدد السجلات
     */
    public function countUserAPILogs($user_id, $filters = []) {
        try {
            // بناء استعلام SQL
            $sql = "SELECT COUNT(*) as total FROM api_logs WHERE user_id = :user_id";
            
            $params = [':user_id' => $user_id];
            
            // إضافة المرشحات
            if (!empty($filters['endpoint'])) {
                $sql .= " AND endpoint = :endpoint";
                $params[':endpoint'] = $filters['endpoint'];
            }
            
            if (!empty($filters['method'])) {
                $sql .= " AND method = :method";
                $params[':method'] = $filters['method'];
            }
            
            if (!empty($filters['status_code'])) {
                $sql .= " AND status_code = :status_code";
                $params[':status_code'] = $filters['status_code'];
            }
            
            if (!empty($filters['date_from'])) {
                $sql .= " AND created_at >= :date_from";
                $params[':date_from'] = $filters['date_from'] . ' 00:00:00';
            }
            
            if (!empty($filters['date_to'])) {
                $sql .= " AND created_at <= :date_to";
                $params[':date_to'] = $filters['date_to'] . ' 23:59:59';
            }
            
            $stmt = $this->db->prepare($sql);
            
            // ربط المعلمات
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            return $result['total'];
        } catch (Exception $e) {
            logError('APIModel::countUserAPILogs - ' . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * إنشاء طلب خدمة من خلال API
     * 
     * @param int $user_id معرف المستخدم
     * @param array $data بيانات الطلب
     * @return array نتيجة العملية مع رسالة ومعرف الطلب إن وجد
     */
    public function createAPIOrder($user_id, $data) {
        try {
            // التحقق من وجود الخدمة
            $service_model = new ServiceModel();
            $service = $service_model->getServiceById($data['service']);
            
            if (!$service) {
                return [
                    'success' => false,
                    'message' => 'الخدمة غير موجودة'
                ];
            }
            
            // التحقق من الكمية
            if ($data['quantity'] < $service['min'] || $data['quantity'] > $service['max']) {
                return [
                    'success' => false,
                    'message' => "الكمية يجب أن تكون بين {$service['min']} و {$service['max']}"
                ];
            }
            
            // حساب السعر
            $price = $service_model->calculatePrice($service['id'], $data['quantity']);
            
            // التحقق من الرصيد
            $user_model = new UserModel();
            $user = $user_model->getUserById($user_id);
            
            if ($user['balance'] < $price) {
                return [
                    'success' => false,
                    'message' => 'رصيد غير كاف'
                ];
            }
            
            // إنشاء الطلب
            $order_model = new OrderModel();
            $order_data = [
                'user_id' => $user_id,
                'service_id' => $service['id'],
                'link' => $data['link'],
                'quantity' => $data['quantity'],
                'price' => $price,
                'status' => 'pending'
            ];
            
            // إضافة البيانات الإضافية حسب نوع الخدمة
            if ($service['type'] == 'custom_comments') {
                $order_data['comments'] = $data['comments'];
            } elseif ($service['type'] == 'package') {
                $order_data['username'] = $data['username'];
            } elseif ($service['type'] == 'subscriptions') {
                $order_data['username'] = $data['username'];
                $order_data['posts'] = $data['posts'];
                $order_data['delay'] = $data['delay'];
            }
            
            $order_id = $order_model->createOrder($order_data);
            
            if (!$order_id) {
                return [
                    'success' => false,
                    'message' => 'فشل في إنشاء الطلب'
                ];
            }
            
            // تحديث الرصيد
            $new_balance = $user['balance'] - $price;
            $user_model->updateUserBalance($user_id, $new_balance);
            
            // إنشاء سجل معاملة
            $transaction_model = new TransactionModel();
            $transaction_data = [
                'user_id' => $user_id,
                'type' => 'order',
                'amount' => $price,
                'description' => "طلب جديد #{$order_id} - {$service['name']}",
                'status' => 'completed',
                'payment_method' => 'balance',
                'transaction_ref' => null,
                'order_id' => $order_id
            ];
            $transaction_model->createTransaction($transaction_data);
            
            return [
                'success' => true,
                'order' => $order_id,
                'message' => 'تم إنشاء الطلب بنجاح'
            ];
        } catch (Exception $e) {
            logError('APIModel::createAPIOrder - ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'حدث خطأ أثناء معالجة الطلب'
            ];
        }
    }
    
    /**
     * الحصول على حالة الطلب من خلال API
     * 
     * @param int $user_id معرف المستخدم
     * @param int $order_id معرف الطلب
     * @return array نتيجة العملية مع بيانات الطلب إن وجد
     */
    public function getAPIOrderStatus($user_id, $order_id) {
        try {
            $order_model = new OrderModel();
            $order = $order_model->getOrderById($order_id);
            
            if (!$order) {
                return [
                    'success' => false,
                    'message' => 'الطلب غير موجود'
                ];
            }
            
            // التحقق من ملكية الطلب
            if ($order['user_id'] != $user_id) {
                return [
                    'success' => false,
                    'message' => 'غير مصرح لك بالوصول إلى هذا الطلب'
                ];
            }
            
            return [
                'success' => true,
                'order' => [
                    'id' => $order['id'],
                    'status' => $order['status'],
                    'charge' => $order['price'],
                    'start_count' => $order['start_count'],
                    'remains' => $order['remains'],
                    'created_at' => $order['created_at']
                ]
            ];
        } catch (Exception $e) {
            logError('APIModel::getAPIOrderStatus - ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'حدث خطأ أثناء الحصول على حالة الطلب'
            ];
        }
    }
    
    /**
     * الحصول على قائمة الخدمات من خلال API
     * 
     * @return array قائمة الخدمات
     */
    public function getAPIServices() {
        try {
            $service_model = new ServiceModel();
            $services = $service_model->getAllServices();
            
            $formatted_services = [];
            
            foreach ($services as $service) {
                $formatted_services[] = [
                    'service' => $service['id'],
                    'name' => $service['name'],
                    'category' => $service['category_name'],
                    'type' => $service['type'],
                    'rate' => $service['price'],
                    'min' => $service['min'],
                    'max' => $service['max'],
                    'desc' => $service['description']
                ];
            }
            
            return [
                'success' => true,
                'services' => $formatted_services
            ];
        } catch (Exception $e) {
            logError('APIModel::getAPIServices - ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'حدث خطأ أثناء الحصول على قائمة الخدمات'
            ];
        }
    }
    
    /**
     * الحصول على معلومات المستخدم من خلال API
     * 
     * @param int $user_id معرف المستخدم
     * @return array معلومات المستخدم
     */
    public function getAPIUserInfo($user_id) {
        try {
            $user_model = new UserModel();
            $user = $user_model->getUserById($user_id);
            
            if (!$user) {
                return [
                    'success' => false,
                    'message' => 'المستخدم غير موجود'
                ];
            }
            
            // الحصول على إحصائيات الطلبات
            $order_model = new OrderModel();
            $order_stats = $order_model->getUserOrderStats($user_id);
            
            return [
                'success' => true,
                'user' => [
                    'username' => $user['username'],
                    'email' => $user['email'],
                    'balance' => $user['balance'],
                    'currency' => CURRENCY_CODE,
                    'total_orders' => $order_stats['total_orders'] ?? 0,
                    'total_spent' => $order_stats['total_spent'] ?? 0
                ]
            ];
        } catch (Exception $e) {
            logError('APIModel::getAPIUserInfo - ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'حدث خطأ أثناء الحصول على معلومات المستخدم'
            ];
        }
    }
    
    /**
     * توليد مفتاح API فريد
     * 
     * @return string مفتاح API
     */
    private function generateUniqueAPIKey() {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $key = '';
        
        for ($i = 0; $i < 32; $i++) {
            $key .= $characters[random_int(0, strlen($characters) - 1)];
        }
        
        // التحقق من عدم وجود المفتاح بالفعل
        $sql = "SELECT COUNT(*) FROM api_keys WHERE api_key = :api_key";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':api_key', $key);
        $stmt->execute();
        
        if ($stmt->fetchColumn() > 0) {
            // إذا كان المفتاح موجودًا بالفعل، قم بتوليد مفتاح آخر
            return $this->generateUniqueAPIKey();
        }
        
        return $key;
    }
    
    /**
     * التحقق من وجود تكامل API خارجي
     * 
     * @param string $provider_name اسم مزود الخدمة
     * @return array|bool بيانات التكامل أو false إذا لم يكن موجودًا
     */
    public function getProviderIntegration($provider_name) {
        try {
            $sql = "SELECT * FROM api_providers WHERE name = :name AND status = 'active'";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':name', $provider_name);
            $stmt->execute();
            
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('APIModel::getProviderIntegration - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على قائمة مزودي خدمات API
     * 
     * @param bool $active_only جلب المزودين النشطين فقط
     * @return array قائمة المزودين
     */
    public function getAPIProviders($active_only = true) {
        try {
            $sql = "SELECT * FROM api_providers";
            
            if ($active_only) {
                $sql .= " WHERE status = 'active'";
            }
            
            $sql .= " ORDER BY name";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('APIModel::getAPIProviders - ' . $e->getMessage());
            return [];
        }
    }
}
