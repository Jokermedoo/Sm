<?php
/**
 * Ticket Model
 * يتعامل مع جميع عمليات قاعدة البيانات المتعلقة بتذاكر الدعم الفني
 */
class TicketModel {
    private $db;
    
    /**
     * إنشاء كائن النموذج
     */
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * إنشاء تذكرة دعم جديدة
     * 
     * @param array $data بيانات التذكرة
     * @return int|bool معرف التذكرة إذا نجح أو false إذا فشل
     */
    public function createTicket($data) {
        try {
            $sql = "INSERT INTO tickets (user_id, subject, department, priority, message, status, created_at) 
                    VALUES (:user_id, :subject, :department, :priority, :message, 'open', NOW())";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':user_id', $data['user_id']);
            $stmt->bindParam(':subject', $data['subject']);
            $stmt->bindParam(':department', $data['department']);
            $stmt->bindParam(':priority', $data['priority']);
            $stmt->bindParam(':message', $data['message']);
            $stmt->execute();
            
            $ticket_id = $this->db->lastInsertId();
            
            // إضافة رد أولي (رسالة المستخدم)
            if ($ticket_id) {
                $this->addReply([
                    'ticket_id' => $ticket_id,
                    'user_id' => $data['user_id'],
                    'message' => $data['message'],
                    'is_admin' => 0
                ]);
                
                // إذا كانت هناك مرفقات
                if (!empty($data['attachments'])) {
                    foreach ($data['attachments'] as $attachment) {
                        $this->addAttachment($ticket_id, $attachment);
                    }
                }
            }
            
            return $ticket_id;
        } catch (Exception $e) {
            logError('TicketModel::createTicket - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على تذكرة بواسطة المعرف
     * 
     * @param int $ticket_id معرف التذكرة
     * @return array|bool بيانات التذكرة أو false إذا لم يتم العثور عليها
     */
    public function getTicketById($ticket_id) {
        try {
            $sql = "SELECT t.*, u.username, u.email, u.full_name 
                    FROM tickets t
                    JOIN users u ON t.user_id = u.id
                    WHERE t.id = :ticket_id";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':ticket_id', $ticket_id);
            $stmt->execute();
            
            $ticket = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$ticket) {
                return false;
            }
            
            // جلب الردود
            $ticket['replies'] = $this->getTicketReplies($ticket_id);
            
            // جلب المرفقات
            $ticket['attachments'] = $this->getTicketAttachments($ticket_id);
            
            return $ticket;
        } catch (Exception $e) {
            logError('TicketModel::getTicketById - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على قائمة تذاكر المستخدم
     * 
     * @param int $user_id معرف المستخدم
     * @param array $filters مرشحات للبحث
     * @param int $page رقم الصفحة
     * @param int $limit عدد العناصر في الصفحة
     * @return array قائمة التذاكر
     */
    public function getUserTickets($user_id, $filters = [], $page = 1, $limit = 10) {
        try {
            $offset = ($page - 1) * $limit;
            
            // بناء استعلام SQL
            $sql = "SELECT t.*, u.username, u.full_name 
                    FROM tickets t
                    JOIN users u ON t.user_id = u.id
                    WHERE t.user_id = :user_id";
            
            $params = [':user_id' => $user_id];
            
            // إضافة المرشحات
            if (!empty($filters['status'])) {
                if ($filters['status'] !== 'all') {
                    $sql .= " AND t.status = :status";
                    $params[':status'] = $filters['status'];
                }
            }
            
            if (!empty($filters['department'])) {
                $sql .= " AND t.department = :department";
                $params[':department'] = $filters['department'];
            }
            
            if (!empty($filters['priority'])) {
                $sql .= " AND t.priority = :priority";
                $params[':priority'] = $filters['priority'];
            }
            
            if (!empty($filters['search'])) {
                $sql .= " AND (t.subject LIKE :search OR t.message LIKE :search)";
                $params[':search'] = '%' . $filters['search'] . '%';
            }
            
            // إضافة الترتيب والحد
            $sql .= " ORDER BY t.created_at DESC LIMIT :limit OFFSET :offset";
            
            $stmt = $this->db->prepare($sql);
            
            // ربط المعلمات
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('TicketModel::getUserTickets - ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * الحصول على عدد تذاكر المستخدم (للترقيم)
     * 
     * @param int $user_id معرف المستخدم
     * @param array $filters مرشحات للبحث
     * @return int عدد التذاكر
     */
    public function countUserTickets($user_id, $filters = []) {
        try {
            // بناء استعلام SQL
            $sql = "SELECT COUNT(*) as total FROM tickets WHERE user_id = :user_id";
            
            $params = [':user_id' => $user_id];
            
            // إضافة المرشحات
            if (!empty($filters['status'])) {
                if ($filters['status'] !== 'all') {
                    $sql .= " AND status = :status";
                    $params[':status'] = $filters['status'];
                }
            }
            
            if (!empty($filters['department'])) {
                $sql .= " AND department = :department";
                $params[':department'] = $filters['department'];
            }
            
            if (!empty($filters['priority'])) {
                $sql .= " AND priority = :priority";
                $params[':priority'] = $filters['priority'];
            }
            
            if (!empty($filters['search'])) {
                $sql .= " AND (subject LIKE :search OR message LIKE :search)";
                $params[':search'] = '%' . $filters['search'] . '%';
            }
            
            $stmt = $this->db->prepare($sql);
            
            // ربط المعلمات
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            return $result['total'];
        } catch (Exception $e) {
            logError('TicketModel::countUserTickets - ' . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * إضافة رد جديد على تذكرة
     * 
     * @param array $data بيانات الرد
     * @return int|bool معرف الرد إذا نجح أو false إذا فشل
     */
    public function addReply($data) {
        try {
            $sql = "INSERT INTO ticket_replies (ticket_id, user_id, message, is_admin, created_at) 
                    VALUES (:ticket_id, :user_id, :message, :is_admin, NOW())";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':ticket_id', $data['ticket_id']);
            $stmt->bindParam(':user_id', $data['user_id']);
            $stmt->bindParam(':message', $data['message']);
            $stmt->bindParam(':is_admin', $data['is_admin']);
            $stmt->execute();
            
            $reply_id = $this->db->lastInsertId();
            
            // تحديث حالة التذكرة
            if ($data['is_admin']) {
                $this->updateTicketStatus($data['ticket_id'], 'answered');
            } else {
                $this->updateTicketStatus($data['ticket_id'], 'customer_reply');
            }
            
            // تحديث وقت التحديث
            $this->updateTicketTimestamp($data['ticket_id']);
            
            // إذا كانت هناك مرفقات
            if (!empty($data['attachments'])) {
                foreach ($data['attachments'] as $attachment) {
                    $this->addAttachment($data['ticket_id'], $attachment);
                }
            }
            
            return $reply_id;
        } catch (Exception $e) {
            logError('TicketModel::addReply - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على ردود تذكرة
     * 
     * @param int $ticket_id معرف التذكرة
     * @return array قائمة الردود
     */
    public function getTicketReplies($ticket_id) {
        try {
            $sql = "SELECT r.*, u.username, u.full_name, u.avatar 
                    FROM ticket_replies r
                    JOIN users u ON r.user_id = u.id
                    WHERE r.ticket_id = :ticket_id
                    ORDER BY r.created_at ASC";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':ticket_id', $ticket_id);
            $stmt->execute();
            
            $replies = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // جلب المرفقات لكل رد
            foreach ($replies as &$reply) {
                $reply['attachments'] = $this->getReplyAttachments($reply['id']);
            }
            
            return $replies;
        } catch (Exception $e) {
            logError('TicketModel::getTicketReplies - ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * إضافة مرفق للتذكرة
     * 
     * @param int $ticket_id معرف التذكرة
     * @param array $attachment بيانات المرفق
     * @return int|bool معرف المرفق إذا نجح أو false إذا فشل
     */
    public function addAttachment($ticket_id, $attachment) {
        try {
            $sql = "INSERT INTO ticket_attachments (ticket_id, reply_id, file_name, file_path, file_size, file_type, created_at) 
                    VALUES (:ticket_id, :reply_id, :file_name, :file_path, :file_size, :file_type, NOW())";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':ticket_id', $ticket_id);
            $stmt->bindParam(':reply_id', $attachment['reply_id']);
            $stmt->bindParam(':file_name', $attachment['file_name']);
            $stmt->bindParam(':file_path', $attachment['file_path']);
            $stmt->bindParam(':file_size', $attachment['file_size']);
            $stmt->bindParam(':file_type', $attachment['file_type']);
            $stmt->execute();
            
            return $this->db->lastInsertId();
        } catch (Exception $e) {
            logError('TicketModel::addAttachment - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على مرفقات التذكرة
     * 
     * @param int $ticket_id معرف التذكرة
     * @return array قائمة المرفقات
     */
    public function getTicketAttachments($ticket_id) {
        try {
            $sql = "SELECT * FROM ticket_attachments 
                    WHERE ticket_id = :ticket_id AND reply_id IS NULL
                    ORDER BY created_at ASC";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':ticket_id', $ticket_id);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('TicketModel::getTicketAttachments - ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * الحصول على مرفقات الرد
     * 
     * @param int $reply_id معرف الرد
     * @return array قائمة المرفقات
     */
    public function getReplyAttachments($reply_id) {
        try {
            $sql = "SELECT * FROM ticket_attachments 
                    WHERE reply_id = :reply_id
                    ORDER BY created_at ASC";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':reply_id', $reply_id);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('TicketModel::getReplyAttachments - ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * تحديث حالة التذكرة
     * 
     * @param int $ticket_id معرف التذكرة
     * @param string $status الحالة الجديدة
     * @return bool نجاح أو فشل العملية
     */
    public function updateTicketStatus($ticket_id, $status) {
        try {
            $sql = "UPDATE tickets SET status = :status WHERE id = :ticket_id";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':status', $status);
            $stmt->bindParam(':ticket_id', $ticket_id);
            
            return $stmt->execute();
        } catch (Exception $e) {
            logError('TicketModel::updateTicketStatus - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * تحديث وقت تعديل التذكرة
     * 
     * @param int $ticket_id معرف التذكرة
     * @return bool نجاح أو فشل العملية
     */
    public function updateTicketTimestamp($ticket_id) {
        try {
            $sql = "UPDATE tickets SET updated_at = NOW() WHERE id = :ticket_id";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':ticket_id', $ticket_id);
            
            return $stmt->execute();
        } catch (Exception $e) {
            logError('TicketModel::updateTicketTimestamp - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * إغلاق تذكرة
     * 
     * @param int $ticket_id معرف التذكرة
     * @return bool نجاح أو فشل العملية
     */
    public function closeTicket($ticket_id) {
        try {
            $sql = "UPDATE tickets SET status = 'closed', updated_at = NOW() WHERE id = :ticket_id";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':ticket_id', $ticket_id);
            
            return $stmt->execute();
        } catch (Exception $e) {
            logError('TicketModel::closeTicket - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * إعادة فتح تذكرة
     * 
     * @param int $ticket_id معرف التذكرة
     * @return bool نجاح أو فشل العملية
     */
    public function reopenTicket($ticket_id) {
        try {
            $sql = "UPDATE tickets SET status = 'open', updated_at = NOW() WHERE id = :ticket_id";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':ticket_id', $ticket_id);
            
            return $stmt->execute();
        } catch (Exception $e) {
            logError('TicketModel::reopenTicket - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على أقسام التذاكر
     * 
     * @return array قائمة الأقسام
     */
    public function getTicketDepartments() {
        try {
            $sql = "SELECT * FROM ticket_departments WHERE status = 'active' ORDER BY name";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('TicketModel::getTicketDepartments - ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * الحصول على عدد التذاكر غير المقروءة للمستخدم
     * 
     * @param int $user_id معرف المستخدم
     * @return int عدد التذاكر غير المقروءة
     */
    public function countUnreadTickets($user_id) {
        try {
            $sql = "SELECT COUNT(*) as total FROM tickets 
                    WHERE user_id = :user_id AND status = 'answered' AND is_read = 0";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();
            
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            return $result['total'];
        } catch (Exception $e) {
            logError('TicketModel::countUnreadTickets - ' . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * تحديث حالة قراءة التذكرة
     * 
     * @param int $ticket_id معرف التذكرة
     * @param int $is_read حالة القراءة (0 أو 1)
     * @return bool نجاح أو فشل العملية
     */
    public function updateTicketReadStatus($ticket_id, $is_read) {
        try {
            $sql = "UPDATE tickets SET is_read = :is_read WHERE id = :ticket_id";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':is_read', $is_read, PDO::PARAM_INT);
            $stmt->bindParam(':ticket_id', $ticket_id);
            
            return $stmt->execute();
        } catch (Exception $e) {
            logError('TicketModel::updateTicketReadStatus - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * البحث عن تذاكر
     * 
     * @param string $query نص البحث
     * @param int $user_id معرف المستخدم (اختياري للبحث في تذاكر مستخدم محدد)
     * @param int $limit الحد الأقصى للنتائج
     * @return array نتائج البحث
     */
    public function searchTickets($query, $user_id = null, $limit = 10) {
        try {
            $sql = "SELECT t.*, u.username, u.full_name 
                    FROM tickets t
                    JOIN users u ON t.user_id = u.id
                    WHERE (t.subject LIKE :query OR t.message LIKE :query)";
            
            $params = [':query' => '%' . $query . '%'];
            
            if ($user_id) {
                $sql .= " AND t.user_id = :user_id";
                $params[':user_id'] = $user_id;
            }
            
            $sql .= " ORDER BY t.created_at DESC LIMIT :limit";
            
            $stmt = $this->db->prepare($sql);
            
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            logError('TicketModel::searchTickets - ' . $e->getMessage());
            return [];
        }
    }
}
