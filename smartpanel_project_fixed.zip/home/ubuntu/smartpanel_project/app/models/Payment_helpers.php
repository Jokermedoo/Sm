<?php
/**
 * وظائف مساعدة لنظام الدفع
 * Helper functions for payment system
 */

/**
 * حساب رسوم المعاملة
 * Calculate transaction fee
 * 
 * @param float $amount المبلغ الأساسي
 * @param string $gateway بوابة الدفع
 * @return float
 */
function calculatePaymentFee($amount, $gateway, $config) {
    if (!isset($config['gateways'][$gateway])) {
        return 0;
    }
    
    $gateway_config = $config['gateways'][$gateway];
    $fee_percentage = $gateway_config['fee'] ?? 0;
    
    // حساب الرسوم
    $fee = round($amount * $fee_percentage, 2);
    
    // التحقق من الحد الأدنى للرسوم إذا كان محددًا
    if (isset($gateway_config['min_fee']) && $fee < $gateway_config['min_fee']) {
        $fee = $gateway_config['min_fee'];
    }
    
    return $fee;
}

/**
 * إنشاء معرف فريد للمعاملة
 * Generate unique transaction ID
 * 
 * @return string
 */
function generateTransactionId() {
    $prefix = 'TXN';
    $timestamp = time();
    $random = bin2hex(random_bytes(4));
    
    return $prefix . $timestamp . $random;
}

/**
 * إنشاء رمز أمان للمعاملة
 * Generate security token for transaction
 * 
 * @return string
 */
function generateSecurityToken() {
    return bin2hex(random_bytes(16));
}

/**
 * تشفير البيانات الحساسة
 * Encrypt sensitive data
 * 
 * @param string $data البيانات للتشفير
 * @param array $config معلومات التشفير
 * @return string البيانات المشفرة
 */
function encryptPaymentData($data, $config) {
    $method = $config['encryption']['method'] ?? 'AES-256-CBC';
    $key = $config['encryption']['key'] ?? 'default-key';
    $iv = $config['encryption']['iv'] ?? substr(md5(time()), 0, 16);
    
    return openssl_encrypt($data, $method, $key, 0, $iv);
}

/**
 * فك تشفير البيانات
 * Decrypt data
 * 
 * @param string $encrypted_data البيانات المشفرة
 * @param array $config معلومات التشفير
 * @return string البيانات الأصلية
 */
function decryptPaymentData($encrypted_data, $config) {
    $method = $config['encryption']['method'] ?? 'AES-256-CBC';
    $key = $config['encryption']['key'] ?? 'default-key';
    $iv = $config['encryption']['iv'] ?? substr(md5(time()), 0, 16);
    
    return openssl_decrypt($encrypted_data, $method, $key, 0, $iv);
}

/**
 * تحويل حالة المعاملة إلى نص مقروء
 * Convert transaction status to readable text
 * 
 * @param string $status رمز الحالة
 * @return string النص المقروء
 */
function getPaymentStatusText($status) {
    $statuses = [
        PAYMENT_STATUS_PENDING => 'بانتظار المعالجة',
        PAYMENT_STATUS_PROCESSING => 'قيد المعالجة',
        PAYMENT_STATUS_COMPLETED => 'تمت بنجاح',
        PAYMENT_STATUS_FAILED => 'فشلت',
        PAYMENT_STATUS_CANCELLED => 'ملغاة',
        PAYMENT_STATUS_REFUNDED => 'تم استرداد المبلغ'
    ];
    
    return $statuses[$status] ?? 'غير معروفة';
}

/**
 * تسجيل عملية الدفع في ملف السجل
 * Log payment operation
 * 
 * @param string $level مستوى السجل (info, warning, error)
 * @param string $message الرسالة
 * @param array $context بيانات إضافية
 */
function logPaymentOperation($level, $message, $context = []) {
    $log_file = ROOT_PATH . '/logs/payments_' . date('Y-m-d') . '.log';
    
    $timestamp = date('Y-m-d H:i:s');
    $context_json = json_encode($context, JSON_UNESCAPED_UNICODE);
    
    $log_entry = "[$timestamp] [$level] $message $context_json" . PHP_EOL;
    
    file_put_contents($log_file, $log_entry, FILE_APPEND);
}
