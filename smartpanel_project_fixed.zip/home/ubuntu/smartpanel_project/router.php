<?php
// تكوين الخطأ وتسجيل الدخول
error_reporting(E_ALL);
ini_set('display_errors', 1);

// المسار الأساسي للتطبيق
define('BASE_PATH', __DIR__);

// التحقق من الملفات الثابتة في المجلد public
$request_uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$public_path = __DIR__ . '/public' . $request_uri;

// إذا كان الملف موجوداً في المجلد public، قم بتقديمه مباشرة
if (is_file($public_path)) {
    // تعيين نوع المحتوى المناسب
    $ext = pathinfo($public_path, PATHINFO_EXTENSION);
    switch ($ext) {
        case 'css':
            header('Content-Type: text/css');
            break;
        case 'js':
            header('Content-Type: application/javascript');
            break;
        case 'jpg':
        case 'jpeg':
            header('Content-Type: image/jpeg');
            break;
        case 'png':
            header('Content-Type: image/png');
            break;
    }
    readfile($public_path);
    return true;
}

// إذا لم يكن ملفاً ثابتاً، قم بتوجيه الطلب إلى index.php
require __DIR__ . '/index.php';