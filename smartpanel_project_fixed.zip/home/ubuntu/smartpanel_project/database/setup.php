l<?php
/**
 * ملف إعداد قاعدة الِِِشششبيانات
 * يقوم بإنشاء قاعدة البيانات وجميع الجداول المطلوبة
 */

// استيراد ملف التكوين
require_once '../config/config.php';

try {
    // الاتصال بقاعدة البيانات MySQL بدون تحديد اسم قاعدة البيانات
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );

    // إنشاء قاعدة البيانات إذا لم تكن موجودة
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    echo "تم إنشاء قاعدة البيانات بنجاح.<br>";

    // اختيار قاعدة البيانات
    $pdo->exec("USE `" . DB_NAME . "`");

    // قراءة ملف schema.sql
    $sql = file_get_contents(__DIR__ . '/schema.sql');
    
    // تجاهل الأسطر الخاصة بإنشاء قاعدة البيانات واختيارها
    $sql = preg_replace('/CREATE DATABASE.*?;/s', '', $sql);
    $sql = preg_replace('/USE.*?;/s', '', $sql);

    // تنفيذ الاستعلامات
    $statements = explode(';', $sql);
    foreach ($statements as $statement) {
        $statement = trim($statement);
        if (!empty($statement)) {
            $pdo->exec($statement);
        }
    }

    echo "تم إنشاء جميع الجداول بنجاح.<br>";
    echo "تم إعداد قاعدة البيانات بالكامل.";

} catch (PDOException $e) {
    die("خطأ في إعداد قاعدة البيانات: " . $e->getMessage());
}