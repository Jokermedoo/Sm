-- Town Media SMM Panel - Database Schema (Updated May 31, 2025)
-- Create database
CREATE DATABASE IF NOT EXISTS sm_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE sm_system;

-- Users table
CREATE TABLE users (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL, -- Hashed password
    full_name VARCHAR(100),
    balance DECIMAL(10, 2) NOT NULL DEFAULT 0.00, -- User account balance (Added NOT NULL constraint)
    api_key VARCHAR(64) UNIQUE, -- For API access
    role ENUM('admin', 'user', 'reseller') DEFAULT 'user' NOT NULL,
    status ENUM('active', 'suspended', 'banned') DEFAULT 'active' NOT NULL, -- Added NOT NULL constraint
    phone VARCHAR(30), -- Increased length for international numbers
    country VARCHAR(50),
    city VARCHAR(50),
    address TEXT,
    profile_image VARCHAR(255),
    email_verified TINYINT(1) DEFAULT 0 NOT NULL, -- Added NOT NULL constraint
    remember_token VARCHAR(100),
    last_login_at TIMESTAMP NULL,
    last_login_ip VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_api_key (api_key),
    INDEX idx_role (role),
    INDEX idx_status (status)
    -- Consider adding CHECK constraint: CHECK (balance >= 0)
) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Categories table (for services)
CREATE TABLE categories (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    icon VARCHAR(50),
    sort_order INT DEFAULT 0 NOT NULL, -- Added NOT NULL constraint
    status ENUM('active', 'inactive') DEFAULT 'active' NOT NULL, -- Added NOT NULL constraint
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_sort_order (sort_order)
) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Services table
CREATE TABLE services (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    category_id BIGINT UNSIGNED NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    min_quantity INT UNSIGNED NOT NULL DEFAULT 1, -- Changed to UNSIGNED
    max_quantity INT UNSIGNED NOT NULL DEFAULT 1000, -- Changed to UNSIGNED
    service_type ENUM('default', 'custom', 'api', 'subscription') DEFAULT 'default' NOT NULL, -- Added NOT NULL constraint
    api_provider_id BIGINT UNSIGNED NULL, -- NULL if not from external API
    api_service_id VARCHAR(50) NULL, -- External API service ID
    status ENUM('active', 'inactive') DEFAULT 'active' NOT NULL, -- Added NOT NULL constraint
    sort_order INT DEFAULT 0 NOT NULL, -- Added NOT NULL constraint
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT, -- Changed from CASCADE to RESTRICT (safer default)
    INDEX idx_title (title),
    INDEX idx_status (status),
    INDEX idx_category (category_id),
    INDEX idx_api_provider (api_provider_id)
    -- Consider adding CHECK constraints: CHECK (price >= 0), CHECK (min_quantity > 0), CHECK (max_quantity >= min_quantity)
) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Orders table
CREATE TABLE orders (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    service_id BIGINT UNSIGNED NOT NULL,
    link VARCHAR(1024) NOT NULL, -- Increased length for potentially long URLs
    quantity INT UNSIGNED NOT NULL, -- Changed to UNSIGNED
    price DECIMAL(10, 2) NOT NULL, -- Price at time of order
    status ENUM('pending', 'processing', 'completed', 'canceled', 'failed', 'partial') DEFAULT 'pending' NOT NULL, -- Added NOT NULL constraint
    start_counter INT UNSIGNED DEFAULT 0, -- Changed to UNSIGNED
    remains INT UNSIGNED DEFAULT 0, -- Changed to UNSIGNED
    api_order_id VARCHAR(100) NULL, -- Increased length for potentially longer IDs
    api_provider_id BIGINT UNSIGNED NULL, -- If ordered through external API
    notes TEXT, -- Admin notes
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    -- REVIEW: ON DELETE CASCADE for user_id might lead to data loss. Consider ON DELETE RESTRICT or implementing soft deletes.
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    -- REVIEW: ON DELETE CASCADE for service_id might lead to data loss if a service is deleted. Consider ON DELETE RESTRICT.
    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE,
    INDEX idx_user (user_id),
    INDEX idx_service (service_id),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at),
    INDEX idx_api_order (api_order_id) -- Added index for API order ID lookup
    -- Consider adding CHECK constraints: CHECK (quantity > 0), CHECK (price >= 0)
) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Transactions table (for payments and refunds)
CREATE TABLE transactions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    amount DECIMAL(10, 2) NOT NULL, -- Positive for deposits/refunds, can be negative for adjustments?
    type ENUM('deposit', 'order', 'refund', 'adjustment') NOT NULL,
    status ENUM('pending', 'completed', 'failed', 'canceled') DEFAULT 'pending' NOT NULL, -- Added NOT NULL constraint
    description TEXT,
    payment_method VARCHAR(50) NULL, -- PayPal, Stripe, etc.
    transaction_id VARCHAR(100) NULL, -- External transaction ID
    order_id BIGINT UNSIGNED NULL, -- If related to an order
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    -- REVIEW: ON DELETE CASCADE for user_id might lead to data loss. Consider ON DELETE RESTRICT or implementing soft deletes.
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    -- Added Foreign Key for order_id, setting to NULL if the order is deleted
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL,
    INDEX idx_user (user_id),
    INDEX idx_type (type),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at),
    INDEX idx_order (order_id), -- Added index for order ID lookup
    INDEX idx_transaction (transaction_id) -- Added index for external transaction ID lookup
    -- Consider adding CHECK constraint: CHECK (type = 'order' AND amount <= 0 OR type != 'order' AND amount >= 0)
) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- API Providers table
CREATE TABLE api_providers (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    url VARCHAR(255) NOT NULL,
    api_key VARCHAR(255) NOT NULL,
    balance DECIMAL(10, 2) DEFAULT 0.00 NOT NULL, -- Added NOT NULL constraint
    currency VARCHAR(10) DEFAULT 'USD' NOT NULL, -- Added NOT NULL constraint
    status ENUM('active', 'inactive') DEFAULT 'active' NOT NULL, -- Added NOT NULL constraint
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status)
) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Tickets table (for support)
CREATE TABLE tickets (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    subject VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    status ENUM('open', 'answered', 'closed', 'user_reply') DEFAULT 'open' NOT NULL, -- Added NOT NULL constraint
    priority ENUM('low', 'medium', 'high') DEFAULT 'medium' NOT NULL, -- Added NOT NULL constraint
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    -- REVIEW: ON DELETE CASCADE for user_id might lead to data loss. Consider ON DELETE RESTRICT or implementing soft deletes.
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user (user_id),
    INDEX idx_status (status)
) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Ticket Replies table
CREATE TABLE ticket_replies (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ticket_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE, -- Cascade delete for replies seems reasonable
    -- REVIEW: ON DELETE CASCADE for user_id might lead to data loss. Consider ON DELETE RESTRICT or implementing soft deletes.
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_ticket (ticket_id)
) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Settings table (for system settings)
CREATE TABLE settings (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    value TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_name (name)
) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Payment Methods table
CREATE TABLE payment_methods (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    instructions TEXT,
    min_amount DECIMAL(10, 2) DEFAULT 0 NOT NULL, -- Added NOT NULL constraint
    max_amount DECIMAL(10, 2) DEFAULT 0 NOT NULL, -- Added NOT NULL constraint
    fixed_fee DECIMAL(10, 2) DEFAULT 0 NOT NULL, -- Added NOT NULL constraint
    percentage_fee DECIMAL(5, 2) DEFAULT 0 NOT NULL, -- Added NOT NULL constraint
    api_details TEXT, -- JSON with API credentials
    status ENUM('active', 'inactive') DEFAULT 'active' NOT NULL, -- Added NOT NULL constraint
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status)
    -- Consider adding CHECK constraints: CHECK (min_amount >= 0), CHECK (max_amount >= min_amount), CHECK (fixed_fee >= 0), CHECK (percentage_fee >= 0)
) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Posts table (for blog)
CREATE TABLE posts (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    content TEXT NOT NULL,
    published_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    -- REVIEW: ON DELETE CASCADE for user_id might lead to data loss. Consider ON DELETE RESTRICT or implementing soft deletes.
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_slug (slug),
    INDEX idx_published_at (published_at)
) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Contacts table (for contact form submissions)
CREATE TABLE contacts (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- FAQs table
CREATE TABLE faqs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    question VARCHAR(255) NOT NULL,
    answer TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

