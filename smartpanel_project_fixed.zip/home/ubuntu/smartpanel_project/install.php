<?php
/**
 * أداة تثبيت نظام SMM Panel - الإصدار المحسن
 * تساعد في إعداد النظام والتحقق من المتطلبات.
 * 
 * تاريخ التحديث: 31-05-2025
 * التحسينات:
 * - الاعتماد على .env و config.php المحسّن.
 * - استخدام Composer Autoloader.
 * - استيراد مخطط قاعدة البيانات بدلاً من الإنشاء اليدوي.
 * - استخدام Security class لتجزئة كلمة مرور المسؤول.
 * - تحسين واجهة المستخدم والتحقق من الأخطاء.
 * - إضافة PHPDoc وتوثيق أفضل.
 */

declare(strict_types=1);

// --- الإعدادات الأولية والتحقق من التثبيت ---

// مسار ملف القفل للإشارة إلى أن التثبيت قد تم
$lockFile = __DIR__ . 
'/config/installed.lock
';

if (file_exists($lockFile)) {
    http_response_code(403);
    die(
'النظام مثبت بالفعل! إذا كنت ترغب في إعادة التثبيت، قم بحذف ملف 
' . basename($lockFile) . 
' من مجلد 
'config
' أولاً، مع العلم أن هذا قد يؤدي إلى فقدان البيانات إذا لم يتم التعامل معه بحذر.
');
}

// --- المتغيرات والخطوات ---

$step = isset($_GET[
'step
']) ? (int)$_GET[
'step
'] : 1;
$errors = [];
$successMessage = 
'';
$config = []; // سيتم تحميل الإعدادات لاحقًا

// --- التحقق من المتطلبات الأساسية (قبل تحميل أي شيء آخر) ---

$requirements = [];
$allRequirementsMet = true;

// 1. إصدار PHP
$phpVersionOk = version_compare(PHP_VERSION, 
'7.4.0
', 
'>=
');
$requirements[
'PHP Version
'] = [
    
'required
' => 
'7.4.0+
',
    
'current
' => PHP_VERSION,
    
'status
' => $phpVersionOk
];
if (!$phpVersionOk) $allRequirementsMet = false;

// 2. Composer Autoloader
$autoloaderPath = __DIR__ . 
'/vendor/autoload.php
';
$autoloaderOk = file_exists($autoloaderPath);
$requirements[
'Composer Autoloader
'] = [
    
'required
' => 
'موجود (vendor/autoload.php)
',
    
'current
' => $autoloaderOk ? 
'موجود
' : 
'غير موجود
',
    
'status
' => $autoloaderOk,
    
'notes
' => $autoloaderOk ? 
'' : 
'يرجى تشغيل `composer install` في مجلد المشروع.
'
];
if (!$autoloaderOk) $allRequirementsMet = false;

// 3. الإضافات المطلوبة
$requiredExtensions = [
'pdo
', 
'pdo_mysql
', 
'mbstring
', 
'json
', 
'curl
', 
'openssl
', 
'gd
'];
foreach ($requiredExtensions as $ext) {
    $loaded = extension_loaded($ext);
    $requirements[
"PHP Extension: {$ext}
"] = [
        
'required
' => 
'مفعلة
',
        
'current
' => $loaded ? 
'مفعلة
' : 
'غير مفعلة
',
        
'status
' => $loaded
    ];
    if (!$loaded) $allRequirementsMet = false;
}

// 4. صلاحيات الكتابة للمجلدات (تعتمد على تعريف المسارات لاحقًا)
$writableDirs = [
    
'Config Directory
' => __DIR__ . 
'/config
',
    
'Storage Directory
' => __DIR__ . 
'/storage
',
    
'Logs Directory
' => __DIR__ . 
'/storage/logs
',
    
'Cache Directory
' => __DIR__ . 
'/storage/cache
',
    
'Uploads Directory
' => __DIR__ . 
'/public/uploads
' // تأكد من أن هذا المسار صحيح
];

foreach ($writableDirs as $name => $dir) {
    $isWritable = false;
    $dirExists = is_dir($dir);
    if ($dirExists) {
        $isWritable = is_writable($dir);
    } else {
        // محاولة إنشاء المجلد
        if (@mkdir($dir, 0755, true)) {
            $isWritable = is_writable($dir);
            // إضافة ملف .gitignore لمنع تتبع الملفات داخل المجلدات التي تم إنشاؤها حديثًا
            if ($name !== 
'Config Directory
' && !file_exists($dir . 
'/.gitignore
')) {
                @file_put_contents($dir . 
'/.gitignore
', 
"*\n!.gitignore\n");
            }
        } else {
             $isWritable = false; // فشل الإنشاء
        }
    }
    $requirements[$name] = [
        
'required
' => 
'قابل للكتابة
',
        
'current
' => $isWritable ? 
'قابل للكتابة
' : (
$dirExists ? 
'غير قابل للكتابة
' : 
'غير موجود وفشل الإنشاء
'),
        
'status
' => $isWritable
    ];
    if (!$isWritable) $allRequirementsMet = false;
}

// --- تحميل الاعتماديات والإعدادات إذا تم تجاوز فحص المتطلبات ---

if ($step > 1 && $autoloaderOk) {
    require_once $autoloaderPath;
    try {
        // تحميل ملف التكوين الذي بدوره يحمل .env
        require_once __DIR__ . 
'/config/config.php
';
        // تحميل فئة الأمان (إذا لم يتم تحميلها تلقائيًا)
        // require_once __DIR__ . 
'/includes/security.php
'; 
        // $security = new Security(); // إنشاء كائن الأمان إذا لزم الأمر
    } catch (\Throwable $e) {
        // خطأ فادح أثناء تحميل الإعدادات
        $errors[] = 
'خطأ فادح في تحميل الإعدادات: 
' . $e->getMessage() . 
' - تأكد من وجود ملف .env وصلاحيات المجلدات.
';
        $step = 1; // العودة للخطوة الأولى
    }
}

// --- معالجة خطوات التثبيت (POST requests) ---

if ($_SERVER[
'REQUEST_METHOD
'] === 
'POST
' && empty($errors)) {
    // التحقق من CSRF (مثال بسيط، يمكن تحسينه)
    if (!isset($_POST[
'csrf_token
']) || !isset($_SESSION[
'installer_csrf_token
']) || !hash_equals($_SESSION[
'installer_csrf_token
'], $_POST[
'csrf_token
'])) {
        $errors[] = 
'خطأ في التحقق من CSRF. يرجى تحديث الصفحة والمحاولة مرة أخرى.
';
    } else {
        // إزالة التوكن بعد التحقق
        unset($_SESSION[
'installer_csrf_token
']);

        switch ($step) {
            case 1:
                // تم التحقق من المتطلبات، الانتقال للخطوة التالية
                if ($allRequirementsMet) {
                    $step = 2;
                } else {
                    $errors[] = 
'لا يمكن المتابعة، يرجى تلبية جميع متطلبات النظام أولاً.
';
                }
                break;

            case 2: // إعداد قاعدة البيانات
                $dbHost = trim($_POST[
'db_host
'] ?? 
''
);
                $dbName = trim($_POST[
'db_name
'] ?? 
''
);
                $dbUser = trim($_POST[
'db_user
'] ?? 
''
);
                $dbPass = $_POST[
'db_pass
'] ?? 
''
; // كلمة المرور يمكن أن تكون فارغة

                if (empty($dbHost) || empty($dbName) || empty($dbUser)) {
                    $errors[] = 
'الرجاء ملء جميع حقول قاعدة البيانات (المضيف، الاسم، المستخدم).
';
                } else {
                    try {
                        // 1. محاولة الاتصال بالخادم (بدون تحديد قاعدة بيانات)
                        $dsn = 
"mysql:host={$dbHost};charset=utf8mb4"
;
                        $options = [
                            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                            PDO::ATTR_EMULATE_PREPARES => false,
                        ];
                        $pdo = new PDO($dsn, $dbUser, $dbPass, $options);

                        // 2. محاولة إنشاء قاعدة البيانات إذا لم تكن موجودة
                        $pdo->exec(
"CREATE DATABASE IF NOT EXISTS `{$dbName}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
);
                        
                        // 3. إعادة الاتصال مع تحديد قاعدة البيانات
                        $dsn = 
"mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4"
;
                        $pdo = new PDO($dsn, $dbUser, $dbPass, $options);
                        $pdo->exec(
"USE `{$dbName}`"
);

                        // 4. تحديث ملف .env
                        $envPath = __DIR__ . 
'/.env
';
                        if (!file_exists($envPath)) {
                            if (!copy(__DIR__ . 
'/.env.example
', $envPath)) {
                                throw new Exception(
'فشل في نسخ ملف .env.example إلى .env
');
                            }
                        }
                        $envContent = file_get_contents($envPath);

                        // استخدام preg_replace لتحديث القيم الموجودة أو إضافتها إذا لم تكن موجودة
                        $updates = [
                            
'DB_HOST
' => $dbHost,
                            
'DB_PORT
' => 
'3306
', // افترض المنفذ الافتراضي
                            
'DB_DATABASE
' => $dbName,
                            
'DB_USERNAME
' => $dbUser,
                            
'DB_PASSWORD
' => $dbPass, // قد تحتاج إلى تغليف القيمة بعلامات اقتباس إذا كانت تحتوي على رموز خاصة
                        ];

                        foreach ($updates as $key => $value) {
                            if (preg_match(
"/^({$key}=)(.*)$/m"
, $envContent)) {
                                $envContent = preg_replace(
"/^({$key}=)(.*)$/m"
, 
"\1{$value}"
, $envContent);
                            } else {
                                $envContent .= 
"\n{$key}={$value}"
; // إضافة المتغير إذا لم يكن موجودًا
                            }
                        }

                        if (file_put_contents($envPath, $envContent) === false) {
                            throw new Exception(
'فشل في كتابة إعدادات قاعدة البيانات إلى ملف .env
');
                        }

                        // 5. استيراد مخطط قاعدة البيانات
                        $schemaPath = __DIR__ . 
'/database/schema.sql
';
                        if (!file_exists($schemaPath)) {
                            throw new Exception(
'ملف مخطط قاعدة البيانات (database/schema.sql) غير موجود.
');
                        }
                        $sql = file_get_contents($schemaPath);
                        if ($sql === false) {
                             throw new Exception(
'فشل في قراءة ملف مخطط قاعدة البيانات.
');
                        }
                        // تنفيذ جمل SQL (قد تحتاج إلى تقسيمها إذا كانت كبيرة جدًا أو تحتوي على محددات مختلفة)
                        $pdo->exec($sql);

                        $step = 3; // الانتقال للخطوة التالية

                    } catch (PDOException $e) {
                        $errors[] = 
'خطأ في الاتصال أو إعداد قاعدة البيانات: 
' . $e->getMessage();
                    } catch (Exception $e) {
                        $errors[] = 
'خطأ عام: 
' . $e->getMessage();
                    }
                }
                break;

            case 3: // إعداد الموقع والمسؤول
                $siteUrl = filter_var(trim($_POST[
'site_url
'] ?? 
''
), FILTER_VALIDATE_URL);
                $siteName = htmlspecialchars(trim($_POST[
'site_name
'] ?? 
''
), ENT_QUOTES, 
'UTF-8
');
                $adminEmail = filter_var(trim($_POST[
'admin_email
'] ?? 
''
), FILTER_VALIDATE_EMAIL);
                $adminPassword = $_POST[
'admin_password
'] ?? 
''
;

                if (!$siteUrl || empty($siteName) || !$adminEmail || empty($adminPassword)) {
                    $errors[] = 
'الرجاء ملء جميع حقول معلومات الموقع والمسؤول بشكل صحيح (رابط صالح، اسم، بريد إلكتروني صالح، كلمة مرور).
';
                } elseif (strlen($adminPassword) < 8) {
                     $errors[] = 
'كلمة مرور المسؤول يجب أن تكون 8 أحرف على الأقل.
';
                } else {
                    try {
                        // 1. تحديث ملف .env بمعلومات الموقع
                        $envPath = __DIR__ . 
'/.env
';
                        $envContent = file_get_contents($envPath);
                        if ($envContent === false) {
                            throw new Exception(
'فشل في قراءة ملف .env لتحديث معلومات الموقع.
');
                        }

                        $updates = [
                            
'APP_URL
' => $siteUrl,
                            
'APP_NAME
' => 
"\"{$siteName}\"
", // إضافة علامات اقتباس للاسم
                            
'MAIL_FROM_ADDRESS
' => $adminEmail, // استخدام بريد المسؤول كبريد افتراضي للإرسال
                            
'MAIL_FROM_NAME
' => 
"\"{$siteName}\"
",
                            
'APP_KEY
' => 
'base64:
' . base64_encode(random_bytes(32)) // إنشاء مفتاح تطبيق آمن
                        ];

                        foreach ($updates as $key => $value) {
                             if (preg_match(
"/^({$key}=)(.*)$/m"
, $envContent)) {
                                $envContent = preg_replace(
"/^({$key}=)(.*)$/m"
, 
"\1{$value}"
, $envContent);
                            } else {
                                $envContent .= 
"\n{$key}={$value}"
;
                            }
                        }
                        
                        if (file_put_contents($envPath, $envContent) === false) {
                            throw new Exception(
'فشل في كتابة معلومات الموقع إلى ملف .env
');
                        }

                        // 2. إنشاء حساب المسؤول
                        // إعادة تحميل الإعدادات بعد تحديث .env (قد لا يكون ضروريًا إذا لم نستخدم الثوابت هنا)
                        // require __DIR__ . 
'/config/config.php
'; 
                        
                        // الاتصال بقاعدة البيانات (قراءة الإعدادات المحدثة من .env)
                        $dbHost = getenv(
'DB_HOST
');
                        $dbName = getenv(
'DB_DATABASE
');
                        $dbUser = getenv(
'DB_USERNAME
');
                        $dbPass = getenv(
'DB_PASSWORD
');
                        
                        $dsn = 
"mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4"
;
                        $options = [
                            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                            PDO::ATTR_EMULATE_PREPARES => false,
                        ];
                        $pdo = new PDO($dsn, $dbUser, $dbPass, $options);

                        // التحقق من وجود المسؤول بالفعل
                        $stmt = $pdo->prepare(
"SELECT id FROM users WHERE email = :email OR username = 'admin' LIMIT 1"
);
                        $stmt->execute([
':email
' => $adminEmail]);
                        $existingAdmin = $stmt->fetch();

                        if (!$existingAdmin) {
                            // استخدام فئة الأمان لتجزئة كلمة المرور
                            // تأكد من أن فئة Security متاحة عبر Autoloader
                            $security = new \includes\Security(); // أو App\Includes\Security حسب الـ namespace
                            $hashedPassword = $security->hashPassword($adminPassword);
                            
                            $stmt = $pdo->prepare(
"INSERT INTO users (username, email, password, role, status, created_at) VALUES (:username, :email, :password, 'admin', 'active', NOW())"
);
                            $stmt->execute([
                                
':username
' => 
'admin
',
                                
':email
' => $adminEmail,
                                
':password
' => $hashedPassword
                            ]);
                        } else {
                            // يمكن تحديث كلمة مرور المسؤول الموجود إذا لزم الأمر
                            // $security = new \includes\Security();
                            // $hashedPassword = $security->hashPassword($adminPassword);
                            // $stmt = $pdo->prepare("UPDATE users SET password = :password WHERE id = :id");
                            // $stmt->execute([':password' => $hashedPassword, ':id' => $existingAdmin['id']]);
                            $errors[] = 
'تنبيه: حساب المسؤول (admin) أو البريد الإلكتروني المحدد موجود بالفعل. لم يتم إنشاء حساب جديد.
';
                        }

                        // 3. إنشاء ملف القفل
                        if (file_put_contents($lockFile, date(
'Y-m-d H:i:s
')) === false) {
                            throw new Exception(
'فشل في إنشاء ملف القفل لمنع إعادة التثبيت.
');
                        }

                        $successMessage = 
'تم تثبيت النظام بنجاح!
';
                        $step = 4; // الانتقال لصفحة النهاية

                    } catch (PDOException $e) {
                        $errors[] = 
'خطأ في قاعدة البيانات أثناء إنشاء حساب المسؤول: 
' . $e->getMessage();
                    } catch (Exception $e) {
                        $errors[] = 
'خطأ عام: 
' . $e->getMessage();
                    }
                }
                break;
        }
    }
}

// --- إنشاء توكن CSRF للجلسة الحالية ---
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (empty($_SESSION[
'installer_csrf_token
'])) {
    $_SESSION[
'installer_csrf_token
'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION[
'installer_csrf_token
'];

// --- عرض HTML ---
?>
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تثبيت نظام SMM Panel</title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Cairo', sans-serif;
            line-height: 1.7;
            color: #34495e;
            margin: 0;
            padding: 20px;
            background-color: #ecf0f1;
            direction: rtl;
        }
        .container {
            max-width: 850px;
            margin: 30px auto;
            padding: 30px;
            background: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            border-top: 5px solid #3498db;
        }
        h1, h2 {
            color: #2c3e50;
            margin-top: 0;
            padding-bottom: 15px;
            border-bottom: 1px solid #e0e0e0;
            margin-bottom: 25px;
        }
        h1 {
            text-align: center;
            font-size: 2em;
        }
        h2 {
            font-size: 1.5em;
            display: flex;
            align-items: center;
        }
        .step-number {
            display: inline-flex; /* Use flex for centering */
            justify-content: center; /* Center horizontally */
            align-items: center; /* Center vertically */
            width: 35px;
            height: 35px;
            background-color: #3498db;
            color: white;
            border-radius: 50%;
            font-size: 1.1em;
            font-weight: bold;
            margin-left: 15px; /* Changed from margin-right */
            flex-shrink: 0; /* Prevent shrinking */
        }
        .requirement, .alert {
            margin-bottom: 15px;
            padding: 15px;
            border-radius: 6px;
            border-left: 4px solid;
        }
        .requirement strong, .alert strong {
            display: block;
            margin-bottom: 5px;
        }
        .requirement.met {
            background-color: #e8f5e9;
            color: #2e7d32;
            border-left-color: #4caf50;
        }
        .requirement.not-met {
            background-color: #ffebee;
            color: #c62828;
            border-left-color: #f44336;
        }
        .requirement .notes {
            font-size: 0.9em;
            color: #555;
            margin-top: 5px;
        }
        .alert-danger {
            background-color: #ffebee;
            color: #c62828;
            border-left-color: #f44336;
        }
        .alert-success {
            background-color: #e8f5e9;
            color: #2e7d32;
            border-left-color: #4caf50;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #555;
        }
        input[type="text"], input[type="password"], input[type="email"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #bdc3c7;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 1em;
            transition: border-color 0.3s ease;
        }
        input[type="text"]:focus, input[type="password"]:focus, input[type="email"]:focus {
            border-color: #3498db;
            outline: none;
        }
        .form-group small {
            display: block;
            margin-top: 5px;
            color: #7f8c8d;
            font-size: 0.9em;
        }
        button {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1.1em;
            transition: background-color 0.3s ease;
            display: inline-block;
        }
        button:hover {
            background-color: #2980b9;
        }
        button:disabled {
            background-color: #bdc3c7;
            cursor: not-allowed;
        }
        .final-links a {
            display: inline-block;
            margin: 10px;
            padding: 10px 20px;
            background-color: #2ecc71;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .final-links a:hover {
            background-color: #27ae60;
        }
        ul {
            padding-right: 20px; /* Adjust padding for RTL */
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>تثبيت نظام SMM Panel</h1>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <strong>حدث خطأ!</strong>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if (!empty($successMessage)): ?>
            <div class="alert alert-success">
                <strong><?php echo htmlspecialchars($successMessage, ENT_QUOTES, 'UTF-8'); ?></strong>
            </div>
        <?php endif; ?>

        <?php // --- عرض الخطوات --- ?>

        <?php if ($step === 1): ?>
            <div class="step">
                <h2><span class="step-number">1</span> التحقق من متطلبات النظام</h2>
                <?php foreach ($requirements as $name => $req): ?>
                    <div class="requirement <?php echo $req['status'] ? 'met' : 'not-met'; ?>">
                        <strong><?php echo htmlspecialchars($name, ENT_QUOTES, 'UTF-8'); ?>:</strong>
                        <span><?php echo htmlspecialchars($req['current'], ENT_QUOTES, 'UTF-8'); ?></span>
                        <?php if (!$req['status']): ?>
                            <span style="font-weight:normal;">(المطلوب: <?php echo htmlspecialchars($req['required'], ENT_QUOTES, 'UTF-8'); ?>)</span>
                            <?php if (!empty($req['notes'])): ?>
                                <div class="notes"><?php echo htmlspecialchars($req['notes'], ENT_QUOTES, 'UTF-8'); ?></div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>

                <form method="post" action="?step=1">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                    <button type="submit" <?php echo !$allRequirementsMet ? 'disabled' : ''; ?>>
                        <?php echo $allRequirementsMet ? 'المتابعة إلى إعداد قاعدة البيانات' : 'يرجى تلبية جميع المتطلبات أولاً'; ?>
                    </button>
                </form>
            </div>

        <?php elseif ($step === 2): ?>
            <div class="step">
                <h2><span class="step-number">2</span> إعداد قاعدة البيانات</h2>
                <p>سيقوم المثبّت بمحاولة إنشاء قاعدة البيانات المحددة إذا لم تكن موجودة واستيراد الجداول اللازمة.</p>
                <form method="post" action="?step=2">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                    <div class="form-group">
                        <label for="db_host">مضيف قاعدة البيانات:</label>
                        <input type="text" id="db_host" name="db_host" value="<?php echo htmlspecialchars($_POST['db_host'] ?? '127.0.0.1', ENT_QUOTES); ?>" required>
                        <small>عادةً يكون '127.0.0.1' أو 'localhost'.</small>
                    </div>
                    <div class="form-group">
                        <label for="db_name">اسم قاعدة البيانات:</label>
                        <input type="text" id="db_name" name="db_name" value="<?php echo htmlspecialchars($_POST['db_name'] ?? 'smm_panel', ENT_QUOTES); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="db_user">اسم مستخدم قاعدة البيانات:</label>
                        <input type="text" id="db_user" name="db_user" value="<?php echo htmlspecialchars($_POST['db_user'] ?? '', ENT_QUOTES); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="db_pass">كلمة مرور قاعدة البيانات:</label>
                        <input type="password" id="db_pass" name="db_pass">
                        <small>(اتركه فارغًا إذا لم تكن هناك كلمة مرور)</small>
                    </div>
                    <button type="submit">المتابعة إلى إعداد الموقع</button>
                </form>
            </div>

        <?php elseif ($step === 3): ?>
            <div class="step">
                <h2><span class="step-number">3</span> إعداد الموقع وحساب المسؤول</h2>
                <form method="post" action="?step=3">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                    <div class="form-group">
                        <label for="site_url">رابط الموقع (URL):</label>
                        <input type="text" id="site_url" name="site_url" value="<?php echo htmlspecialchars($_POST['site_url'] ?? ('http' . (isset($_SERVER['HTTPS']) ? 's' : '') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost')), ENT_QUOTES); ?>" required>
                        <small>الرابط الكامل لموقعك، مثال: https://yourdomain.com</small>
                    </div>
                    <div class="form-group">
                        <label for="site_name">اسم الموقع:</label>
                        <input type="text" id="site_name" name="site_name" value="<?php echo htmlspecialchars($_POST['site_name'] ?? 'SmartPanel SMM', ENT_QUOTES); ?>" required>
                    </div>
                    <hr style="margin: 25px 0; border: none; border-top: 1px solid #e0e0e0;">
                    <h4>حساب المسؤول الرئيسي</h4>
                    <div class="form-group">
                        <label for="admin_email">البريد الإلكتروني للمسؤول:</label>
                        <input type="email" id="admin_email" name="admin_email" value="<?php echo htmlspecialchars($_POST['admin_email'] ?? '', ENT_QUOTES); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="admin_password">كلمة مرور المسؤول:</label>
                        <input type="password" id="admin_password" name="admin_password" required>
                        <small>يجب أن تكون 8 أحرف على الأقل.</small>
                    </div>
                    <button type="submit">إنهاء التثبيت</button>
                </form>
            </div>

        <?php elseif ($step === 4): ?>
            <div class="step">
                <h2><span class="step-number">4</span> اكتمل التثبيت!</h2>
                <p>تهانينا! تم تثبيت نظام SMM Panel بنجاح.</p>
                <p><strong>معلومات الدخول للمسؤول:</strong></p>
                <ul>
                    <li>اسم المستخدم: <strong>admin</strong></li>
                    <li>كلمة المرور: <strong>(الكلمة التي أدخلتها في الخطوة السابقة)</strong></li>
                </ul>
                <p><strong>هام:</strong> لأسباب أمنية، يوصى بشدة بحذف ملف <code>install.php</code> الآن.</p>
                <div class="final-links">
                    <a href="<?php echo htmlspecialchars(getenv('APP_URL') ?: './', ENT_QUOTES); ?>" target="_blank">الانتقال إلى واجهة الموقع</a>
                    <a href="<?php echo htmlspecialchars(getenv('APP_URL') ?: './', ENT_QUOTES) . '/admin'; // افترض أن رابط لوحة التحكم هو /admin ?>" target="_blank">الانتقال إلى لوحة التحكم</a>
                </div>
            </div>
        <?php endif; ?>

    </div>
</body>
</html>

