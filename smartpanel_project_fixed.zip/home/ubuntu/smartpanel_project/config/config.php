<?php
/**
 * ملف التكوين الرئيسي
 * يحتوي على الإعدادات الأساسية للتطبيق
 * 
 * تم تحسينه بتاريخ: 31-05-2025
 * - الاعتماد الكامل على المتغيرات البيئية من ملف .env للبيانات الحساسة
 * - إزالة تعريف الثوابت للبيانات الحساسة (البريد، API)
 */

// تحميل المتغيرات البيئية أولاً
require_once __DIR__ . '/env.php';

// --- إعدادات عامة --- 

// استخدام getenv() لجلب القيم من .env أو توفير قيمة افتراضية
define('APP_NAME', getenv('APP_NAME') ?: 'SmartPanel SMM');
define('APP_DEBUG', filter_var(getenv('APP_DEBUG') ?: false, FILTER_VALIDATE_BOOLEAN));
define('APP_URL', getenv('APP_URL') ?: 'http://localhost');
define('SITE_DESCRIPTION', getenv('SITE_DESCRIPTION') ?: 'منصة متكاملة لخدمات وسائل التواصل الاجتماعي');

// --- المسارات --- 
// (يجب التأكد من أن paths.php يعمل بشكل صحيح أو دمج المسارات هنا إذا لزم الأمر)
// افتراض أن paths.php أو التحميل التلقائي يعالج هذا
// إذا لم يكن كذلك، يجب تعريف المسارات هنا باستخدام getenv('ROOT_PATH') أو __DIR__
define('ROOT_PATH', dirname(__DIR__)); // المسار الجذر للمشروع
define('APP_PATH', ROOT_PATH . '/app');
define('CONFIG_PATH', ROOT_PATH . '/config');
define('PUBLIC_PATH', ROOT_PATH . '/public');
define('STORAGE_PATH', ROOT_PATH . '/storage');
define('LOGS_PATH', STORAGE_PATH . '/logs');
define('CACHE_PATH', STORAGE_PATH . '/cache'); // تم تغيير المسار ليكون داخل storage
define('UPLOADS_PATH', PUBLIC_PATH . '/uploads'); // يفضل وضع التحميلات داخل public إذا كانت ستُخدم مباشرة

// --- اللغة والتوقيت --- 
define('DEFAULT_LANG', getenv('DEFAULT_LANG') ?: 'ar');
define('DEFAULT_TIMEZONE', getenv('DEFAULT_TIMEZONE') ?: 'UTC');
date_default_timezone_set(DEFAULT_TIMEZONE);

// --- إعدادات الأمان --- 
define('APP_KEY', getenv('APP_KEY') ?: ''); // مفتاح التطبيق يجب أن يكون في .env
define('HASH_COST', 12);
define('SESSION_NAME', getenv('SESSION_NAME') ?: 'smm_session');
define('CSRF_TOKEN_NAME', 'csrf_token');
define('SESSION_LIFETIME', (int)(getenv('SESSION_LIFETIME') ?: 3600)); // 60 دقيقة افتراضي
define('MAX_LOGIN_ATTEMPTS', (int)(getenv('MAX_LOGIN_ATTEMPTS') ?: 5));
define('LOGIN_TIMEOUT', (int)(getenv('LOGIN_TIMEOUT') ?: 900)); // 15 دقيقة افتراضي

// --- إعدادات التطبيق --- 
define('ITEMS_PER_PAGE', 20);
define('MAINTENANCE_MODE', filter_var(getenv('MAINTENANCE_MODE') ?: false, FILTER_VALIDATE_BOOLEAN));
define('MAX_UPLOAD_SIZE', 2097152); // 2MB
define('ALLOWED_FILE_TYPES', json_encode(['jpg', 'jpeg', 'png', 'gif'])); // يمكن نقلها لـ .env إذا لزم الأمر

// --- إعدادات البريد الإلكتروني --- 
// لا يتم تعريف ثوابت هنا، يجب استخدام getenv() مباشرة في كود إرسال البريد
// مثال:
// $mailHost = getenv('MAIL_HOST');
// $mailUser = getenv('MAIL_USER');
// ... إلخ

// --- إعدادات API لمزودي الخدمات --- 
// لا يتم تعريف ثوابت هنا، يجب استخدام getenv('API_PROVIDERS_JSON') وتحليلها عند الحاجة
// مثال:
// $apiProvidersJson = getenv('API_PROVIDERS_JSON');
// $apiProviders = json_decode($apiProvidersJson, true);

// --- إعدادات كلمة المرور --- 
define('PASSWORD_MIN_LENGTH', 8);
define('PASSWORD_REQUIRE_SPECIAL', true);
define('PASSWORD_REQUIRE_NUMBERS', true);
define('PASSWORD_REQUIRE_UPPERCASE', true);
define('PASSWORD_REQUIRE_LOWERCASE', true);

// --- إعدادات التخزين المؤقت --- 
define('CACHE_ENABLED', filter_var(getenv('CACHE_ENABLED') ?: true, FILTER_VALIDATE_BOOLEAN));
define('CACHE_LIFETIME', (int)(getenv('CACHE_LIFETIME') ?: 3600)); // ساعة واحدة افتراضي

// --- إعدادات السجلات --- 
define('LOG_LEVEL', getenv('LOG_LEVEL') ?: 'error'); // error, warning, info, debug
define('LOG_ROTATION', 7); // عدد أيام الاحتفاظ بالسجلات

// --- التحقق من وجود مفتاح التطبيق --- 
if (empty(APP_KEY)) {
    // يمكنك رمي استثناء أو إيقاف التطبيق هنا إذا كان المفتاح إلزاميًا
    // throw new Exception('APP_KEY is not set in the .env file.');
    // أو تسجيل تحذير
    error_log('Warning: APP_KEY is not set in the .env file. This is required for security features.');
}

// --- التأكد من وجود المجلدات المطلوبة --- 
$required_dirs = [STORAGE_PATH, LOGS_PATH, CACHE_PATH, UPLOADS_PATH];
foreach ($required_dirs as $dir) {
    if (!is_dir($dir)) {
        // محاولة إنشاء المجلد
        if (!mkdir($dir, 0755, true) && !is_dir($dir)) { // التحقق مرة أخرى بعد الإنشاء
            throw new RuntimeException(sprintf('Directory "%s" was not created', $dir));
        }
    }
    // التحقق من قابلية الكتابة
    if (!is_writable($dir)) {
        throw new RuntimeException(sprintf('Directory "%s" is not writable', $dir));
    }
}


