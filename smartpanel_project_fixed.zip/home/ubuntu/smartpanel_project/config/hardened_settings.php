<?php
/**
 * إعدادات أمان مشددة للنظام
 */

declare(strict_types=1);
error_reporting(0);
ini_set('session.cookie_httponly', '1');
ini_set('session.cookie_samesite', 'Strict');
header_remove('X-Powered-By');

// إعدادات المنطقة الزمنية السعودية
date_default_timezone_set('Asia/Riyadh');

// تعطيل عرض الأخطاء في الإنتاج
ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('error_log', __DIR__.'/../storage/logs/php_errors.log');
