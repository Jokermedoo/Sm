<?php
/**
 * ملف إعدادات المسارات المحسّن
 * إصدار محسّن من نظام المسارات يوفر مزيداً من المرونة والأمان
 * تاريخ التحديث: 30-05-2025
 */

// استخدام المسار المطلق للمشروع مع دعم مختلف أنظمة التشغيل
$root_path = str_replace('\\', '/', dirname(__DIR__));
define('ROOT_PATH', $root_path);

// المسارات الرئيسية للمشروع - بصيغة موحدة مع دعم جميع أنظمة التشغيل
define('CONFIG_PATH', ROOT_PATH . '/config');
define('APP_PATH', ROOT_PATH . '/app');
define('INCLUDES_PATH', ROOT_PATH . '/includes');
define('PUBLIC_PATH', ROOT_PATH . '/public');
define('VIEWS_PATH', APP_PATH . '/views');
define('CACHE_PATH', ROOT_PATH . '/cache');
define('LOGS_PATH', ROOT_PATH . '/logs');
define('UPLOADS_PATH', ROOT_PATH . '/uploads');
define('ASSETS_PATH', ROOT_PATH . '/assets');
define('STORAGE_PATH', ROOT_PATH . '/storage');

// مسارات متجر SMM - منظمة ومرتبة
define('SMM_STORE_PATH', ROOT_PATH . '/smm-store');
define('SMM_STORE_APP_PATH', SMM_STORE_PATH . '/app');
define('SMM_STORE_PUBLIC_PATH', SMM_STORE_PATH . '/public');
define('SMM_STORE_VIEWS_PATH', SMM_STORE_PATH . '/views');
define('SMM_STORE_CONFIG_PATH', SMM_STORE_PATH . '/config');

// مسارات خاصة بالمكونات - تنظيم أفضل للمسارات
define('CONTROLLERS_PATH', APP_PATH . '/controllers');
define('MODELS_PATH', APP_PATH . '/models');
define('CORE_PATH', APP_PATH . '/core');
define('MODULES_PATH', APP_PATH . '/modules');
define('HELPERS_PATH', APP_PATH . '/helpers');

// مسارات ملفات النظام الأساسية
define('SECURITY_PATH', INCLUDES_PATH . '/security.php');
define('SECURITY_HELPERS_PATH', INCLUDES_PATH . '/security_helpers.php');
define('SESSION_MANAGER_PATH', CORE_PATH . '/SessionManager.php');
define('HARDENED_SETTINGS_PATH', CONFIG_PATH . '/hardened_settings.php');

// مسارات الخدمات وبوابات الدفع - منظمة بشكل أفضل
define('PAYMENT_CORE_PATH', CORE_PATH . '/PaymentProcessor.php');
define('PAYMENT_MODEL_PATH', MODELS_PATH . '/Payment.php');
define('PAYMENT_HELPERS_PATH', MODELS_PATH . '/Payment_helpers.php');
define('UNIFIED_PAYMENT_PATH', CORE_PATH . '/UnifiedPaymentSystem.php');
define('SERVICE_API_PATH', CORE_PATH . '/ServiceAPI.php');

// مسارات الوصول العام (URLs) - تعريف مركزي لمسارات الوصول
$protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https://' : 'http://';
$host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
define('BASE_URL', $protocol . $host);
define('ASSETS_URL', BASE_URL . '/assets');
define('UPLOADS_URL', BASE_URL . '/uploads');
define('API_URL', BASE_URL . '/api');
define('ADMIN_URL', BASE_URL . '/admin');
define('DASHBOARD_URL', BASE_URL . '/dashboard');

// مسارات المجلدات المؤقتة وملفات السجلات
define('TEMP_PATH', ROOT_PATH . '/storage/temp');
define('BACKUP_PATH', ROOT_PATH . '/storage/backup');
define('ERROR_LOGS_PATH', LOGS_PATH . '/errors');
define('SECURITY_LOGS_PATH', LOGS_PATH . '/security');
define('PAYMENT_LOGS_PATH', LOGS_PATH . '/payments');
define('API_LOGS_PATH', LOGS_PATH . '/api');

/**
 * دالة محسّنة للحصول على مسار مطلق من مسار نسبي
 * تدعم مختلف أنظمة التشغيل وتعالج الحالات الخاصة
 * 
 * @param string $relativePath المسار النسبي
 * @param string $basePath المسار الأساسي (اختياري، الافتراضي هو مسار المشروع)
 * @return string المسار المطلق
 */
function getAbsolutePath($relativePath, $basePath = ROOT_PATH) {
    // تنسيق المسار لدعم مختلف أنظمة التشغيل
    $relativePath = str_replace('\\', '/', $relativePath);
    $basePath = str_replace('\\', '/', $basePath);
    
    // إزالة الشرطة من بداية المسار النسبي إذا وُجدت
    $relativePath = ltrim($relativePath, '/');
    
    // التأكد من وجود الشرطة في نهاية المسار الأساسي
    $basePath = rtrim($basePath, '/') . '/';
    
    // دمج المسار الأساسي مع المسار النسبي
    return $basePath . $relativePath;
}

/**
 * دالة جديدة للحصول على المسار النسبي من مسار مطلق
 * مفيدة للعرض أو التخزين
 * 
 * @param string $absolutePath المسار المطلق
 * @param string $basePath المسار الأساسي (اختياري، الافتراضي هو مسار المشروع)
 * @return string المسار النسبي
 */
function getRelativePath($absolutePath, $basePath = ROOT_PATH) {
    // تنسيق المسار لدعم مختلف أنظمة التشغيل
    $absolutePath = str_replace('\\', '/', $absolutePath);
    $basePath = str_replace('\\', '/', $basePath);
    
    // التأكد من وجود الشرطة في نهاية المسار الأساسي
    $basePath = rtrim($basePath, '/') . '/';
    
    // إذا كان المسار المطلق يبدأ بالمسار الأساسي، قم بإزالته
    if (strpos($absolutePath, $basePath) === 0) {
        return substr($absolutePath, strlen($basePath));
    }
    
    // إذا لم يكن المسار المطلق يبدأ بالمسار الأساسي، أعد المسار المطلق كما هو
    return $absolutePath;
}

/**
 * دالة جديدة للتحقق من وجود وإمكانية الوصول للمسار
 * 
 * @param string $path المسار المراد التحقق منه
 * @return bool هل المسار موجود ويمكن الوصول إليه
 */
function isPathAccessible($path) {
    return file_exists($path) && is_readable($path);
}

/**
 * دالة جديدة لإنشاء مسار إذا لم يكن موجوداً
 * 
 * @param string $path المسار المراد إنشاؤه
 * @param int $permissions صلاحيات المجلد (اختياري)
 * @return bool نجاح أو فشل العملية
 */
function createPathIfNotExists($path, $permissions = 0755) {
    if (!file_exists($path)) {
        return mkdir($path, $permissions, true);
    }
    return true;
}

/**
 * دالة جديدة للحصول على مسار URL من مسار ملف
 * 
 * @param string $filePath مسار الملف
 * @return string مسار URL للملف
 */
function getUrlFromFilePath($filePath) {
    $relativePath = getRelativePath($filePath, PUBLIC_PATH);
    return BASE_URL . '/' . $relativePath;
}

// إنشاء المجلدات الأساسية إذا لم تكن موجودة
$directories = [
    LOGS_PATH,
    CACHE_PATH,
    UPLOADS_PATH,
    TEMP_PATH,
    BACKUP_PATH,
    ERROR_LOGS_PATH,
    SECURITY_LOGS_PATH,
    PAYMENT_LOGS_PATH,
    API_LOGS_PATH
];

foreach ($directories as $dir) {
    createPathIfNotExists($dir);
}
