<?php
/**
 * ملف إعدادات المسارات المركزي
 * يحدد جميع المسارات الثابتة للمشروع لتجنب تعارضات المسارات
 */

// المسارات الرئيسية للمشروع
define('ROOT_PATH', dirname(__DIR__));
define('CONFIG_PATH', ROOT_PATH . '/config');
define('APP_PATH', ROOT_PATH . '/app');
define('INCLUDES_PATH', ROOT_PATH . '/includes');
define('PUBLIC_PATH', ROOT_PATH . '/public');
define('VIEWS_PATH', APP_PATH . '/views');
define('CACHE_PATH', ROOT_PATH . '/cache');
define('LOGS_PATH', ROOT_PATH . '/logs');
define('UPLOADS_PATH', ROOT_PATH . '/uploads');
define('ASSETS_PATH', ROOT_PATH . '/assets');

// مسارات متجر SMM
define('SMM_STORE_PATH', ROOT_PATH . '/smm-store');
define('SMM_STORE_APP_PATH', SMM_STORE_PATH . '/app');
define('SMM_STORE_PUBLIC_PATH', SMM_STORE_PATH . '/public');
define('SMM_STORE_VIEWS_PATH', SMM_STORE_PATH . '/views');

// مسارات خاصة بالمكونات
define('CONTROLLERS_PATH', APP_PATH . '/controllers');
define('MODELS_PATH', APP_PATH . '/models');
define('CORE_PATH', APP_PATH . '/core');
define('MODULES_PATH', APP_PATH . '/modules');

// مسارات الخدمات وبوابات الدفع
define('PAYMENT_PATH', SMM_STORE_APP_PATH . '/core/Payment.php');
define('SERVICE_API_PATH', SMM_STORE_APP_PATH . '/core/ServiceAPI.php');

// مسارات ملفات النظام الأساسية
define('SECURITY_PATH', INCLUDES_PATH . '/security.php');
define('SECURITY_HELPERS_PATH', INCLUDES_PATH . '/security_helpers.php');
define('SESSION_MANAGER_PATH', CORE_PATH . '/SessionManager.php');
define('HARDENED_SETTINGS_PATH', CONFIG_PATH . '/hardened_settings.php');

/**
 * دالة مساعدة للحصول على مسار مطلق من مسار نسبي
 * 
 * @param string $relativePath المسار النسبي
 * @return string المسار المطلق
 */
function getAbsolutePath($relativePath) {
    // إذا كان المسار يبدأ بـ / فهو مسار نسبي للمجلد الرئيسي
    if (strpos($relativePath, '/') === 0) {
        return ROOT_PATH . $relativePath;
    }
    
    // وإلا فهو مسار نسبي للمجلد الحالي
    return dirname(debug_backtrace()[0]['file']) . '/' . $relativePath;
}
