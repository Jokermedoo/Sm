<?php
/**
 * إعدادات الجلسات الآمنة
 */

// مسار تخزين الجلسات خارج مسار الويب
session_save_path('D:/SMM_Panel_PHP/storage/sessions');

// إعدادات أمان الجلسة
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);
ini_set('session.cookie_samesite', 'Strict');

// تشفير الجلسة
ini_set('session.encrypt', 1);

// صلاحيات المجلد
if (!is_dir(session_save_path())) {
    mkdir(session_save_path(), 0700, true);
}
