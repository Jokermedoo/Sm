<?php
/**
 * ملف الوظائف المساعدة
 * يحتوي على الوظائف العامة المستخدمة في التطبيق
 */

/**
 * اتصال بقاعدة البيانات باستخدام PDO
 * @return PDO
 */
function connectDB() {
    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
        ];
        return new PDO($dsn, DB_USER, DB_PASS, $options);
    } catch (PDOException $e) {
        logActivity("خطأ في الاتصال بقاعدة البيانات: " . $e->getMessage(), 'error');
        if (DEBUG_MODE) {
            die("خطأ في الاتصال بقاعدة البيانات: " . $e->getMessage());
        } else {
            die("حدث خطأ في النظام. الرجاء المحاولة لاحقًا أو الاتصال بمسؤول النظام.");
        }
    }
}

/**

 * التحقق من وجود قاعدة البيانات وإنشائها إذا لم تكن موجودة
 * @return bool
 */














































































































































function checkAndCreateDatabase() {
    try {


























































        // الاتصال بالسيرفر بدون تحديد قاعدة البيانات
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
            ]
        );

        // التحقق من وجود قاعدة البيانات
        $stmt = $pdo->query("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '" . DB_NAME . "'");
        $dbExists = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$dbExists) {
            // إنشاء قاعدة البيانات إذا لم تكن موجودة
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            logActivity("تم إنشاء قاعدة البيانات", 'info');

            // الاتصال بقاعدة البيانات الجديدة
            $pdo->exec("USE `" . DB_NAME . "`");

            // استيراد مخطط قاعدة البيانات
            importDatabaseSchema($pdo);

            return true;
        }

        return true;
    } catch (PDOException $e) {
        logActivity("خطأ في إنشاء قاعدة البيانات: " . $e->getMessage(), 'error');
        return false;
    }
}

/**




 * استيراد مخطط قاعدة البيانات من ملف SQL
 * @param PDO $pdo اتصال قاعدة البيانات
 * @return bool
 */

function importDatabaseSchema($pdo) {
    try {




        $schemaFile = ROOT_PATH . '/database/schema.sql';

        if (!file_exists($schemaFile)) {
            logActivity("ملف مخطط قاعدة البيانات غير موجود: " . $schemaFile, 'error');
            return false;
        }
        































        // قراءة ملف المخطط
        $sql = file_get_contents($schemaFile);

        // تجاهل جمل إنشاء قاعدة البيانات واستخدامها
        $sql = preg_replace('/CREATE DATABASE.*?;/s', '', $sql);
        $sql = preg_replace('/USE.*?;/s', '', $sql);

        // تنفيذ كل استعلام على حدة
        $statements = explode(';', $sql);
        foreach ($statements as $statement) {
            $statement = trim($statement);
            if (!empty($statement)) {
                $pdo->exec($statement);
            }
        }

        logActivity("تم استيراد مخطط قاعدة البيانات بنجاح", 'info');
        return true;
    } catch (PDOException $e) {
        logActivity("خطأ في استيراد مخطط قاعدة البيانات: " . $e->getMessage(), 'error');
        return false;
    }
}
/**



 * التحقق من وجود جداول قاعدة البيانات
 * @param array $requiredTables قائمة بأسماء الجداول المطلوبة
 * @return bool
 */




function checkDatabaseTables($requiredTables = []) {
    try {
        $pdo = connectDB();

        // إذا لم يتم تحديد قائمة، استخدم الجداول الأساسية
        if (empty($requiredTables)) {
            $requiredTables = [
                'users', 'categories', 'services', 'orders', 'transactions',
                'payment_methods', 'tickets', 'ticket_replies', 'settings'
            ];
        }
    



        // الحصول على قائمة الجداول الموجودة
        $stmt = $pdo->query("SHOW TABLES");
        $existingTables = $stmt->fetchAll(PDO::FETCH_COLUMN);

        // التحقق من وجود جميع الجداول المطلوبة
        $missingTables = array_diff($requiredTables, $existingTables);

        if (!empty($missingTables)) {
            logActivity("جداول مفقودة في قاعدة البيانات: " . implode(', ', $missingTables), 'warning');
            return false;
        }
    


        return true;
    } catch (PDOException $e) {
        logActivity("خطأ في التحقق من جداول قاعدة البيانات: " . $e->getMessage(), 'error');
        return false;
    }




}
    


/**
 * التحقق من أن المستخدم مسجل الدخول
 * @return bool
 */
function isLoggedIn() {
    if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
        return false;
    }
    


    // التحقق من مدة الجلسة
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > SESSION_LIFETIME)) {
        session_unset();
        session_destroy();
        return false;
    }

    // تحديث وقت آخر نشاط
    $_SESSION['last_activity'] = time();
    return true;
}

/**
 * التحقق من أن المستخدم لديه صلاحيات مسؤول
 * @return bool
 */
function isAdmin() {
    return isLoggedIn() && isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

/**
 * توجيه المستخدم إلى صفحة معينة
 * @param string $url الرابط
 * @return void
 */
function redirect($url) {
    if (!headers_sent()) {
    header("Location: " . $url);
    exit();
    } else {
        echo '<script>window.location.href="' . $url . '";</script>';
        echo '<noscript><meta http-equiv="refresh" content="0;url=' . $url . '"></noscript>';
        exit();
    }
}

/**
 * التحويل الآمن للمدخلات
 * @param string $input النص المدخل
 * @return string
 */
function sanitize($input) {
    if (is_array($input)) {
        return array_map('sanitize', $input);
    }
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * إنشاء رمز CSRF
 * @return string
 */
function generateCsrfToken() {
    if (!isset($_SESSION[CSRF_TOKEN_NAME])) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}

/**
 * التحقق من صحة رمز CSRF
 * @param string $token الرمز المقدم
 * @return bool
 */
function validateCsrfToken($token) {
    if (!isset($_SESSION[CSRF_TOKEN_NAME]) || !hash_equals($_SESSION[CSRF_TOKEN_NAME], $token)) {
        logActivity("محاولة CSRF فاشلة", 'warning');
        return false;
    }
    return true;
}

/**
 * عرض رسالة خطأ
 * @param string $message نص الرسالة
 * @return void
 */
function showError($message) {
    $_SESSION['error_message'] = $message;
}

/**
 * عرض رسالة نجاح
 * @param string $message نص الرسالة
 * @return void
 */
function showSuccess($message) {
    $_SESSION['success_message'] = $message;
}

/**
 * الحصول على رسائل النظام وحذفها بعد العرض
 * @return array
 */
function getMessages() {
    $messages = [
        'error' => isset($_SESSION['error_message']) ? $_SESSION['error_message'] : null,
        'success' => isset($_SESSION['success_message']) ? $_SESSION['success_message'] : null
    ];

    // حذف الرسائل بعد استرجاعها
    unset($_SESSION['error_message']);
    unset($_SESSION['success_message']);

    return $messages;
}

/**
 * تنسيق التاريخ والوقت
 * @param string $date التاريخ بتنسيق قاعدة البيانات
 * @param string $format تنسيق العرض
 * @return string
 */
function formatDate($date, $format = 'd/m/Y H:i') {
    $dateObj = new DateTime($date);
    return $dateObj->format($format);
}

/**
 * تنسيق المبالغ المالية
 * @param float $amount المبلغ
 * @param string $currency العملة
 * @return string
 */
function formatCurrency($amount, $currency = 'EGP') {
    return number_format($amount, 2) . ' ' . $currency;
}

/**
 * تحميل ملف
 * @param array $file معلومات الملف من $_FILES
 * @param string $destination مجلد الوجهة
 * @param array $allowedTypes أنواع الملفات المسموح بها
 * @param int $maxSize الحجم الأقصى بالبايت
 * @return string|bool اسم الملف الجديد أو false في حالة الفشل
 */
function uploadFile($file, $destination, $allowedTypes = null, $maxSize = null) {
    try {
        // استخدام القيم الافتراضية من التكوين إذا لم يتم تحديدها
        $allowedTypes = $allowedTypes ?: json_decode(ALLOWED_FILE_TYPES, true);
        $maxSize = $maxSize ?: MAX_UPLOAD_SIZE;

    // التحقق من وجود خطأ في التحميل
    if ($file['error'] !== UPLOAD_ERR_OK) {
            throw new Exception('خطأ في تحميل الملف: ' . $file['error']);
    }

    // التحقق من حجم الملف
    if ($file['size'] > $maxSize) {
            throw new Exception('حجم الملف يتجاوز الحد المسموح به');
    }

    // التحقق من نوع الملف
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);

    $fileExt = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($fileExt, $allowedTypes)) {
            throw new Exception('نوع الملف غير مسموح به');
        }

        // التحقق من نوع MIME
        $allowedMimes = [
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            'gif' => 'image/gif'
        ];

        if (!isset($allowedMimes[$fileExt]) || $allowedMimes[$fileExt] !== $mimeType) {
            throw new Exception('نوع MIME غير صالح');
    }

    // إنشاء اسم ملف فريد
        $newFilename = uniqid() . '_' . bin2hex(random_bytes(8)) . '.' . $fileExt;
    $uploadPath = $destination . '/' . $newFilename;

        // التأكد من وجود المجلد
        if (!is_dir($destination)) {
            if (!mkdir($destination, 0755, true)) {
                throw new Exception('فشل في إنشاء مجلد التحميل');
            }
        }

    // نقل الملف المؤقت إلى الوجهة النهائية
        if (!move_uploaded_file($file['tmp_name'], $uploadPath)) {
            throw new Exception('فشل في نقل الملف');
        }

        // تعيين الصلاحيات المناسبة
        chmod($uploadPath, 0644);

        return $newFilename;
    } catch (Exception $e) {
        logActivity("خطأ في تحميل الملف: " . $e->getMessage(), 'error');
        return false;
    }
}

/**
 * تسجيل الأحداث في ملف السجل
 * @param string $message الرسالة
 * @param string $level مستوى الحدث (info, warning, error)
 * @return void
 */
function logActivity($message, $level = 'info') {
    try {
        // التحقق من مستوى السجل
        $logLevels = ['debug', 'info', 'warning', 'error'];
        if (!in_array($level, $logLevels) || array_search($level, $logLevels) < array_search(LOG_LEVEL, $logLevels)) {
            return;
        }

        $logFile = LOGS_PATH . '/' . date('Y-m-d') . '.log';
    $timestamp = date('Y-m-d H:i:s');
    $userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'guest';
        $ip = $_SERVER['REMOTE_ADDR'];

        $logMessage = "[$timestamp] [$level] [User: $userId] [IP: $ip] $message" . PHP_EOL;

    // التأكد من وجود مجلد السجلات
        if (!is_dir(LOGS_PATH)) {
            if (!mkdir(LOGS_PATH, 0755, true)) {
                throw new Exception('فشل في إنشاء مجلد السجلات');
    }
        }

        // كتابة السجل
        if (file_put_contents($logFile, $logMessage, FILE_APPEND) === false) {
            throw new Exception('فشل في كتابة السجل');
        }

        // تنظيف السجلات القديمة
        $oldLogs = glob(LOGS_PATH . '/*.log');
        foreach ($oldLogs as $log) {
            if (filemtime($log) < strtotime('-' . LOG_ROTATION . ' days')) {
                unlink($log);
            }
        }
    } catch (Exception $e) {
        error_log("خطأ في تسجيل النشاط: " . $e->getMessage());
    }
}

/**
 * التحقق من قوة كلمة المرور
 * @param string $password كلمة المرور
 * @return array [bool $isValid, string $message]
 */
function validatePassword($password) {
    if (strlen($password) < PASSWORD_MIN_LENGTH) {
        return [false, 'كلمة المرور يجب أن تكون ' . PASSWORD_MIN_LENGTH . ' أحرف على الأقل'];
    }

    if (PASSWORD_REQUIRE_SPECIAL && !preg_match('/[!@#$%^&*()\-_=+{};:,<.>]/', $password)) {
        return [false, 'كلمة المرور يجب أن تحتوي على حرف خاص واحد على الأقل'];
    }

    if (PASSWORD_REQUIRE_NUMBERS && !preg_match('/[0-9]/', $password)) {
        return [false, 'كلمة المرور يجب أن تحتوي على رقم واحد على الأقل'];
    }

    if (PASSWORD_REQUIRE_UPPERCASE && !preg_match('/[A-Z]/', $password)) {
        return [false, 'كلمة المرور يجب أن تحتوي على حرف كبير واحد على الأقل'];
    }

    if (PASSWORD_REQUIRE_LOWERCASE && !preg_match('/[a-z]/', $password)) {
        return [false, 'كلمة المرور يجب أن تحتوي على حرف صغير واحد على الأقل'];
    }

    return [true, 'كلمة المرور صالحة'];