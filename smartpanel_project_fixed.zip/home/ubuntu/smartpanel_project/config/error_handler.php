<?php
/**
 * إعدادات التصحيح والأخطاء
 */

// تعيين منطقة التوقيت
date_default_timezone_set(DEFAULT_TIMEZONE);

// إعدادات عرض الأخطاء
if (DEBUG_MODE) {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
    error_reporting(0);
}

// تعيين معالج الأخطاء المخصص
set_error_handler(function ($errno, $errstr, $errfile, $errline) {
    if (!(error_reporting() & $errno)) {
        return false;
    }
    
    $error = [
        'type' => $errno,
        'message' => $errstr,
        'file' => $errfile,
        'line' => $errline
    ];
    
    // تسجيل الخطأ
    logError(json_encode($error));
    
    if (DEBUG_MODE) {
        throw new ErrorException($errstr, 0, $errno, $errfile, $errline);
    } else {
        // عرض صفحة خطأ للمستخدم
        require_once VIEWS_PATH . '/error.php';
        exit;
    }
});

// تعيين معالج الاستثناءات غير المعالجة
set_exception_handler(function ($exception) {
    $error = [
        'type' => get_class($exception),
        'message' => $exception->getMessage(),
        'file' => $exception->getFile(),
        'line' => $exception->getLine(),
        'trace' => $exception->getTraceAsString()
    ];
    
    // تسجيل الخطأ
    logError(json_encode($error));
    
    if (DEBUG_MODE) {
        throw $exception;
    } else {
        // عرض صفحة خطأ للمستخدم
        require_once VIEWS_PATH . '/error.php';
        exit;
    }
});
