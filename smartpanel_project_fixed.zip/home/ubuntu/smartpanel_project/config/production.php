<?php
/**
 * ملف التكوين للبيئة الإنتاجية على استضافة Hostinger
 * يتم تحميل هذا الملف فقط في بيئة الإنتاج
 */

// معلومات الاتصال بقاعدة البيانات - يجب تغييرها حسب معلومات Hostinger
define('DB_HOST', 'localhost');         // عادة ما تكون localhost على Hostinger
define('DB_USER', 'username_here');     // اسم المستخدم من Hostinger
define('DB_PASS', 'password_here');     // كلمة المرور من Hostinger
define('DB_NAME', 'database_name_here'); // اسم قاعدة البيانات من Hostinger

// إعدادات URL للموقع الحقيقي
define('BASE_URL', 'https://yourdomain.com'); // غير هذا إلى اسم النطاق الخاص بك
define('SITE_NAME', 'Town Media - لوحة خدمات التواصل الاجتماعي');
define('SITE_DESCRIPTION', 'منصة متكاملة لخدمات وسائل التواصل الاجتماعي');

// المجلدات الرئيسية - تكييفها حسب هيكل Hostinger
define('ROOT_PATH', dirname(dirname(__FILE__)));
define('APP_PATH', ROOT_PATH . '/app');
define('CONTROLLERS_PATH', APP_PATH . '/controllers');
define('MODELS_PATH', APP_PATH . '/models');
define('VIEWS_PATH', APP_PATH . '/views');
define('UPLOADS_PATH', ROOT_PATH . '/uploads');
define('ASSETS_PATH', ROOT_PATH . '/assets');
define('LOGS_PATH', ROOT_PATH . '/logs');

// إعدادات الأمان المحسنة للإنتاج
define('HASH_COST', 12);
define('SESSION_NAME', 'smm_session');
define('CSRF_TOKEN_NAME', 'csrf_token');
define('SESSION_LIFETIME', 3600);
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_TIMEOUT', 900);

// تعطيل وضع التصحيح في الإنتاج
define('MAINTENANCE_MODE', false);
define('DEBUG_MODE', false);
define('MAX_UPLOAD_SIZE', 2097152); // 2MB
define('ALLOWED_FILE_TYPES', json_encode(['jpg', 'jpeg', 'png', 'gif']));

// إعدادات البريد الإلكتروني - تحديثها بإعدادات Hostinger
define('MAIL_HOST', 'smtp.hostinger.com'); // أو ما توفره Hostinger
define('MAIL_USER', 'your-email@yourdomain.com');
define('MAIL_PASS', 'your-email-password');
define('MAIL_PORT', 587);
define('MAIL_FROM', 'your-email@yourdomain.com');
define('MAIL_FROM_NAME', 'Town Media');
define('MAIL_SECURE', 'tls');

// إعدادات API لمزودي الخدمات - استخدم نفس المفاتيح من الإعداد المحلي
define('API_PROVIDERS', json_encode([
    'provider1' => [
        'name' => 'Provider 1',
        'url' => 'https://api.provider1.com',
        'key' => 'your-secure-api-key-1',
        'secret' => 'your-secure-api-secret-1'
    ],
    'provider2' => [
        'name' => 'Provider 2',
        'url' => 'https://api.provider2.com',
        'key' => 'your-secure-api-key-2',
        'secret' => 'your-secure-api-secret-2'
    ]
]));

// إعدادات الأمان الإضافية
define('PASSWORD_MIN_LENGTH', 10); // زيادة طول كلمة المرور للإنتاج
define('PASSWORD_REQUIRE_SPECIAL', true);
define('PASSWORD_REQUIRE_NUMBERS', true);
define('PASSWORD_REQUIRE_UPPERCASE', true);
define('PASSWORD_REQUIRE_LOWERCASE', true);

// إعدادات التخزين المؤقت - تفعيل للإنتاج لتحسين الأداء
define('CACHE_ENABLED', true);
define('CACHE_LIFETIME', 3600);
define('CACHE_PATH', ROOT_PATH . '/cache');

// إعدادات السجلات - تعيين لمستوى الخطأ فقط في الإنتاج
define('LOG_LEVEL', 'error');
define('LOG_ROTATION', 14); // زيادة فترة الاحتفاظ بالسجلات
