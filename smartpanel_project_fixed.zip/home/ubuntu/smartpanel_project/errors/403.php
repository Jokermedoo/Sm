<?php
// تعيين رمز الاستجابة HTTP
http_response_code(403);
?>
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>403 - غير مصرح بالوصول</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            direction: rtl;
        }
        .error-container {
            text-align: center;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            padding: 40px;
            max-width: 500px;
            width: 90%;
        }
        h1 {
            font-size: 48px;
            margin: 0;
            color: #e74c3c;
        }
        h2 {
            font-size: 24px;
            margin: 10px 0 20px;
            color: #444;
        }
        p {
            font-size: 16px;
            line-height: 1.6;
            margin-bottom: 20px;
        }
        .btn {
            display: inline-block;
            background-color: #3498db;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 4px;
            font-weight: bold;
            transition: background-color 0.3s;
        }
        .btn:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
    <div class="error-container">
        <h1>403</h1>
        <h2>غير مصرح بالوصول</h2>
        <p>عذراً، لا تملك الصلاحيات اللازمة للوصول إلى هذه الصفحة.</p>
        <p>يرجى التأكد من تسجيل الدخول بالحساب المناسب أو الرجوع إلى الصفحة الرئيسية.</p>
        <a href="/" class="btn">العودة إلى الصفحة الرئيسية</a>
    </div>
</body>
</html>
